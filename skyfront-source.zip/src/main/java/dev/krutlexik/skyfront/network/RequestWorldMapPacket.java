package dev.krutlexik.skyfront.network;

import dev.krutlexik.skyfront.worldmap.WorldMapData;
import dev.krutlexik.skyfront.worldmap.WorldMapScanner;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public class RequestWorldMapPacket implements CustomPacketPayload {
   public static final Type<RequestWorldMapPacket> TYPE = new Type(ResourceLocation.fromNamespaceAndPath("sfw", "RequestWorldMapPacket".toLowerCase()));
   public static final StreamCodec<RegistryFriendlyByteBuf, RequestWorldMapPacket> STREAM_CODEC = StreamCodec.ofMember(
      RequestWorldMapPacket::toBytes, RequestWorldMapPacket::new
   );
   private final int centerX;
   private final int centerZ;
   private final int radius;

   public Type<RequestWorldMapPacket> type() {
      return TYPE;
   }

   public RequestWorldMapPacket(int centerX, int centerZ, int radius) {
      this.centerX = centerX;
      this.centerZ = centerZ;
      this.radius = radius;
   }

   public RequestWorldMapPacket(RegistryFriendlyByteBuf buf) {
      this.centerX = buf.readInt();
      this.centerZ = buf.readInt();
      this.radius = buf.readInt();
   }

   public void toBytes(RegistryFriendlyByteBuf buf) {
      buf.writeInt(this.centerX);
      buf.writeInt(this.centerZ);
      buf.writeInt(this.radius);
   }

   public void handle(IPayloadContext ctx) {
      ctx.enqueueWork(
         () -> {
            ServerPlayer player = (ServerPlayer)ctx.player();
            if (player != null) {
               ServerLevel level = player.serverLevel();
               WorldMapData mapData = WorldMapData.get(level);
               WorldMapScanner scanner = WorldMapScanner.getInstance();
               int radiusChunks = Math.min(Math.max(this.radius, 16), 2048) >> 4;
               int centerChunkX = this.centerX >> 4;
               int centerChunkZ = this.centerZ >> 4;
               int[] grid = mapData.collectSquare(centerChunkX, centerChunkZ, radiusChunks);
               NetworkHandler.sendToPlayer(
                  player,
                  WorldMapPacket.fromGrid(
                     centerChunkX, centerChunkZ, radiusChunks, mapData.isScanComplete(), scanner.getProgress(), scanner.getTotalChunks(), grid
                  )
               );
            }
         }
      );
   }
}
