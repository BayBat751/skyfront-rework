package dev.krutlexik.skyfront.network;

import dev.krutlexik.skyfront.client.gui.ShahedRadarScreen;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public class RadarUpdatePacket implements CustomPacketPayload {
   public static final Type<RadarUpdatePacket> TYPE = new Type(ResourceLocation.fromNamespaceAndPath("sfw", "RadarUpdatePacket".toLowerCase()));
   public static final StreamCodec<RegistryFriendlyByteBuf, RadarUpdatePacket> STREAM_CODEC = StreamCodec.ofMember(
      RadarUpdatePacket::toBytes, RadarUpdatePacket::new
   );
   private final BlockPos radarPos;
   private final int detectRange;
   private final List<Vec3> dronePositions;

   public Type<RadarUpdatePacket> type() {
      return TYPE;
   }

   public RadarUpdatePacket(BlockPos radarPos, int detectRange, List<Vec3> dronePositions) {
      this.radarPos = radarPos;
      this.detectRange = detectRange;
      this.dronePositions = dronePositions;
   }

   public RadarUpdatePacket(RegistryFriendlyByteBuf buf) {
      this.radarPos = buf.readBlockPos();
      this.detectRange = buf.readInt();
      int count = buf.readInt();
      this.dronePositions = new ArrayList<>();

      for (int i = 0; i < count; i++) {
         this.dronePositions.add(new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble()));
      }
   }

   public void toBytes(RegistryFriendlyByteBuf buf) {
      buf.writeBlockPos(this.radarPos);
      buf.writeInt(this.detectRange);
      buf.writeInt(this.dronePositions.size());

      for (Vec3 pos : this.dronePositions) {
         buf.writeDouble(pos.x);
         buf.writeDouble(pos.y);
         buf.writeDouble(pos.z);
      }
   }

   public void handle(IPayloadContext ctx) {
      ctx.enqueueWork(() -> ShahedRadarScreen.updateDronePositions(this.radarPos, this.detectRange, this.dronePositions));
   }
}
