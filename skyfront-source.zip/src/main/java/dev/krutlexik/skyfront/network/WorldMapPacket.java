package dev.krutlexik.skyfront.network;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public class WorldMapPacket implements CustomPacketPayload {
   public static final Type<WorldMapPacket> TYPE = new Type(ResourceLocation.fromNamespaceAndPath("sfw", "worldmappacket"));
   public static final StreamCodec<RegistryFriendlyByteBuf, WorldMapPacket> STREAM_CODEC = StreamCodec.ofMember(WorldMapPacket::toBytes, WorldMapPacket::new);
   private final int centerChunkX;
   private final int centerChunkZ;
   private final int radiusChunks;
   private final boolean scanComplete;
   private final int scanProgress;
   private final int totalChunks;
   private final int[] palette;
   private final byte[] cells;
   private static final int[] QUANTIZE_MASKS = new int[]{16777215, 16711422, 16579836, 16316664, 15790320, 14737632, 12632256, 8421504};

   public Type<WorldMapPacket> type() {
      return TYPE;
   }

   public WorldMapPacket(
      int centerChunkX, int centerChunkZ, int radiusChunks, boolean scanComplete, int scanProgress, int totalChunks, int[] palette, byte[] cells
   ) {
      this.centerChunkX = centerChunkX;
      this.centerChunkZ = centerChunkZ;
      this.radiusChunks = radiusChunks;
      this.scanComplete = scanComplete;
      this.scanProgress = scanProgress;
      this.totalChunks = totalChunks;
      this.palette = palette;
      this.cells = cells;
   }

   public static WorldMapPacket fromGrid(
      int centerChunkX, int centerChunkZ, int radiusChunks, boolean scanComplete, int scanProgress, int totalChunks, int[] grid
   ) {
      for (int mask : QUANTIZE_MASKS) {
         Map<Integer, Integer> indexOf = new HashMap<>();
         int[] palette = new int[256];
         indexOf.put(0, 0);
         int paletteSize = 1;
         byte[] cells = new byte[grid.length];
         boolean overflow = false;

         for (int i = 0; i < grid.length; i++) {
            int color = grid[i] == 0 ? 0 : Math.max(1, grid[i] & mask);
            Integer index = indexOf.get(color);
            if (index == null) {
               if (paletteSize >= 256) {
                  overflow = true;
                  break;
               }

               index = paletteSize;
               palette[paletteSize++] = color;
               indexOf.put(color, index);
            }

            cells[i] = (byte)index.intValue();
         }

         if (!overflow) {
            int[] trimmed = new int[paletteSize];
            System.arraycopy(palette, 0, trimmed, 0, paletteSize);
            return new WorldMapPacket(centerChunkX, centerChunkZ, radiusChunks, scanComplete, scanProgress, totalChunks, trimmed, cells);
         }
      }

      return new WorldMapPacket(centerChunkX, centerChunkZ, radiusChunks, scanComplete, scanProgress, totalChunks, new int[]{0}, new byte[grid.length]);
   }

   public WorldMapPacket(RegistryFriendlyByteBuf buf) {
      this.centerChunkX = buf.readInt();
      this.centerChunkZ = buf.readInt();
      this.radiusChunks = buf.readInt();
      this.scanComplete = buf.readBoolean();
      this.scanProgress = buf.readInt();
      this.totalChunks = buf.readInt();
      int paletteSize = buf.readShort() & '\uffff';
      this.palette = new int[paletteSize];

      for (int i = 0; i < paletteSize; i++) {
         this.palette[i] = buf.readInt();
      }

      this.cells = buf.readByteArray();
   }

   public void toBytes(RegistryFriendlyByteBuf buf) {
      buf.writeInt(this.centerChunkX);
      buf.writeInt(this.centerChunkZ);
      buf.writeInt(this.radiusChunks);
      buf.writeBoolean(this.scanComplete);
      buf.writeInt(this.scanProgress);
      buf.writeInt(this.totalChunks);
      buf.writeShort(this.palette.length);

      for (int color : this.palette) {
         buf.writeInt(color);
      }

      buf.writeByteArray(this.cells);
   }

   public void handle(IPayloadContext ctx) {
      ctx.enqueueWork(() -> ClientPacketHandler.handleWorldMapPacket(this));
   }

   public int[] decodeGrid() {
      int[] grid = new int[this.cells.length];

      for (int i = 0; i < this.cells.length; i++) {
         int index = this.cells[i] & 255;
         grid[i] = index < this.palette.length ? this.palette[index] : 0;
      }

      return grid;
   }

   public int getCenterChunkX() {
      return this.centerChunkX;
   }

   public int getCenterChunkZ() {
      return this.centerChunkZ;
   }

   public int getRadiusChunks() {
      return this.radiusChunks;
   }

   public boolean isScanComplete() {
      return this.scanComplete;
   }

   public int getScanProgress() {
      return this.scanProgress;
   }

   public int getTotalChunks() {
      return this.totalChunks;
   }
}
