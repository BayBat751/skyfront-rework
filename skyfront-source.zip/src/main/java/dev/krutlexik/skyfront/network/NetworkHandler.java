package dev.krutlexik.skyfront.network;

import dev.krutlexik.skyfront.drone.client.DroneClientPayloadHandler;
import dev.krutlexik.skyfront.drone.network.DroneDropPayload;
import dev.krutlexik.skyfront.drone.network.DroneInputPayload;
import dev.krutlexik.skyfront.drone.network.DroneLinkPayload;
import dev.krutlexik.skyfront.drone.network.DroneRamPayload;
import dev.krutlexik.skyfront.drone.network.DroneSelfDestructPayload;
import dev.krutlexik.skyfront.drone.network.DroneServerPayloadHandler;
import dev.krutlexik.skyfront.drone.network.DroneStatePayload;
import dev.krutlexik.skyfront.drone.network.DroneTuningPayload;
import dev.krutlexik.skyfront.drone.network.StartControlPayload;
import dev.krutlexik.skyfront.drone.network.StopControlPayload;
import dev.krutlexik.skyfront.drone.network.StopControlRequestPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public class NetworkHandler {
   private static final String PROTOCOL_VERSION = "5";

   public static void register(RegisterPayloadHandlersEvent event) {
      PayloadRegistrar registrar = event.registrar("5");
      registrar.playToClient(ShahedSpawnPacket.TYPE, ShahedSpawnPacket.STREAM_CODEC, ShahedSpawnPacket::handle);
      registrar.playToClient(ShahedRemovePacket.TYPE, ShahedRemovePacket.STREAM_CODEC, ShahedRemovePacket::handle);
      registrar.playToClient(ShahedExplosionPacket.TYPE, ShahedExplosionPacket.STREAM_CODEC, ShahedExplosionPacket::handle);
      registrar.playToClient(DebrisBurstPacket.TYPE, DebrisBurstPacket.STREAM_CODEC, DebrisBurstPacket::handle);
      registrar.playToClient(TerminalDataPacket.TYPE, TerminalDataPacket.STREAM_CODEC, TerminalDataPacket::handle);
      registrar.playToServer(TerminalActionPacket.TYPE, TerminalActionPacket.STREAM_CODEC, TerminalActionPacket::handle);
      registrar.playToClient(OpenRadarScreenPacket.TYPE, OpenRadarScreenPacket.STREAM_CODEC, OpenRadarScreenPacket::handle);
      registrar.playToClient(SirenSoundPacket.TYPE, SirenSoundPacket.STREAM_CODEC, SirenSoundPacket::handle);
      registrar.playToClient(RadarUpdatePacket.TYPE, RadarUpdatePacket.STREAM_CODEC, RadarUpdatePacket::handle);
      registrar.playToServer(RequestRadarUpdatePacket.TYPE, RequestRadarUpdatePacket.STREAM_CODEC, RequestRadarUpdatePacket::handle);
      registrar.playToClient(WorldMapPacket.TYPE, WorldMapPacket.STREAM_CODEC, WorldMapPacket::handle);
      registrar.playToServer(RequestWorldMapPacket.TYPE, RequestWorldMapPacket.STREAM_CODEC, RequestWorldMapPacket::handle);
      registrar.playToServer(DroneInputPayload.TYPE, DroneInputPayload.STREAM_CODEC, DroneServerPayloadHandler::droneInput);
      registrar.playToServer(StopControlRequestPayload.TYPE, StopControlRequestPayload.STREAM_CODEC, DroneServerPayloadHandler::stopRequest);
      registrar.playToServer(DroneDropPayload.TYPE, DroneDropPayload.STREAM_CODEC, DroneServerPayloadHandler::dropGrenade);
      registrar.playToServer(DroneSelfDestructPayload.TYPE, DroneSelfDestructPayload.STREAM_CODEC, DroneServerPayloadHandler::selfDestruct);
      registrar.playToServer(DroneRamPayload.TYPE, DroneRamPayload.STREAM_CODEC, DroneServerPayloadHandler::ramReported);
      registrar.playToClient(StartControlPayload.TYPE, StartControlPayload.STREAM_CODEC, DroneClientPayloadHandler::startControl);
      registrar.playToClient(StopControlPayload.TYPE, StopControlPayload.STREAM_CODEC, DroneClientPayloadHandler::stopControl);
      registrar.playToClient(DroneLinkPayload.TYPE, DroneLinkPayload.STREAM_CODEC, DroneClientPayloadHandler::linkUpdate);
      registrar.playToClient(DroneStatePayload.TYPE, DroneStatePayload.STREAM_CODEC, DroneClientPayloadHandler::droneState);
      registrar.playToClient(DroneTuningPayload.TYPE, DroneTuningPayload.STREAM_CODEC, DroneClientPayloadHandler::tuning);
   }

   public static <MSG extends CustomPacketPayload> void sendToServer(MSG message) {
      PacketDistributor.sendToServer(message, new CustomPacketPayload[0]);
   }

   public static <MSG extends CustomPacketPayload> void sendToPlayer(ServerPlayer player, MSG message) {
      PacketDistributor.sendToPlayer(player, message, new CustomPacketPayload[0]);
   }

   public static <MSG extends CustomPacketPayload> void sendToAllPlayers(MSG message) {
      PacketDistributor.sendToAllPlayers(message, new CustomPacketPayload[0]);
   }

   public static <MSG extends CustomPacketPayload> void sendToNear(ServerLevel level, double x, double y, double z, double radius, MSG message) {
      double rSq = radius * radius;

      for (ServerPlayer player : level.players()) {
         if (player.distanceToSqr(x, y, z) <= rSq) {
            PacketDistributor.sendToPlayer(player, message, new CustomPacketPayload[0]);
         }
      }
   }
}
