package dev.krutlexik.skyfront.network;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public class ShahedRemovePacket implements CustomPacketPayload {
   public static final Type<ShahedRemovePacket> TYPE = new Type(ResourceLocation.fromNamespaceAndPath("sfw", "ShahedRemovePacket".toLowerCase()));
   public static final StreamCodec<RegistryFriendlyByteBuf, ShahedRemovePacket> STREAM_CODEC = StreamCodec.ofMember(
      ShahedRemovePacket::toBytes, ShahedRemovePacket::new
   );
   private final int entityId;

   public Type<ShahedRemovePacket> type() {
      return TYPE;
   }

   public ShahedRemovePacket(int entityId) {
      this.entityId = entityId;
   }

   public ShahedRemovePacket(RegistryFriendlyByteBuf buf) {
      this.entityId = buf.readInt();
   }

   public void toBytes(RegistryFriendlyByteBuf buf) {
      buf.writeInt(this.entityId);
   }

   public void handle(IPayloadContext ctx) {
      ctx.enqueueWork(() -> ClientPacketHandler.handleShahedRemove(this.entityId));
   }

   public int getEntityId() {
      return this.entityId;
   }
}
