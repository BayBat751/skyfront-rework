package dev.krutlexik.skyfront.network;

import dev.krutlexik.skyfront.client.sound.SirenSoundInstance;
import dev.krutlexik.skyfront.config.SkyfrontConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public class SirenSoundPacket implements CustomPacketPayload {
   public static final Type<SirenSoundPacket> TYPE = new Type(ResourceLocation.fromNamespaceAndPath("sfw", "SirenSoundPacket".toLowerCase()));
   public static final StreamCodec<RegistryFriendlyByteBuf, SirenSoundPacket> STREAM_CODEC = StreamCodec.ofMember(
      SirenSoundPacket::toBytes, SirenSoundPacket::new
   );
   private final BlockPos pos;
   private final boolean stop;
   private final int range;

   public Type<SirenSoundPacket> type() {
      return TYPE;
   }

   public SirenSoundPacket(BlockPos pos) {
      this(pos, false, (Integer)SkyfrontConfig.SIREN_RANGE.get());
   }

   public SirenSoundPacket(BlockPos pos, boolean stop) {
      this(pos, stop, (Integer)SkyfrontConfig.SIREN_RANGE.get());
   }

   public SirenSoundPacket(BlockPos pos, boolean stop, int range) {
      this.pos = pos;
      this.stop = stop;
      this.range = range;
   }

   public SirenSoundPacket(RegistryFriendlyByteBuf buf) {
      this.pos = buf.readBlockPos();
      this.stop = buf.readBoolean();
      this.range = buf.readVarInt();
   }

   public void toBytes(RegistryFriendlyByteBuf buf) {
      buf.writeBlockPos(this.pos);
      buf.writeBoolean(this.stop);
      buf.writeVarInt(this.range);
   }

   public void handle(IPayloadContext ctx) {
      ctx.enqueueWork(() -> this.handleClient());
   }

   private void handleClient() {
      if (this.stop) {
         SirenSoundInstance.stopSiren(this.pos);
      } else {
         SirenSoundInstance.playSiren(this.pos, this.range);
      }
   }
}
