package dev.krutlexik.skyfront.network;

import dev.krutlexik.skyfront.client.gui.ShahedRadarScreen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public class OpenRadarScreenPacket implements CustomPacketPayload {
   public static final Type<OpenRadarScreenPacket> TYPE = new Type(ResourceLocation.fromNamespaceAndPath("sfw", "OpenRadarScreenPacket".toLowerCase()));
   public static final StreamCodec<RegistryFriendlyByteBuf, OpenRadarScreenPacket> STREAM_CODEC = StreamCodec.ofMember(
      OpenRadarScreenPacket::toBytes, OpenRadarScreenPacket::new
   );
   private final BlockPos pos;

   public Type<OpenRadarScreenPacket> type() {
      return TYPE;
   }

   public OpenRadarScreenPacket(BlockPos pos) {
      this.pos = pos;
   }

   public OpenRadarScreenPacket(RegistryFriendlyByteBuf buf) {
      this.pos = buf.readBlockPos();
   }

   public void toBytes(RegistryFriendlyByteBuf buf) {
      buf.writeBlockPos(this.pos);
   }

   public void handle(IPayloadContext ctx) {
      ctx.enqueueWork(() -> ShahedRadarScreen.open(this.pos));
   }
}
