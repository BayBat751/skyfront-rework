package dev.krutlexik.skyfront.network;

import dev.krutlexik.skyfront.block.entity.ShahedTerminalBlockEntity;
import dev.krutlexik.skyfront.config.SkyfrontConfig;
import dev.krutlexik.skyfront.entity.ShahedEntity;
import dev.krutlexik.skyfront.seeker.SeekerHooks;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public class TerminalActionPacket implements CustomPacketPayload {
   public static final Type<TerminalActionPacket> TYPE = new Type(ResourceLocation.fromNamespaceAndPath("sfw", "terminalactionpacket"));
   public static final StreamCodec<RegistryFriendlyByteBuf, TerminalActionPacket> STREAM_CODEC = StreamCodec.ofMember(
      TerminalActionPacket::toBytes, TerminalActionPacket::new
   );
   public static final int HARD_MAX_WAYPOINTS = 15;
   public static final int ACTION_REFRESH = 0;
   public static final int ACTION_SET_ROUTE = 1;
   public static final int ACTION_LAUNCH = 2;
   public static final int ACTION_UNBIND = 3;
   public static final int ACTION_PUT_MAP = 4;
   public static final int ACTION_TAKE_MAP = 5;
   public final BlockPos terminalPos;
   public final int action;
   public final UUID uuid;
   private final int[] route;
   private final int altitude;
   private final boolean farDive;

   public TerminalActionPacket(BlockPos terminalPos, int action, UUID uuid, int[] route, int altitude, boolean farDive) {
      this.terminalPos = terminalPos;
      this.action = action;
      this.uuid = uuid;
      this.route = route;
      this.altitude = altitude;
      this.farDive = farDive;
   }

   public static TerminalActionPacket refresh(BlockPos terminalPos) {
      return new TerminalActionPacket(terminalPos, 0, new UUID(0L, 0L), new int[0], 0, true);
   }

   public static TerminalActionPacket unbind(BlockPos terminalPos, UUID uuid) {
      return new TerminalActionPacket(terminalPos, 3, uuid, new int[0], 0, true);
   }

   public static TerminalActionPacket putMap(BlockPos terminalPos) {
      return new TerminalActionPacket(terminalPos, 4, new UUID(0L, 0L), new int[0], 0, true);
   }

   public static TerminalActionPacket takeMap(BlockPos terminalPos) {
      return new TerminalActionPacket(terminalPos, 5, new UUID(0L, 0L), new int[0], 0, true);
   }

   public TerminalActionPacket(RegistryFriendlyByteBuf buf) {
      this.terminalPos = buf.readBlockPos();
      this.action = buf.readByte();
      this.uuid = buf.readUUID();
      this.route = buf.readVarIntArray();
      this.altitude = buf.readInt();
      this.farDive = buf.readBoolean();
   }

   public void toBytes(RegistryFriendlyByteBuf buf) {
      buf.writeBlockPos(this.terminalPos);
      buf.writeByte(this.action);
      buf.writeUUID(this.uuid);
      buf.writeVarIntArray(this.route);
      buf.writeInt(this.altitude);
      buf.writeBoolean(this.farDive);
   }

   public Type<TerminalActionPacket> type() {
      return TYPE;
   }

   public void handle(IPayloadContext ctx) {
      ctx.enqueueWork(() -> {
         if (!SeekerHooks.onTerminalAction(this, ctx)) {
            if (ctx.player() instanceof ServerPlayer player) {
               if (player.level() instanceof ServerLevel level) {
                  if (!(player.position().distanceToSqr(this.terminalPos.getCenter()) > 64.0)) {
                     if (level.getBlockEntity(this.terminalPos) instanceof ShahedTerminalBlockEntity terminal) {
                        switch (this.action) {
                           case 1:
                              this.applyRoute(level, player, terminal, true);
                              break;
                           case 2:
                              if (this.applyRoute(level, player, terminal, true)) {
                                 this.launch(level, player, terminal);
                              }
                              break;
                           case 3:
                              terminal.unbind(this.uuid);
                              break;
                           case 4:
                              if (putMap(player, terminal)) {
                                 TerminalDataPacket.sendMapPicture(player, level, terminal);
                              }
                              break;
                           case 5:
                              giveBack(player, terminal.takeMap());
                        }

                        NetworkHandler.sendToPlayer(player, TerminalDataPacket.build(level, this.terminalPos, terminal, false));
                     }
                  }
               }
            }
         }
      });
   }

   private static boolean putMap(ServerPlayer player, ShahedTerminalBlockEntity terminal) {
      Inventory inventory = player.getInventory();
      ItemStack source = null;
      if (ShahedTerminalBlockEntity.isMap(player.getMainHandItem())) {
         source = player.getMainHandItem();
      } else if (ShahedTerminalBlockEntity.isMap(player.getOffhandItem())) {
         source = player.getOffhandItem();
      } else {
         for (int i = 0; i < inventory.getContainerSize(); i++) {
            if (ShahedTerminalBlockEntity.isMap(inventory.getItem(i))) {
               source = inventory.getItem(i);
               break;
            }
         }
      }

      if (source == null) {
         player.displayClientMessage(Component.translatable("msg.sfw.map.none").withStyle(ChatFormatting.YELLOW), true);
         return false;
      } else {
         ItemStack previous = terminal.swapMap(source);
         source.shrink(1);
         giveBack(player, previous);
         return true;
      }
   }

   public static void giveBack(ServerPlayer player, ItemStack stack) {
      if (!stack.isEmpty() && !player.getInventory().add(stack)) {
         player.drop(stack, false);
      }
   }

   private boolean applyRoute(ServerLevel level, ServerPlayer player, ShahedTerminalBlockEntity terminal, boolean strict) {
      ShahedTerminalBlockEntity.Entry entry = terminal.findByUuid(this.uuid);
      if (entry != null && this.route.length % 2 == 0) {
         int maxPoints = SkyfrontConfig.getMaxWaypoints();
         if (this.route.length / 2 > maxPoints) {
            if (strict) {
               player.sendSystemMessage(Component.translatable("msg.sfw.route.too_many", new Object[]{maxPoints}).withStyle(ChatFormatting.RED));
            }

            return false;
         } else {
            int minSpacing = SkyfrontConfig.getMinWaypointDistance();

            for (int i = 2; i < this.route.length; i += 2) {
               double dx = this.route[i] - this.route[i - 2];
               double dz = this.route[i + 1] - this.route[i - 1];
               if (dx * dx + dz * dz < (double)minSpacing * minSpacing) {
                  if (strict) {
                     player.sendSystemMessage(Component.translatable("msg.sfw.route.too_close", new Object[]{minSpacing}).withStyle(ChatFormatting.RED));
                  }

                  return false;
               }
            }

            for (int ix = 0; ix < this.route.length; ix += 2) {
               if (SkyfrontConfig.isInForbiddenZone(this.route[ix], this.route[ix + 1])) {
                  if (strict) {
                     player.sendSystemMessage(Component.translatable("msg.sfw.route.forbidden_zone").withStyle(ChatFormatting.RED));
                  }

                  return false;
               }
            }

            Entity droneEntity = level.getEntity(this.uuid);
            int minLaunch = (Integer)SkyfrontConfig.MIN_LAUNCH_DISTANCE.get();
            if (droneEntity != null && minLaunch > 0) {
               for (int ixx = 0; ixx < this.route.length; ixx += 2) {
                  double dx = this.route[ixx] - droneEntity.getX();
                  double dz = this.route[ixx + 1] - droneEntity.getZ();
                  if (dx * dx + dz * dz < (double)minLaunch * minLaunch) {
                     if (strict) {
                        player.sendSystemMessage(
                           Component.translatable("msg.sfw.route.too_close_launch", new Object[]{minLaunch}).withStyle(ChatFormatting.RED)
                        );
                     }

                     return false;
                  }
               }
            }

            entry.route = (int[])this.route.clone();
            entry.altitude = Mth.clamp(this.altitude, 70, SkyfrontConfig.getMaxAltitude());
            entry.farDive = this.farDive;
            terminal.setChanged();
            return true;
         }
      } else {
         return false;
      }
   }

   private void launch(ServerLevel level, ServerPlayer player, ShahedTerminalBlockEntity terminal) {
      ShahedTerminalBlockEntity.Entry entry = terminal.findByUuid(this.uuid);
      if (entry != null) {
         if (entry.waypointCount() == 0) {
            player.sendSystemMessage(Component.translatable("msg.sfw.route.empty").withStyle(ChatFormatting.RED));
         } else {
            int targetX = entry.route[entry.route.length - 2];
            int targetZ = entry.route[entry.route.length - 1];
            if (SkyfrontConfig.isInForbiddenZone(targetX, targetZ)) {
               player.sendSystemMessage(Component.translatable("chat.sfw.error.forbidden").withStyle(ChatFormatting.RED));
            } else if (level.getEntity(entry.uuid) instanceof ShahedEntity shahed && shahed.isAlive() && shahed.isParked()) {
               int maxRange = (Integer)SkyfrontConfig.MAX_FLIGHT_RANGE.get();

               for (int i = 0; i < entry.route.length; i += 2) {
                  double dx = entry.route[i] - shahed.getX();
                  double dz = entry.route[i + 1] - shahed.getZ();
                  double distance = Math.sqrt(dx * dx + dz * dz);
                  if (distance > maxRange) {
                     player.sendSystemMessage(
                        Component.translatable("msg.sfw.launch.too_far", new Object[]{(int)distance, maxRange}).withStyle(ChatFormatting.RED)
                     );
                     return;
                  }
               }

               shahed.setOwner(player);
               shahed.launchFromGround(entry.route, entry.altitude, entry.farDive ? "high" : "low");
               Component prefix = Component.literal("[")
                  .withStyle(ChatFormatting.DARK_GRAY)
                  .append(Component.literal("SFW").withStyle(ChatFormatting.GREEN))
                  .append(Component.literal("] ").withStyle(ChatFormatting.DARK_GRAY));
               player.sendSystemMessage(
                  prefix.copy()
                     .append(Component.translatable("msg.sfw.launch.success", new Object[]{entry.number, targetX, targetZ}).withStyle(ChatFormatting.GREEN))
               );
            } else {
               player.sendSystemMessage(Component.translatable("msg.sfw.launch.not_ready").withStyle(ChatFormatting.RED));
            }
         }
      }
   }
}
