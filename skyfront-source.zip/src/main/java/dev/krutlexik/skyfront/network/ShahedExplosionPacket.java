package dev.krutlexik.skyfront.network;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public class ShahedExplosionPacket implements CustomPacketPayload {
   public static final Type<ShahedExplosionPacket> TYPE = new Type(ResourceLocation.fromNamespaceAndPath("sfw", "ShahedExplosionPacket".toLowerCase()));
   public static final StreamCodec<RegistryFriendlyByteBuf, ShahedExplosionPacket> STREAM_CODEC = StreamCodec.ofMember(
      ShahedExplosionPacket::toBytes, ShahedExplosionPacket::new
   );
   private final Vec3 position;
   private final float particleMultiplier;
   private final boolean customSounds;

   public Type<ShahedExplosionPacket> type() {
      return TYPE;
   }

   public ShahedExplosionPacket(Vec3 position, float particleMultiplier, boolean customSounds) {
      this.position = position;
      this.particleMultiplier = particleMultiplier;
      this.customSounds = customSounds;
   }

   public ShahedExplosionPacket(RegistryFriendlyByteBuf buf) {
      this.position = new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble());
      this.particleMultiplier = buf.readFloat();
      this.customSounds = buf.readBoolean();
   }

   public void toBytes(RegistryFriendlyByteBuf buf) {
      buf.writeDouble(this.position.x);
      buf.writeDouble(this.position.y);
      buf.writeDouble(this.position.z);
      buf.writeFloat(this.particleMultiplier);
      buf.writeBoolean(this.customSounds);
   }

   public void handle(IPayloadContext ctx) {
      ctx.enqueueWork(() -> ClientPacketHandler.handleExplosion(this.position, this.particleMultiplier, this.customSounds));
   }

   public Vec3 getPosition() {
      return this.position;
   }

   public float getParticleMultiplier() {
      return this.particleMultiplier;
   }
}
