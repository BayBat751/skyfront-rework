package dev.krutlexik.skyfront.worldmap;

import java.io.File;
import java.io.RandomAccessFile;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.storage.LevelResource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WorldMapScanner {
   private static final Logger LOGGER = LoggerFactory.getLogger("SFW-WorldMap");
   private static WorldMapScanner instance;
   private final ExecutorService scanExecutor = Executors.newSingleThreadExecutor(r -> {
      Thread t = new Thread(r, "SFW-MapScanner");
      t.setDaemon(true);
      return t;
   });
   private final AtomicBoolean isScanning = new AtomicBoolean(false);
   private final AtomicInteger progress = new AtomicInteger(0);
   private volatile int totalChunks = 0;

   private WorldMapScanner() {
   }

   public static WorldMapScanner getInstance() {
      if (instance == null) {
         instance = new WorldMapScanner();
      }

      return instance;
   }

   public void startScan(ServerLevel level) {
      if (!this.isScanning.compareAndSet(false, true)) {
         LOGGER.info("[SFW] Map scan already in progress");
      } else {
         WorldMapData mapData = WorldMapData.get(level);
         int minY = level.getMinBuildHeight();
         int heightBits = Mth.ceillog2(level.getHeight() + 1);
         CompletableFuture.runAsync(
            () -> {
               try {
                  List<ChunkPos> existing = this.findExistingChunks(level);
                  List<ChunkPos> toScan = new ArrayList<>();

                  for (ChunkPos pos : existing) {
                     if (!mapData.isChunkScanned(pos.x, pos.z)) {
                        toScan.add(pos);
                     }
                  }

                  this.totalChunks = toScan.size();
                  this.progress.set(0);
                  LOGGER.info(
                     "[SFW] World map: {} chunks on disk, {} new to scan ({} colors cached)",
                     new Object[]{existing.size(), toScan.size(), mapData.getColorCount()}
                  );
                  int batchSize = 128;

                  for (int i = 0; i < toScan.size(); i += batchSize) {
                     if (!this.isScanning.get()) {
                        LOGGER.info("[SFW] Map scan cancelled");
                        return;
                     }

                     int end = Math.min(i + batchSize, toScan.size());
                     List<ChunkPos> batch = toScan.subList(i, end);
                     List<CompletableFuture<Optional<CompoundTag>>> reads = new ArrayList<>(batch.size());

                     for (ChunkPos posx : batch) {
                        reads.add(level.getChunkSource().chunkMap.read(posx));
                     }

                     for (int k = 0; k < batch.size(); k++) {
                        ChunkPos posx = batch.get(k);
                        int color = 0;

                        try {
                           Optional<CompoundTag> tag = reads.get(k).get(30L, TimeUnit.SECONDS);
                           if (tag.isPresent()) {
                              color = this.parseChunkColor(tag.get(), minY, heightBits);
                           }
                        } catch (Exception var20) {
                        }

                        mapData.putChunkColor(posx.x, posx.z, color);
                     }

                     int done = this.progress.addAndGet(batch.size());
                     if (done % 8192 < batchSize) {
                        LOGGER.info(
                           "[SFW] Map scan progress: {}/{} chunks ({}%)",
                           new Object[]{done, this.totalChunks, this.totalChunks == 0 ? 100 : done * 100 / this.totalChunks}
                        );
                     }
                  }

                  mapData.setScanComplete(true);
                  LOGGER.info("[SFW] Map scan complete! {} chunk colors in the map", mapData.getColorCount());
               } catch (Exception var21) {
                  LOGGER.error("[SFW] Error during map scan", var21);
               } finally {
                  this.isScanning.set(false);
               }
            },
            this.scanExecutor
         );
      }
   }

   private List<ChunkPos> findExistingChunks(ServerLevel level) {
      List<ChunkPos> chunks = new ArrayList<>();
      Path worldPath = level.getServer().getWorldPath(LevelResource.ROOT);
      File regionDir = worldPath.resolve("region").toFile();
      if (regionDir.exists() && regionDir.isDirectory()) {
         File[] regionFiles = regionDir.listFiles((dir, namex) -> namex.endsWith(".mca"));
         if (regionFiles == null) {
            return chunks;
         } else {
            for (File regionFile : regionFiles) {
               String name = regionFile.getName();
               String[] parts = name.replace("r.", "").replace(".mca", "").split("\\.");
               if (parts.length == 2) {
                  try {
                     int regionX = Integer.parseInt(parts[0]);
                     int regionZ = Integer.parseInt(parts[1]);
                     chunks.addAll(this.getChunksInRegion(regionFile, regionX, regionZ));
                  } catch (NumberFormatException var14) {
                     LOGGER.warn("[SFW] Invalid region file name: {}", name);
                  }
               }
            }

            return chunks;
         }
      } else {
         LOGGER.warn("[SFW] Region directory not found: {}", regionDir);
         return chunks;
      }
   }

   private List<ChunkPos> getChunksInRegion(File regionFile, int regionX, int regionZ) {
      List<ChunkPos> chunks = new ArrayList<>();

      try (RandomAccessFile raf = new RandomAccessFile(regionFile, "r")) {
         for (int localZ = 0; localZ < 32; localZ++) {
            for (int localX = 0; localX < 32; localX++) {
               raf.seek(4L * (localX + localZ * 32));
               if (raf.readInt() != 0) {
                  chunks.add(new ChunkPos(regionX * 32 + localX, regionZ * 32 + localZ));
               }
            }
         }
      } catch (Exception var10) {
         LOGGER.warn("[SFW] Error reading region file: {}", regionFile.getName());
      }

      return chunks;
   }

   private int parseChunkColor(CompoundTag tag, int minY, int heightBits) {
      if (!"minecraft:full".equals(tag.getString("Status"))) {
         return 0;
      } else {
         long[] heightmap = tag.getCompound("Heightmaps").getLongArray("WORLD_SURFACE");
         if (heightmap.length == 0) {
            return 0;
         } else {
            int stored = readPacked(heightmap, heightBits, 136);
            int topY = minY + stored - 1;
            if (stored <= 0) {
               return 0;
            } else {
               String block = findBlockAt(tag, 8, topY, 8);
               return colorFor(block, topY);
            }
         }
      }
   }

   private static int readPacked(long[] data, int bits, int index) {
      int valuesPerLong = 64 / bits;
      int word = index / valuesPerLong;
      if (word >= data.length) {
         return 0;
      } else {
         int shift = index % valuesPerLong * bits;
         return (int)(data[word] >>> shift & (1L << bits) - 1L);
      }
   }

   private static String findBlockAt(CompoundTag chunkTag, int x, int y, int z) {
      ListTag sections = chunkTag.getList("sections", 10);
      int sectionY = Math.floorDiv(y, 16);

      for (int i = 0; i < sections.size(); i++) {
         CompoundTag section = sections.getCompound(i);
         if (section.getByte("Y") == sectionY) {
            CompoundTag blockStates = section.getCompound("block_states");
            ListTag palette = blockStates.getList("palette", 10);
            if (palette.isEmpty()) {
               return "minecraft:air";
            }

            if (palette.size() != 1 && blockStates.contains("data")) {
               long[] data = blockStates.getLongArray("data");
               int bits = Math.max(4, Mth.ceillog2(palette.size()));
               int index = (y & 15) << 8 | (z & 15) << 4 | x & 15;
               int paletteIndex = readPacked(data, bits, index);
               if (paletteIndex >= palette.size()) {
                  return "minecraft:air";
               }

               return palette.getCompound(paletteIndex).getString("Name");
            }

            return palette.getCompound(0).getString("Name");
         }
      }

      return "minecraft:air";
   }

   private static int colorFor(String blockId, int y) {
      String id = blockId.startsWith("minecraft:") ? blockId.substring(10) : blockId;
      int base = baseColor(id);
      if (base == 0) {
         return 0;
      } else {
         boolean water = id.contains("water") || id.endsWith("ice");
         float shade;
         if (water) {
            shade = 1.15F;
         } else {
            float t = Mth.clamp((y - 40) / 140.0F, 0.0F, 1.0F);
            shade = 1.0F + 0.3F * (Math.round(t * 7.0F) / 7.0F);
         }

         int r = Math.min(255, (int)((base >> 16 & 0xFF) * shade));
         int g = Math.min(255, (int)((base >> 8 & 0xFF) * shade));
         int b = Math.min(255, (int)((base & 0xFF) * shade));
         int color = r << 16 | g << 8 | b;
         return color == 0 ? 65793 : color;
      }
   }

   private static int baseColor(String id) {
      if (id.equals("air") || id.equals("cave_air") || id.equals("void_air")) {
         return 0;
      } else if (id.contains("water")) {
         return 6067168;
      } else if (id.endsWith("ice")) {
         return 12114165;
      } else if (id.equals("lava")) {
         return 16747054;
      } else if (id.equals("snow") || id.equals("snow_block") || id.equals("powder_snow")) {
         return 16448255;
      } else if (id.equals("grass_block")) {
         return 10146154;
      } else if (id.endsWith("_leaves") || id.equals("mangrove_roots")) {
         return 7319113;
      } else if (id.endsWith("_log") || id.endsWith("_wood") || id.endsWith("_stem") || id.endsWith("_planks")) {
         return 11043151;
      } else if (id.contains("sandstone")) {
         return 15391906;
      } else if (id.equals("sand")) {
         return 15919540;
      } else if (id.equals("red_sand")) {
         return 14517319;
      } else if (id.equals("gravel")) {
         return 11513775;
      } else if (id.equals("clay")) {
         return 12766169;
      } else if (id.contains("deepslate")) {
         return 9211020;
      } else if (id.equals("dirt") || id.equals("coarse_dirt") || id.equals("rooted_dirt") || id.equals("dirt_path") || id.equals("farmland")) {
         return 11962974;
      } else if (id.equals("podzol") || id.equals("mud") || id.equals("muddy_mangrove_roots")) {
         return 9072213;
      } else if (id.equals("mycelium")) {
         return 11048104;
      } else if (id.contains("moss")) {
         return 9092963;
      } else if (id.contains("terracotta")) {
         return 14388067;
      } else if (id.contains("basalt") || id.equals("blackstone")) {
         return 7763582;
      } else if (id.equals("obsidian") || id.equals("crying_obsidian")) {
         return 4868710;
      } else if (id.contains("netherrack") || id.contains("nether")) {
         return 11815498;
      } else if (id.contains("end_stone")) {
         return 15790260;
      } else if (id.contains("stone")
         || id.contains("andesite")
         || id.contains("diorite")
         || id.contains("granite")
         || id.contains("tuff")
         || id.contains("calcite")
         || id.contains("cobble")) {
         return 11842740;
      } else if (id.contains("grass") || id.contains("fern") || id.contains("bush")) {
         return 10146154;
      } else if (id.contains("flower") || id.contains("tulip") || id.contains("orchid")) {
         return 11587187;
      } else if (id.contains("mushroom") || id.contains("fungus")) {
         return 12885642;
      } else if (id.contains("bamboo")) {
         return 9092942;
      } else if (id.contains("cactus")) {
         return 7843922;
      } else if (id.contains("pumpkin") || id.contains("melon")) {
         return 12890190;
      } else if (id.contains("coral")) {
         return 15108814;
      } else {
         return !id.contains("kelp") && !id.contains("seagrass") && !id.contains("lily") ? 10526880 : 5414519;
      }
   }

   public void stopScan() {
      this.isScanning.set(false);
   }

   public boolean isScanning() {
      return this.isScanning.get();
   }

   public int getProgress() {
      return this.progress.get();
   }

   public int getTotalChunks() {
      return this.totalChunks;
   }
}
