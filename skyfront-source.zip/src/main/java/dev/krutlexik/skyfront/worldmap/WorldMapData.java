package dev.krutlexik.skyfront.worldmap;

import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedData.Factory;
import net.minecraft.world.level.storage.DimensionDataStorage;

public class WorldMapData extends SavedData {
   private static final String DATA_NAME = "skyfront_world_map";
   private static final int PALETTE_VERSION = 2;
   private final Map<Long, Integer> chunkColors = new ConcurrentHashMap<>();
   private final Set<Long> scannedChunks = ConcurrentHashMap.newKeySet();
   private volatile boolean scanComplete = false;

   public static WorldMapData load(CompoundTag tag, Provider provider) {
      WorldMapData data = new WorldMapData();
      if (tag.getInt("paletteVersion") != 2) {
         return data;
      } else {
         long[] keys = tag.getLongArray("colorKeys");
         int[] values = tag.getIntArray("colorValues");

         for (int i = 0; i < keys.length && i < values.length; i++) {
            data.chunkColors.put(keys[i], values[i]);
         }

         for (long scanned : tag.getLongArray("scanned")) {
            data.scannedChunks.add(scanned);
         }

         data.scanComplete = tag.getBoolean("scanComplete");
         return data;
      }
   }

   public CompoundTag save(CompoundTag tag, Provider provider) {
      long[] keys = new long[this.chunkColors.size()];
      int[] values = new int[this.chunkColors.size()];
      int i = 0;

      for (Entry<Long, Integer> entry : this.chunkColors.entrySet()) {
         if (i >= keys.length) {
            break;
         }

         keys[i] = entry.getKey();
         values[i] = entry.getValue();
         i++;
      }

      tag.putLongArray("colorKeys", keys);
      tag.putIntArray("colorValues", values);
      long[] scanned = new long[this.scannedChunks.size()];
      int j = 0;

      for (Long chunk : this.scannedChunks) {
         if (j >= scanned.length) {
            break;
         }

         scanned[j++] = chunk;
      }

      tag.putLongArray("scanned", scanned);
      tag.putBoolean("scanComplete", this.scanComplete);
      tag.putInt("paletteVersion", 2);
      return tag;
   }

   public static WorldMapData get(ServerLevel level) {
      DimensionDataStorage storage = level.getDataStorage();
      Factory<WorldMapData> factory = new Factory(WorldMapData::new, WorldMapData::load, null);
      return (WorldMapData)storage.computeIfAbsent(factory, "skyfront_world_map");
   }

   public void putChunkColor(int chunkX, int chunkZ, int color) {
      if (color != 0) {
         this.chunkColors.put(packChunkPos(chunkX, chunkZ), color);
      }

      this.scannedChunks.add(packChunkPos(chunkX, chunkZ));
      this.setDirty();
   }

   public boolean isChunkScanned(int chunkX, int chunkZ) {
      return this.scannedChunks.contains(packChunkPos(chunkX, chunkZ));
   }

   public int[] collectSquare(int centerChunkX, int centerChunkZ, int radiusChunks) {
      int size = radiusChunks * 2 + 1;
      int[] grid = new int[size * size];

      for (int dz = -radiusChunks; dz <= radiusChunks; dz++) {
         for (int dx = -radiusChunks; dx <= radiusChunks; dx++) {
            Integer color = this.chunkColors.get(packChunkPos(centerChunkX + dx, centerChunkZ + dz));
            if (color != null) {
               grid[(dz + radiusChunks) * size + dx + radiusChunks] = color;
            }
         }
      }

      return grid;
   }

   public boolean isScanComplete() {
      return this.scanComplete;
   }

   public void setScanComplete(boolean complete) {
      this.scanComplete = complete;
      this.setDirty();
   }

   public int getColorCount() {
      return this.chunkColors.size();
   }

   public void clear() {
      this.chunkColors.clear();
      this.scannedChunks.clear();
      this.scanComplete = false;
      this.setDirty();
   }

   public static long packChunkPos(int chunkX, int chunkZ) {
      return chunkX & 4294967295L | (chunkZ & 4294967295L) << 32;
   }
}
