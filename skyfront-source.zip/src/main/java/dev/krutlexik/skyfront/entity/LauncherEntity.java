package dev.krutlexik.skyfront.entity;

import dev.krutlexik.skyfront.drone.entity.DroneEntity;
import dev.krutlexik.skyfront.drone.entity.InterceptorDroneEntity;
import dev.krutlexik.skyfront.drone.entity.MolniyaDroneEntity;
import dev.krutlexik.skyfront.drone.registry.DroneEntities;
import dev.krutlexik.skyfront.drone.registry.DroneItems;
import dev.krutlexik.skyfront.item.ModItems;
import dev.krutlexik.skyfront.item.ShahedItem;
import dev.krutlexik.skyfront.seeker.SeekerHooks;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity.RemovalReason;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class LauncherEntity extends Entity {
   public static final float SCALE = 1.2F;
   public static final double CENTRE_X = 8.0;
   public static final double CENTRE_Z = 10.705;
   private static final double RAIL_LOW_Z = -8.834;
   private static final double RAIL_LOW_Y = 13.161;
   private static final double RAIL_HIGH_Z = 31.194;
   private static final double RAIL_HIGH_Y = 22.035;
   private static final double RAIL_LENGTH = 41.0;
   public static final float RAIL_PITCH = 12.5F;
   private static final double SHAHED_SEAT = 0.53;
   private static final double MOLNIYA_SEAT = 0.5;
   private static final float BREAK_DAMAGE = 8.0F;
   @Nullable
   private UUID occupant;
   private float damage;

   public LauncherEntity(EntityType<? extends LauncherEntity> type, Level level) {
      super(type, level);
   }

   protected void defineSynchedData(Builder builder) {
   }

   public boolean isPickable() {
      return !this.isRemoved();
   }

   public boolean isPushable() {
      return false;
   }

   public ItemStack getPickResult() {
      return new ItemStack((ItemLike)ModItems.LAUNCHER.get());
   }

   public Vec3 railPoint(double along) {
      double s = 0.075F;
      double z = (Mth.lerp(along, -8.834, 31.194) - 10.705) * s;
      double y = Mth.lerp(along, 13.161, 22.035) * s;
      double yaw = Math.toRadians(this.getYRot());
      return this.position().add(-Math.sin(yaw) * z, y, Math.cos(yaw) * z);
   }

   public double railAhead(double along) {
      return (1.0 - along) * 41.0 * 1.2F / 16.0;
   }

   public InteractionResult interact(Player player, InteractionHand hand) {
      if (player.isShiftKeyDown()) {
         if (this.level() instanceof ServerLevel) {
            this.packUp(player);
         }

         return InteractionResult.sidedSuccess(this.level().isClientSide);
      } else {
         ItemStack stack = player.getItemInHand(hand);
         boolean shahed = stack.getItem() instanceof ShahedItem;
         boolean molniya = stack.is((Item)DroneItems.MOLNIYA_DRONE.get());
         if (!shahed && !molniya) {
            return InteractionResult.PASS;
         } else if (this.level() instanceof ServerLevel server) {
            if (this.occupied(server)) {
               player.displayClientMessage(Component.translatable("msg.sfw.launcher.occupied").withStyle(ChatFormatting.RED), true);
               return InteractionResult.FAIL;
            } else {
               Entity placed;
               if (shahed) {
                  ShahedEntity drone = SeekerHooks.newShahed(stack, server);
                  ShahedItem.applyStackData(drone, server, stack);
                  drone.seatOnRail(this.railPoint(0.53).add(0.0, 0.02, 0.0), -this.getYRot(), 12.5F, this.railAhead(0.53));
                  placed = drone;
                  player.setItemInHand(hand, ItemStack.EMPTY);
               } else {
                  MolniyaDroneEntity drone = (MolniyaDroneEntity)((EntityType)DroneEntities.MOLNIYA_DRONE.get()).create(server);
                  if (drone == null) {
                     return InteractionResult.FAIL;
                  }

                  drone.seatOnRail(this.railPoint(0.5).add(0.0, 0.02, 0.0), this.getYRot(), 12.5F);
                  placed = drone;
                  if (!player.getAbilities().instabuild) {
                     stack.shrink(1);
                  }
               }

               server.addFreshEntity(placed);
               this.occupant = placed.getUUID();
               return InteractionResult.CONSUME;
            }
         } else {
            return InteractionResult.SUCCESS;
         }
      }
   }

   private boolean occupied(ServerLevel server) {
      return this.seatedOccupant(server) != null;
   }

   @Nullable
   private Entity seatedOccupant(ServerLevel server) {
      if (this.occupant == null) {
         return null;
      } else {
         Entity there = server.getEntity(this.occupant);
         boolean seated = there instanceof ShahedEntity shahed && shahed.isOnRail() || there instanceof InterceptorDroneEntity plane && plane.isRailSeated();
         if (seated && !(there.distanceToSqr(this) > 16.0)) {
            return there;
         } else {
            this.occupant = null;
            return null;
         }
      }
   }

   public void packUp(Player player) {
      if (this.level() instanceof ServerLevel server && !this.isRemoved()) {
         Entity drone = this.seatedOccupant(server);
         this.occupant = null;
         if (drone instanceof ShahedEntity shahed) {
            giveOrDrop(player, shahed.toItem());
            shahed.discardAsItem();
         } else if (drone instanceof DroneEntity plane) {
            plane.packUpFor(player, true);
         } else {
            giveOrDrop(player, new ItemStack((ItemLike)ModItems.LAUNCHER.get()));
            this.discard();
         }
      }
   }

   private static void giveOrDrop(Player player, ItemStack stack) {
      if (!player.getInventory().add(stack)) {
         player.drop(stack, false);
      }
   }

   private void dropOccupant() {
      if (this.level() instanceof ServerLevel server) {
         Entity drone = this.seatedOccupant(server);
         this.occupant = null;
         if (drone instanceof ShahedEntity shahed) {
            shahed.spawnAtLocation(shahed.toItem());
            shahed.discardAsItem();
         } else if (drone instanceof DroneEntity plane) {
            plane.dropAsItem();
         }
      }

      this.occupant = null;
   }

   public boolean hurt(DamageSource source, float amount) {
      if (!this.level().isClientSide && !this.isRemoved() && !this.isInvulnerableTo(source)) {
         if (source.getEntity() instanceof Player player && player.getAbilities().instabuild) {
            this.breakApart(false);
            return true;
         } else {
            this.damage += amount;
            this.markHurt();
            if (this.damage >= 8.0F) {
               this.breakApart(true);
            }

            return true;
         }
      } else {
         return false;
      }
   }

   private void breakApart(boolean drop) {
      this.dropOccupant();
      if (drop) {
         this.spawnAtLocation(new ItemStack((ItemLike)ModItems.LAUNCHER.get()));
      }

      this.discard();
   }

   public void remove(RemovalReason reason) {
      if (!this.level().isClientSide && reason.shouldDestroy()) {
         this.dropOccupant();
      }

      super.remove(reason);
   }

   protected void readAdditionalSaveData(CompoundTag tag) {
      this.occupant = tag.hasUUID("Occupant") ? tag.getUUID("Occupant") : null;
      this.damage = tag.getFloat("Damage");
   }

   protected void addAdditionalSaveData(CompoundTag tag) {
      if (this.occupant != null) {
         tag.putUUID("Occupant", this.occupant);
      }

      tag.putFloat("Damage", this.damage);
   }
}
