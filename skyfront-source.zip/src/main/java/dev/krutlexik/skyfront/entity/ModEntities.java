package dev.krutlexik.skyfront.entity;

import dev.krutlexik.skyfront.seeker.SeekerRegistry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType.Builder;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModEntities {
   public static final DeferredRegister<EntityType<?>> ENTITY_TYPES = DeferredRegister.create(BuiltInRegistries.ENTITY_TYPE, "sfw");
   public static final DeferredHolder<EntityType<?>, EntityType<ShahedEntity>> SHAHED = ENTITY_TYPES.register(
      "shahed",
      () -> Builder.of(ShahedEntity::new, MobCategory.MISC)
         .sized(3.0F, 1.5F)
         .clientTrackingRange(600)
         .updateInterval(1)
         .setShouldReceiveVelocityUpdates(true)
         .build("shahed")
   );
   public static final DeferredHolder<EntityType<?>, EntityType<DebrisEntity>> DEBRIS = ENTITY_TYPES.register(
      "debris",
      () -> Builder.of(DebrisEntity::new, MobCategory.MISC)
         .sized(0.5F, 0.3F)
         .clientTrackingRange(10)
         .updateInterval(2)
         .setShouldReceiveVelocityUpdates(true)
         .build("debris")
   );
   public static final DeferredHolder<EntityType<?>, EntityType<LauncherEntity>> LAUNCHER = ENTITY_TYPES.register(
      "launcher", () -> Builder.of(LauncherEntity::new, MobCategory.MISC).sized(3.1F, 1.7F).clientTrackingRange(10).updateInterval(20).build("launcher")
   );

   public static void register(IEventBus eventBus) {
      SeekerRegistry.register(eventBus);
      ENTITY_TYPES.register(eventBus);
   }
}
