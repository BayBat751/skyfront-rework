package dev.krutlexik.skyfront.entity;

import dev.krutlexik.skyfront.network.DebrisBurstPacket;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap.Types;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;
import org.joml.Vector3f;

public class DebrisEntity extends Entity {
   public static final int LIFETIME = 3600;
   private static final EntityDataAccessor<Integer> DATA_PIECE = SynchedEntityData.defineId(DebrisEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Quaternionf> DATA_ATTITUDE = SynchedEntityData.defineId(DebrisEntity.class, EntityDataSerializers.QUATERNION);
   private static final EntityDataAccessor<Vector3f> DATA_SPIN = SynchedEntityData.defineId(DebrisEntity.class, EntityDataSerializers.VECTOR3);
   private static final EntityDataAccessor<Integer> DATA_STATE = SynchedEntityData.defineId(DebrisEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Integer> DATA_BOUNCES = SynchedEntityData.defineId(DebrisEntity.class, EntityDataSerializers.INT);
   private static final int IN_THE_AIR = 0;
   private static final int SLIDING = 1;
   private static final int AT_REST = 2;
   private static final double GRAVITY = 0.04;
   private static final double BOUNCE_SPEED = 0.15;
   private static final double GROUND_FRICTION = 0.8;
   private int age;
   private boolean local;
   private final Quaternionf attitude = new Quaternionf();
   private final Quaternionf attitudeO = new Quaternionf();
   private final Vector3f spinAxis = new Vector3f();
   private float spinRate;
   private boolean attitudeReady;
   private int bouncesSeen;
   private float settling;
   private double targetX;
   private double targetY;
   private double targetZ;
   private int targetSteps;
   public static final double GROUND_RADIUS = 40.0;
   public static final double HIGH_RADIUS = 100.0;
   private static final double LOW_BLAST = 8.0;
   private static final double HIGH_BLAST = 60.0;
   private static final double BOUNCE_ALLOWANCE = 0.8;
   private static final int MAX_FLIGHT = 600;
   private static int nextLocalId = -1000000;

   public DebrisEntity(EntityType<? extends DebrisEntity> type, Level level) {
      super(type, level);
   }

   protected void defineSynchedData(Builder builder) {
      builder.define(DATA_PIECE, 0);
      builder.define(DATA_ATTITUDE, new Quaternionf());
      builder.define(DATA_SPIN, new Vector3f());
      builder.define(DATA_STATE, 0);
      builder.define(DATA_BOUNCES, 0);
   }

   public DebrisEntity.Piece piece() {
      return DebrisEntity.Piece.of((Integer)this.entityData.get(DATA_PIECE));
   }

   public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
      super.onSyncedDataUpdated(key);
      if (DATA_PIECE.equals(key)) {
         this.refreshDimensions();
      }

      if (DATA_ATTITUDE.equals(key)) {
         this.attitudeReady = false;
      }
   }

   public EntityDimensions getDimensions(Pose pose) {
      return this.piece().dimensions();
   }

   private static float lightness(DebrisEntity.Piece piece) {
      return Mth.clamp((piece.reach - 0.5F) / 0.5F, 0.0F, 1.0F);
   }

   static double dragAcross(DebrisEntity.Piece piece) {
      return 1.0 - Mth.lerp(lightness(piece), 0.012, 0.03);
   }

   static double dragDown(DebrisEntity.Piece piece) {
      return 1.0 - Mth.lerp(lightness(piece), 0.02, 0.065);
   }

   private static double bounceKeep(DebrisEntity.Piece piece) {
      return Mth.lerp(lightness(piece), 0.18, 0.32);
   }

   public static Quaternionf shahedAttitude(float yawDeg, float pitchDeg) {
      return new Quaternionf().rotationY(yawDeg * (float) (Math.PI / 180.0)).rotateX(pitchDeg * (float) (Math.PI / 180.0));
   }

   public static void burst(ServerLevel level, DebrisEntity.Airframe airframe, Vec3 position, Quaternionfc attitude, Vec3 motion) {
      int ground = level.getHeight(Types.MOTION_BLOCKING_NO_LEAVES, Mth.floor(position.x), Mth.floor(position.z));
      double height = Math.max(0.0, position.y - ground);
      double high = Mth.clamp((height - 8.0) / 52.0, 0.0, 1.0);
      burst(level, airframe, position, attitude, motion, height, Mth.lerp(high, 40.0, 100.0));
   }

   public static void burst(ServerLevel level, DebrisEntity.Airframe airframe, Vec3 position, Quaternionfc attitude, Vec3 motion, double height, double radius) {
      List<DebrisEntity.Spawn> pieces = plan(level.getRandom(), airframe, position, attitude, motion, height, radius);
      DebrisBurstPacket packet = new DebrisBurstPacket(pieces);

      for (ServerPlayer player : level.players()) {
         if (player.connection.hasChannel(DebrisBurstPacket.TYPE)) {
            PacketDistributor.sendToPlayer(player, packet, new CustomPacketPayload[0]);
         }
      }
   }

   public static List<DebrisEntity.Spawn> plan(
      RandomSource random, DebrisEntity.Airframe airframe, Vec3 position, Quaternionfc attitude, Vec3 motion, double height, double radius
   ) {
      List<DebrisEntity.Spawn> out = new ArrayList<>();
      double high = Mth.clamp((height - 8.0) / 52.0, 0.0, 1.0);
      double groundY = position.y - height;
      Vec3 heading = motion.horizontalDistanceSqr() > 1.0E-4 ? new Vec3(motion.x, 0.0, motion.z).normalize() : Vec3.ZERO;
      Vec3 blast = airframe.world(position, attitude, new Vector3f(airframe.centreX, 0.0F, airframe.centreZ));

      for (DebrisEntity.Piece piece : DebrisEntity.Piece.of(airframe)) {
         Vector3f middleOfPiece = new Vector3f(piece.base).add(0.0F, piece.size.y / 2.0F, 0.0F);
         Vec3 middle = airframe.world(position, attitude, middleOfPiece);
         double startY = Math.max(middle.y - piece.pivotHeight(), groundY) + 0.3;
         Vector3f nose = attitude.transform(new Vector3f(0.0F, 0.0F, 1.0F));
         float yRot = (float)Math.toDegrees(Math.atan2(nose.x, nose.z));
         Vec3 dir = new Vec3(middle.x - blast.x + random.nextGaussian() * 0.4, 0.0, middle.z - blast.z + random.nextGaussian() * 0.4);
         if (dir.lengthSqr() < 1.0E-4) {
            dir = new Vec3(random.nextGaussian(), 0.0, random.nextGaussian());
         }

         dir = dir.normalize().add(heading.scale(0.6));
         if (dir.lengthSqr() < 1.0E-4) {
            dir = new Vec3(1.0, 0.0, 0.0);
         }

         dir = dir.normalize();
         double reach = radius * 0.8 * piece.reach * (0.35 + 0.65 * random.nextDouble());
         double up = Mth.lerp(high, 0.55 + random.nextDouble() * 0.45, 0.05 + random.nextDouble() * 0.3);
         int flight = flightTicks(piece, up, Math.max(0.0, startY - groundY));
         double drag = dragAcross(piece);
         double speed = Math.min(6.0, reach * (1.0 - drag) / (1.0 - Math.pow(drag, flight)));
         Vector3f axis = new Vector3f((float)random.nextGaussian(), (float)random.nextGaussian(), (float)random.nextGaussian());
         if (axis.lengthSquared() < 1.0E-4F) {
            axis.set(1.0F, 0.0F, 0.0F);
         }

         float rate = Mth.lerp(lightness(piece), 6.0F, 16.0F) * (0.7F + random.nextFloat() * 0.6F) * (float) (Math.PI / 180.0);
         out.add(
            new DebrisEntity.Spawn(
               piece,
               new Vec3(middle.x, startY, middle.z),
               new Vec3(dir.x * speed, up, dir.z * speed),
               yRot,
               new Quaternionf(attitude),
               axis.normalize().mul(rate)
            )
         );
      }

      return out;
   }

   public static List<DebrisEntity> spawnLocally(Level level, List<DebrisEntity.Spawn> pieces, Consumer<DebrisEntity> add) {
      List<DebrisEntity> made = new ArrayList<>();

      for (DebrisEntity.Spawn spawn : pieces) {
         DebrisEntity debris = (DebrisEntity)((EntityType)ModEntities.DEBRIS.get()).create(level);
         if (debris != null) {
            debris.local = true;
            debris.setId(nextLocalId--);
            debris.setInvisible(true);
            debris.entityData.set(DATA_PIECE, spawn.piece().ordinal());
            debris.refreshDimensions();
            debris.setPos(spawn.position());
            debris.setYRot(spawn.yRot());
            debris.setDeltaMovement(spawn.velocity());
            debris.entityData.set(DATA_ATTITUDE, new Quaternionf(spawn.attitude()));
            debris.entityData.set(DATA_SPIN, new Vector3f(spawn.spin()));
            add.accept(debris);
            made.add(debris);
         }
      }

      return made;
   }

   public static int flightTicks(DebrisEntity.Piece piece, double up, double drop) {
      double y = 0.0;
      double vy = up;
      double drag = dragDown(piece);

      for (int tick = 1; tick <= 600; tick++) {
         vy -= 0.04;
         y += vy;
         vy *= drag;
         if (y <= -drop) {
            return tick;
         }
      }

      return 600;
   }

   public static double flightDistance(DebrisEntity.Piece piece, Vec3 velocity, double drop) {
      int ticks = flightTicks(piece, velocity.y, drop);
      double drag = dragAcross(piece);
      return velocity.horizontalDistance() * (1.0 - Math.pow(drag, ticks)) / (1.0 - drag);
   }

   public void tick() {
      super.tick();
      if (this.level().isClientSide && !this.local) {
         this.followServer();
         this.tumble();
      } else {
         this.fly();
         if (this.level().isClientSide && !this.isRemoved()) {
            this.tumble();
         }
      }
   }

   private void fly() {
      if (++this.age >= 3600) {
         this.discard();
      } else {
         if (!this.level().noCollision(this, this.getBoundingBox().deflate(1.0E-7))) {
            this.moveTowardsClosestSpace(this.getX(), (this.getBoundingBox().minY + this.getBoundingBox().maxY) / 2.0, this.getZ());
         }

         DebrisEntity.Piece piece = this.piece();
         Vec3 before = this.getDeltaMovement().add(0.0, -0.04, 0.0);
         if (!this.onGround()) {
            before = before.add(this.flutter(piece, before));
         }

         this.move(MoverType.SELF, before);
         Vec3 after;
         int state;
         if (this.onGround()) {
            if (before.y < -0.15) {
               after = new Vec3(before.x * 0.65, -before.y * bounceKeep(piece), before.z * 0.65);
               this.entityData.set(DATA_BOUNCES, (Integer)this.entityData.get(DATA_BOUNCES) + 1);
               state = 0;
            } else {
               after = new Vec3(before.x * 0.8, 0.0, before.z * 0.8);
               state = after.horizontalDistanceSqr() < 4.0E-4 ? 2 : 1;
            }
         } else {
            after = new Vec3(before.x * dragAcross(piece), before.y * dragDown(piece), before.z * dragAcross(piece));
            state = 0;
         }

         if (state == 2) {
            after = Vec3.ZERO;
         }

         this.setDeltaMovement(after);
         if ((Integer)this.entityData.get(DATA_STATE) != state) {
            this.entityData.set(DATA_STATE, state);
         }
      }
   }

   private Vec3 flutter(DebrisEntity.Piece piece, Vec3 velocity) {
      float light = lightness(piece);
      if (!(light <= 0.0F) && !(velocity.horizontalDistanceSqr() < 1.0E-6)) {
         Vec3 across = new Vec3(-velocity.z, 0.0, velocity.x).normalize();
         double phase = this.getId() * 1.618;
         double swing = Math.sin(this.age * (0.25 + Math.floorMod(this.getId(), 7) * 0.03) + phase);
         return across.scale(0.018 * light * swing);
      } else {
         return Vec3.ZERO;
      }
   }

   public void lerpTo(double x, double y, double z, float yRot, float xRot, int steps) {
      this.targetX = x;
      this.targetY = y;
      this.targetZ = z;
      this.targetSteps = 3;
      this.setRot(yRot, xRot);
   }

   private void followServer() {
      if (this.targetSteps > 0) {
         double share = 1.0 / this.targetSteps;
         this.setPos(
            this.getX() + (this.targetX - this.getX()) * share,
            this.getY() + (this.targetY - this.getY()) * share,
            this.getZ() + (this.targetZ - this.getZ()) * share
         );
         this.targetSteps--;
      } else if ((Integer)this.entityData.get(DATA_STATE) != 2) {
         Vec3 velocity = this.getDeltaMovement();
         this.setPos(this.getX() + velocity.x, this.getY() + velocity.y, this.getZ() + velocity.z);
      }
   }

   private void tumble() {
      if (!this.attitudeReady) {
         this.attitude.set((Quaternionfc)this.entityData.get(DATA_ATTITUDE));
         this.attitudeO.set(this.attitude);
         Vector3f spin = (Vector3f)this.entityData.get(DATA_SPIN);
         this.spinRate = spin.length();
         if (this.spinRate > 1.0E-6F) {
            this.spinAxis.set(spin).div(this.spinRate);
         } else {
            this.spinAxis.set(1.0F, 0.0F, 0.0F);
         }

         this.bouncesSeen = (Integer)this.entityData.get(DATA_BOUNCES);
         this.attitudeReady = true;
      }

      this.attitudeO.set(this.attitude);
      int bounces = (Integer)this.entityData.get(DATA_BOUNCES);
      if (bounces != this.bouncesSeen) {
         this.bouncesSeen = bounces;
         RandomSource knock = RandomSource.create(this.getId() * 31L + bounces * 1013L);
         this.spinAxis.add((float)knock.nextGaussian() * 0.8F, (float)knock.nextGaussian() * 0.8F, (float)knock.nextGaussian() * 0.8F);
         if (this.spinAxis.lengthSquared() < 1.0E-4F) {
            this.spinAxis.set(0.0F, 0.0F, 1.0F);
         }

         this.spinAxis.normalize();
         this.spinRate *= 0.5F;
      }

      int state = (Integer)this.entityData.get(DATA_STATE);
      if (state == 0) {
         this.settling = 0.0F;
         this.turn(this.spinAxis, this.spinRate);
         this.spinRate *= 0.996F;
      } else {
         Vec3 velocity = this.getDeltaMovement();
         if (state == 1 && velocity.horizontalDistanceSqr() > 1.0E-6) {
            Vector3f axis = new Vector3f((float)velocity.z, 0.0F, (float)(-velocity.x)).normalize();
            float radius = Math.max(0.05F, this.piece().pivotHeight());
            this.turn(axis, (float)velocity.horizontalDistance() / radius * 0.35F);
         }

         this.settling = Math.min(1.0F, this.settling + 0.06F);
         this.attitude.slerp(this.nearestRest(), 0.04F + this.settling * this.settling * 0.4F);
      }
   }

   private void turn(Vector3f axis, float angle) {
      if (angle > 1.0E-5F) {
         new Quaternionf().fromAxisAngleRad(axis, angle).mul(this.attitude, this.attitude);
      }
   }

   private Quaternionf nearestRest() {
      Vector3f forward = this.attitude.transform(new Vector3f(0.0F, 0.0F, 1.0F));
      float heading;
      if (forward.x * forward.x + forward.z * forward.z > 0.1F) {
         heading = (float)Math.atan2(forward.x, forward.z);
      } else {
         Vector3f side = this.attitude.transform(new Vector3f(1.0F, 0.0F, 0.0F));
         heading = (float)Math.atan2(side.x, side.z) - (float) (Math.PI / 2);
      }

      Quaternionf best = null;
      float bestDot = -1.0F;

      for (Quaternionf pose : restPoses(this.piece().lie)) {
         Quaternionf rest = new Quaternionf().rotationY(heading).mul(pose);
         float dot = Math.abs(rest.dot(this.attitude));
         if (dot > bestDot) {
            bestDot = dot;
            best = rest;
         }
      }

      return best;
   }

   private static Quaternionf[] restPoses(DebrisEntity.Lie lie) {
      return switch (lie) {
         case NONE -> new Quaternionf[]{new Quaternionf(), new Quaternionf().rotationZ((float) Math.PI)};
         case X -> new Quaternionf[]{new Quaternionf().rotationX((float) (Math.PI / 2)), new Quaternionf().rotationX((float) (-Math.PI / 2))};
         case Z -> new Quaternionf[]{new Quaternionf().rotationZ((float) (Math.PI / 2)), new Quaternionf().rotationZ((float) (-Math.PI / 2))};
      };
   }

   public Quaternionf renderAttitude(float partialTick, Quaternionf out) {
      return !this.attitudeReady ? out.set((Quaternionfc)this.entityData.get(DATA_ATTITUDE)) : this.attitudeO.slerp(this.attitude, partialTick, out);
   }

   public boolean hurt(DamageSource source, float amount) {
      return false;
   }

   public boolean ignoreExplosion(Explosion explosion) {
      return true;
   }

   public boolean isPickable() {
      return false;
   }

   public boolean isPushable() {
      return false;
   }

   protected void readAdditionalSaveData(CompoundTag tag) {
      this.entityData.set(DATA_PIECE, tag.getInt("Piece"));
      this.age = tag.getInt("Age");
      this.entityData.set(DATA_SPIN, new Vector3f());
      this.entityData.set(DATA_STATE, 2);
      this.entityData.set(DATA_ATTITUDE, new Quaternionf().rotationY(this.getYRot() * (float) (Math.PI / 180.0)));
      this.refreshDimensions();
   }

   public boolean shouldBeSaved() {
      return !this.local && super.shouldBeSaved();
   }

   protected void addAdditionalSaveData(CompoundTag tag) {
      tag.putInt("Piece", (Integer)this.entityData.get(DATA_PIECE));
      tag.putInt("Age", this.age);
   }

   public static enum Airframe {
      SHAHED(1.0F, 0.0F, 0.0F, 0.0F),
      MOLNIYA(1.4F, 0.0F, 0.615F, -0.8F);

      public final float scale;
      final float centreX;
      final float centreZ;
      final float minY;

      private Airframe(float scale, float centreX, float centreZ, float minY) {
         this.scale = scale;
         this.centreX = centreX;
         this.centreZ = centreZ;
         this.minY = minY;
      }

      Vec3 world(Vec3 position, Quaternionfc attitude, Vector3f point) {
         Vector3f p = new Vector3f(point).sub(this.centreX, 0.0F, this.centreZ).mul(this.scale / 16.0F);
         attitude.transform(p);
         return position.add(p.x, p.y - this.minY * this.scale / 16.0, p.z);
      }
   }

   public static enum Lie {
      NONE,
      X,
      Z;
   }

   public static enum Piece {
      SHAHED_MOTOR(DebrisEntity.Airframe.SHAHED, "shahed_debris_motor", 0.0F, 1.9F, -28.5F, 6.0F, 4.8F, 9.0F, DebrisEntity.Lie.NONE, 0.5F),
      SHAHED_WINGS_LEFT(DebrisEntity.Airframe.SHAHED, "shahed_debris_wings_left", -11.61F, -2.22F, -9.92F, 23.23F, 10.23F, 38.16F, DebrisEntity.Lie.NONE, 0.8F),
      SHAHED_WINGS_RIGHT(DebrisEntity.Airframe.SHAHED, "shahed_debris_wings_right", 11.61F, -2.22F, -9.92F, 23.23F, 10.23F, 38.16F, DebrisEntity.Lie.NONE, 0.8F),
      SHAHED_MAIN(DebrisEntity.Airframe.SHAHED, "shahed_debris_main", 0.0F, 0.0F, 0.5F, 6.0F, 6.0F, 49.0F, DebrisEntity.Lie.NONE, 0.5F),
      SHAHED_ELERONS_LEFT(DebrisEntity.Airframe.SHAHED, "shahed_debris_elerons_left", -12.0F, 1.9F, -25.5F, 16.0F, 2.2F, 5.0F, DebrisEntity.Lie.NONE, 1.0F),
      SHAHED_ELERONS_RIGHT(DebrisEntity.Airframe.SHAHED, "shahed_debris_elerons_right", 12.0F, 1.9F, -25.5F, 16.0F, 2.2F, 5.0F, DebrisEntity.Lie.NONE, 1.0F),
      SHAHED_PROP(DebrisEntity.Airframe.SHAHED, "shahed_debris_prop", 0.0F, 2.5F, -32.0F, 18.0F, 1.2F, 0.0F, DebrisEntity.Lie.X, 1.0F),
      MOLNIYA_STICKS_1(DebrisEntity.Airframe.MOLNIYA, "molniya_debris_sticks_1", -4.5F, 0.0F, -2.19F, 1.0F, 1.0F, 42.02F, DebrisEntity.Lie.NONE, 1.0F),
      MOLNIYA_STICKS_2(DebrisEntity.Airframe.MOLNIYA, "molniya_debris_sticks_2", 4.5F, 0.0F, -2.19F, 1.0F, 1.0F, 42.02F, DebrisEntity.Lie.NONE, 1.0F),
      MOLNIYA_MOTOR_PROP(DebrisEntity.Airframe.MOLNIYA, "molniya_debris_motor_prop", 0.0F, -0.1F, -24.7F, 12.4F, 1.2F, 2.6F, DebrisEntity.Lie.NONE, 0.5F),
      MOLNIYA_GUIDES_1(DebrisEntity.Airframe.MOLNIYA, "molniya_debris_guides_1", 0.0F, -0.3F, -23.1F, 11.0F, 1.6F, 0.6F, DebrisEntity.Lie.X, 1.0F),
      MOLNIYA_GUIDES_2(DebrisEntity.Airframe.MOLNIYA, "molniya_debris_guides_2", 0.0F, -0.3F, -11.7F, 11.0F, 1.6F, 0.6F, DebrisEntity.Lie.X, 1.0F),
      MOLNIYA_GUIDES_3(DebrisEntity.Airframe.MOLNIYA, "molniya_debris_guides_3", 0.0F, -0.3F, -0.2F, 11.0F, 1.6F, 0.6F, DebrisEntity.Lie.X, 1.0F),
      MOLNIYA_GUIDES_4(DebrisEntity.Airframe.MOLNIYA, "molniya_debris_guides_4", 0.0F, -0.3F, 17.3F, 11.0F, 1.6F, 0.6F, DebrisEntity.Lie.X, 1.0F),
      MOLNIYA_WING0(DebrisEntity.Airframe.MOLNIYA, "molniya_debris_wing0", 0.0F, -0.3F, 22.1F, 26.0F, 1.6F, 8.2F, DebrisEntity.Lie.NONE, 0.8F),
      MOLNIYA_MAIN(DebrisEntity.Airframe.MOLNIYA, "molniya_debris_main", 0.0F, -0.3F, -5.95F, 13.0F, 1.6F, 10.1F, DebrisEntity.Lie.NONE, 0.5F),
      MOLNIYA_WING1(DebrisEntity.Airframe.MOLNIYA, "molniya_debris_wing1", -13.9F, -0.3F, -5.95F, 20.2F, 1.6F, 10.1F, DebrisEntity.Lie.NONE, 0.8F),
      MOLNIYA_WING4(DebrisEntity.Airframe.MOLNIYA, "molniya_debris_wing4", 0.0F, -0.15F, 23.0F, 1.0F, 10.02F, 8.11F, DebrisEntity.Lie.Z, 0.8F),
      MOLNIYA_SERVO(DebrisEntity.Airframe.MOLNIYA, "molniya_debris_servo", -1.0F, 0.8F, 24.12F, 1.0F, 5.83F, 6.23F, DebrisEntity.Lie.Z, 1.0F),
      MOLNIYA_ELERONS_MIDDLE(DebrisEntity.Airframe.MOLNIYA, "molniya_debris_elerons_middle", 0.0F, 0.2F, 25.6F, 23.6F, 0.6F, 1.2F, DebrisEntity.Lie.NONE, 1.0F),
      MOLNIYA_ELERONS_LEFT(DebrisEntity.Airframe.MOLNIYA, "molniya_debris_elerons_left", -14.4F, -0.1F, -1.95F, 15.2F, 0.8F, 2.1F, DebrisEntity.Lie.NONE, 1.0F),
      MOLNIYA_ELERONS_RIGHT(DebrisEntity.Airframe.MOLNIYA, "molniya_debris_elerons_right", 14.4F, -0.1F, -1.95F, 15.2F, 0.8F, 2.1F, DebrisEntity.Lie.NONE, 1.0F),
      MOLNIYA_BATTERY_1(DebrisEntity.Airframe.MOLNIYA, "molniya_debris_battery_1", -1.3F, 1.1F, -5.7F, 2.2F, 1.9F, 4.6F, DebrisEntity.Lie.NONE, 0.5F),
      MOLNIYA_BATTERY_2(DebrisEntity.Airframe.MOLNIYA, "molniya_debris_battery_2", 1.3F, 1.1F, -5.7F, 2.2F, 1.9F, 4.6F, DebrisEntity.Lie.NONE, 0.5F),
      MOLNIYA_WING3(DebrisEntity.Airframe.MOLNIYA, "molniya_debris_wing3", 13.9F, -0.3F, -5.95F, 20.2F, 1.6F, 10.1F, DebrisEntity.Lie.NONE, 0.8F);

      public final DebrisEntity.Airframe airframe;
      public final String model;
      public final Vector3f base;
      public final Vector3f size;
      public final DebrisEntity.Lie lie;
      public final float reach;

      private Piece(DebrisEntity.Airframe airframe, String model, float x, float y, float z, float sx, float sy, float sz, DebrisEntity.Lie lie, float reach) {
         this.airframe = airframe;
         this.model = model;
         this.base = new Vector3f(x, y, z);
         this.size = new Vector3f(sx, sy, sz);
         this.lie = lie;
         this.reach = reach;
      }

      public float visualHeight() {
         return this.size.y * this.airframe.scale / 16.0F;
      }

      public float pivotHeight() {
         float thick = switch (this.lie) {
            case NONE -> this.size.y;
            case X -> this.size.z;
            case Z -> this.size.x;
         };
         return thick * this.airframe.scale / 32.0F;
      }

      EntityDimensions dimensions() {
         float s = this.airframe.scale / 16.0F;
         float width = Mth.clamp(Math.max(this.size.x, this.size.z) * s, 0.3F, 1.2F);
         float height = Mth.clamp(this.pivotHeight() * 2.0F, 0.1F, 0.5F);
         return EntityDimensions.scalable(width, height);
      }

      public static DebrisEntity.Piece of(int index) {
         DebrisEntity.Piece[] all = values();
         return all[Mth.clamp(index, 0, all.length - 1)];
      }

      static List<DebrisEntity.Piece> of(DebrisEntity.Airframe airframe) {
         List<DebrisEntity.Piece> out = new ArrayList<>();

         for (DebrisEntity.Piece piece : values()) {
            if (piece.airframe == airframe) {
               out.add(piece);
            }
         }

         return out;
      }
   }

   public record Spawn(DebrisEntity.Piece piece, Vec3 position, Vec3 velocity, float yRot, Quaternionf attitude, Vector3f spin) {
   }
}
