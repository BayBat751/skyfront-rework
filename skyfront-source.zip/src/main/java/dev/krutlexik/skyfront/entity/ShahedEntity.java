package dev.krutlexik.skyfront.entity;

import dev.krutlexik.skyfront.client.ClientLatency;
import dev.krutlexik.skyfront.client.sound.ClientSoundHelper;
import dev.krutlexik.skyfront.compat.sbw.SbwCompat;
import dev.krutlexik.skyfront.compat.sbw.SbwVehicles;
import dev.krutlexik.skyfront.config.SkyfrontConfig;
import dev.krutlexik.skyfront.item.ShahedItem;
import dev.krutlexik.skyfront.network.NetworkHandler;
import dev.krutlexik.skyfront.network.ShahedExplosionPacket;
import dev.krutlexik.skyfront.network.ShahedRemovePacket;
import dev.krutlexik.skyfront.network.ShahedSpawnPacket;
import dev.krutlexik.skyfront.seeker.SeekerHooks;
import dev.krutlexik.skyfront.util.ChunkLoadHelper;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.Entity.RemovalReason;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.minecraft.world.level.levelgen.Heightmap.Types;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.AnimationState;
import software.bernie.geckolib.animation.PlayState;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.animation.AnimatableManager.ControllerRegistrar;
import software.bernie.geckolib.util.GeckoLibUtil;

public class ShahedEntity extends Projectile implements GeoEntity {
   private static final EntityDataAccessor<BlockPos> TARGET_POS = SynchedEntityData.defineId(ShahedEntity.class, EntityDataSerializers.BLOCK_POS);
   private static final EntityDataAccessor<Boolean> IS_DIVING = SynchedEntityData.defineId(ShahedEntity.class, EntityDataSerializers.BOOLEAN);
   private static final EntityDataAccessor<Boolean> IS_FALLING = SynchedEntityData.defineId(ShahedEntity.class, EntityDataSerializers.BOOLEAN);
   private static final EntityDataAccessor<String> DIVE_MODE = SynchedEntityData.defineId(ShahedEntity.class, EntityDataSerializers.STRING);
   private static final EntityDataAccessor<Float> HEALTH_FRACT = SynchedEntityData.defineId(ShahedEntity.class, EntityDataSerializers.FLOAT);
   private static final EntityDataAccessor<Integer> SWERVE_DIR = SynchedEntityData.defineId(ShahedEntity.class, EntityDataSerializers.INT);
   public static final int STATE_GUIDED = 0;
   public static final int STATE_PARKED = 1;
   public static final int STATE_TAKEOFF = 2;
   public static final int STATE_CLIMB = 3;
   public static final int STATE_TURN = 4;
   public static final int STATE_RAIL = 5;
   private static final EntityDataAccessor<Integer> LAUNCH_STATE = SynchedEntityData.defineId(ShahedEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Integer> CRUISE_ALT = SynchedEntityData.defineId(ShahedEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Boolean> FINAL_LEG = SynchedEntityData.defineId(ShahedEntity.class, EntityDataSerializers.BOOLEAN);
   private static final EntityDataAccessor<Float> DIVE_PROGRESS = SynchedEntityData.defineId(ShahedEntity.class, EntityDataSerializers.FLOAT);
   public static final double CRUISE_SPEED = 1.5;
   public static final double DIVE_SPEED = 3.6;
   private static final float BLAST_SCALE = 1.5F;
   private static final float EXPLOSION_POWER = 18.0F;
   private static final float EXPLOSION_RADIUS = 37.5F;
   private static final float SBW_VEHICLE_DIRECT_HIT_DAMAGE = 1200.0F;
   private static final float SBW_VEHICLE_EXPLOSION_DAMAGE = 1350.0F;
   private static final float SBW_VEHICLE_EXPLOSION_RADIUS = 24.0F;
   private boolean isDiving = false;
   private float diveProgress = 0.0F;
   private double diveDistance = 150.0;
   private double diveTransitionDistance = 180.0;
   private Vec3 lastDirection = new Vec3(0.0, -1.0, 0.0);
   private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
   private int syncTickCounter = 0;
   private static final int SYNC_INTERVAL = 40;
   private boolean initialPacketSent = false;
   private Vec3 serverTargetPos = null;
   private static final double CORRECTION_SNAP_DISTANCE = 30.0;
   private static final double CORRECTION_SHARE = 0.12;
   private boolean soundStarted = false;
   private float droneHealth = -1.0F;
   private boolean isFalling = false;
   private float postFallDamage = 0.0F;
   private boolean pendingSelfDiscard = false;
   private Vec3 takeoffOrigin = null;
   private Vec3 launchOrigin = null;
   private int[] route = new int[0];
   private int routeIndex = 0;
   private boolean targetGroundResolved = false;
   private static final int FALLBACK_TARGET_Y = 64;
   private BlockPos boundTerminal = null;
   private float destroyRot = 0.0F;
   private float rollDeg = 0.0F;
   private float prevRollDeg = 0.0F;
   private static final double RAIL_ACCELERATION = 0.16;
   private static final double RAIL_EXIT_SPEED = 0.9;
   private boolean onRail;
   private float railPitch;
   private double railRun;
   @Nullable
   private Vec3 railStart;

   public ShahedEntity(EntityType<? extends ShahedEntity> type, Level level) {
      super(type, level);
      this.setNoGravity(true);
      this.noPhysics = true;
   }

   public ShahedEntity(Level level, Vec3 startPos, BlockPos targetPos, String diveMode) {
      this((EntityType<? extends ShahedEntity>)ModEntities.SHAHED.get(), level);
      this.setPos(startPos);
      this.launchOrigin = startPos;
      this.entityData.set(TARGET_POS, targetPos);
      this.entityData.set(DIVE_MODE, diveMode);
      if (diveMode.equals("high")) {
         this.diveDistance = 350.0;
         this.diveTransitionDistance = 500.0;
      } else {
         this.diveDistance = 150.0;
         this.diveTransitionDistance = 280.0;
      }

      Vec3 targetVec = Vec3.atCenterOf(targetPos);
      Vec3 dir = targetVec.subtract(startPos);
      if (dir.lengthSqr() > 1.0E-4) {
         this.lastDirection = dir.normalize();
      }
   }

   public void seatOnRail(Vec3 pos, float yawDeg, float pitchDeg, double run) {
      this.initParked(pos, yawDeg);
      this.onRail = true;
      this.railPitch = pitchDeg;
      this.railRun = run;
      this.setXRot(-pitchDeg);
      this.xRotO = -pitchDeg;
      this.noPhysics = true;
      this.setNoGravity(true);
   }

   public boolean isOnRail() {
      return this.onRail;
   }

   public void initParked(Vec3 pos, float yawDeg) {
      this.setPos(pos);
      this.setYRot(yawDeg);
      this.yRotO = yawDeg;
      this.setXRot(0.0F);
      this.entityData.set(LAUNCH_STATE, 1);
      this.noPhysics = false;
      this.setNoGravity(false);
      this.setDeltaMovement(Vec3.ZERO);
   }

   public void launchFromGround(int[] routePoints, int altitude, String diveMode) {
      this.route = (int[])routePoints.clone();
      this.routeIndex = 0;
      this.entityData.set(CRUISE_ALT, altitude);
      this.setWaypointTarget(this.route[0], this.route[1], this.route.length <= 2);
      this.entityData.set(FINAL_LEG, this.route.length <= 2);
      this.entityData.set(DIVE_MODE, diveMode);
      this.entityData.set(LAUNCH_STATE, 2);
      this.takeoffOrigin = this.position();
      this.launchOrigin = this.position();
      this.noPhysics = false;
      this.setNoGravity(true);
      if (this.onRail) {
         this.entityData.set(LAUNCH_STATE, 5);
         this.railStart = this.position();
         this.noPhysics = true;
      }
   }

   public int getLaunchState() {
      return (Integer)this.entityData.get(LAUNCH_STATE);
   }

   public boolean isParked() {
      return (Integer)this.entityData.get(LAUNCH_STATE) == 1;
   }

   public boolean isFinalLeg() {
      return (Boolean)this.entityData.get(FINAL_LEG);
   }

   public float getSyncedDiveProgress() {
      return (Float)this.entityData.get(DIVE_PROGRESS);
   }

   @Nullable
   public Vec3 getLaunchOrigin() {
      return this.launchOrigin;
   }

   public void setDroneHealthDirect(float health) {
      this.droneHealth = health;
      this.entityData.set(HEALTH_FRACT, health < 0.0F ? 1.0F : Math.max(0.0F, health / maxDroneHealth()));
   }

   public float getDroneHealth() {
      return this.droneHealth;
   }

   public void setBoundTerminal(@Nullable BlockPos pos) {
      this.boundTerminal = pos;
   }

   @Nullable
   public BlockPos getBoundTerminal() {
      return this.boundTerminal;
   }

   public boolean canBeCollidedWith() {
      return this.isParked();
   }

   public InteractionResult interact(Player player, InteractionHand hand) {
      if (this.isParked() && player.isShiftKeyDown()) {
         if (!this.level().isClientSide) {
            ItemStack stack = this.toItem();
            if (!player.addItem(stack)) {
               player.drop(stack, false);
            }

            this.discardAsItem();
         }

         return InteractionResult.sidedSuccess(this.level().isClientSide);
      } else {
         return super.interact(player, hand);
      }
   }

   public ItemStack toItem() {
      ItemStack stack = new ItemStack(SeekerHooks.itemFor(this));
      ShahedItem.writeData(stack, this.getUUID(), this.droneHealth, this.boundTerminal, this.level().dimension().location().toString());
      return stack;
   }

   public void discardAsItem() {
      this.pendingSelfDiscard = true;
      this.discard();
   }

   public boolean shouldRenderAtSqrDistance(double distance) {
      return distance < 490000.0;
   }

   public void setServerPosition(Vec3 pos) {
      if (this.level().isClientSide) {
         Vec3 target = pos.add(this.getDeltaMovement().scale(ClientLatency.packetAgeTicks()));
         if (target.distanceToSqr(this.position()) > 900.0) {
            this.setPos(target.x, target.y, target.z);
            this.serverTargetPos = null;
         } else {
            this.serverTargetPos = target;
         }
      }
   }

   private void tickClientCorrection() {
      if (this.serverTargetPos != null) {
         this.serverTargetPos = this.serverTargetPos.add(this.getDeltaMovement());
         Vec3 error = this.serverTargetPos.subtract(this.position());
         if (!(error.lengthSqr() < 1.0E-6)) {
            this.setPos(this.getX() + error.x * 0.12, this.getY() + error.y * 0.12, this.getZ() + error.z * 0.12);
         }
      }
   }

   public void lerpTo(double x, double y, double z, float yRot, float xRot, int steps) {
      if (!this.level().isClientSide) {
         super.lerpTo(x, y, z, yRot, xRot, steps);
      } else {
         this.setServerPosition(new Vec3(x, y, z));
         this.setRot(yRot, xRot);
      }
   }

   public void lerpMotion(double x, double y, double z) {
      this.setDeltaMovement(x, y, z);
   }

   protected void defineSynchedData(Builder builder) {
      builder.define(TARGET_POS, BlockPos.ZERO);
      builder.define(IS_DIVING, false);
      builder.define(IS_FALLING, false);
      builder.define(DIVE_MODE, "low");
      builder.define(HEALTH_FRACT, 1.0F);
      builder.define(SWERVE_DIR, 0);
      builder.define(LAUNCH_STATE, 0);
      builder.define(CRUISE_ALT, 150);
      builder.define(FINAL_LEG, true);
      builder.define(DIVE_PROGRESS, 0.0F);
   }

   public boolean isPickable() {
      return !this.isRemoved();
   }

   protected boolean canHitEntity(Entity entity) {
      return !(entity instanceof ShahedEntity) && !(entity instanceof Projectile) ? super.canHitEntity(entity) : false;
   }

   public void tick() {
      super.tick();
      if ((Boolean)this.entityData.get(IS_FALLING)) {
         this.tickFalling();
      } else {
         int launchState = (Integer)this.entityData.get(LAUNCH_STATE);
         if (launchState == 1) {
            this.tickParked();
         } else if (launchState != 0) {
            this.tickLaunchSequence(launchState);
         } else if (this.level().isClientSide) {
            if (!this.soundStarted) {
               ClientSoundHelper.startShahedSound(this);
               this.soundStarted = true;
            }

            this.tickClientCorrection();
            Vec3 synced = this.getDeltaMovement();
            this.setPos(this.getX() + synced.x, this.getY() + synced.y, this.getZ() + synced.z);
         } else {
            BlockPos target = (BlockPos)this.entityData.get(TARGET_POS);
            Vec3 targetVec = Vec3.atCenterOf(target);
            String mode = (String)this.entityData.get(DIVE_MODE);
            if (mode.equals("high")) {
               this.diveDistance = 350.0;
               this.diveTransitionDistance = 500.0;
            } else {
               this.diveDistance = 150.0;
               this.diveTransitionDistance = 280.0;
            }

            Vec3 currentPos = this.position();
            double horizontalDist = Math.sqrt(Math.pow(targetVec.x - currentPos.x, 2.0) + Math.pow(targetVec.z - currentPos.z, 2.0));
            boolean finalLeg = (Boolean)this.entityData.get(FINAL_LEG);
            boolean passed = horizontalDist < 40.0
               && new Vec3(targetVec.x - currentPos.x, 0.0, targetVec.z - currentPos.z).dot(new Vec3(this.lastDirection.x, 0.0, this.lastDirection.z)) < 0.0;
            if (!finalLeg && !this.level().isClientSide && (horizontalDist < 24.0 || passed)) {
               this.routeIndex++;
               int base = this.routeIndex * 2;
               if (base + 1 < this.route.length) {
                  boolean nowFinal = base + 2 >= this.route.length;
                  this.setWaypointTarget(this.route[base], this.route[base + 1], nowFinal);
                  this.entityData.set(FINAL_LEG, nowFinal);
                  finalLeg = nowFinal;
               } else {
                  this.entityData.set(FINAL_LEG, true);
                  finalLeg = true;
               }

               target = (BlockPos)this.entityData.get(TARGET_POS);
               targetVec = Vec3.atCenterOf(target);
               horizontalDist = Math.sqrt(Math.pow(targetVec.x - currentPos.x, 2.0) + Math.pow(targetVec.z - currentPos.z, 2.0));
            }

            if (finalLeg && !this.level().isClientSide) {
               this.resolveTargetGround(target);
               target = (BlockPos)this.entityData.get(TARGET_POS);
               targetVec = Vec3.atCenterOf(target);
            }

            Vec3 toTargetFlat = new Vec3(targetVec.x - currentPos.x, 0.0, targetVec.z - currentPos.z);
            Vec3 headingFlat = new Vec3(this.lastDirection.x, 0.0, this.lastDirection.z);
            boolean alignedWithTarget = toTargetFlat.lengthSqr() < 1.0E-4
               || headingFlat.lengthSqr() < 1.0E-4
               || toTargetFlat.normalize().dot(headingFlat.normalize()) > 0.94;
            float targetProgress = 0.0F;
            boolean wasNotDiving = !this.isDiving;
            if (finalLeg && alignedWithTarget && horizontalDist < this.diveTransitionDistance) {
               if (horizontalDist < this.diveDistance) {
                  this.isDiving = true;
                  targetProgress = 1.0F;
               } else {
                  targetProgress = 1.0F - (float)((horizontalDist - this.diveDistance) / (this.diveTransitionDistance - this.diveDistance));
               }
            }

            this.diveProgress = this.diveProgress + (targetProgress - this.diveProgress) * 0.035F;
            this.diveProgress = Math.max(0.0F, Math.min(1.0F, this.diveProgress));
            if (Math.abs(this.diveProgress - (Float)this.entityData.get(DIVE_PROGRESS)) > 0.02F) {
               this.entityData.set(DIVE_PROGRESS, this.diveProgress);
            }

            Vec3 toTarget = targetVec.subtract(currentPos);
            Vec3 moveDirection;
            if (toTarget.lengthSqr() < 4.0) {
               moveDirection = this.lastDirection;
            } else if (this.diveProgress < 0.01F) {
               Vec3 horizontalTarget = new Vec3(targetVec.x, currentPos.y, targetVec.z);
               Vec3 diff = horizontalTarget.subtract(currentPos);
               if (diff.lengthSqr() > 1.0E-4) {
                  moveDirection = diff.normalize();
               } else {
                  moveDirection = toTarget.normalize();
               }
            } else {
               Vec3 horizontalTarget = new Vec3(targetVec.x, currentPos.y, targetVec.z);
               Vec3 horizontalDiff = horizontalTarget.subtract(currentPos);
               Vec3 horizontalDir = horizontalDiff.lengthSqr() > 1.0E-4 ? horizontalDiff.normalize() : this.lastDirection;
               Vec3 directDir = toTarget.lengthSqr() > 1.0E-4 ? toTarget.normalize() : this.lastDirection;
               moveDirection = new Vec3(
                  horizontalDir.x + (directDir.x - horizontalDir.x) * this.diveProgress,
                  horizontalDir.y + (directDir.y - horizontalDir.y) * this.diveProgress,
                  horizontalDir.z + (directDir.z - horizontalDir.z) * this.diveProgress
               );
               if (moveDirection.lengthSqr() > 1.0E-4) {
                  moveDirection = moveDirection.normalize();
               } else {
                  moveDirection = this.lastDirection;
               }
            }

            if (moveDirection.lengthSqr() > 1.0E-4 && this.lastDirection.lengthSqr() > 1.0E-4) {
               double maxTurn = Math.toRadians(2.5 + 2.5 * this.diveProgress);
               moveDirection = turnToward(this.lastDirection, moveDirection, maxTurn);
            }

            if (moveDirection.lengthSqr() > 1.0E-4) {
               this.lastDirection = moveDirection;
            }

            double speed = 1.5 + 2.1 * this.diveProgress;
            Vec3 motion = moveDirection.scale(speed);
            this.setDeltaMovement(motion);
            if (motion.lengthSqr() > 1.0E-4) {
               this.setYRot((float)(Math.atan2(motion.x, motion.z) * (180.0 / Math.PI)));
               this.setXRot((float)(Math.atan2(motion.y, Math.sqrt(motion.x * motion.x + motion.z * motion.z)) * (180.0 / Math.PI)));
            }

            if (wasNotDiving && this.isDiving) {
               this.entityData.set(IS_DIVING, true);
            }

            HitResult hitResult = ProjectileUtil.getHitResultOnMoveVector(this, this::canHitEntity);
            if (hitResult.getType() != Type.MISS) {
               this.onHit(hitResult);
            } else if (this.isDiving && this.getY() <= targetVec.y) {
               this.explode();
            } else if (!this.checkFlightRange()) {
               this.setPos(this.getX() + motion.x, this.getY() + motion.y, this.getZ() + motion.z);
               if ((Float)this.entityData.get(HEALTH_FRACT) <= 0.25F) {
                  this.tickDamagedEngineEffects();
               }

               this.sendFlightSync();
            }
         }
      }
   }

   private void maintainFlightChunks() {
      if (this.level() instanceof ServerLevel serverLevel && this.tickCount % 4 == 0) {
         ChunkPos current = this.chunkPosition();
         ChunkLoadHelper.keepTicking(serverLevel, current);
         Vec3 motion = this.getDeltaMovement();
         double speed = motion.horizontalDistance();
         if (!(speed < 0.001)) {
            double dirX = motion.x / speed;
            double dirZ = motion.z / speed;
            ChunkPos last = current;

            for (double ahead = 16.0; ahead <= 48.0; ahead += 16.0) {
               ChunkPos next = ChunkLoadHelper.chunkAt(this.getX() + dirX * ahead, this.getZ() + dirZ * ahead);
               if (!next.equals(last)) {
                  ChunkLoadHelper.keepTicking(serverLevel, next);
                  last = next;
               }
            }

            for (double aheadx = 96.0; aheadx <= 160.0; aheadx += 64.0) {
               ChunkPos far = ChunkLoadHelper.chunkAt(this.getX() + dirX * aheadx, this.getZ() + dirZ * aheadx);
               ChunkLoadHelper.preloadAhead(serverLevel, far);
            }
         }
      }
   }

   private boolean checkFlightRange() {
      if (!this.level().isClientSide && this.launchOrigin != null && !this.isFalling) {
         int max = (Integer)SkyfrontConfig.MAX_FLIGHT_RANGE.get();
         double dx = this.getX() - this.launchOrigin.x;
         double dz = this.getZ() - this.launchOrigin.z;
         if (dx * dx + dz * dz > (double)max * max) {
            this.startFalling();
            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private void setWaypointTarget(int x, int z, boolean isFinal) {
      int y = isFinal ? 64 : (Integer)this.entityData.get(CRUISE_ALT);
      this.entityData.set(TARGET_POS, new BlockPos(x, y, z));
      this.targetGroundResolved = false;
   }

   private void resolveTargetGround(BlockPos target) {
      if (!this.targetGroundResolved && this.level() instanceof ServerLevel serverLevel) {
         if (serverLevel.hasChunkAt(target)) {
            int groundY = serverLevel.getHeight(Types.MOTION_BLOCKING, target.getX(), target.getZ());
            this.entityData.set(TARGET_POS, new BlockPos(target.getX(), groundY, target.getZ()));
            this.targetGroundResolved = true;
         } else if (this.tickCount % 20 == 0) {
            ChunkLoadHelper.preloadAhead(serverLevel, new ChunkPos(target));
         }
      }
   }

   private static Vec3 turnToward(Vec3 from, Vec3 to, double maxAngleRad) {
      Vec3 a = from.normalize();
      Vec3 b = to.normalize();
      double dot = Math.max(-1.0, Math.min(1.0, a.dot(b)));
      double angle = Math.acos(dot);
      if (!(angle <= maxAngleRad) && !(angle < 1.0E-4)) {
         if (angle > 3.1405926535897932) {
            b = b.add(0.01, 0.0, 0.01).normalize();
         }

         Vec3 result = a.add(b.subtract(a).scale(maxAngleRad / angle));
         return result.lengthSqr() > 1.0E-8 ? result.normalize() : b;
      } else {
         return b;
      }
   }

   private void sendFlightSync() {
      this.maintainFlightChunks();
      BlockPos target = (BlockPos)this.entityData.get(TARGET_POS);
      String mode = (String)this.entityData.get(DIVE_MODE);
      if (!this.initialPacketSent) {
         this.initialPacketSent = true;
         NetworkHandler.sendToAllPlayers(
            new ShahedSpawnPacket(
               this.getId(),
               this.position(),
               target,
               mode,
               (Float)this.entityData.get(HEALTH_FRACT),
               (Boolean)this.entityData.get(IS_FALLING),
               (Float)this.entityData.get(DIVE_PROGRESS),
               (Boolean)this.entityData.get(FINAL_LEG)
            )
         );
      }

      this.syncTickCounter++;
      if (this.syncTickCounter >= 40) {
         this.syncTickCounter = 0;
         NetworkHandler.sendToAllPlayers(
            new ShahedSpawnPacket(
               this.getId(),
               this.position(),
               target,
               mode,
               (Float)this.entityData.get(HEALTH_FRACT),
               (Boolean)this.entityData.get(IS_FALLING),
               (Float)this.entityData.get(DIVE_PROGRESS),
               (Boolean)this.entityData.get(FINAL_LEG)
            )
         );
      }
   }

   private void tickParked() {
      if (!this.level().isClientSide) {
         if (this.onRail) {
            this.setDeltaMovement(Vec3.ZERO);
         } else {
            if (!this.onGround()) {
               this.setDeltaMovement(this.getDeltaMovement().add(0.0, -0.06, 0.0).multiply(0.98, 0.98, 0.98));
               this.move(MoverType.SELF, this.getDeltaMovement());
            } else {
               this.setDeltaMovement(Vec3.ZERO);
            }
         }
      }
   }

   private void tickLaunchSequence(int state) {
      if (this.level().isClientSide) {
         if (!this.soundStarted) {
            ClientSoundHelper.startShahedSound(this);
            this.soundStarted = true;
         }

         this.tickClientCorrection();
         Vec3 m = this.getDeltaMovement();
         if (state == 2) {
            this.setPos(this.getX() + m.x, this.getY(), this.getZ() + m.z);
         } else {
            this.setPos(this.getX() + m.x, this.getY() + m.y, this.getZ() + m.z);
         }
      } else {
         double yawRad = Math.toRadians(this.getYRot());
         Vec3 forward = new Vec3(Math.sin(yawRad), 0.0, Math.cos(yawRad));
         BlockPos target = (BlockPos)this.entityData.get(TARGET_POS);
         int cruiseAlt = (Integer)this.entityData.get(CRUISE_ALT);
         switch (state) {
            case 2:
               if (this.takeoffOrigin == null) {
                  this.takeoffOrigin = this.position();
               }

               double run = this.position().multiply(1.0, 0.0, 1.0).distanceTo(this.takeoffOrigin.multiply(1.0, 0.0, 1.0));
               double speed = Math.min(0.12 + run * 0.032, 0.9);
               Vec3 motionxx = forward.scale(speed).add(0.0, -0.08, 0.0);
               this.setDeltaMovement(motionxx);
               this.move(MoverType.SELF, motionxx);
               this.setXRot(0.0F);
               if (this.horizontalCollision) {
                  this.explode();
                  return;
               }

               if (run >= 24.0) {
                  this.entityData.set(LAUNCH_STATE, 3);
                  this.noPhysics = true;
               }
               break;
            case 3:
               Vec3 current = this.getDeltaMovement();
               double fwdSpeed = Math.min(current.horizontalDistance() + 0.008, 1.5);
               double remaining = cruiseAlt - this.getY();
               double targetVy = Math.max(0.03, Math.min(remaining * 0.04, 0.3));
               double vyx = current.y + (targetVy - current.y) * 0.045;
               Vec3 motionx = forward.scale(fwdSpeed).add(0.0, vyx, 0.0);
               this.setDeltaMovement(motionx);
               if (this.checkFlightCollision()) {
                  return;
               }

               this.setPos(this.getX() + motionx.x, this.getY() + motionx.y, this.getZ() + motionx.z);
               this.setXRot((float)(Math.atan2(motionx.y, motionx.horizontalDistance()) * (180.0 / Math.PI)));
               if (this.getY() >= cruiseAlt - 0.5) {
                  this.entityData.set(LAUNCH_STATE, 4);
               }
               break;
            case 4:
               Vec3 targetVec = Vec3.atCenterOf(target);
               float bearing = (float)(Math.atan2(targetVec.x - this.getX(), targetVec.z - this.getZ()) * (180.0 / Math.PI));
               float delta = Mth.wrapDegrees(bearing - this.getYRot());
               float step = Mth.clamp(delta, -2.2F, 2.2F);
               this.setYRot(this.getYRot() + step);
               double newYawRad = Math.toRadians(this.getYRot());
               Vec3 dir = new Vec3(Math.sin(newYawRad), 0.0, Math.cos(newYawRad));
               double vy = Mth.clamp((cruiseAlt - this.getY()) * 0.1, -0.1, 0.1);
               Vec3 motion = dir.scale(1.5).add(0.0, vy, 0.0);
               this.setDeltaMovement(motion);
               if (this.checkFlightCollision()) {
                  return;
               }

               this.setPos(this.getX() + motion.x, this.getY() + motion.y, this.getZ() + motion.z);
               this.setXRot(0.0F);
               if (Math.abs(delta) < 4.0F) {
                  this.lastDirection = dir;
                  this.entityData.set(LAUNCH_STATE, 0);
               }
               break;
            case 5:
               double pitch = Math.toRadians(this.railPitch);
               Vec3 along = new Vec3(forward.x * Math.cos(pitch), Math.sin(pitch), forward.z * Math.cos(pitch));
               double speedx = Math.min(this.getDeltaMovement().length() + 0.16, 0.9);
               Vec3 motionxxx = along.scale(speedx);
               this.setDeltaMovement(motionxxx);
               this.setPos(this.getX() + motionxxx.x, this.getY() + motionxxx.y, this.getZ() + motionxxx.z);
               if (this.railStart == null) {
                  this.railStart = this.position();
               }

               if (this.position().distanceTo(this.railStart) >= this.railRun) {
                  this.onRail = false;
                  this.entityData.set(LAUNCH_STATE, 3);
               }
         }

         this.sendFlightSync();
      }
   }

   private boolean checkFlightCollision() {
      HitResult hitResult = ProjectileUtil.getHitResultOnMoveVector(this, this::canHitEntity);
      if (hitResult.getType() != Type.MISS) {
         this.onHit(hitResult);
         return true;
      } else {
         return false;
      }
   }

   public boolean hurt(DamageSource source, float amount) {
      if (this.level().isClientSide || this.isRemoved() || amount <= 0.0F) {
         return false;
      } else if (this.isInvulnerableTo(source)) {
         return false;
      } else if (source.getEntity() != this && source.getDirectEntity() != this) {
         Vec3 origin = null;
         Entity direct = source.getDirectEntity();
         if (direct != null && direct != source.getEntity()) {
            origin = direct.position();
         } else if (source.getEntity() instanceof LivingEntity attacker) {
            origin = attacker.getEyePosition();
         } else if (source.getSourcePosition() != null) {
            origin = source.getSourcePosition();
         }

         Vec3 hitPos;
         if (origin != null) {
            AABB box = this.getBoundingBox();
            hitPos = new Vec3(Mth.clamp(origin.x, box.minX, box.maxX), Mth.clamp(origin.y, box.minY, box.maxY), Mth.clamp(origin.z, box.minZ, box.maxZ));
         } else {
            hitPos = this.position().add(0.0, this.getBbHeight() * 0.5, 0.0);
         }

         if (this.level() instanceof ServerLevel serverLevel) {
            this.spawnBulletImpact(serverLevel, hitPos);
         }

         this.level()
            .playSound(null, hitPos.x, hitPos.y, hitPos.z, SoundEvents.NETHERITE_BLOCK_HIT, SoundSource.HOSTILE, 1.4F, 0.7F + this.random.nextFloat() * 0.4F);
         if (amount >= maxDroneHealth() * 2.0F) {
            this.explode();
            return true;
         } else if (this.isFalling) {
            this.postFallDamage += amount;
            if (this.postFallDamage >= maxDroneHealth()) {
               this.explode();
            }

            return true;
         } else {
            if (this.droneHealth < 0.0F) {
               this.droneHealth = (float)((Double)SkyfrontConfig.SHAHED_HEALTH.get()).doubleValue();
            }

            this.droneHealth -= amount;
            this.entityData.set(HEALTH_FRACT, Math.max(0.0F, this.droneHealth / maxDroneHealth()));
            if (this.droneHealth <= 0.0F) {
               if (this.isParked()) {
                  this.explode();
               } else {
                  this.startFalling();
               }
            }

            return true;
         }
      } else {
         return false;
      }
   }

   private static float maxDroneHealth() {
      return (float)Math.max(1.0, (Double)SkyfrontConfig.SHAHED_HEALTH.get());
   }

   private void startFalling() {
      this.isFalling = true;
      this.entityData.set(IS_FALLING, true);
      this.entityData.set(HEALTH_FRACT, 0.0F);
      this.noPhysics = true;
      if ((Integer)this.entityData.get(SWERVE_DIR) == 0) {
         this.entityData.set(SWERVE_DIR, this.random.nextBoolean() ? 1 : -1);
      }

      this.setNoGravity(true);
      Vec3 m = this.getDeltaMovement();
      this.setDeltaMovement(m.x, m.y - 0.05, m.z);
   }

   private void tickDamagedEngineEffects() {
      if (this.level() instanceof ServerLevel serverLevel) {
         this.sendParticlesForced(serverLevel, ParticleTypes.SMOKE, this.getX(), this.getY() + 0.3, this.getZ(), 2, 0.15, 0.1, 0.15, 0.01);
         if (this.random.nextInt(4) == 0) {
            this.sendParticlesForced(serverLevel, ParticleTypes.LARGE_SMOKE, this.getX(), this.getY() + 0.3, this.getZ(), 1, 0.1, 0.1, 0.1, 0.01);
         }

         if (this.random.nextInt(35) == 0) {
            this.level()
               .playSound(
                  null,
                  this.getX(),
                  this.getY(),
                  this.getZ(),
                  SoundEvents.FIREWORK_ROCKET_BLAST,
                  SoundSource.HOSTILE,
                  4.0F,
                  0.5F + this.random.nextFloat() * 0.2F
               );
            this.sendParticlesForced(serverLevel, ParticleTypes.FLAME, this.getX(), this.getY() + 0.2, this.getZ(), 8, 0.3, 0.2, 0.3, 0.06);
            this.sendParticlesForced(serverLevel, ParticleTypes.ELECTRIC_SPARK, this.getX(), this.getY() + 0.3, this.getZ(), 5, 0.2, 0.2, 0.2, 0.15);
            this.sendParticlesForced(serverLevel, ParticleTypes.LARGE_SMOKE, this.getX(), this.getY() + 0.3, this.getZ(), 4, 0.2, 0.2, 0.2, 0.02);
         }
      }
   }

   private void spawnBulletImpact(ServerLevel level, Vec3 pos) {
      this.sendParticlesForced(level, ParticleTypes.CRIT, pos.x, pos.y, pos.z, 6, 0.1, 0.1, 0.1, 0.15);
      this.sendParticlesForced(level, ParticleTypes.ELECTRIC_SPARK, pos.x, pos.y, pos.z, 8, 0.1, 0.1, 0.1, 0.2);
      this.sendParticlesForced(level, ParticleTypes.SMOKE, pos.x, pos.y, pos.z, 3, 0.05, 0.05, 0.05, 0.02);
   }

   private void tickFalling() {
      this.destroyRot += 0.12F;
      Vec3 motion = this.getDeltaMovement();
      double speed = motion.length();
      if (speed < 1.0E-4) {
         motion = new Vec3(0.0, -0.1, 0.0);
         speed = 0.1;
      }

      double blend = Math.min(0.0012 * this.destroyRot, 0.06);
      Vec3 dir = motion.scale(1.0 / speed);
      Vec3 down = new Vec3(0.0, -1.0, 0.0);
      Vec3 newDir = dir.add(down.subtract(dir).scale(blend));
      if (newDir.lengthSqr() > 1.0E-6) {
         newDir = newDir.normalize();
      } else {
         newDir = down;
      }

      double newSpeed = Math.min(speed + 0.02 * Math.max(0.0, -newDir.y), 4.6);
      Vec3 newMotion = newDir.scale(newSpeed).add(0.0, -Math.min(0.002 * this.destroyRot, 0.06), 0.0);
      int fallCurve = (Integer)this.entityData.get(SWERVE_DIR);
      if (fallCurve != 0) {
         double curve = fallCurve * Math.min(this.destroyRot * 0.004, 0.045);
         double cos = Math.cos(curve);
         double sin = Math.sin(curve);
         newMotion = new Vec3(newMotion.x * cos - newMotion.z * sin, newMotion.y, newMotion.x * sin + newMotion.z * cos);
      }

      this.setDeltaMovement(newMotion);
      this.prevRollDeg = this.rollDeg;
      this.rollDeg = this.rollDeg - Math.min(this.destroyRot * 1.5F, 9.0F);
      if (newMotion.lengthSqr() > 1.0E-4) {
         this.setYRot((float)(Math.atan2(newMotion.x, newMotion.z) * (180.0 / Math.PI)));
         this.setXRot((float)(Math.atan2(newMotion.y, Math.sqrt(newMotion.x * newMotion.x + newMotion.z * newMotion.z)) * (180.0 / Math.PI)));
      }

      Vec3 before = this.position();
      if (this.level().isClientSide) {
         if (!this.soundStarted) {
            ClientSoundHelper.startShahedSound(this);
            this.soundStarted = true;
         }

         this.tickClientCorrection();
         this.setPos(this.getX() + newMotion.x, this.getY() + newMotion.y, this.getZ() + newMotion.z);
      } else {
         HitResult hitResult = ProjectileUtil.getHitResultOnMoveVector(this, this::canHitEntity);
         if (hitResult.getType() != Type.MISS) {
            this.onHit(hitResult);
         } else {
            this.setPos(this.getX() + newMotion.x, this.getY() + newMotion.y, this.getZ() + newMotion.z);
            if (this.level() instanceof ServerLevel serverLevel) {
               Vec3 after = this.position();
               int steps = 3;

               for (int i = 0; i < steps; i++) {
                  double t = (double)(i + 1) / steps;
                  double px = before.x + (after.x - before.x) * t;
                  double py = before.y + (after.y - before.y) * t + 0.3;
                  double pz = before.z + (after.z - before.z) * t;
                  this.sendParticlesForced(serverLevel, ParticleTypes.LARGE_SMOKE, px, py, pz, 2, 0.2, 0.2, 0.2, 0.01);
                  if (i == 0) {
                     this.sendParticlesForced(serverLevel, ParticleTypes.CAMPFIRE_COSY_SMOKE, px, py, pz, 1, 0.1, 0.1, 0.1, 0.005);
                  }

                  if (this.random.nextInt(3) == 0) {
                     this.sendParticlesForced(serverLevel, ParticleTypes.FLAME, px, py - 0.1, pz, 1, 0.1, 0.05, 0.1, 0.02);
                  }

                  if (this.random.nextInt(6) == 0) {
                     this.sendParticlesForced(serverLevel, ParticleTypes.LAVA, px, py, pz, 1, 0.05, 0.05, 0.05, 0.05);
                  }
               }

               if (this.random.nextInt(22) == 0) {
                  this.level()
                     .playSound(
                        null,
                        this.getX(),
                        this.getY(),
                        this.getZ(),
                        SoundEvents.FIREWORK_ROCKET_BLAST,
                        SoundSource.HOSTILE,
                        3.5F,
                        0.4F + this.random.nextFloat() * 0.15F
                     );
               }
            }

            if (this.getY() < this.level().getMinBuildHeight() - 8) {
               this.explode();
            } else {
               this.maintainFlightChunks();
               this.syncTickCounter++;
               if (this.syncTickCounter >= 4) {
                  this.syncTickCounter = 0;
                  NetworkHandler.sendToAllPlayers(
                     new ShahedSpawnPacket(
                        this.getId(),
                        this.position(),
                        (BlockPos)this.entityData.get(TARGET_POS),
                        (String)this.entityData.get(DIVE_MODE),
                        (Float)this.entityData.get(HEALTH_FRACT),
                        (Boolean)this.entityData.get(IS_FALLING),
                        (Float)this.entityData.get(DIVE_PROGRESS),
                        (Boolean)this.entityData.get(FINAL_LEG)
                     )
                  );
               }
            }
         }
      }
   }

   protected void onHitBlock(BlockHitResult result) {
      super.onHitBlock(result);
      if (!this.level().isClientSide) {
         this.explode();
      }
   }

   protected void onHitEntity(EntityHitResult result) {
      super.onHitEntity(result);
      if (!this.level().isClientSide) {
         if (SbwCompat.isLoaded()) {
            SbwVehicles.damageVehicleDirectHit(result.getEntity(), this, this.getOwner(), 1200.0F);
         }

         this.explode();
      }
   }

   private void explode() {
      if (!this.level().isClientSide) {
         Vec3 pos = this.position();
         float particleMult = SkyfrontConfig.areExplosionParticlesEnabled() ? SkyfrontConfig.getParticleMultiplier() / 100.0F : 0.0F;
         NetworkHandler.sendToAllPlayers(new ShahedExplosionPacket(pos, particleMult, SkyfrontConfig.areCustomExplosionSoundsEnabled()));
         Entity owner = this.getOwner();
         AABB explosionBox = new AABB(pos.x - 37.5, pos.y - 37.5, pos.z - 37.5, pos.x + 37.5, pos.y + 37.5, pos.z + 37.5);

         for (Entity entity : this.level().getEntities(this, explosionBox)) {
            if (entity instanceof Player targetPlayer) {
               double distance = targetPlayer.position().distanceTo(pos);
               float damage = 0.0F;
               if (distance <= 25.5) {
                  damage = 40.0F;
               } else if (distance <= 30.0) {
                  damage = 30.0F;
               } else if (distance <= 33.0) {
                  damage = 20.0F;
               } else if (distance <= 36.0) {
                  damage = 12.0F;
               } else if (distance <= 37.5) {
                  damage = 6.0F;
               }

               if (damage > 0.0F) {
                  DamageSource damageSource;
                  if (owner instanceof LivingEntity livingOwner) {
                     damageSource = targetPlayer.damageSources().explosion(this, livingOwner);
                  } else {
                     damageSource = targetPlayer.damageSources().explosion(this, null);
                  }

                  targetPlayer.hurt(damageSource, damage);
                  Vec3 knockback = targetPlayer.position().subtract(pos).normalize();
                  double knockbackStrength = Math.max(0.0, 1.0 - distance / 37.5) * 2.5;
                  targetPlayer.push(knockback.x * knockbackStrength, knockback.y * knockbackStrength * 0.6, knockback.z * knockbackStrength);
                  targetPlayer.hurtMarked = true;
               }
            } else if (entity instanceof LivingEntity livingEntity) {
               double distancex = livingEntity.position().distanceTo(pos);
               if (distancex <= 37.5) {
                  double damageMultiplier = 1.0 - distancex / 37.5;
                  float damagex = (float)(18.0 * damageMultiplier * 3.0);
                  DamageSource damageSource;
                  if (owner instanceof LivingEntity livingOwner) {
                     damageSource = livingEntity.damageSources().explosion(this, livingOwner);
                  } else {
                     damageSource = livingEntity.damageSources().explosion(this, null);
                  }

                  livingEntity.hurt(damageSource, damagex);
                  Vec3 knockback = livingEntity.position().subtract(pos).normalize();
                  double knockbackStrength = damageMultiplier * 2.0;
                  livingEntity.push(knockback.x * knockbackStrength, knockback.y * knockbackStrength * 0.6, knockback.z * knockbackStrength);
                  livingEntity.hurtMarked = true;
               }
            }
         }

         if (this.level() instanceof ServerLevel serverLevel && SbwCompat.isLoaded()) {
            SbwVehicles.damageVehiclesAround(serverLevel, this, owner, pos, 1350.0F, 24.0F);
         }

         LivingEntity explosionOwner = owner instanceof LivingEntity ? (LivingEntity)owner : null;
         if (SkyfrontConfig.doExplosionsBreakBlocks()) {
            this.level().explode(this, this.damageSources().explosion(this, explosionOwner), null, pos.x, pos.y, pos.z, 18.0F, false, ExplosionInteraction.TNT);
         } else {
            this.level()
               .explode(this, this.damageSources().explosion(this, explosionOwner), null, pos.x, pos.y, pos.z, 18.0F, false, ExplosionInteraction.NONE);
         }

         if (this.level() instanceof ServerLevel serverLevel) {
            Vec3 motion = this.getDeltaMovement();
            float yaw;
            float pitch;
            if (!this.isParked() && motion.lengthSqr() > 1.0E-4) {
               yaw = (float)Math.toDegrees(Math.atan2(motion.x, motion.z));
               pitch = (float)Math.toDegrees(Math.atan2(-motion.y, motion.horizontalDistance()));
            } else {
               yaw = this.getYRot();
               pitch = this.getXRot();
            }

            DebrisEntity.burst(serverLevel, DebrisEntity.Airframe.SHAHED, pos, DebrisEntity.shahedAttitude(yaw, pitch), motion);
         }
      }

      this.pendingSelfDiscard = true;
      this.discard();
   }

   public void remove(RemovalReason reason) {
      if (reason != RemovalReason.DISCARDED || this.pendingSelfDiscard || this.level().isClientSide) {
         if (!this.level().isClientSide) {
            NetworkHandler.sendToAllPlayers(new ShahedRemovePacket(this.getId()));
         }

         super.remove(reason);
      }
   }

   public boolean getIsDiving() {
      return (Boolean)this.entityData.get(IS_DIVING);
   }

   public boolean getIsFalling() {
      return (Boolean)this.entityData.get(IS_FALLING);
   }

   public float getHealthFraction() {
      return (Float)this.entityData.get(HEALTH_FRACT);
   }

   public float getRenderRoll(float partialTick) {
      return this.prevRollDeg + (this.rollDeg - this.prevRollDeg) * partialTick;
   }

   public String getDiveMode() {
      return (String)this.entityData.get(DIVE_MODE);
   }

   public double getDiveDistance() {
      return this.diveDistance;
   }

   public double getDiveTransitionDistance() {
      return this.diveTransitionDistance;
   }

   public void addAdditionalSaveData(CompoundTag tag) {
      super.addAdditionalSaveData(tag);
      BlockPos target = (BlockPos)this.entityData.get(TARGET_POS);
      tag.putInt("TargetX", target.getX());
      tag.putInt("TargetY", target.getY());
      tag.putInt("TargetZ", target.getZ());
      tag.putBoolean("IsDiving", this.isDiving);
      tag.putFloat("DiveProgress", this.diveProgress);
      tag.putString("DiveMode", (String)this.entityData.get(DIVE_MODE));
      tag.putDouble("LastDirX", this.lastDirection.x);
      tag.putDouble("LastDirY", this.lastDirection.y);
      tag.putDouble("LastDirZ", this.lastDirection.z);
      tag.putFloat("DroneHealth", this.droneHealth);
      tag.putBoolean("IsFalling", this.isFalling);
      tag.putFloat("DestroyRot", this.destroyRot);
      tag.putFloat("PostFallDamage", this.postFallDamage);
      tag.putInt("SwerveDir", (Integer)this.entityData.get(SWERVE_DIR));
      tag.putInt("LaunchState", (Integer)this.entityData.get(LAUNCH_STATE));
      tag.putInt("CruiseAlt", (Integer)this.entityData.get(CRUISE_ALT));
      if (this.takeoffOrigin != null) {
         tag.putDouble("TakeoffX", this.takeoffOrigin.x);
         tag.putDouble("TakeoffY", this.takeoffOrigin.y);
         tag.putDouble("TakeoffZ", this.takeoffOrigin.z);
      }

      if (this.boundTerminal != null) {
         tag.putIntArray("BoundTerminal", new int[]{this.boundTerminal.getX(), this.boundTerminal.getY(), this.boundTerminal.getZ()});
      }

      if (this.launchOrigin != null) {
         tag.putDouble("LaunchOriginX", this.launchOrigin.x);
         tag.putDouble("LaunchOriginY", this.launchOrigin.y);
         tag.putDouble("LaunchOriginZ", this.launchOrigin.z);
      }

      tag.putIntArray("Route", this.route);
      tag.putInt("RouteIndex", this.routeIndex);
      tag.putBoolean("TargetGroundResolved", this.targetGroundResolved);
      tag.putBoolean("FinalLeg", (Boolean)this.entityData.get(FINAL_LEG));
      tag.putBoolean("OnRail", this.onRail);
      tag.putFloat("RailPitch", this.railPitch);
      tag.putDouble("RailRun", this.railRun);
      if (this.railStart != null) {
         tag.putDouble("RailStartX", this.railStart.x);
         tag.putDouble("RailStartY", this.railStart.y);
         tag.putDouble("RailStartZ", this.railStart.z);
      }
   }

   public void readAdditionalSaveData(CompoundTag tag) {
      super.readAdditionalSaveData(tag);
      BlockPos target = new BlockPos(tag.getInt("TargetX"), tag.getInt("TargetY"), tag.getInt("TargetZ"));
      this.entityData.set(TARGET_POS, target);
      this.isDiving = tag.getBoolean("IsDiving");
      this.diveProgress = tag.getFloat("DiveProgress");
      String mode = tag.getString("DiveMode");
      this.entityData.set(DIVE_MODE, mode);
      if (mode.equals("high")) {
         this.diveDistance = 350.0;
         this.diveTransitionDistance = 500.0;
      } else {
         this.diveDistance = 150.0;
         this.diveTransitionDistance = 280.0;
      }

      this.entityData.set(IS_DIVING, this.isDiving);
      if (tag.contains("LastDirX")) {
         this.lastDirection = new Vec3(tag.getDouble("LastDirX"), tag.getDouble("LastDirY"), tag.getDouble("LastDirZ"));
      }

      this.droneHealth = tag.contains("DroneHealth") ? tag.getFloat("DroneHealth") : -1.0F;
      this.isFalling = tag.getBoolean("IsFalling");
      this.destroyRot = tag.getFloat("DestroyRot");
      this.postFallDamage = tag.getFloat("PostFallDamage");
      this.entityData.set(IS_FALLING, this.isFalling);
      this.entityData.set(HEALTH_FRACT, this.droneHealth < 0.0F ? 1.0F : Math.max(0.0F, this.droneHealth / maxDroneHealth()));
      this.entityData.set(SWERVE_DIR, tag.getInt("SwerveDir"));
      int launchState = tag.getInt("LaunchState");
      this.entityData.set(LAUNCH_STATE, launchState);
      if (tag.contains("CruiseAlt")) {
         this.entityData.set(CRUISE_ALT, tag.getInt("CruiseAlt"));
      }

      if (tag.contains("TakeoffX")) {
         this.takeoffOrigin = new Vec3(tag.getDouble("TakeoffX"), tag.getDouble("TakeoffY"), tag.getDouble("TakeoffZ"));
      }

      if (tag.contains("LaunchOriginX")) {
         this.launchOrigin = new Vec3(tag.getDouble("LaunchOriginX"), tag.getDouble("LaunchOriginY"), tag.getDouble("LaunchOriginZ"));
      }

      this.route = tag.getIntArray("Route");
      this.routeIndex = tag.getInt("RouteIndex");
      this.targetGroundResolved = tag.getBoolean("TargetGroundResolved");
      if (tag.contains("FinalLeg")) {
         this.entityData.set(FINAL_LEG, tag.getBoolean("FinalLeg"));
      }

      if (tag.contains("BoundTerminal")) {
         int[] p = tag.getIntArray("BoundTerminal");
         if (p.length == 3) {
            this.boundTerminal = new BlockPos(p[0], p[1], p[2]);
         }
      }

      this.noPhysics = launchState != 1 && launchState != 2;
      this.setNoGravity(launchState != 1);
      this.onRail = tag.getBoolean("OnRail");
      this.railPitch = tag.getFloat("RailPitch");
      this.railRun = tag.getDouble("RailRun");
      if (tag.contains("RailStartX")) {
         this.railStart = new Vec3(tag.getDouble("RailStartX"), tag.getDouble("RailStartY"), tag.getDouble("RailStartZ"));
      }

      if (this.onRail && launchState == 1) {
         this.noPhysics = true;
         this.setNoGravity(true);
      }
   }

   public float getDiveProgress() {
      return this.diveProgress;
   }

   public void registerControllers(ControllerRegistrar controllerRegistrar) {
      controllerRegistrar.add(new AnimationController(this, "controller", 0, this::predicate));
   }

   private PlayState predicate(AnimationState<ShahedEntity> animationState) {
      if (this.isParked()) {
         return PlayState.STOP;
      } else {
         if (!(Boolean)this.entityData.get(IS_FALLING) && !(Boolean)this.entityData.get(IS_DIVING)) {
            animationState.getController().setAnimation(RawAnimation.begin().thenLoop("animation.shahed.fly"));
         } else {
            animationState.getController().setAnimation(RawAnimation.begin().thenLoop("animation.shahed.dive"));
         }

         return PlayState.CONTINUE;
      }
   }

   public AnimatableInstanceCache getAnimatableInstanceCache() {
      return this.cache;
   }

   private <T extends ParticleOptions> void sendParticlesForced(
      ServerLevel level, T particle, double x, double y, double z, int count, double xOffset, double yOffset, double zOffset, double speed
   ) {
      for (ServerPlayer player : level.players()) {
         level.sendParticles(player, particle, true, x, y, z, count, xOffset, yOffset, zOffset, speed);
      }
   }
}
