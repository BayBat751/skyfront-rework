package dev.krutlexik.skyfront.block;

import dev.krutlexik.skyfront.item.ModItems;
import java.util.function.Supplier;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredRegister.Blocks;

public class ModBlocks {
   public static final Blocks BLOCKS = DeferredRegister.createBlocks("sfw");
   public static final DeferredBlock<Block> SHAHED_TERMINAL = registerBlock(
      "shahed_terminal", () -> new ShahedTerminalBlock(Properties.of().strength(3.0F).sound(SoundType.METAL).requiresCorrectToolForDrops().noOcclusion())
   );
   public static final DeferredBlock<Block> SHAHED_RADAR = registerBlock(
      "shahed_radar", () -> new ShahedRadarBlock(Properties.of().strength(3.0F).sound(SoundType.METAL).requiresCorrectToolForDrops())
   );
   public static final DeferredBlock<Block> SIREN = registerBlock(
      "siren", () -> new SirenBlock(Properties.of().strength(2.0F).sound(SoundType.METAL).requiresCorrectToolForDrops())
   );

   private static <T extends Block> DeferredBlock<T> registerBlock(String name, Supplier<T> block) {
      DeferredBlock<T> toReturn = BLOCKS.register(name, block);
      registerBlockItem(name, toReturn);
      return toReturn;
   }

   private static <T extends Block> void registerBlockItem(String name, DeferredBlock<T> block) {
      ModItems.ITEMS.register(name, () -> new BlockItem((Block)block.get(), new net.minecraft.world.item.Item.Properties()));
   }

   public static void register(IEventBus eventBus) {
      BLOCKS.register(eventBus);
   }
}
