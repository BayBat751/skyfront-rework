package dev.krutlexik.skyfront.block.entity;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

public class ShahedTerminalBlockEntity extends BlockEntity {
   private final List<ShahedTerminalBlockEntity.Entry> entries = new ArrayList<>();
   private int nextNumber = 1;
   private ItemStack map = ItemStack.EMPTY;

   public ShahedTerminalBlockEntity(BlockPos pos, BlockState state) {
      super((BlockEntityType)ModBlockEntities.SHAHED_TERMINAL.get(), pos, state);
   }

   public List<ShahedTerminalBlockEntity.Entry> getEntries() {
      return this.entries;
   }

   @Nullable
   public ShahedTerminalBlockEntity.Entry findByUuid(UUID uuid) {
      for (ShahedTerminalBlockEntity.Entry entry : this.entries) {
         if (entry.uuid.equals(uuid)) {
            return entry;
         }
      }

      return null;
   }

   public ShahedTerminalBlockEntity.Entry bind(UUID uuid) {
      ShahedTerminalBlockEntity.Entry entry = new ShahedTerminalBlockEntity.Entry(uuid, this.nextNumber++, 150);
      this.entries.add(entry);
      this.setChanged();
      return entry;
   }

   public static boolean isMap(ItemStack stack) {
      return stack.is(Items.FILLED_MAP);
   }

   public ItemStack getMap() {
      return this.map;
   }

   public ItemStack swapMap(ItemStack stack) {
      ItemStack previous = this.map;
      this.map = isMap(stack) ? stack.copyWithCount(1) : ItemStack.EMPTY;
      this.setChanged();
      return previous;
   }

   public ItemStack takeMap() {
      return this.swapMap(ItemStack.EMPTY);
   }

   public boolean unbind(UUID uuid) {
      boolean removed = this.entries.removeIf(e -> e.uuid.equals(uuid));
      if (removed) {
         this.setChanged();
      }

      return removed;
   }

   protected void saveAdditional(CompoundTag tag, Provider registries) {
      super.saveAdditional(tag, registries);
      tag.putInt("NextNumber", this.nextNumber);
      ListTag list = new ListTag();

      for (ShahedTerminalBlockEntity.Entry entry : this.entries) {
         CompoundTag e = new CompoundTag();
         e.putUUID("Uuid", entry.uuid);
         e.putInt("Number", entry.number);
         e.putInt("Altitude", entry.altitude);
         e.putBoolean("FarDive", entry.farDive);
         e.putIntArray("Route", entry.route);
         list.add(e);
      }

      tag.put("Shaheds", list);
      if (!this.map.isEmpty()) {
         tag.put("Map", this.map.save(registries));
      }
   }

   protected void loadAdditional(CompoundTag tag, Provider registries) {
      super.loadAdditional(tag, registries);
      this.nextNumber = Math.max(1, tag.getInt("NextNumber"));
      this.entries.clear();
      ListTag list = tag.getList("Shaheds", 10);

      for (int i = 0; i < list.size(); i++) {
         CompoundTag e = list.getCompound(i);
         ShahedTerminalBlockEntity.Entry entry = new ShahedTerminalBlockEntity.Entry(e.getUUID("Uuid"), e.getInt("Number"), e.getInt("Altitude"));
         entry.farDive = !e.contains("FarDive") || e.getBoolean("FarDive");
         int[] route = e.getIntArray("Route");
         entry.route = route.length % 2 == 0 ? route : new int[0];
         this.entries.add(entry);
      }

      this.map = tag.contains("Map", 10) ? ItemStack.parseOptional(registries, tag.getCompound("Map")) : ItemStack.EMPTY;
   }

   public static class Entry {
      public UUID uuid;
      public int number;
      public int altitude;
      public boolean farDive = true;
      public int[] route = new int[0];

      public Entry(UUID uuid, int number, int altitude) {
         this.uuid = uuid;
         this.number = number;
         this.altitude = altitude;
      }

      public int waypointCount() {
         return this.route.length / 2;
      }

      public int waypointX(int index) {
         return this.route[index * 2];
      }

      public int waypointZ(int index) {
         return this.route[index * 2 + 1];
      }
   }
}
