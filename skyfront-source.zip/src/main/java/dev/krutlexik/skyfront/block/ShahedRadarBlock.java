package dev.krutlexik.skyfront.block;

import dev.krutlexik.skyfront.entity.ShahedEntity;
import dev.krutlexik.skyfront.network.NetworkHandler;
import dev.krutlexik.skyfront.network.OpenRadarScreenPacket;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

public class ShahedRadarBlock extends Block {
   public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;
   public static final IntegerProperty POWER = BlockStateProperties.POWER;
   private static final int RADAR_RANGE = 1000;

   public ShahedRadarBlock(Properties properties) {
      super(properties);
      this.registerDefaultState((BlockState)((BlockState)((BlockState)this.stateDefinition.any()).setValue(FACING, Direction.NORTH)).setValue(POWER, 0));
   }

   protected void createBlockStateDefinition(Builder<Block, BlockState> builder) {
      builder.add(new Property[]{FACING, POWER});
   }

   public BlockState getStateForPlacement(BlockPlaceContext context) {
      return (BlockState)this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
   }

   protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
      if (!level.isClientSide && player instanceof ServerPlayer serverPlayer) {
         NetworkHandler.sendToPlayer(serverPlayer, new OpenRadarScreenPacket(pos));
      }

      return InteractionResult.sidedSuccess(level.isClientSide);
   }

   public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean isMoving) {
      if (!level.isClientSide) {
         level.scheduleTick(pos, this, 20);
      }
   }

   public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
      int newPower = this.calculateSignalStrength(level, pos);
      int oldPower = (Integer)state.getValue(POWER);
      if (newPower != oldPower) {
         level.setBlock(pos, (BlockState)state.setValue(POWER, newPower), 3);
         level.updateNeighborsAt(pos, this);

         for (Direction dir : Direction.values()) {
            level.updateNeighborsAt(pos.relative(dir), this);
         }
      }

      level.scheduleTick(pos, this, 20);
   }

   private int calculateSignalStrength(ServerLevel level, BlockPos pos) {
      Vec3 radarCenter = Vec3.atCenterOf(pos);
      AABB searchBox = new AABB(
         radarCenter.x - 1000.0, radarCenter.y - 500.0, radarCenter.z - 1000.0, radarCenter.x + 1000.0, radarCenter.y + 500.0, radarCenter.z + 1000.0
      );
      double closestDistance = Double.MAX_VALUE;

      for (Entity entity : level.getEntities(null, searchBox)) {
         if (entity instanceof ShahedEntity) {
            double dist = entity.position().distanceTo(radarCenter);
            if (dist < closestDistance) {
               closestDistance = dist;
            }
         }
      }

      if (closestDistance == Double.MAX_VALUE) {
         return 0;
      } else if (closestDistance < 50.0) {
         return 15;
      } else if (closestDistance < 100.0) {
         return 14;
      } else if (closestDistance < 150.0) {
         return 13;
      } else if (closestDistance < 200.0) {
         return 12;
      } else if (closestDistance < 300.0) {
         return 10;
      } else if (closestDistance < 400.0) {
         return 8;
      } else if (closestDistance < 500.0) {
         return 6;
      } else if (closestDistance < 600.0) {
         return 5;
      } else if (closestDistance < 700.0) {
         return 4;
      } else if (closestDistance < 800.0) {
         return 3;
      } else if (closestDistance < 900.0) {
         return 2;
      } else {
         return closestDistance < 1000.0 ? 1 : 0;
      }
   }

   public boolean isSignalSource(BlockState state) {
      return true;
   }

   public int getSignal(BlockState state, BlockGetter level, BlockPos pos, Direction direction) {
      return (Integer)state.getValue(POWER);
   }

   public int getDirectSignal(BlockState state, BlockGetter level, BlockPos pos, Direction direction) {
      return (Integer)state.getValue(POWER);
   }
}
