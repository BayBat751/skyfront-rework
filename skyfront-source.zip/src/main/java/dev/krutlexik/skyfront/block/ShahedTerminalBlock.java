package dev.krutlexik.skyfront.block;

import dev.krutlexik.skyfront.block.entity.ShahedTerminalBlockEntity;
import dev.krutlexik.skyfront.item.ShahedItem;
import dev.krutlexik.skyfront.network.NetworkHandler;
import dev.krutlexik.skyfront.network.TerminalActionPacket;
import dev.krutlexik.skyfront.network.TerminalDataPacket;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.BlockHitResult;

public class ShahedTerminalBlock extends Block implements EntityBlock {
   public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

   public ShahedTerminalBlock(Properties properties) {
      super(properties);
      this.registerDefaultState((BlockState)((BlockState)this.stateDefinition.any()).setValue(FACING, Direction.NORTH));
   }

   protected void createBlockStateDefinition(Builder<Block, BlockState> builder) {
      builder.add(new Property[]{FACING});
   }

   public BlockState getStateForPlacement(BlockPlaceContext context) {
      return (BlockState)this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
   }

   protected RenderShape getRenderShape(BlockState state) {
      return RenderShape.ENTITYBLOCK_ANIMATED;
   }

   @Nullable
   public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
      return new ShahedTerminalBlockEntity(pos, state);
   }

   protected ItemInteractionResult useItemOn(
      ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit
   ) {
      if (ShahedTerminalBlockEntity.isMap(stack)) {
         return this.insertMap(stack, level, pos, player);
      } else if (!(stack.getItem() instanceof ShahedItem)) {
         return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
      } else if (level.isClientSide) {
         return ItemInteractionResult.SUCCESS;
      } else if (level.getBlockEntity(pos) instanceof ShahedTerminalBlockEntity terminal) {
         CompoundTag tag = ShahedItem.getData(stack);
         UUID uuid = tag.hasUUID("ShahedUuid") ? tag.getUUID("ShahedUuid") : UUID.randomUUID();
         if (terminal.findByUuid(uuid) != null) {
            player.displayClientMessage(Component.translatable("msg.sfw.bind.already_this").withStyle(ChatFormatting.YELLOW), true);
            return ItemInteractionResult.SUCCESS;
         } else {
            if (tag.contains("ShahedTerminal")) {
               int[] p = tag.getIntArray("ShahedTerminal");
               if (p.length == 3) {
                  BlockPos other = new BlockPos(p[0], p[1], p[2]);
                  if (!other.equals(pos) && this.isBindingStillValid(level, tag, other, uuid)) {
                     player.displayClientMessage(
                        Component.translatable("msg.sfw.bind.already_other", new Object[]{other.getX(), other.getY(), other.getZ()})
                           .withStyle(ChatFormatting.RED),
                        true
                     );
                     return ItemInteractionResult.SUCCESS;
                  }
               }
            }

            ShahedTerminalBlockEntity.Entry entry = terminal.bind(uuid);
            float health = tag.contains("ShahedHealth") ? tag.getFloat("ShahedHealth") : -1.0F;
            ShahedItem.writeData(stack, uuid, health, pos, level.dimension().location().toString());
            player.displayClientMessage(Component.translatable("msg.sfw.bind.success", new Object[]{entry.number}).withStyle(ChatFormatting.GREEN), true);
            return ItemInteractionResult.SUCCESS;
         }
      } else {
         return ItemInteractionResult.FAIL;
      }
   }

   private ItemInteractionResult insertMap(ItemStack stack, Level level, BlockPos pos, Player player) {
      if (level.isClientSide) {
         return ItemInteractionResult.SUCCESS;
      } else if (player instanceof ServerPlayer serverPlayer
         && level instanceof ServerLevel serverLevel
         && level.getBlockEntity(pos) instanceof ShahedTerminalBlockEntity terminal) {
         ItemStack var9 = terminal.swapMap(stack);
         stack.consume(1, player);
         TerminalActionPacket.giveBack(serverPlayer, var9);
         player.displayClientMessage(Component.translatable("msg.sfw.map.inserted").withStyle(ChatFormatting.GREEN), true);
         TerminalDataPacket.sendMapPicture(serverPlayer, serverLevel, terminal);
         NetworkHandler.sendToPlayer(serverPlayer, TerminalDataPacket.build(serverLevel, pos, terminal, true));
         return ItemInteractionResult.SUCCESS;
      } else {
         return ItemInteractionResult.FAIL;
      }
   }

   protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
      if (!state.is(newState.getBlock()) && level.getBlockEntity(pos) instanceof ShahedTerminalBlockEntity terminal) {
         ItemStack map = terminal.takeMap();
         if (!map.isEmpty()) {
            Containers.dropItemStack(level, pos.getX(), pos.getY(), pos.getZ(), map);
         }
      }

      super.onRemove(state, level, pos, newState, movedByPiston);
   }

   private boolean isBindingStillValid(Level level, CompoundTag tag, BlockPos other, UUID uuid) {
      String dim = tag.getString("ShahedTerminalDim");
      if (!dim.isEmpty() && !dim.equals(level.dimension().location().toString())) {
         return true;
      } else {
         return !level.isLoaded(other)
            ? true
            : level.getBlockEntity(other) instanceof ShahedTerminalBlockEntity otherTerminal && otherTerminal.findByUuid(uuid) != null;
      }
   }

   protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
      if (!level.isClientSide
         && player instanceof ServerPlayer serverPlayer
         && level instanceof ServerLevel serverLevel
         && level.getBlockEntity(pos) instanceof ShahedTerminalBlockEntity terminal) {
         TerminalDataPacket.sendMapPicture(serverPlayer, serverLevel, terminal);
         NetworkHandler.sendToPlayer(serverPlayer, TerminalDataPacket.build(serverLevel, pos, terminal, true));
         return InteractionResult.SUCCESS;
      } else {
         return InteractionResult.CONSUME;
      }
   }
}
