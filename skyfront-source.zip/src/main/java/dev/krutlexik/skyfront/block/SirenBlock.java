package dev.krutlexik.skyfront.block;

import dev.krutlexik.skyfront.config.SkyfrontConfig;
import dev.krutlexik.skyfront.network.NetworkHandler;
import dev.krutlexik.skyfront.network.SirenSoundPacket;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.Property;

public class SirenBlock extends Block {
   public static final BooleanProperty POWERED = BlockStateProperties.POWERED;

   public SirenBlock(Properties properties) {
      super(properties);
      this.registerDefaultState((BlockState)((BlockState)this.stateDefinition.any()).setValue(POWERED, false));
   }

   protected void createBlockStateDefinition(Builder<Block, BlockState> builder) {
      builder.add(new Property[]{POWERED});
   }

   public void neighborChanged(BlockState state, Level level, BlockPos pos, Block block, BlockPos fromPos, boolean isMoving) {
      if (!level.isClientSide) {
         boolean powered = level.hasNeighborSignal(pos);
         boolean wasPowered = (Boolean)state.getValue(POWERED);
         if (powered != wasPowered) {
            level.setBlock(pos, (BlockState)state.setValue(POWERED, powered), 3);
            if (powered) {
               level.scheduleTick(pos, this, 1);
            }
         }
      }
   }

   public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
      if ((Boolean)state.getValue(POWERED)) {
         int range = (Integer)SkyfrontConfig.SIREN_RANGE.get();
         NetworkHandler.sendToNear(level, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, range, new SirenSoundPacket(pos, false, range));
         level.scheduleTick(pos, this, 500);
      }
   }

   public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean isMoving) {
      if (!oldState.is(state.getBlock()) && !level.isClientSide && (Boolean)state.getValue(POWERED)) {
         level.scheduleTick(pos, this, 1);
      }
   }

   public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean isMoving) {
      if (!state.is(newState.getBlock()) && !level.isClientSide) {
         NetworkHandler.sendToAllPlayers(new SirenSoundPacket(pos, true));
      }

      super.onRemove(state, level, pos, newState, isMoving);
   }
}
