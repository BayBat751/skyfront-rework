package dev.krutlexik.skyfront.drone;

import java.util.Set;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerPlayerConnection;
import org.jetbrains.annotations.Nullable;

public final class TrackerAccess {
   @Nullable
   public static TrackerAccess.Entry tracked(ServerLevel level, int entityId) {
      return ((TrackerAccess.Map)level.getChunkSource().chunkMap).sfw$tracked(entityId);
   }

   private TrackerAccess() {
   }

   public interface Entry {
      void sfw$updatePlayer(ServerPlayer var1);

      Set<ServerPlayerConnection> sfw$seenBy();
   }

   public interface Map {
      @Nullable
      TrackerAccess.Entry sfw$tracked(int var1);
   }
}
