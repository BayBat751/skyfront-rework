package dev.krutlexik.skyfront.drone.item;

import dev.krutlexik.skyfront.drone.entity.DroneEntity;
import dev.krutlexik.skyfront.drone.entity.DroneStandEntity;
import dev.krutlexik.skyfront.drone.entity.FpvDroneEntity;
import dev.krutlexik.skyfront.drone.registry.DroneEntities;
import java.util.function.Supplier;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import net.minecraft.world.phys.shapes.CollisionContext;

public class DroneItem extends Item {
   private final Supplier<? extends EntityType<? extends DroneEntity>> type;
   private final boolean railOnly;

   public DroneItem(Properties properties) {
      this(properties, DroneEntities.DRONE);
   }

   public DroneItem(Properties properties, Supplier<? extends EntityType<? extends DroneEntity>> type) {
      this(properties, type, false);
   }

   public DroneItem(Properties properties, Supplier<? extends EntityType<? extends DroneEntity>> type, boolean railOnly) {
      super(properties);
      this.type = type;
      this.railOnly = railOnly;
   }

   public InteractionResult useOn(UseOnContext context) {
      Level level = context.getLevel();
      if (this.railOnly) {
         if (!level.isClientSide && context.getPlayer() != null) {
            context.getPlayer().displayClientMessage(Component.translatable("msg.sfw.place.launcher_only").withStyle(ChatFormatting.RED), true);
         }

         return InteractionResult.FAIL;
      } else if (!(level instanceof ServerLevel serverLevel)) {
         return InteractionResult.sidedSuccess(true);
      } else {
         BlockPos pos = context.getClickedPos().relative(context.getClickedFace());
         DroneEntity drone = (DroneEntity)this.type.get().create(level);
         if (drone == null) {
            return InteractionResult.FAIL;
         } else {
            Player player = context.getPlayer();
            drone.setYRot(player != null ? player.getYRot() : 0.0F);
            double floor = floorUnder(level, pos);
            if (drone instanceof FpvDroneEntity) {
               DroneStandEntity stand = (DroneStandEntity)((EntityType)DroneEntities.DRONE_STAND.get()).create(level);
               if (stand != null) {
                  stand.setPos(pos.getX() + 0.5, floor, pos.getZ() + 0.5);
                  stand.holding(drone);
                  serverLevel.addFreshEntity(stand);
               }

               drone.setPos(pos.getX() + 0.5, floor + 0.225, pos.getZ() + 0.5);
            } else {
               drone.setPos(pos.getX() + 0.5, floor, pos.getZ() + 0.5);
            }

            serverLevel.addFreshEntity(drone);
            ItemStack stack = context.getItemInHand();
            if (player == null || !player.getAbilities().instabuild) {
               stack.shrink(1);
            }

            return InteractionResult.CONSUME;
         }
      }
   }

   private static double floorUnder(Level level, BlockPos pos) {
      Vec3 from = new Vec3(pos.getX() + 0.5, pos.getY() + 0.999, pos.getZ() + 0.5);
      Vec3 to = from.subtract(0.0, 1.999, 0.0);
      BlockHitResult hit = level.clip(new ClipContext(from, to, Block.COLLIDER, Fluid.NONE, CollisionContext.empty()));
      return hit.getType() == Type.MISS ? pos.getY() : hit.getLocation().y;
   }
}
