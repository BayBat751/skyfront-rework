package dev.krutlexik.skyfront.drone.entity;

import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import org.jetbrains.annotations.Nullable;

public class DroneStandEntity extends Entity {
   public static final int LINGER_TICKS = 100;
   private static final int LOAD_GRACE_TICKS = 40;
   private static final double ON_TOP = 0.15;
   @Nullable
   private UUID drone;
   private int leftTicks = -1;

   public DroneStandEntity(EntityType<? extends DroneStandEntity> type, Level level) {
      super(type, level);
      this.blocksBuilding = true;
   }

   public void holding(DroneEntity drone) {
      this.drone = drone.getUUID();
      this.setYRot(drone.getYRot());
      this.yRotO = this.getYRot();
   }

   protected void defineSynchedData(Builder builder) {
   }

   public void tick() {
      super.tick();
      if (this.level() instanceof ServerLevel level) {
         Entity quad = this.drone != null ? level.getEntity(this.drone) : null;
         if (quad != null && !quad.isRemoved()) {
            if (this.carrying(quad)) {
               this.leftTicks = -1;
            } else if (this.leftTicks < 0) {
               this.leftTicks = 0;
            } else if (++this.leftTicks >= 100) {
               this.discard();
            }
         } else {
            if (this.tickCount > 40) {
               this.discard();
            }
         }
      }
   }

   private boolean carrying(Entity quad) {
      AABB top = this.getBoundingBox();
      AABB box = quad.getBoundingBox();
      return box.minY <= top.maxY + 0.15 && box.maxY >= top.minY && box.maxX > top.minX && box.minX < top.maxX && box.maxZ > top.minZ && box.minZ < top.maxZ;
   }

   public boolean canBeCollidedWith() {
      return true;
   }

   public boolean isPickable() {
      return false;
   }

   public boolean isPushable() {
      return false;
   }

   public boolean hurt(DamageSource source, float amount) {
      return false;
   }

   protected void readAdditionalSaveData(CompoundTag tag) {
      this.drone = tag.hasUUID("Drone") ? tag.getUUID("Drone") : null;
      this.leftTicks = tag.contains("LeftTicks") ? tag.getInt("LeftTicks") : -1;
   }

   protected void addAdditionalSaveData(CompoundTag tag) {
      if (this.drone != null) {
         tag.putUUID("Drone", this.drone);
      }

      tag.putInt("LeftTicks", this.leftTicks);
   }
}
