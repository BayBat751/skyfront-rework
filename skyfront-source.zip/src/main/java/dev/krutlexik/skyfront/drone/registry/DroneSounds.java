package dev.krutlexik.skyfront.drone.registry;

import dev.krutlexik.skyfront.drone.DroneMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class DroneSounds {
   public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(Registries.SOUND_EVENT, "sfw");
   public static final DeferredHolder<SoundEvent, SoundEvent> DRONE_LOOP = SOUNDS.register(
      "drone_loop", () -> SoundEvent.createFixedRangeEvent(DroneMod.id("drone_loop"), 32.0F)
   );
   public static final DeferredHolder<SoundEvent, SoundEvent> INTERCEPTOR_LOOP = SOUNDS.register(
      "interceptor_loop", () -> SoundEvent.createFixedRangeEvent(DroneMod.id("interceptor_loop"), 192.0F)
   );
   public static final DeferredHolder<SoundEvent, SoundEvent> FPV_LOOP = SOUNDS.register(
      "fpv_loop", () -> SoundEvent.createFixedRangeEvent(DroneMod.id("fpv_loop"), 192.0F)
   );
   public static final DeferredHolder<SoundEvent, SoundEvent> MOLNIYA_LOOP = SOUNDS.register(
      "molniya_loop", () -> SoundEvent.createFixedRangeEvent(DroneMod.id("molniya_loop"), 192.0F)
   );

   private DroneSounds() {
   }
}
