package dev.krutlexik.skyfront.drone.client.render;

import dev.krutlexik.skyfront.drone.DroneMod;
import java.lang.reflect.Method;

public final class IrisCompat {
   private static boolean looked;
   private static Object api;
   private static Method shaderPackInUse;
   private static Method renderingShadowPass;

   private static void lookUp() {
      looked = true;

      try {
         Class<?> type = Class.forName("net.irisshaders.iris.api.v0.IrisApi");
         api = type.getMethod("getInstance").invoke(null);
         shaderPackInUse = type.getMethod("isShaderPackInUse");
         renderingShadowPass = type.getMethod("isRenderingShadowPass");
         DroneMod.LOGGER.info("Iris found: the thermal camera will follow its shader packs");
      } catch (ClassNotFoundException var1) {
         api = null;
      } catch (LinkageError | ReflectiveOperationException var2) {
         DroneMod.LOGGER.warn("Iris is installed but its API could not be read; treating shaders as off", var2);
         api = null;
      }
   }

   public static boolean shaderPackInUse() {
      return ask(shaderPackInUse);
   }

   public static boolean renderingShadowPass() {
      return ask(renderingShadowPass);
   }

   private static boolean ask(Method method) {
      if (!looked) {
         lookUp();
      }

      if (api != null && method != null) {
         try {
            return (Boolean)method.invoke(api);
         } catch (RuntimeException | ReflectiveOperationException var2) {
            return false;
         }
      } else {
         return false;
      }
   }

   private IrisCompat() {
   }
}
