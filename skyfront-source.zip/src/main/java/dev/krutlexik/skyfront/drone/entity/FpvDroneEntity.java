package dev.krutlexik.skyfront.drone.entity;

import dev.krutlexik.skyfront.drone.GrenadeAttachments;
import dev.krutlexik.skyfront.drone.registry.DroneItems;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public class FpvDroneEntity extends InterceptorDroneEntity {
   private static final double FUSE_SPEED = 0.15;
   private static final GrenadeAttachments.Mount PG7VM = new GrenadeAttachments.Mount(
      -0.11F, 1.37F, 0.0F, 0.0F, 0.0F, 0.85F, ResourceLocation.fromNamespaceAndPath("superbwarfare", "rpg_rocket_standard")
   );
   private static final GrenadeAttachments.Mount MORTAR = new GrenadeAttachments.Mount(-0.065F, 0.0F, 0.0F, 0.0F, 0.0F, 0.9F, GrenadeAttachments.MORTAR_SHELL);
   private static final GrenadeAttachments.Mount YASIN = new GrenadeAttachments.Mount(
      -0.11F, 1.5F, 0.0F, 0.0F, 0.0F, 0.85F, ResourceLocation.fromNamespaceAndPath("superbwarfare", "rpg_rocket_tbg")
   );
   public static final double STAND_HEIGHT = 0.225;

   public FpvDroneEntity(EntityType<? extends FpvDroneEntity> type, Level level) {
      super(type, level);
   }

   @Override
   public DroneEntity.Osd osdStyle() {
      return DroneEntity.Osd.BETAFLIGHT_GPS;
   }

   @Override
   public boolean analogVideo() {
      return true;
   }

   @Override
   public double topSpeedKmh() {
      return 111.0;
   }

   @Override
   protected double thrustToWeight() {
      return super.thrustToWeight() * 1.3;
   }

   @Override
   protected double agility() {
      return 1.3;
   }

   @Override
   public ItemStack packedItem() {
      return new ItemStack((ItemLike)DroneItems.FPV_DRONE.get());
   }

   @Override
   protected boolean carriesStores() {
      return true;
   }

   @Override
   protected boolean canCarry(ItemStack stack) {
      return GrenadeAttachments.isRocket(stack) || GrenadeAttachments.isMortarShell(stack);
   }

   @Override
   public boolean storesFollowAttitude() {
      return true;
   }

   @Override
   public GrenadeAttachments.Mount mountFor(ItemStack stack) {
      GrenadeAttachments.Mount own = GrenadeAttachments.mountOf(stack);
      if (own.display() != null && own.display().getPath().equals("rpg_rocket_standard")) {
         return PG7VM;
      } else if (own.display() != null && own.display().getPath().equals("rpg_rocket_tbg")) {
         return YASIN;
      } else {
         return GrenadeAttachments.isMortarShell(stack) ? MORTAR : own;
      }
   }

   @Override
   protected void goOff(ServerLevel level, @Nullable Entity attacker) {
      if (!this.hasAttachment()) {
         GrenadeAttachments.breakUpHarmlessly(level, this.position());
      } else {
         this.goOffWithStore(level, attacker);
      }
   }

   @Override
   protected double ramSpeed() {
      return this.hasAttachment() ? super.ramSpeed() : this.crashSpeed();
   }

   @Override
   protected float impactSpeed(Vec3 approach, @Nullable DroneEntity.Ram ram) {
      return this.hasAttachment() && ram == null && (this.horizontalCollision || this.verticalCollision) && approach.length() >= 0.15
         ? Math.nextUp((float)Math.max(approach.length(), this.crashSpeed()))
         : super.impactSpeed(approach, ram);
   }

   @Override
   protected float ramDamage() {
      if (!this.hasAttachment()) {
         return 0.0F;
      } else {
         float hit = GrenadeAttachments.hitDamage(this.getAttachment());
         return hit > 0.0F ? hit : super.ramDamage();
      }
   }
}
