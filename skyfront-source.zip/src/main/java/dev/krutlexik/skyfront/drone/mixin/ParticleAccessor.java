package dev.krutlexik.skyfront.drone.mixin;

import net.minecraft.client.particle.Particle;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({Particle.class})
public interface ParticleAccessor {
   @Accessor("rCol")
   float sfw$getRed();

   @Accessor("rCol")
   void sfw$setRed(float var1);

   @Accessor("gCol")
   float sfw$getGreen();

   @Accessor("gCol")
   void sfw$setGreen(float var1);

   @Accessor("bCol")
   float sfw$getBlue();

   @Accessor("bCol")
   void sfw$setBlue(float var1);

   @Accessor("age")
   int sfw$getAge();

   @Accessor("lifetime")
   int sfw$getLifetime();
}
