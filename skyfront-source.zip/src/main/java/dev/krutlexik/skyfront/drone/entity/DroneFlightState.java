package dev.krutlexik.skyfront.drone.entity;

import net.minecraft.network.FriendlyByteBuf;
import org.joml.Quaternionf;

public final class DroneFlightState {
   public double x;
   public double y;
   public double z;
   public double vx;
   public double vy;
   public double vz;
   public float yRot;
   public float xRot;
   public float inputSideways;
   public float inputVertical;
   public float inputForward;
   public float charge;
   public boolean armed;
   public boolean airframe;
   public boolean attitudeReady;
   public final Quaternionf attitude = new Quaternionf();
   public double ratePitch;
   public double rateYaw;
   public double rateRoll;
   public double demandPitch;
   public double demandYaw;
   public double demandRoll;
   public int holdX;
   public int holdY;
   public int holdZ;
   public int lastVerticalDir;
   public float leanRateX;
   public float leanRateZ;
   public float power;
   public double planeThrottle;
   public double glideRun;
   public boolean railSeated;
   public float railPitch;
   private static final double POSITION_TOLERANCE = 0.001;
   private static final double VELOCITY_TOLERANCE = 0.001;
   private static final double RATE_TOLERANCE = 0.5;
   private static final double AXIS_TOLERANCE = 0.001;
   private static final double ATTITUDE_TOLERANCE = 1.0E-6;

   public DroneFlightState copyFrom(DroneFlightState other) {
      this.x = other.x;
      this.y = other.y;
      this.z = other.z;
      this.vx = other.vx;
      this.vy = other.vy;
      this.vz = other.vz;
      this.yRot = other.yRot;
      this.xRot = other.xRot;
      this.inputSideways = other.inputSideways;
      this.inputVertical = other.inputVertical;
      this.inputForward = other.inputForward;
      this.charge = other.charge;
      this.armed = other.armed;
      this.airframe = other.airframe;
      this.attitudeReady = other.attitudeReady;
      this.attitude.set(other.attitude);
      this.ratePitch = other.ratePitch;
      this.rateYaw = other.rateYaw;
      this.rateRoll = other.rateRoll;
      this.demandPitch = other.demandPitch;
      this.demandYaw = other.demandYaw;
      this.demandRoll = other.demandRoll;
      this.holdX = other.holdX;
      this.holdY = other.holdY;
      this.holdZ = other.holdZ;
      this.lastVerticalDir = other.lastVerticalDir;
      this.leanRateX = other.leanRateX;
      this.leanRateZ = other.leanRateZ;
      this.power = other.power;
      this.planeThrottle = other.planeThrottle;
      this.glideRun = other.glideRun;
      this.railSeated = other.railSeated;
      this.railPitch = other.railPitch;
      return this;
   }

   public DroneFlightState copy() {
      return new DroneFlightState().copyFrom(this);
   }

   public boolean matches(DroneFlightState other) {
      if (Math.abs(this.x - other.x) > 0.001
         || Math.abs(this.y - other.y) > 0.001
         || Math.abs(this.z - other.z) > 0.001
         || Math.abs(this.vx - other.vx) > 0.001
         || Math.abs(this.vy - other.vy) > 0.001
         || Math.abs(this.vz - other.vz) > 0.001
         || Math.abs(this.inputSideways - other.inputSideways) > 0.001
         || Math.abs(this.inputVertical - other.inputVertical) > 0.001
         || Math.abs(this.inputForward - other.inputForward) > 0.001
         || this.armed != other.armed
         || this.airframe != other.airframe) {
         return false;
      } else {
         return !this.airframe
            ? true
            : this.attitudeReady == other.attitudeReady
               && Math.abs(Math.abs(this.attitude.dot(other.attitude)) - 1.0) < 1.0E-6
               && Math.abs(this.ratePitch - other.ratePitch) < 0.5
               && Math.abs(this.rateYaw - other.rateYaw) < 0.5
               && Math.abs(this.rateRoll - other.rateRoll) < 0.5
               && Math.abs(this.demandPitch - other.demandPitch) < 0.5
               && Math.abs(this.demandYaw - other.demandYaw) < 0.5
               && Math.abs(this.demandRoll - other.demandRoll) < 0.5
               && this.holdX == other.holdX
               && this.holdY == other.holdY
               && this.holdZ == other.holdZ
               && this.lastVerticalDir == other.lastVerticalDir
               && Math.abs(this.leanRateX - other.leanRateX) < 0.001
               && Math.abs(this.leanRateZ - other.leanRateZ) < 0.001
               && Math.abs(this.power - other.power) < 0.001
               && Math.abs(this.planeThrottle - other.planeThrottle) < 0.001
               && Math.abs(this.glideRun - other.glideRun) < 0.001
               && this.railSeated == other.railSeated;
      }
   }

   public void write(FriendlyByteBuf buf) {
      buf.writeDouble(this.x);
      buf.writeDouble(this.y);
      buf.writeDouble(this.z);
      buf.writeDouble(this.vx);
      buf.writeDouble(this.vy);
      buf.writeDouble(this.vz);
      buf.writeFloat(this.yRot);
      buf.writeFloat(this.xRot);
      buf.writeFloat(this.inputSideways);
      buf.writeFloat(this.inputVertical);
      buf.writeFloat(this.inputForward);
      buf.writeFloat(this.charge);
      buf.writeBoolean(this.armed);
      buf.writeBoolean(this.airframe);
      if (this.airframe) {
         buf.writeBoolean(this.attitudeReady);
         buf.writeFloat(this.attitude.x);
         buf.writeFloat(this.attitude.y);
         buf.writeFloat(this.attitude.z);
         buf.writeFloat(this.attitude.w);
         buf.writeDouble(this.ratePitch);
         buf.writeDouble(this.rateYaw);
         buf.writeDouble(this.rateRoll);
         buf.writeDouble(this.demandPitch);
         buf.writeDouble(this.demandYaw);
         buf.writeDouble(this.demandRoll);
         buf.writeVarInt(this.holdX);
         buf.writeVarInt(this.holdY);
         buf.writeVarInt(this.holdZ);
         buf.writeByte(this.lastVerticalDir);
         buf.writeFloat(this.leanRateX);
         buf.writeFloat(this.leanRateZ);
         buf.writeFloat(this.power);
         buf.writeDouble(this.planeThrottle);
         buf.writeDouble(this.glideRun);
         buf.writeBoolean(this.railSeated);
         buf.writeFloat(this.railPitch);
      }
   }

   public static DroneFlightState read(FriendlyByteBuf buf) {
      DroneFlightState state = new DroneFlightState();
      state.x = buf.readDouble();
      state.y = buf.readDouble();
      state.z = buf.readDouble();
      state.vx = buf.readDouble();
      state.vy = buf.readDouble();
      state.vz = buf.readDouble();
      state.yRot = buf.readFloat();
      state.xRot = buf.readFloat();
      state.inputSideways = buf.readFloat();
      state.inputVertical = buf.readFloat();
      state.inputForward = buf.readFloat();
      state.charge = buf.readFloat();
      state.armed = buf.readBoolean();
      state.airframe = buf.readBoolean();
      if (!state.airframe) {
         return state;
      } else {
         state.attitudeReady = buf.readBoolean();
         state.attitude.set(buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readFloat());
         state.ratePitch = buf.readDouble();
         state.rateYaw = buf.readDouble();
         state.rateRoll = buf.readDouble();
         state.demandPitch = buf.readDouble();
         state.demandYaw = buf.readDouble();
         state.demandRoll = buf.readDouble();
         state.holdX = buf.readVarInt();
         state.holdY = buf.readVarInt();
         state.holdZ = buf.readVarInt();
         state.lastVerticalDir = buf.readByte();
         state.leanRateX = buf.readFloat();
         state.leanRateZ = buf.readFloat();
         state.power = buf.readFloat();
         state.planeThrottle = buf.readDouble();
         state.glideRun = buf.readDouble();
         state.railSeated = buf.readBoolean();
         state.railPitch = buf.readFloat();
         return state;
      }
   }
}
