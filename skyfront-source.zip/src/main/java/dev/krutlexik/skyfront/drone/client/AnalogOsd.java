package dev.krutlexik.skyfront.drone.client;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.krutlexik.skyfront.config.SkyfrontConfig;
import dev.krutlexik.skyfront.drone.DroneMod;
import dev.krutlexik.skyfront.drone.RateModeFlight;
import dev.krutlexik.skyfront.drone.entity.DroneEntity;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

public abstract class AnalogOsd {
   protected static final ResourceLocation DEFAULT_FONT = DroneMod.id("textures/gui/osd_font.png");
   private static final int SHEET_W = 207;
   private static final int SHEET_H = 303;
   protected static final int GLYPH_W = 12;
   protected static final int GLYPH_H = 18;
   private static final int PITCH_X = 13;
   private static final int PITCH_Y = 19;
   private static final float FEED_ASPECT = 1.3333334F;
   protected static final int COLS = 30;
   protected static final int ROWS = 16;
   protected static final int EDGE_COL = 1;
   protected static final int CENTRE_COL = 15;
   protected GuiGraphics g;
   protected float originX;
   protected float originY;
   protected float glyphW;
   protected float glyphH;
   protected int feedX;
   protected int feedY;
   protected int feedW;
   protected int feedH;
   private static boolean homeKnown;
   private static double homeX;
   private static double homeY;
   private static double homeZ;
   private static final Map<Integer, Vec3> HOMES = new HashMap<>();
   private static final int SYM_AH_BAR_TOP = 128;
   private static final int AH_HALF_COLS = 4;

   public static void setHome(DroneEntity drone) {
      Vec3 home = HOMES.get(drone.getId());
      if (home == null || drone.isGrounded()) {
         home = drone.position();
         HOMES.put(drone.getId(), home);
      }

      homeX = home.x;
      homeY = home.y;
      homeZ = home.z;
      homeKnown = true;
   }

   public static void clearHome() {
      homeKnown = false;
   }

   protected static double altitude(DroneEntity drone) {
      return homeKnown ? drone.getY() - homeY : drone.getY();
   }

   protected static double homeDistance(DroneEntity drone) {
      if (!homeKnown) {
         return 0.0;
      } else {
         double dx = drone.getX() - homeX;
         double dz = drone.getZ() - homeZ;
         return Math.sqrt(dx * dx + dz * dz);
      }
   }

   protected static double homeBearing(DroneEntity drone) {
      double dx = homeX - drone.getX();
      double dz = homeZ - drone.getZ();
      return (Math.toDegrees(Math.atan2(dx, -dz)) + 360.0) % 360.0;
   }

   protected ResourceLocation font() {
      return DEFAULT_FONT;
   }

   protected void setUpFrame(GuiGraphics graphics) {
      int width = graphics.guiWidth();
      int height = graphics.guiHeight();
      if ((float)width / height > 1.3333334F) {
         this.feedH = height;
         this.feedW = Math.round(height * 1.3333334F);
      } else {
         this.feedW = width;
         this.feedH = Math.round(width / 1.3333334F);
      }

      this.feedX = (width - this.feedW) / 2;
      this.feedY = (height - this.feedH) / 2;
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      int black = -16777216;
      if (this.feedX > 0) {
         graphics.fill(0, 0, this.feedX, height, black);
         graphics.fill(this.feedX + this.feedW, 0, width, height, black);
      }

      if (this.feedY > 0) {
         graphics.fill(0, 0, width, this.feedY, black);
         graphics.fill(0, this.feedY + this.feedH, width, height, black);
      }

      this.g = graphics;
      this.glyphH = this.feedH / 16.0F;
      this.glyphW = this.glyphH * 12.0F / 18.0F;
      float gridW = 30.0F * this.glyphW;
      this.originX = this.feedX + (this.feedW - gridW) / 2.0F;
      this.originY = this.feedY;
   }

   protected void text(int col, int row, String string) {
      this.drawString(this.originX + col * this.glyphW, this.originY + row * this.glyphH, string);
   }

   protected void rightText(int rightCol, int row, String string) {
      float x = this.originX + rightCol * this.glyphW - string.length() * this.glyphW;
      this.drawString(x, this.originY + row * this.glyphH, string);
   }

   protected void centre(int row, String string) {
      this.offsetFromCentre(row, string, 0.0F);
   }

   protected void offsetFromCentre(int row, String string, float offset) {
      float x = this.originX + (15.5F + offset) * this.glyphW - string.length() * this.glyphW / 2.0F;
      this.drawString(x, this.originY + row * this.glyphH, string);
   }

   protected void blitCell(int col, int row, int index) {
      this.blit(this.originX + col * this.glyphW, this.originY + row * this.glyphH, index);
   }

   protected void drawString(float x, float y, String string) {
      for (int i = 0; i < string.length(); i++) {
         this.blit(x + i * this.glyphW, y, string.charAt(i));
      }
   }

   protected static String glyph(int index) {
      return String.valueOf((char)index);
   }

   protected void blit(float x, float y, int index) {
      if (index > 0 && index != 32) {
         int u = index % 16 * 13;
         int v = index / 16 * 19;
         this.g.pose().pushPose();
         this.g.pose().translate(x, y, 0.0F);
         this.g.pose().scale(this.glyphW / 12.0F, this.glyphH / 18.0F, 1.0F);
         this.g.blit(this.font(), 0, 0, 12, 18, u, v, 12, 18, 207, 303);
         this.g.pose().popPose();
      }
   }

   protected void strokes(float centreX, float centreY, int[][] lines) {
      this.g.pose().pushPose();
      this.g.pose().translate(centreX, centreY, 0.0F);
      this.g.pose().scale(this.glyphW / 12.0F, this.glyphH / 18.0F, 1.0F);

      for (int[] line : lines) {
         this.g.fill(Math.min(line[0], line[2]) - 1, Math.min(line[1], line[3]) - 1, Math.max(line[0], line[2]) + 2, Math.max(line[1], line[3]) + 2, -16777216);
      }

      for (int[] line : lines) {
         this.g.fill(Math.min(line[0], line[2]), Math.min(line[1], line[3]), Math.max(line[0], line[2]) + 1, Math.max(line[1], line[3]) + 1, -1);
      }

      this.g.pose().popPose();
   }

   protected float colX(float col) {
      return this.originX + col * this.glyphW;
   }

   protected float rowY(float row) {
      return this.originY + row * this.glyphH;
   }

   protected void drawHorizon(int row, float bodyPitch, float bodyRoll) {
      int maxPitchDeci = (Integer)SkyfrontConfig.INTERCEPTOR_OSD_MAX_PITCH.get() * 10;
      int maxRollDeci = (Integer)SkyfrontConfig.INTERCEPTOR_OSD_MAX_ROLL.get() * 10;
      int pitchDeci = Mth.clamp(Math.round(bodyPitch * 10.0F), -maxPitchDeci, maxPitchDeci);
      int rollDeci = Mth.clamp(Math.round(RateModeFlight.cameraRoll(bodyRoll) * 10.0F), -maxRollDeci, maxRollDeci);
      if (maxPitchDeci > 0) {
         pitchDeci = pitchDeci * 25 / maxPitchDeci;
      }

      int baseRow = row - 4;

      for (int x = -4; x <= 4; x++) {
         int y = -rollDeci * x / 64 + pitchDeci + 41;
         if (y >= 0 && y <= 81) {
            this.blitCell(15 + x, baseRow + y / 9, 128 + y % 9);
         }
      }
   }
}
