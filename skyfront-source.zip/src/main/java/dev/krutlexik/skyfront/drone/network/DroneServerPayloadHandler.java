package dev.krutlexik.skyfront.drone.network;

import dev.krutlexik.skyfront.drone.DroneLinks;
import dev.krutlexik.skyfront.drone.entity.DroneEntity;
import dev.krutlexik.skyfront.drone.entity.InterceptorDroneEntity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public final class DroneServerPayloadHandler {
   public static void droneInput(DroneInputPayload payload, IPayloadContext context) {
      context.enqueueWork(() -> {
         if (context.player() instanceof ServerPlayer pilot) {
            if (pilot.level().getEntity(payload.entityId()) instanceof DroneEntity drone && drone.isControlledBy(pilot)) {
               drone.acceptPilotInput(payload.input());
            }
         }
      });
   }

   public static void dropGrenade(DroneDropPayload payload, IPayloadContext context) {
      context.enqueueWork(() -> {
         if (context.player() instanceof ServerPlayer pilot) {
            if (pilot.level().getEntity(payload.entityId()) instanceof DroneEntity drone && drone.isControlledBy(pilot)) {
               drone.orderDrop(pilot, payload.atSeq());
            }
         }
      });
   }

   public static void selfDestruct(DroneSelfDestructPayload payload, IPayloadContext context) {
      context.enqueueWork(() -> {
         if (context.player() instanceof ServerPlayer pilot) {
            if (pilot.level().getEntity(payload.entityId()) instanceof InterceptorDroneEntity drone && drone.isControlledBy(pilot) && !drone.isWrecked()) {
               drone.orderSelfDestruct(pilot, payload.atSeq());
            }
         }
      });
   }

   public static void ramReported(DroneRamPayload payload, IPayloadContext context) {
      context.enqueueWork(() -> {
         if (context.player() instanceof ServerPlayer pilot) {
            if (pilot.level().getEntity(payload.droneId()) instanceof DroneEntity drone) {
               Entity target = pilot.level().getEntity(payload.targetId());
               if (target != null) {
                  drone.acceptReportedRam(pilot, target);
               }
            }
         }
      });
   }

   public static void stopRequest(StopControlRequestPayload payload, IPayloadContext context) {
      context.enqueueWork(() -> {
         if (context.player() instanceof ServerPlayer pilot) {
            DroneEntity drone = pilot.level().getEntity(payload.entityId()) instanceof DroneEntity named && named.isControlledBy(pilot) ? named : null;
            if (drone == null) {
               drone = DroneLinks.flownBy(pilot);
            }

            if (drone != null) {
               drone.releaseControl(false);
            }
         }
      });
   }

   private DroneServerPayloadHandler() {
   }
}
