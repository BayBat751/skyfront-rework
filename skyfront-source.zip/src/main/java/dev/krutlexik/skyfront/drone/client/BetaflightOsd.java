package dev.krutlexik.skyfront.drone.client;

import dev.krutlexik.skyfront.config.SkyfrontConfig;
import dev.krutlexik.skyfront.drone.client.render.AnalogFeedPass;
import dev.krutlexik.skyfront.drone.entity.DroneEntity;
import dev.krutlexik.skyfront.drone.entity.InterceptorDroneEntity;
import java.util.Locale;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.LayeredDraw.Layer;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

public class BetaflightOsd extends AnalogOsd implements Layer {
   private static final int SYM_RSSI = 1;
   private static final int SYM_VOLTS = 6;
   private static final int SYM_MAH = 7;
   private static final int SYM_METRE = 12;
   private static final int SYM_ALTITUDE = 127;
   private static final int SYM_BATTERY_FULL = 144;
   private static final int SYM_BATTERY_EMPTY = 150;
   private static final int SYM_AMPS = 154;
   private static final int SYM_FLY_TIME = 156;
   private static final int SYM_MS = 159;
   private static final int SYM_ARROW_UP = 117;
   private static final int SYM_ARROW_DOWN = 118;
   private static final int ROW_MODE = 1;
   private static final int ROW_RATE = 2;
   private static final int ROW_HORIZON = 8;
   private static final int ROW_ALT = 9;
   private static final int ROW_AMPS = 12;
   private static final int ROW_VOLTS = 13;
   private static final int ROW_MAH = 14;
   private static final int ROW_FUSE = 13;
   private static final int ROW_TIMER = 14;
   private static final int LQ_RATE = 20;
   private static final int LQ_BEST = 100;
   private static final int RSSI_BEST = -30;
   private static final int RSSI_WORST = -110;
   private static final int LQ_WARN = 25;
   private static final int RSSI_WARN = -80;
   private static final int FUSE_ARM_SECONDS = 10;
   private static final long FUSE_BLINK_MS = 400L;
   private static final float RXLOSS_LEFT_OF_CENTRE = 4.0F;
   private static String lossVolts;
   private static String lossMah;
   private static String lossTimer;
   private static String lossFuse;
   private static DroneEntity.Osd lossStyle = DroneEntity.Osd.BETAFLIGHT;
   private static boolean lossAnalog;
   private static final InavOsd INAV = new InavOsd();
   private static final GpsBetaflightOsd GPS = new GpsBetaflightOsd();
   private static float lossPitch;
   private static float lossRoll;
   private static final int[][] CROSSHAIR = new int[][]{{-9, -4, -3}, {4, 9, -3}, {-6, -1, 0}, {1, 6, 0}, {-3, 3, 3}};

   public void render(GuiGraphics graphics, DeltaTracker deltaTracker) {
      Minecraft minecraft = Minecraft.getInstance();
      if (minecraft.player != null) {
         DroneFeedFreeze.captureIfRequested();
         if (DroneControl.isPictureHeld()) {
            if (lossAnalog) {
               if (lossStyle == DroneEntity.Osd.INAV) {
                  INAV.renderSignalLost(graphics);
               } else if (lossStyle == DroneEntity.Osd.BETAFLIGHT_GPS) {
                  GPS.renderSignalLost(graphics);
               } else {
                  this.setUpFrame(graphics);
               }

               AnalogFeedPass.renderStatic(graphics);
            } else {
               DroneFeedFreeze.renderHold(graphics);
               if (lossStyle == DroneEntity.Osd.BETAFLIGHT) {
                  this.setUpFrame(graphics);
                  this.renderSignalLost();
               } else if (lossStyle == DroneEntity.Osd.INAV) {
                  INAV.renderSignalLost(graphics);
               } else if (lossStyle == DroneEntity.Osd.BETAFLIGHT_GPS) {
                  GPS.renderSignalLost(graphics);
               }
            }
         } else {
            DroneEntity drone = DroneControl.drone();
            if (drone instanceof InterceptorDroneEntity analog && analog.analogVideo()) {
               AnalogFeedPass.renderPicture(graphics, analog);
            }

            if (drone != null && drone.osdStyle() == DroneEntity.Osd.INAV) {
               INAV.render(graphics, drone, deltaTracker.getGameTimeDeltaPartialTick(false));
               if (drone instanceof InterceptorDroneEntity analog && analog.analogVideo()) {
                  AnalogFeedPass.renderOverlay(graphics);
               }
            } else if (drone != null && drone.osdStyle() == DroneEntity.Osd.BETAFLIGHT_GPS) {
               GPS.render(graphics, drone, deltaTracker.getGameTimeDeltaPartialTick(false));
               if (drone instanceof InterceptorDroneEntity analog && analog.analogVideo()) {
                  AnalogFeedPass.renderOverlay(graphics);
               }
            } else if (drone != null && drone.osdStyle() == DroneEntity.Osd.NONE) {
               this.setUpFrame(graphics);
               if (drone instanceof InterceptorDroneEntity analog && analog.analogVideo()) {
                  AnalogFeedPass.renderOverlay(graphics);
               }
            } else if (drone != null && drone.osdStyle() == DroneEntity.Osd.BETAFLIGHT) {
               this.setUpFrame(graphics);
               float partialTick = deltaTracker.getGameTimeDeltaPartialTick(false);
               Vec3 velocity = drone.getDeltaMovement();
               double altitude = altitude(drone);
               double reach = Mth.clamp(minecraft.player.distanceTo(drone) / DroneControl.controlRange(), 0.0, 1.0);
               int linkQuality = (int)Math.round(100.0 * (1.0 - reach));
               int rssiDbm = (int)Math.round(-30.0 - 80.0 * reach);
               int antennas = 2;
               double climb = velocity.y * 20.0;
               boolean blink = System.currentTimeMillis() / 400L % 2L == 0L;
               this.text(1, 1, "ACRO");
               this.text(1, 2, "R:1:2.5");
               this.centre(1, ((String)SkyfrontConfig.INTERCEPTOR_CRAFT_NAME.get()).toUpperCase(Locale.ROOT));
               if (rssiDbm > -80 || blink) {
                  this.rightText(29, 1, glyph(1) + rssiDbm + ":" + antennas);
               }

               if (linkQuality > 25 || blink) {
                  this.rightText(29, 2, "LQ20:" + linkQuality);
               }

               this.rightText(29, 8, glyph(climb < 0.0 ? 118 : 117) + String.format(Locale.ROOT, "%.1f", Math.abs(climb)) + glyph(159));
               this.rightText(29, 9, glyph(127) + String.format(Locale.ROOT, "%.1f", altitude) + glyph(12));
               this.drawHorizon(8, drone.bodyPitch(partialTick), drone.bodyRoll(partialTick));
               this.drawCrosshair();
               double cell = FpvBattery.cellVolts();
               boolean packWarning = drone.isArmed() && cell < 3.5;
               this.text(1, 12, String.format(Locale.ROOT, "%.2f", FpvBattery.amps()) + glyph(154));
               if (!packWarning || blink) {
                  this.text(1, 13, glyph(batterySymbol(drone.getCharge())) + String.format(Locale.ROOT, "%.2f", cell) + glyph(6));
               }

               this.text(1, 14, FpvBattery.mahDrawn(drone) + glyph(7));
               int seconds = FpvBattery.armedSeconds();
               this.rightText(29, 14, glyph(156) + String.format(Locale.ROOT, "%02d:%02d", seconds / 60, seconds % 60));
               if (!drone.isArmed()) {
                  this.centre(13, DroneControl.isArmRefused() ? "THROTTLE" : "DISARMED");
               } else if (DroneControl.isArmedFlash()) {
                  this.centre(13, "ARMED");
               } else if (cell < 3.0) {
                  if (blink) {
                     this.centre(13, "LAND NOW");
                  }
               } else if (cell < 3.5) {
                  if (blink) {
                     this.centre(13, "LOW BATTERY");
                  }
               } else if (seconds >= 10 && blink) {
                  this.centre(13, "WAIT FUSE2");
               }
            }
         }
      }
   }

   public static void captureSignalLoss(DroneEntity drone) {
      lossVolts = glyph(batterySymbol(drone.getCharge())) + String.format(Locale.ROOT, "%.2f", FpvBattery.cellVolts()) + glyph(6);
      lossMah = FpvBattery.mahDrawn(drone) + glyph(7);
      int seconds = FpvBattery.armedSeconds();
      lossTimer = glyph(156) + String.format(Locale.ROOT, "%02d:%02d", seconds / 60, seconds % 60);
      lossFuse = drone.isArmed() ? "WAIT FUSE2" : "DISARMED";
      lossStyle = drone.osdStyle();
      lossAnalog = drone instanceof InterceptorDroneEntity analog && analog.analogVideo();
      if (lossStyle == DroneEntity.Osd.INAV) {
         InavOsd.captureSignalLoss(drone);
      } else if (lossStyle == DroneEntity.Osd.BETAFLIGHT_GPS) {
         GpsBetaflightOsd.captureSignalLoss(drone);
      }

      lossPitch = drone.bodyPitch(1.0F);
      lossRoll = drone.bodyRoll(1.0F);
   }

   private void renderSignalLost() {
      this.drawHorizon(8, lossPitch, lossRoll);
      this.drawCrosshair();
      this.text(1, 1, "ACRO");
      this.centre(1, ((String)SkyfrontConfig.INTERCEPTOR_CRAFT_NAME.get()).toUpperCase(Locale.ROOT));
      this.rightText(29, 1, glyph(1) + "-110:2");
      this.rightText(29, 2, "LQ20:0");
      if (lossVolts != null) {
         this.text(1, 13, lossVolts);
      }

      if (lossMah != null) {
         this.text(1, 14, lossMah);
      }

      if (lossTimer != null) {
         this.rightText(29, 14, lossTimer);
      }

      if (lossFuse != null) {
         this.centre(13, lossFuse);
      }

      this.offsetFromCentre(12, "RX LOSS", -4.0F);
   }

   private void drawCrosshair() {
      float centreX = this.originX + 15.5F * this.glyphW;
      float centreY = this.originY + 8.5F * this.glyphH;
      this.g.pose().pushPose();
      this.g.pose().translate(centreX, centreY, 0.0F);
      this.g.pose().scale(this.glyphW / 12.0F, this.glyphH / 18.0F, 1.0F);

      for (int[] dash : CROSSHAIR) {
         this.g.fill(dash[0] - 1, dash[2], dash[1] + 1, dash[2] + 2, -16777216);
      }

      for (int[] dash : CROSSHAIR) {
         this.g.fill(dash[0], dash[2], dash[1], dash[2] + 1, -1);
      }

      this.g.pose().popPose();
   }

   private static int batterySymbol(float charge) {
      int step = Math.round((1.0F - Mth.clamp(charge, 0.0F, 1.0F)) * 6.0F);
      return Mth.clamp(144 + step, 144, 150);
   }
}
