package dev.krutlexik.skyfront.drone.client;

import dev.krutlexik.skyfront.drone.entity.DroneEntity;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

public class GpsBetaflightOsd extends AnalogOsd {
   private static final int SYM_RSSI = 1;
   private static final int SYM_THROTTLE = 4;
   private static final int SYM_VOLTS = 6;
   private static final int SYM_MAH = 7;
   private static final int SYM_METRE = 12;
   private static final int SYM_HOME = 17;
   private static final int SYM_SAT_LEFT = 30;
   private static final int SYM_SAT_RIGHT = 31;
   private static final int SYM_ARROW_SOUTH = 96;
   private static final int SYM_AH_CENTER_LINE = 114;
   private static final int SYM_AH_CENTER = 115;
   private static final int SYM_AH_CENTER_LINE_RIGHT = 116;
   private static final int SYM_SPEED = 123;
   private static final int SYM_TRIP = 125;
   private static final int SYM_ALTITUDE = 127;
   private static final int SYM_LAT = 137;
   private static final int SYM_BATTERY_FULL = 144;
   private static final int SYM_BATTERY_EMPTY = 150;
   private static final int SYM_LON = 152;
   private static final int SYM_AMPS = 154;
   private static final int SYM_FLY_TIME = 156;
   private static final int SYM_KMH = 158;
   private static final int LEFT_COL = 0;
   private static final int RIGHT_COL = 30;
   private static final int ROW_1 = 0;
   private static final int ROW_2 = 1;
   private static final int ROW_3 = 2;
   private static final int ROW_4 = 3;
   private static final int ROW_5 = 4;
   private static final int ROW_HORIZON = 8;
   private static final int ROW_HOME = 11;
   private static final int ROW_LOSS = 12;
   private static final int ROW_LAT = 14;
   private static final int ROW_LON = 15;
   private static final float WARNING_OFFSET = 2.0F;
   private static final String LINK_MODE = "R:2:200:P";
   private static final int LQ_MODE = 2;
   private static final int RSSI_BEST = -30;
   private static final int RSSI_WORST = -130;
   private static final int RSSI_WARN = -100;
   private static final int LQ_WARN = 25;
   private static final double METRES_PER_DEGREE = 111320.0;
   private static final long BLINK_MS = 400L;
   private static int tripDroneId = -1;
   private static double tripBlocks;
   private static Vec3 tripLast;
   private static GpsBetaflightOsd.Reading lost;

   public static void captureSignalLoss(DroneEntity drone) {
      lost = read(drone, 1.0F);
   }

   public void render(GuiGraphics graphics, DroneEntity drone, float partialTick) {
      this.setUpFrame(graphics);
      this.draw(read(drone, partialTick), false);
   }

   public void renderSignalLost(GuiGraphics graphics) {
      this.setUpFrame(graphics);
      if (lost != null) {
         this.draw(lost, true);
      }
   }

   private static GpsBetaflightOsd.Reading read(DroneEntity drone, float partialTick) {
      if (drone.getId() != tripDroneId) {
         tripDroneId = drone.getId();
         tripBlocks = 0.0;
         tripLast = null;
      }

      Vec3 here = drone.position();
      if (tripLast != null) {
         double step = here.distanceTo(tripLast);
         if (step < 20.0) {
            tripBlocks += step;
         }
      }

      tripLast = here;
      float heading = Mth.positiveModulo(drone.getViewYRot(partialTick) + 180.0F, 360.0F);
      int toHome = Math.floorMod(Math.round((float)(homeBearing(drone) - heading) / 22.5F), 16);
      int arrow = 96 + (16 - toHome + 8) % 16;
      Minecraft minecraft = Minecraft.getInstance();
      double reach = minecraft.player == null ? 0.0 : Mth.clamp(minecraft.player.distanceTo(drone) / DroneControl.controlRange(), 0.0, 1.0);
      long wander = System.currentTimeMillis() / 20000L + drone.getId();
      int satellites = 12 + Math.floorMod(drone.getId(), 3) + (int)Math.floorMod(wander, 3L);
      return new GpsBetaflightOsd.Reading(
         FpvBattery.armedSeconds(),
         FpvBattery.cellVolts(),
         drone.getCharge(),
         FpvBattery.mahDrawn(drone),
         FpvBattery.amps(),
         Math.round(drone.throttleStick() * 100.0F),
         altitude(drone),
         tripBlocks,
         drone.getDeltaMovement().length() * 72.0,
         satellites,
         drone.bodyPitch(partialTick),
         drone.bodyRoll(partialTick),
         arrow,
         homeDistance(drone),
         -drone.getZ() / 111320.0,
         drone.getX() / 111320.0,
         (int)Math.round(-30.0 - 100.0 * reach),
         (int)Math.round(100.0 * (1.0 - reach)),
         drone.isArmed(),
         DroneControl.isArmRefused(),
         DroneControl.isArmedFlash()
      );
   }

   private void draw(GpsBetaflightOsd.Reading r, boolean linkLost) {
      boolean blink = System.currentTimeMillis() / 400L % 2L == 0L;
      boolean packWarning = r.armed() && r.cellVolts() < 3.5;
      this.text(0, 0, glyph(156) + String.format(Locale.ROOT, "%02d:%02d", r.seconds() / 60, r.seconds() % 60));
      this.centre(0, "R:2:200:P");
      this.rightText(30, 0, glyph(127) + String.format(Locale.ROOT, "%.1f", r.altitude()) + glyph(12));
      if (!packWarning || blink || linkLost) {
         this.text(0, 1, glyph(batterySymbol(r.charge())) + String.format(Locale.ROOT, "%.2f", r.cellVolts()) + glyph(6));
      }

      this.text(0, 2, r.mah() + glyph(7));
      this.text(0, 3, String.format(Locale.ROOT, "%.2f", r.amps()) + glyph(154));
      this.text(0, 4, glyph(4) + String.format(Locale.ROOT, "%3d", r.throttle()));
      this.rightText(30, 1, glyph(125) + Math.round(r.tripBlocks()) + glyph(12));
      this.rightText(30, 2, glyph(123) + String.format(Locale.ROOT, "%3d", Math.round(r.speedKmh())) + glyph(158));
      this.rightText(30, 3, glyph(30) + glyph(31) + r.satellites());
      this.drawHorizon(8, r.pitch(), r.roll());
      this.blitCell(14, 8, 114);
      this.blitCell(15, 8, 115);
      this.blitCell(16, 8, 116);
      this.centre(11, glyph(r.homeArrow()) + " " + glyph(17) + Math.round(r.homeDistance()) + glyph(12));
      this.text(0, 14, glyph(137) + coordinate(r.latitude(), 2));
      this.text(0, 15, glyph(152) + coordinate(r.longitude(), 3));
      String warning = null;
      boolean steady = true;
      if (linkLost) {
         this.offsetFromCentre(12, "RX LOSS", -4.0F);
      } else if (!r.armed()) {
         warning = r.armRefused() ? "THROTTLE" : "DISARMED";
      } else if (r.armedFlash()) {
         warning = "ARMED";
      } else if (r.cellVolts() < 3.0) {
         warning = "LAND NOW";
         steady = false;
      } else if (packWarning) {
         warning = "LOW VOLTAGE";
         steady = false;
      }

      if (warning != null && (steady || blink)) {
         this.offsetFromCentre(15, warning, 2.0F);
      }

      int rssi = linkLost ? -130 : r.rssi();
      int quality = linkLost ? 0 : r.linkQuality();
      if (rssi > -100 || blink || linkLost) {
         this.rightText(30, 14, glyph(1) + rssi);
      }

      if (quality > 25 || blink || linkLost) {
         this.rightText(30, 15, "LQ2:" + quality);
      }
   }

   private static String coordinate(double degrees, int wholeDigits) {
      String sign = degrees < 0.0 ? "-" : "";
      return sign + String.format(Locale.ROOT, "%0" + (wholeDigits + 5) + ".4f", Math.abs(degrees));
   }

   private static int batterySymbol(float charge) {
      int step = Math.round((1.0F - Mth.clamp(charge, 0.0F, 1.0F)) * 6.0F);
      return Mth.clamp(144 + step, 144, 150);
   }

   private record Reading(
      int seconds,
      double cellVolts,
      float charge,
      int mah,
      double amps,
      int throttle,
      double altitude,
      double tripBlocks,
      double speedKmh,
      int satellites,
      float pitch,
      float roll,
      int homeArrow,
      double homeDistance,
      double latitude,
      double longitude,
      int rssi,
      int linkQuality,
      boolean armed,
      boolean armRefused,
      boolean armedFlash
   ) {
   }
}
