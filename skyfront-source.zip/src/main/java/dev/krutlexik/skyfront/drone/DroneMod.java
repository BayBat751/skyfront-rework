package dev.krutlexik.skyfront.drone;

import com.mojang.logging.LogUtils;
import dev.krutlexik.skyfront.drone.registry.DroneEntities;
import dev.krutlexik.skyfront.drone.registry.DroneItems;
import dev.krutlexik.skyfront.drone.registry.DroneSounds;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.IEventBus;
import org.slf4j.Logger;

public final class DroneMod {
   public static final String MODID = "sfw";
   public static final Logger LOGGER = LogUtils.getLogger();

   public static void register(IEventBus modBus) {
      DroneItems.ITEMS.register(modBus);
      DroneEntities.ENTITIES.register(modBus);
      DroneSounds.SOUNDS.register(modBus);
   }

   public static ResourceLocation id(String path) {
      return ResourceLocation.fromNamespaceAndPath("sfw", path);
   }

   private DroneMod() {
   }
}
