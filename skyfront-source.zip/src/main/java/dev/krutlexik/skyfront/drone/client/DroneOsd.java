package dev.krutlexik.skyfront.drone.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.math.Axis;
import dev.krutlexik.skyfront.drone.DroneMod;
import dev.krutlexik.skyfront.drone.client.render.ThermalScreenPass;
import dev.krutlexik.skyfront.drone.entity.DroneEntity;
import java.util.Locale;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.LayeredDraw.Layer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public class DroneOsd implements Layer {
   private static final ResourceLocation ATLAS = DroneMod.id("textures/gui/osd.png");
   private static final Style FONT = Style.EMPTY.withFont(DroneMod.id("osd"));
   private static final float SMALL = 1.0F;
   private static final float TEXT = 1.35F;
   private static final float BIG = 1.9F;
   private static final String NO_VALUE = "--";
   private static final int[] HOME = new int[]{24, 48, 20, 20};
   private static final int[] DOTS = new int[]{48, 48, 20, 20};
   private static final int[] SAT = new int[]{72, 48, 20, 20};
   private static final int[] FILM = new int[]{96, 48, 20, 20};
   private static final int[] PLAY = new int[]{120, 48, 20, 20};
   private static final int[] LAND = new int[]{144, 48, 20, 20};
   private static final int[] ALT = new int[]{168, 48, 12, 12};
   private static final int[] DIST = new int[]{184, 48, 12, 12};
   private static final int[] GREEN_DOT = new int[]{200, 48, 10, 10};
   private static final int[] H_MARK = new int[]{212, 48, 14, 14};
   private static final int[] RECORD = new int[]{228, 48, 26, 26};
   private static final int[] ZOOM_DISC = new int[]{0, 80, 30, 30};
   private static final int[] N_BADGE = new int[]{32, 80, 12, 12};
   private static final int[] COMPASS = new int[]{0, 120, 84, 84};
   private static final int[] ARROW = new int[]{96, 120, 64, 64};
   private static final int WHITE = -1;
   private static final int LABEL = -3550506;
   private static final int GRID = 754974719;
   private static final int AMBER = -866234;
   private static final int RED = -2076092;
   private static final int ALERT_RED = -58597;
   private static final int GREEN = -12593573;
   private static final int TRACK = 1509949439;
   private static final int THERMAL_SCRIM = -1945759708;
   private static final int THERMAL_CHIP = -2065896;
   private static final ResourceLocation DROP_LIGHT = DroneMod.id("textures/gui/drone_light.png");
   private static final int DROP_LIGHT_W = 1920;
   private static final int DROP_LIGHT_H = 1080;
   private static final int LOGO_U = 610;
   private static final int LOGO_V = 170;
   private static final int LOGO_W = 700;
   private static final int LOGO_H = 654;
   private static final int PANEL_W = 162;
   private static final int PANEL_H = 96;
   private static final int PANEL_INSET = 8;

   public void render(GuiGraphics graphics, DeltaTracker deltaTracker) {
      Minecraft minecraft = Minecraft.getInstance();
      LocalPlayer player = minecraft.player;
      DroneEntity flying = DroneControl.drone();
      if (flying == null || flying.osdStyle() == DroneEntity.Osd.CAMERA) {
         DroneFeedFreeze.captureIfRequested();
         boolean signalLost = DroneSignalLoss.isActive();
         DroneTelemetry telemetry;
         if (signalLost) {
            telemetry = DroneFeedFreeze.frozenTelemetry();
         } else {
            DroneEntity drone = DroneControl.drone();
            telemetry = drone != null && player != null ? DroneTelemetry.read(minecraft, drone, player) : null;
         }

         int width = graphics.guiWidth();
         int height = graphics.guiHeight();
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         DroneFeedFreeze.render(graphics);
         if (telemetry != null) {
            boolean blanked = DroneSignalLoss.isBlanked();
            boolean thermal = ThermalVision.isOn() && !signalLost;
            if (thermal && !ThermalScreenPass.isRendering()) {
               graphics.fill(0, 0, width, height, -1945759708);
            }

            graphics.fillGradient(0, 0, width, 26, 1342177280, 0);
            graphics.fillGradient(0, height - 46, width, height, 0, 1577058304);
            this.drawGrid(graphics, width, height);
            this.drawTopBar(graphics, minecraft, telemetry, blanked, width);
            if (thermal) {
               this.drawThermalBadge(graphics, minecraft, 6, 24);
            }

            this.drawSideControls(graphics, width, height);
            this.drawCompass(graphics, telemetry, blanked, height);
            this.drawTelemetry(graphics, minecraft, telemetry, blanked, height);
            this.drawCaptureInfo(graphics, minecraft, telemetry, blanked, width, height);
            this.drawGrenadeDrop(graphics, width, height);
         }
      }
   }

   private void drawGrenadeDrop(GuiGraphics graphics, int width, int height) {
      float progress = DroneControl.dropProgress();
      if (progress > 0.0F) {
         int barWidth = 120;
         int barHeight = 4;
         int x = (width - barWidth) / 2;
         int y = height - 64;
         this.roundedRect(graphics, x - 2, y - 2, barWidth + 4, barHeight + 4, 2, Integer.MIN_VALUE);
         graphics.fill(x, y, x + Math.round(barWidth * progress), y + barHeight, -58597);
      }

      float alpha = DroneControl.dropFlashAlpha();
      if (alpha > 0.0F) {
         int panelX = (width - 162) / 2;
         int panelY = height - 62 - 96;
         int bgAlpha = Math.round(102.0F * alpha) << 24;
         this.roundedRect(graphics, panelX, panelY, 162, 96, 5, bgAlpha);
         int logoHeight = 80;
         int logoWidth = logoHeight * 700 / 654;
         int logoX = panelX + (162 - logoWidth) / 2;
         int logoY = panelY + 8;
         RenderSystem.enableBlend();
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, alpha);
         graphics.blit(DROP_LIGHT, logoX, logoY, logoWidth, logoHeight, 610.0F, 170.0F, 700, 654, 1920, 1080);
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      }
   }

   private void roundedRect(GuiGraphics graphics, int x, int y, int w, int h, int radius, int color) {
      graphics.fill(x, y + radius, x + w, y + h - radius, color);

      for (int row = 0; row < radius; row++) {
         int inset = radius - row;
         graphics.fill(x + inset, y + row, x + w - inset, y + row + 1, color);
         graphics.fill(x + inset, y + h - row - 1, x + w - inset, y + h - row, color);
      }
   }

   private static String value(boolean blanked, String formatted) {
      return blanked ? "--" : formatted;
   }

   private void drawGrid(GuiGraphics graphics, int width, int height) {
      graphics.fill(width / 3, 0, width / 3 + 1, height, 754974719);
      graphics.fill(2 * width / 3, 0, 2 * width / 3 + 1, height, 754974719);
      graphics.fill(0, height / 3, width, height / 3 + 1, 754974719);
      graphics.fill(0, 2 * height / 3, width, 2 * height / 3 + 1, 754974719);
      float diagonal = (float)Math.sqrt((double)width * width + (double)height * height);
      float angle = (float)Math.atan2(height, width);

      for (int sign = -1; sign <= 1; sign += 2) {
         graphics.pose().pushPose();
         graphics.pose().translate(width / 2.0F, height / 2.0F, 0.0F);
         graphics.pose().mulPose(Axis.ZP.rotation(sign * angle));
         graphics.fill((int)(-diagonal / 2.0F), 0, (int)(diagonal / 2.0F), 1, 754974719);
         graphics.pose().popPose();
      }
   }

   private void drawTopBar(GuiGraphics graphics, Minecraft minecraft, DroneTelemetry telemetry, boolean blanked, int width) {
      this.icon(graphics, HOME, 6, 4, 14);
      this.text(graphics, "N Mode", 26.0F, 7.0F, 1.35F, -1);
      if (DroneSignalLoss.showNoSignal()) {
         this.drawNoSignalBadge(graphics, minecraft, 74, 4);
      } else {
         this.text(graphics, telemetry.moving() ? "In flight" : "Hovering", 74.0F, 7.0F, 1.35F, -1);
      }

      int cursor = width - 6;
      cursor -= 13;
      this.icon(graphics, DOTS, cursor, 5, 13);
      String satText = value(blanked, String.valueOf(telemetry.satellites()));
      cursor -= 7 + (int)this.width(minecraft, satText, 1.35F);
      this.text(graphics, satText, cursor, 6.0F, 1.35F, !blanked && telemetry.satellites() >= 12 ? -1 : -866234);
      cursor -= 15;
      this.icon(graphics, SAT, cursor, 4, 14);
      int bars = blanked ? 0 : telemetry.linkBars();
      int barColor = bars >= 4 ? -1 : (bars == 3 ? -866234 : -2076092);
      cursor -= 8 + (int)this.width(minecraft, "RC", 1.0F);
      this.text(graphics, "RC", cursor, 8.0F, 1.0F, -1);
      cursor -= 18;

      for (int i = 0; i < 5; i++) {
         int barHeight = 3 + i;
         int x = cursor + i * 3;
         graphics.fill(x, 16 - barHeight, x + 2, 16, i < bars ? barColor : 1358954495);
      }

      String timeText = value(blanked, telemetry.remainingTime());
      cursor -= 9 + (int)this.width(minecraft, timeText, 1.35F);
      this.text(graphics, timeText, cursor, 6.0F, 1.35F, -1);
      cursor -= 26;
      this.drawBatteryRing(graphics, minecraft, cursor + 9, 12, telemetry.charge(), blanked);
   }

   private void drawBatteryRing(GuiGraphics graphics, Minecraft minecraft, int centreX, int centreY, float charge, boolean blanked) {
      int segments = 60;
      float radius = 8.0F;
      float thickness = 2.0F;
      int fillColor = charge <= 0.15F ? -2076092 : (charge <= 0.3F ? -866234 : -12593573);
      int filled = Mth.clamp(Math.round(charge * 60.0F), 0, 60);

      for (int i = 0; i < 60; i++) {
         float angle = (float)(i * 2.0 * Math.PI / 60.0);
         float halfChord = 0.76887906F;
         graphics.pose().pushPose();
         graphics.pose().translate(centreX + 0.5F, centreY + 0.5F, 0.0F);
         graphics.pose().mulPose(Axis.ZP.rotation(angle));
         graphics.fill(Math.round(-halfChord), Math.round(-8.0F), Math.round(halfChord), Math.round(-6.0F), i < filled && !blanked ? fillColor : 1509949439);
         graphics.pose().popPose();
      }

      String percent = value(blanked, String.valueOf(Math.round(charge * 100.0F)));
      this.centreText(graphics, minecraft, percent, centreX + 0.75F, centreY, 1.0F, !blanked && charge <= 0.15F ? -2076092 : -1);
   }

   private void drawNoSignalBadge(GuiGraphics graphics, Minecraft minecraft, int x, int y) {
      String label = "No signal";
      int padding = 6;
      int textWidth = (int)Math.ceil(this.width(minecraft, label, 1.35F));
      int badgeWidth = textWidth + padding * 2;
      int badgeHeight = 15;
      int radius = 3;
      graphics.fill(x, y + radius, x + badgeWidth, y + badgeHeight - radius, -58597);

      for (int row = 0; row < radius; row++) {
         int inset = radius - row;
         graphics.fill(x + inset, y + row, x + badgeWidth - inset, y + row + 1, -58597);
         graphics.fill(x + inset, y + badgeHeight - row - 1, x + badgeWidth - inset, y + badgeHeight - row, -58597);
      }

      this.centreText(graphics, minecraft, label, x + badgeWidth / 2, y + badgeHeight / 2, 1.35F, -1);
   }

   private void drawThermalBadge(GuiGraphics graphics, Minecraft minecraft, int x, int y) {
      String label = "Thermal";
      int padding = 6;
      int badgeWidth = (int)Math.ceil(this.width(minecraft, label, 1.35F)) + padding * 2;
      int badgeHeight = 15;
      this.roundedRect(graphics, x, y, badgeWidth, badgeHeight, 3, -2065896);
      this.centreText(graphics, minecraft, label, x + badgeWidth / 2.0F, y + badgeHeight / 2.0F, 1.35F, -1);
   }

   private void drawSideControls(GuiGraphics graphics, int width, int height) {
      this.icon(graphics, LAND, 6, height / 2 - 40, 15);
      this.icon(graphics, FILM, width - 21, (int)(height * 0.3F), 14);
      Minecraft minecraft = Minecraft.getInstance();
      int zoomX = width - 36;
      int zoomY = height / 2 - 34;
      int zoomSize = 24;
      this.icon(graphics, ZOOM_DISC, zoomX, zoomY, zoomSize);
      float zoom = DroneControl.zoom();
      String zoomText = zoom == Math.floor(zoom) ? String.format(Locale.ROOT, "%d×", (int)zoom) : String.format(Locale.ROOT, "%.1f×", zoom);
      this.centreText(graphics, minecraft, zoomText, zoomX + zoomSize / 2.0F, zoomY + zoomSize / 2.0F, 1.0F, -1);
      this.icon(graphics, RECORD, width - 37, height / 2 - 4, 26);
      this.icon(graphics, PLAY, width - 32, height / 2 + 32, 16);
   }

   private void drawCompass(GuiGraphics graphics, DroneTelemetry telemetry, boolean blanked, int height) {
      Minecraft minecraft = Minecraft.getInstance();
      int boxX = 5;
      int boxY = height - 89;
      this.icon(graphics, COMPASS, boxX, boxY, 84);
      int centerX = boxX + 42;
      int centerY = boxY + 38;
      graphics.blit(ATLAS, centerX - 32, centerY - 32, 64, 64, ARROW[0], ARROW[1], ARROW[2], ARROW[3], 256, 256);
      float yaw = telemetry.droneYaw();
      String[] names = new String[]{"N", "E", "S", "W"};
      float[] worldYaws = new float[]{180.0F, -90.0F, 0.0F, 90.0F};

      for (int i = 0; i < 4; i++) {
         double relative = Math.toRadians(Mth.wrapDegrees(worldYaws[i] - yaw));
         float x = centerX + (float)Math.sin(relative) * 26.0F;
         float y = centerY - (float)Math.cos(relative) * 26.0F;
         if (i == 0) {
            this.icon(graphics, N_BADGE, (int)x - 5, (int)y - 5, 10);
         }

         float letterWidth = this.width(minecraft, names[i], 1.0F);
         this.text(graphics, names[i], x - letterWidth / 2.0F, y - 3.5F, 1.0F, -385875969);
      }

      if (!blanked) {
         double relative = Math.toRadians(Mth.wrapDegrees(telemetry.operatorYaw() - yaw));
         float radius = 6.0F + (float)Math.min(telemetry.distance() / telemetry.linkRange(), 1.0) * 20.0F;
         int markX = centerX + (int)(Math.sin(relative) * radius) - 5;
         int markY = centerY - (int)(Math.cos(relative) * radius) - 5;
         this.icon(graphics, H_MARK, markX, markY, 10);
      }

      this.icon(graphics, GREEN_DOT, centerX - 3, centerY - 3, 6);
      this.text(graphics, "L", boxX + 7, boxY + 72, 1.0F, -3550506);

      for (int i = 0; i < 3; i++) {
         graphics.fill(boxX + 64 + i * 5, boxY + 74 + (2 - i), boxX + 67 + i * 5, boxY + 79, -1258291201);
      }
   }

   private void drawTelemetry(GuiGraphics graphics, Minecraft minecraft, DroneTelemetry telemetry, boolean blanked, int height) {
      int x = 96;
      this.icon(graphics, ALT, x, height - 39, 10);
      String altText = value(blanked, String.format(Locale.ROOT, "%.0f m", telemetry.altitude()));
      this.text(graphics, altText, x + 14, height - 42, 1.9F, -1);
      this.text(
         graphics,
         value(blanked, String.format(Locale.ROOT, "%.1f km/h", telemetry.verticalKmh())),
         x + 18 + this.width(minecraft, altText, 1.9F),
         height - 38,
         1.0F,
         -3550506
      );
      this.icon(graphics, DIST, x, height - 21, 10);
      String distText = value(blanked, String.format(Locale.ROOT, "%.0f m", telemetry.distance()));
      this.text(graphics, distText, x + 14, height - 24, 1.9F, -1);
      this.text(
         graphics,
         value(blanked, String.format(Locale.ROOT, "%.1f km/h", telemetry.horizontalKmh())),
         x + 18 + this.width(minecraft, distText, 1.9F),
         height - 20,
         1.0F,
         -3550506
      );
   }

   private void drawCaptureInfo(GuiGraphics graphics, Minecraft minecraft, DroneTelemetry telemetry, boolean blanked, int width, int height) {
      int labelY = height - 34;
      int valueY = height - 22;
      int cursor = width - 8;
      int chipWidth = 26;
      int chipX = cursor - chipWidth;
      int chipY = valueY - 2;
      graphics.fill(chipX, chipY, chipX + chipWidth, chipY + 1, -1);
      graphics.fill(chipX, chipY + 11, chipX + chipWidth, chipY + 12, -1);
      graphics.fill(chipX, chipY, chipX + 1, chipY + 12, -1);
      graphics.fill(chipX + chipWidth - 1, chipY, chipX + chipWidth, chipY + 12, -1);
      float autoWidth = this.width(minecraft, "AUTO", 1.0F);
      this.text(graphics, "AUTO", chipX + chipWidth / 2.0F - autoWidth / 2.0F, chipY + 3, 1.0F, -1);
      cursor = chipX - 12;
      cursor = this.column(graphics, minecraft, "EV", value(blanked, "+0.3"), cursor, labelY, valueY);
      cursor = this.column(graphics, minecraft, "RES&FPS", value(blanked, telemetry.resolution()), cursor, labelY, valueY);
      int storageSeconds = Math.max(0, 2700 - telemetry.flightSeconds());
      String storage = String.format(Locale.ROOT, "%02d:%02d:%02d", storageSeconds / 3600, storageSeconds % 3600 / 60, storageSeconds % 60);
      this.column(graphics, minecraft, "Storage", value(blanked, storage), cursor, labelY, valueY);
   }

   private int column(GuiGraphics graphics, Minecraft minecraft, String label, String value, int rightX, int labelY, int valueY) {
      float labelWidth = this.width(minecraft, label, 1.0F);
      float valueWidth = this.width(minecraft, value, 1.35F);
      float columnWidth = Math.max(labelWidth, valueWidth);
      this.text(graphics, label, rightX - columnWidth, labelY, 1.0F, -3550506);
      this.text(graphics, value, rightX - columnWidth, valueY, 1.35F, -1);
      return rightX - (int)columnWidth - 12;
   }

   private void icon(GuiGraphics graphics, int[] region, int x, int y, int size) {
      int drawHeight = size * region[3] / region[2];
      graphics.blit(ATLAS, x, y, size, drawHeight, region[0], region[1], region[2], region[3], 256, 256);
   }

   private void centreText(GuiGraphics graphics, Minecraft minecraft, String string, float centreX, float centreY, float scale, int color) {
      float textWidth = this.width(minecraft, string, scale);
      float ascent = (9 - 1) * scale;
      this.text(graphics, string, centreX - textWidth / 2.0F, centreY - ascent / 2.0F, scale, color);
   }

   private void text(GuiGraphics graphics, String string, float x, float y, float scale, int color) {
      graphics.pose().pushPose();
      graphics.pose().translate(x, y, 0.0F);
      graphics.pose().scale(scale, scale, 1.0F);
      graphics.drawString(Minecraft.getInstance().font, component(string), 0, 0, color, false);
      graphics.pose().popPose();
   }

   private float width(Minecraft minecraft, String string, float scale) {
      return minecraft.font.width(component(string)) * scale;
   }

   private static Component component(String string) {
      return Component.literal(string).setStyle(FONT);
   }
}
