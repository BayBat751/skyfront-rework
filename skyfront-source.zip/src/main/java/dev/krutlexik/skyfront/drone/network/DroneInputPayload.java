package dev.krutlexik.skyfront.drone.network;

import dev.krutlexik.skyfront.drone.DroneMod;
import dev.krutlexik.skyfront.drone.entity.PilotInput;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;

public record DroneInputPayload(int entityId, PilotInput input) implements CustomPacketPayload {
   public static final int FORWARD = 1;
   public static final int BACKWARD = 2;
   public static final int LEFT = 4;
   public static final int RIGHT = 8;
   public static final int UP = 16;
   public static final int DOWN = 32;
   public static final int ARM_SET = 64;
   public static final int ARM_ON = 128;
   public static final Type<DroneInputPayload> TYPE = new Type(DroneMod.id("drone_input"));
   public static final StreamCodec<FriendlyByteBuf, DroneInputPayload> STREAM_CODEC = StreamCodec.of((buf, payload) -> {
      buf.writeVarInt(payload.entityId);
      payload.input.write(buf);
   }, buf -> new DroneInputPayload(buf.readVarInt(), PilotInput.read(buf)));

   public static byte pack(boolean forward, boolean backward, boolean left, boolean right, boolean up, boolean down) {
      int keys = 0;
      if (forward) {
         keys |= 1;
      }

      if (backward) {
         keys |= 2;
      }

      if (left) {
         keys |= 4;
      }

      if (right) {
         keys |= 8;
      }

      if (up) {
         keys |= 16;
      }

      if (down) {
         keys |= 32;
      }

      return (byte)keys;
   }

   public Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }
}
