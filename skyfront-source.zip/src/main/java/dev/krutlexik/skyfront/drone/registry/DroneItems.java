package dev.krutlexik.skyfront.drone.registry;

import dev.krutlexik.skyfront.drone.item.DroneItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Item.Properties;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredRegister.Items;

public final class DroneItems {
   public static final Items ITEMS = DeferredRegister.createItems("sfw");
   public static final DeferredItem<Item> DRONE = ITEMS.registerItem("drone", DroneItem::new, new Properties().stacksTo(1));
   public static final DeferredItem<Item> THERMAL_DRONE = ITEMS.registerItem(
      "thermal_drone", properties -> new DroneItem(properties, DroneEntities.THERMAL_DRONE), new Properties().stacksTo(1)
   );
   public static final DeferredItem<Item> INTERCEPTOR_DRONE = ITEMS.registerItem(
      "interceptor_drone", properties -> new DroneItem(properties, DroneEntities.INTERCEPTOR_DRONE), new Properties().stacksTo(1)
   );
   public static final DeferredItem<Item> THERMAL_INTERCEPTOR_DRONE = ITEMS.registerItem(
      "thermal_interceptor_drone", properties -> new DroneItem(properties, DroneEntities.THERMAL_INTERCEPTOR_DRONE), new Properties().stacksTo(1)
   );
   public static final DeferredItem<Item> FPV_DRONE = ITEMS.registerItem(
      "fpv_drone", properties -> new DroneItem(properties, DroneEntities.FPV_DRONE), new Properties().stacksTo(1)
   );
   public static final DeferredItem<Item> MOLNIYA_DRONE = ITEMS.registerItem(
      "molniya_drone", properties -> new DroneItem(properties, DroneEntities.MOLNIYA_DRONE, true), new Properties().stacksTo(1)
   );

   private DroneItems() {
   }
}
