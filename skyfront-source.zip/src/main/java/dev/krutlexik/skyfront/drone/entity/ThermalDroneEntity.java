package dev.krutlexik.skyfront.drone.entity;

import dev.krutlexik.skyfront.config.SkyfrontConfig;
import dev.krutlexik.skyfront.drone.DroneTuning;
import dev.krutlexik.skyfront.drone.registry.DroneItems;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;

public class ThermalDroneEntity extends DroneEntity {
   private static final double THRUST_MARGIN = 1.25;

   public ThermalDroneEntity(EntityType<? extends ThermalDroneEntity> type, Level level) {
      super(type, level);
   }

   @Override
   public boolean hasThermalCamera() {
      return true;
   }

   @Override
   public double controlRange() {
      return ((Integer)SkyfrontConfig.MAVIC_3T_CONTROL_RANGE.get()).intValue();
   }

   @Override
   public int fullFlightTicks() {
      return (int)DroneTuning.get(DroneTuning.Value.MAVIC_3T_FLIGHT_SECONDS) * 20;
   }

   @Override
   protected double topSpeed() {
      return DroneTuning.get(DroneTuning.Value.MAVIC_3T_TOP_SPEED) / 72.0;
   }

   @Override
   protected float thrust() {
      double keep = 0.9555F;
      double needed = this.topSpeed() * (1.0 - keep) / keep * 1.25;
      return (float)Math.max(needed, (double)super.thrust());
   }

   @Override
   public ItemStack packedItem() {
      return new ItemStack((ItemLike)DroneItems.THERMAL_DRONE.get());
   }
}
