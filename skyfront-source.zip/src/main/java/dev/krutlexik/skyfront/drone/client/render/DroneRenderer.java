package dev.krutlexik.skyfront.drone.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.krutlexik.skyfront.drone.DroneMod;
import dev.krutlexik.skyfront.drone.GrenadeAttachments;
import dev.krutlexik.skyfront.drone.entity.DroneEntity;
import dev.krutlexik.skyfront.drone.entity.InterceptorDroneEntity;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;

public class DroneRenderer<T extends DroneEntity> extends EntityRenderer<T> {
   public static final ResourceLocation RECON_MODEL = DroneMod.id("models/entity/drone.glb");
   public static final float RECON_SCALE = 0.025F;
   public static final ResourceLocation FPV_MODEL = DroneMod.id("models/entity/p1sun.glb");
   public static final float FPV_SCALE = 1.0F;
   public static final float FPV_LEVEL_AT_PITCH = -40.7F;
   public static final ResourceLocation MOLNIYA_MODEL = DroneMod.id("models/entity/molniya.glb");
   public static final ResourceLocation FPV_QUAD_MODEL = DroneMod.id("models/entity/fpv.glb");
   public static final float FPV_QUAD_SCALE = 1.2F;
   public static final float MOLNIYA_SCALE = 1.4F;
   public static final float MOLNIYA_LEVEL_AT_PITCH = -21.1F;
   private static final List<ResourceLocation> MODELS = List.of(RECON_MODEL, FPV_MODEL, MOLNIYA_MODEL, FPV_QUAD_MODEL);
   private static final Map<ResourceLocation, Boolean> SPIN_PROPELLERS = Map.of(
      RECON_MODEL, Boolean.TRUE, FPV_MODEL, Boolean.TRUE, MOLNIYA_MODEL, Boolean.TRUE, FPV_QUAD_MODEL, Boolean.TRUE
   );
   private static final Map<ResourceLocation, GlbModel> LOADED = new HashMap<>();
   private static final Map<ResourceLocation, Boolean> FAILED = new HashMap<>();
   private final ResourceLocation model;
   private final float scale;
   private final boolean centreOnBounds;
   private final DroneRenderer.ModelTrim trim;
   public static final DroneRenderer.ModelTrim AS_HELD = (drone, partialTick) -> 0.0F;

   public static DroneRenderer.ModelTrim gentlerLean(float share) {
      return (drone, partialTick) -> {
         float pitch = drone.bodyPitch(partialTick);
         float t = Mth.clamp((Math.abs(pitch) - 50.0F) / 35.0F, 0.0F, 1.0F);
         return -pitch * share * (1.0F - t * t * (3.0F - 2.0F * t));
      };
   }

   public static DroneRenderer.ModelTrim tailSitter(float levelAtPitch) {
      return (drone, partialTick) -> bodyTip(drone.bodyPitch(partialTick), levelAtPitch);
   }

   public static DroneRenderer.ModelTrim fastCruise(float levelAtPitch) {
      return (drone, partialTick) -> {
         if (drone instanceof InterceptorDroneEntity plane) {
            double speed = Math.sqrt(drone.distanceToSqr(drone.xo, drone.yo, drone.zo));
            double cruise = plane.trimSpeed();
            double top = plane.topSpeedPerTick();
            double span = top * top - cruise * cruise;
            if (span <= 1.0E-6) {
               return 0.0F;
            } else {
               float t = (float)Mth.clamp((speed * speed - cruise * cruise) / span, 0.0, 1.0);
               float eased = t * t * (3.0F - 2.0F * t);
               return -levelAtPitch * eased;
            }
         } else {
            return 0.0F;
         }
      };
   }

   public DroneRenderer(Context context) {
      this(context, RECON_MODEL, 0.025F, false);
   }

   public DroneRenderer(Context context, ResourceLocation model, float scale, boolean centreOnBounds) {
      this(context, model, scale, centreOnBounds, AS_HELD);
   }

   public DroneRenderer(Context context, ResourceLocation model, float scale, boolean centreOnBounds, DroneRenderer.ModelTrim trim) {
      super(context);
      this.model = model;
      this.scale = scale;
      this.centreOnBounds = centreOnBounds;
      this.trim = trim;
      this.shadowRadius = 0.5F;
      this.shadowStrength = 0.4F;
   }

   public static void reload(ResourceManager resources) {
      LOADED.clear();
      FAILED.clear();

      for (ResourceLocation model : MODELS) {
         load(resources, model);
      }
   }

   @Nullable
   private static GlbModel load(ResourceManager resources, ResourceLocation location) {
      try {
         GlbModel loaded = GlbModel.load(resources, location, SPIN_PROPELLERS.getOrDefault(location, Boolean.TRUE));
         LOADED.put(location, loaded);
         DroneMod.LOGGER
            .info(
               "Loaded drone model {} ({} triangles, {} animated groups, resting {} model units above the entity origin)",
               new Object[]{location, loaded.triangleCount(), loaded.animatedGroupCount(), -loaded.minY()}
            );
         return loaded;
      } catch (Exception var3) {
         FAILED.put(location, Boolean.TRUE);
         DroneMod.LOGGER.error("Could not load drone model {}", location, var3);
         return null;
      }
   }

   @Nullable
   public static GlbModel model(ResourceLocation location) {
      GlbModel loaded = LOADED.get(location);
      if (loaded == null && !FAILED.containsKey(location)) {
         loaded = load(Minecraft.getInstance().getResourceManager(), location);
      }

      return loaded;
   }

   @Nullable
   private GlbModel model() {
      return model(this.model);
   }

   public void render(T drone, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int light) {
      GlbModel glb = this.model();
      if (glb != null) {
         poseStack.pushPose();
         poseStack.translate(0.0F, -glb.minY() * this.scale, 0.0F);
         Quaternionf attitude = drone.isWrecked() ? drone.wreckRotation(partialTick) : drone.renderRotation(partialTick);
         if (attitude != null) {
            poseStack.mulPose(attitude);
         } else {
            poseStack.mulPose(Axis.YP.rotationDegrees(180.0F - entityYaw));
            float pitch = drone.isWrecked() ? -drone.getViewXRot(partialTick) : drone.bodyPitch(partialTick);
            float roll = drone.isWrecked() ? drone.getRoll(partialTick) : drone.bodyRoll(partialTick);
            if (pitch != 0.0F) {
               poseStack.mulPose(Axis.XP.rotationDegrees(pitch));
            }

            if (roll != 0.0F) {
               poseStack.mulPose(Axis.ZP.rotationDegrees(roll));
            }
         }

         poseStack.scale(this.scale, this.scale, this.scale);
         if (this.centreOnBounds) {
            poseStack.translate(-glb.centreX(), 0.0F, -glb.centreZ());
         }

         float tip = drone.isWrecked() ? 0.0F : this.trim.degrees(drone, partialTick);
         if (tip != 0.0F) {
            float midY = glb.minY() + glb.height() / 2.0F;
            poseStack.translate(glb.centreX(), midY, glb.centreZ());
            poseStack.mulPose(Axis.XP.rotationDegrees(tip));
            poseStack.translate(-glb.centreX(), -midY, -glb.centreZ());
         }

         glb.render(poseStack, buffers, light, OverlayTexture.NO_OVERLAY, drone.getPropPhase(partialTick));
         poseStack.popPose();
      }

      this.renderAttachment(drone, entityYaw, partialTick, poseStack, buffers, light);
      super.render(drone, entityYaw, partialTick, poseStack, buffers, light);
   }

   static float bodyTip(float pitch, float levelAtPitch) {
      float level = Math.abs(levelAtPitch);
      if (!(level < 0.001F) && !(level >= 90.0F)) {
         float t = Mth.clamp(Math.abs(pitch) / level, 0.0F, 1.0F);
         float eased = t * t * (3.0F - 2.0F * t);
         return Math.signum(pitch) * (90.0F - level) * eased;
      } else {
         return 0.0F;
      }
   }

   private void renderAttachment(DroneEntity drone, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int light) {
      if (drone.hasAttachment()) {
         Minecraft minecraft = Minecraft.getInstance();
         ItemStack attachment = drone.getAttachment();
         GrenadeAttachments.Mount mount = drone.mountFor(attachment);
         poseStack.pushPose();
         Quaternionf attitude = !drone.storesFollowAttitude()
            ? null
            : (drone.isWrecked() ? drone.wreckRotation(partialTick) : drone.renderRotation(partialTick));
         GlbModel glb = this.model();
         if (attitude != null && glb != null) {
            float lift = -glb.minY() * this.scale;
            poseStack.translate(0.0F, lift, 0.0F);
            poseStack.mulPose(attitude);
            float tip = drone.isWrecked() ? 0.0F : this.trim.degrees(drone, partialTick);
            if (tip != 0.0F) {
               float midY = (glb.minY() + glb.height() / 2.0F) * this.scale;
               poseStack.translate(0.0F, midY, 0.0F);
               poseStack.mulPose(Axis.XP.rotationDegrees(tip));
               poseStack.translate(0.0F, -midY, 0.0F);
            }

            poseStack.translate(0.0F, mount.y() - lift, 0.0F);
         } else {
            poseStack.translate(0.0F, mount.y(), 0.0F);
            poseStack.mulPose(Axis.YP.rotationDegrees(180.0F - entityYaw));
         }

         poseStack.translate(0.0F, 0.0F, mount.z());
         if (mount.yaw() != 0.0F) {
            poseStack.mulPose(Axis.YP.rotationDegrees(mount.yaw()));
         }

         if (mount.pitch() != 0.0F) {
            poseStack.mulPose(Axis.XP.rotationDegrees(mount.pitch()));
         }

         if (mount.roll() != 0.0F) {
            poseStack.mulPose(Axis.ZP.rotationDegrees(mount.roll()));
         }

         poseStack.scale(mount.scale(), mount.scale(), mount.scale());
         BedrockStoreModel round = mount.display() != null ? BedrockStoreModel.forProjectile(mount.display()) : null;
         if (round != null) {
            round.render(poseStack, buffers, light);
         } else {
            minecraft.getItemRenderer()
               .renderStatic(attachment, ItemDisplayContext.GROUND, light, OverlayTexture.NO_OVERLAY, poseStack, buffers, drone.level(), 0);
         }

         poseStack.popPose();
      }
   }

   public ResourceLocation getTextureLocation(T drone) {
      return this.model;
   }

   @FunctionalInterface
   public interface ModelTrim {
      float degrees(DroneEntity var1, float var2);
   }
}
