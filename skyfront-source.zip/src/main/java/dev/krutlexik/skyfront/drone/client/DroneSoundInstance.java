package dev.krutlexik.skyfront.drone.client;

import dev.krutlexik.skyfront.drone.entity.DroneEntity;
import dev.krutlexik.skyfront.drone.registry.DroneSounds;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;

public class DroneSoundInstance extends AbstractTickableSoundInstance {
   private static final float IDLE_VOLUME = 0.32F;
   private static final float MAX_VOLUME = 0.55F;
   private static final float VOLUME_STEP = 0.05F;
   private static final float IDLE_PITCH = 0.92F;
   private static final float MAX_PITCH = 1.08F;
   private static final float SPIN_DOWN_PITCH = 0.55F;
   private static final float WRECKED_PITCH = 0.42F;
   private static final float PITCH_STEP = 0.035F;
   private float wreckWobble;
   private final DroneEntity drone;
   private float targetVolume;

   public DroneSoundInstance(DroneEntity drone) {
      super((SoundEvent)DroneSounds.DRONE_LOOP.get(), SoundSource.NEUTRAL, SoundInstance.createUnseededRandom());
      this.drone = drone;
      this.looping = true;
      this.delay = 0;
      this.volume = 0.0F;
      this.pitch = 0.92F;
      this.x = drone.getX();
      this.y = drone.getY();
      this.z = drone.getZ();
   }

   public boolean canStartSilent() {
      return true;
   }

   public void tick() {
      boolean airborne = !this.drone.isRemoved() && !this.drone.isGrounded();
      if (!this.drone.isRemoved()) {
         this.x = this.drone.getX();
         this.y = this.drone.getY();
         this.z = this.drone.getZ();
      }

      if (this.drone.isWrecked()) {
         this.wreckWobble += 0.5F;
         float wobble = Mth.sin(this.wreckWobble) * 0.12F;
         this.targetVolume = 0.55F;
         this.pitch = approach(this.pitch, 0.42F + wobble, 0.105000004F);
         this.volume = approach(this.volume, this.targetVolume, 0.05F);
         if (this.drone.isRemoved()) {
            this.stop();
         }
      } else {
         if (airborne) {
            float speed = (float)this.drone.getDeltaMovement().length();
            float throttle = Mth.clamp(speed / 0.9F, 0.0F, 1.0F);
            float ceiling = this.drone.getCharge() > 0.0F ? 0.55F : 0.32F;
            float topPitch = this.drone.getCharge() > 0.0F ? 1.08F : 0.92F;
            this.targetVolume = Mth.lerp(throttle, 0.32F, ceiling);
            this.pitch = approach(this.pitch, Mth.lerp(throttle, 0.92F, topPitch), 0.035F);
         } else {
            this.targetVolume = 0.0F;
            this.pitch = approach(this.pitch, 0.55F, 0.035F);
         }

         this.volume = approach(this.volume, this.targetVolume, 0.05F);
         if (this.drone.isRemoved() && this.volume <= 0.001F) {
            this.stop();
         }
      }
   }

   private static float approach(float value, float goal, float step) {
      return value < goal ? Math.min(value + step, goal) : Math.max(value - step, goal);
   }
}
