package dev.krutlexik.skyfront.drone.client;

import dev.krutlexik.skyfront.drone.entity.DroneEntity;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

public class InavOsd extends AnalogOsd {
   private static final int SYM_SIGNAL = 1;
   private static final int SYM_VOLTS = 6;
   private static final int SYM_MAH = 7;
   private static final int SYM_METRE = 12;
   private static final int SYM_SATELLITE = 31;
   private static final int SYM_POINT_RIGHT = 119;
   private static final int SYM_POINT_LEFT = 120;
   private static final int SYM_BATTERY_FULL = 144;
   private static final int SYM_BATTERY_EMPTY = 150;
   private static final int SYM_MAIN_BATTERY = 151;
   private static final int SYM_AMPS = 154;
   private static final int SYM_KMH = 158;
   private static final int SYM_MS = 159;
   private static final int LEFT_COL = 2;
   private static final int RIGHT_COL = 28;
   private static final int ROW_TOP = 1;
   private static final int ROW_SECOND = 2;
   private static final int ROW_THIRD = 3;
   private static final int ROW_PITCH = 4;
   private static final int ROW_CENTRE = 7;
   private static final int ROW_WARNING = 11;
   private static final int ROW_BOTTOM_1 = 12;
   private static final int ROW_BOTTOM_2 = 13;
   private static final int ROW_BOTTOM_3 = 14;
   private static final int TAPE_HALF = 78;
   private static final float TAPE_PX_PER_DEGREE = 0.8F;
   private static final int LADDER_HALF = 44;
   private static final float SPEED_LADDER_COL = 7.2F;
   private static final float ALT_LADDER_COL = 23.2F;
   private static final int LADDER_TICK_PX = 6;
   private static final float SPEED_PER_TICK = 5.0F;
   private static final float ALT_PER_TICK = 5.0F;
   private static final long BLINK_MS = 400L;
   private static final String FLIGHT_MODE = "FBWA";
   private static int tripDroneId = -1;
   private static double tripBlocks;
   private static Vec3 tripLast;
   private static InavOsd.Reading lost;
   private static final int[][] AIRCRAFT = new int[][]{
      {-1, -4, 1, -4},
      {-1, 4, 1, 4},
      {-4, -1, -4, 1},
      {4, -1, 4, 1},
      {-3, -3, -2, -3},
      {2, -3, 3, -3},
      {-3, 3, -2, 3},
      {2, 3, 3, 3},
      {-3, -2, -3, -2},
      {3, -2, 3, -2},
      {-3, 2, -3, 2},
      {3, 2, 3, 2},
      {0, -14, 0, -8}
   };

   public static void captureSignalLoss(DroneEntity drone) {
      lost = read(drone, 1.0F);
   }

   public void render(GuiGraphics graphics, DroneEntity drone, float partialTick) {
      this.setUpFrame(graphics);
      this.draw(read(drone, partialTick), false);
   }

   public void renderSignalLost(GuiGraphics graphics) {
      if (lost != null) {
         this.setUpFrame(graphics);
         this.draw(lost, true);
      }
   }

   private static InavOsd.Reading read(DroneEntity drone, float partialTick) {
      if (drone.getId() != tripDroneId) {
         tripDroneId = drone.getId();
         tripBlocks = 0.0;
         tripLast = null;
      }

      Vec3 here = drone.position();
      if (tripLast != null) {
         double step = here.distanceTo(tripLast);
         if (step < 20.0) {
            tripBlocks += step;
         }
      }

      tripLast = here;
      Vec3 velocity = drone.getDeltaMovement();
      float heading = Mth.positiveModulo(drone.getViewYRot(partialTick) + 180.0F, 360.0F);
      return new InavOsd.Reading(
         tripBlocks / 1000.0,
         FpvBattery.cellVolts(),
         heading,
         Math.round(drone.bodyPitch(partialTick)),
         Math.round(drone.bodyRoll(partialTick)),
         velocity.length() * 72.0,
         altitude(drone),
         homeDistance(drone),
         velocity.y * 20.0,
         FpvBattery.packVolts(),
         FpvBattery.amps(),
         FpvBattery.mahDrawn(drone),
         drone.getCharge(),
         FpvBattery.armedSeconds(),
         drone.isArmed(),
         DroneControl.isArmRefused(),
         DroneControl.isArmedFlash(),
         drone.bodyPitch(partialTick)
      );
   }

   private void draw(InavOsd.Reading r, boolean linkLost) {
      boolean blink = System.currentTimeMillis() / 400L % 2L == 0L;
      this.text(2, 1, String.format(Locale.ROOT, "%.1fKM", r.tripKm()));
      this.text(2, 4, String.format(Locale.ROOT, "PIT %+.1f", r.pitchExact()));
      this.drawHeadingTape(r.heading());
      this.centre(3, String.format(Locale.ROOT, "%03d", Math.round(r.heading()) % 360));
      if (!linkLost) {
         this.rightText(28, 1, glyph(31) + glyph(1));
      }

      this.rightText(28, 2, String.format(Locale.ROOT, "%+d P", r.pitch()));
      this.rightText(28, 3, String.format(Locale.ROOT, "%+d R", r.roll()));
      this.drawLadder(7.2F, (float)(r.speedKmh() / 5.0), true);
      this.rightText(7, 7, String.format(Locale.ROOT, "%03d", Math.round(r.speedKmh())) + glyph(119));
      this.rightText(6, 8, glyph(158));
      this.drawLadder(23.2F, (float)(r.altitude() / 5.0), false);
      this.text(24, 7, glyph(120) + String.format(Locale.ROOT, "%04d", Math.round(r.altitude())));
      this.text(25, 8, glyph(12));
      this.drawAircraft();
      boolean packWarning = r.armed() && r.cellVolts() < 3.5;
      if (!packWarning || blink || linkLost) {
         this.text(1, 12, glyph(151) + String.format(Locale.ROOT, "%.2f", r.cellVolts()) + glyph(6));
      }

      this.text(2, 13, String.format(Locale.ROOT, "%.1f", r.amps()) + glyph(154));
      this.text(1, 14, glyph(batterySymbol(r.charge())) + r.mah() + glyph(7));
      if (linkLost) {
         this.offsetFromCentre(11, "RX LOSS", -4.0F);
         this.centre(12, "FBWA");
      } else if (!r.armed()) {
         this.centre(12, r.armRefused() ? "THROTTLE" : "DISARMED");
      } else if (r.armedFlash()) {
         this.centre(12, "ARMED");
      } else {
         this.centre(12, "FBWA");
         if (r.cellVolts() < 3.0 && blink) {
            this.centre(11, "LAND NOW");
         } else if (packWarning && blink) {
            this.centre(11, "LOW BATTERY");
         }
      }

      this.centre(14, Math.round(r.homeDistance()) + glyph(12));
      this.rightText(28, 12, String.format(Locale.ROOT, "%+d", Math.round(r.climb())) + glyph(159));
      this.rightText(28, 13, "U" + String.format(Locale.ROOT, "%.1f", r.packVolts()) + glyph(6));
      this.rightText(28, 14, String.format(Locale.ROOT, "%d:%02d", r.seconds() / 60, r.seconds() % 60));
   }

   private void drawHeadingTape(float heading) {
      float centreX = this.colX(15.5F);
      float tapeY = this.rowY(2.75F);
      List<int[]> lines = new ArrayList<>();
      int first = (int)Math.ceil((heading - 97.5F) / 5.0F) * 5;

      for (int degrees = first; degrees <= heading + 97.5F; degrees += 5) {
         int x = Math.round((degrees - heading) * 0.8F);
         int length = Math.floorMod(degrees, 15) == 0 ? 4 : 2;
         lines.add(new int[]{x, 0, x, -length});
      }

      lines.add(new int[]{-2, -12, 2, -12});
      lines.add(new int[]{-1, -11, 1, -11});
      lines.add(new int[]{0, -10, 0, -10});
      this.strokes(centreX, tapeY, lines.toArray(new int[0][]));
      String[] names = new String[]{"N", "E", "S", "W"};

      for (int i = 0; i < 4; i++) {
         float offset = Mth.wrapDegrees(i * 90.0F - heading);
         if (!(Math.abs(offset) * 0.8F > 72.0F)) {
            float x = centreX + offset * 0.8F * this.glyphW / 12.0F - this.glyphW / 2.0F;
            this.drawString(x, this.rowY(2.0F) - this.glyphH * 0.55F, names[i]);
         }
      }
   }

   private void drawLadder(float col, float ticks, boolean left) {
      float x = this.colX(col);
      float y = this.rowY(7.5F);
      List<int[]> lines = new ArrayList<>();
      lines.add(new int[]{0, -44, 0, 44});
      int whole = (int)Math.floor(ticks);
      float fraction = ticks - whole;
      int reach = 7;

      for (int i = -reach - 1; i <= reach + 1; i++) {
         int ty = Math.round((i + fraction) * 6.0F);
         if (Math.abs(ty) <= 44) {
            int length = Math.floorMod(whole - i, 2) == 0 ? 4 : 2;
            lines.add(left ? new int[]{0, ty, length, ty} : new int[]{-length, ty, 0, ty});
         }
      }

      this.strokes(x, y, lines.toArray(new int[0][]));
   }

   private void drawAircraft() {
      this.strokes(this.colX(15.5F), this.rowY(7.5F), AIRCRAFT);
   }

   private static int batterySymbol(float charge) {
      int step = Math.round((1.0F - Mth.clamp(charge, 0.0F, 1.0F)) * 6.0F);
      return Mth.clamp(144 + step, 144, 150);
   }

   private record Reading(
      double tripKm,
      double cellVolts,
      float heading,
      int pitch,
      int roll,
      double speedKmh,
      double altitude,
      double homeDistance,
      double climb,
      double packVolts,
      double amps,
      int mah,
      float charge,
      int seconds,
      boolean armed,
      boolean armRefused,
      boolean armedFlash,
      float pitchExact
   ) {
   }
}
