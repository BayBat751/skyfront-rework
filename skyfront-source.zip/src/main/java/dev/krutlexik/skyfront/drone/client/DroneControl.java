package dev.krutlexik.skyfront.drone.client;

import dev.krutlexik.skyfront.compat.sable.SableCompat;
import dev.krutlexik.skyfront.config.SkyfrontConfig;
import dev.krutlexik.skyfront.drone.DroneMod;
import dev.krutlexik.skyfront.drone.GrenadeAttachments;
import dev.krutlexik.skyfront.drone.RateModeFlight;
import dev.krutlexik.skyfront.drone.client.radio.RadioInput;
import dev.krutlexik.skyfront.drone.entity.DroneEntity;
import dev.krutlexik.skyfront.drone.entity.DroneFlightState;
import dev.krutlexik.skyfront.drone.entity.InterceptorDroneEntity;
import dev.krutlexik.skyfront.drone.entity.PilotInput;
import dev.krutlexik.skyfront.drone.network.DroneDropPayload;
import dev.krutlexik.skyfront.drone.network.DroneInputPayload;
import dev.krutlexik.skyfront.drone.network.DroneLinkPayload;
import dev.krutlexik.skyfront.drone.network.DroneRamPayload;
import dev.krutlexik.skyfront.drone.network.DroneSelfDestructPayload;
import dev.krutlexik.skyfront.drone.network.StartControlPayload;
import dev.krutlexik.skyfront.drone.network.StopControlRequestPayload;
import dev.krutlexik.skyfront.drone.radio.RadioProfile;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity.RemovalReason;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;
import org.jetbrains.annotations.Nullable;

public final class DroneControl {
   public static final float MIN_ZOOM = 1.0F;
   @Nullable
   private static DroneEntity drone;
   private static float zoom = 1.0F;
   private static float zoomTarget = 1.0F;
   private static long zoomClock;
   private static final double ZOOM_EASE = 12.0;
   public static final float CAMERA_LENS = 1.1F;
   private static int flyingId = -1;
   private static int missingTicks;
   private static final int MISSING_GRACE_TICKS = 200;
   private static double pendingYaw;
   private static double pendingPitch;
   private static final double GIMBAL_EASING = 0.35;
   private static int inputSeq;
   private static final DronePrediction PREDICTION = new DronePrediction();
   private static int flightTicks;
   private static final double STICK_FULL_SCALE = 47.0;
   private static final double STICK_EXPO = 0.45;
   private static final double STICK_REFERENCE_FRAME = 0.016666666666666666;
   private static final double STICK_SMOOTHING = 32.0;
   private static double stickRollNow;
   private static double stickPitchNow;
   private static double stickRollIntegral;
   private static double stickPitchIntegral;
   private static double stickSampleTime;
   private static double stickYaw;
   private static double stickThrottle;
   private static final double YAW_RISE = 4.0;
   private static final double YAW_FALL = 5.5;
   private static final double THROTTLE_RISE = 8.5;
   private static final double THROTTLE_FALL = 4.0;
   private static final double THROTTLE_CUT = 2.5;
   private static float cameraTilt = 25.0F;
   private static final float MAX_CAMERA_TILT = 90.0F;
   private static final Map<EntityType<?>, Float> TILT_BY_TYPE = new HashMap<>();
   @Nullable
   private static Vec3 pilotAnchor;
   @Nullable
   private static Supplier<Vec3> pilotAnchorOnSubLevel;
   private static boolean hudHiddenByUs;
   private static boolean savedHideGui;
   private static int fpvStaticTicks = -1;
   private static final int FPV_HOLD_DURATION_TICKS = 100;
   private static int impactPredictedTicks = -1;
   private static int cameraImpactTicks = -1;
   private static final int IMPACT_CONFIRM_TICKS = 20;
   private static boolean replacingEntity;
   private static int deferredRemovalId = -1;
   @Nullable
   private static RemovalReason deferredRemovalReason;
   private static double serverControlRange;
   private static final int ARMED_FLASH_TICKS = 20;
   private static int armedFlashTicks;
   private static boolean wasArmed;
   private static boolean armWanted;
   private static boolean armRequested;
   private static final int ARM_REFUSED_TICKS = 40;
   private static int armRefusedTicks;
   private static final double CAMERA_PITCH_STEP = 8.0;
   private static int dropCharge;
   private static int dropFlashTicks;
   private static final int DROP_CHARGE_TICKS = 20;
   private static final int DROP_FLASH_TICKS = 70;
   private static final int DROP_FLASH_IN_TICKS = 4;
   private static final int DROP_FLASH_OUT_TICKS = 12;
   private static boolean releaseButtonDown;

   public static float maxZoom() {
      return (float)((Double)SkyfrontConfig.MAVIC_MAX_ZOOM.get()).doubleValue();
   }

   public static int predictionCorrections() {
      return PREDICTION.corrections();
   }

   public static boolean onSticks() {
      return drone instanceof InterceptorDroneEntity interceptor && interceptor.rateMode();
   }

   public static float cameraTilt() {
      return cameraTilt;
   }

   private static void feedSticks(double dx, double dy, double frameSeconds) {
      double dt = Mth.clamp(frameSeconds, 0.0020833333333333333, 0.2);
      double frameScale = Mth.clamp(0.016666666666666666 / dt, 0.1, 8.0);
      double gain = (Double)SkyfrontConfig.INTERCEPTOR_MOUSE_GAIN.get() / 47.0;
      double x = dx * frameScale * gain;
      double y = dy * frameScale * gain;
      double magnitude = Math.min(Math.sqrt(x * x + y * y), 1.0);
      if (magnitude > 1.0E-6) {
         double curved = magnitude * 0.55 + magnitude * magnitude * magnitude * 0.45;
         double scale = curved / magnitude;
         x *= scale;
         y *= scale;
      }

      stickRollNow = RateModeFlight.approach(stickRollNow, Mth.clamp(x, -1.0, 1.0), 32.0, dt);
      stickPitchNow = RateModeFlight.approach(stickPitchNow, Mth.clamp(-y, -1.0, 1.0), 32.0, dt);
      stickRollIntegral = stickRollIntegral + stickRollNow * dt;
      stickPitchIntegral = stickPitchIntegral + stickPitchNow * dt;
      stickSampleTime += dt;
   }

   private static void tickStickKeys(Minecraft minecraft) {
      double dt = 0.05;
      boolean left = minecraft.options.keyLeft.isDown();
      boolean right = minecraft.options.keyRight.isDown();
      boolean up = minecraft.options.keyUp.isDown() || minecraft.options.keyJump.isDown();
      boolean down = minecraft.options.keyDown.isDown() || minecraft.options.keyShift.isDown();
      double yawTarget = (right ? 1.0 : 0.0) - (left ? 1.0 : 0.0);
      boolean yawRising = Math.abs(yawTarget) > Math.abs(stickYaw);
      stickYaw = RateModeFlight.approach(stickYaw, yawTarget, yawRising ? 4.0 : 5.5, dt);
      double rate = up ? 8.5 : (down ? 10.0 : 4.0);
      stickThrottle = Mth.clamp(RateModeFlight.approach(stickThrottle, up ? 1.0 : 0.0, rate, dt), 0.0, 1.0);
   }

   private static void clearSticks() {
      stickRollNow = 0.0;
      stickPitchNow = 0.0;
      stickRollIntegral = 0.0;
      stickPitchIntegral = 0.0;
      stickSampleTime = 0.0;
      stickYaw = 0.0;
      stickThrottle = 0.0;
   }

   private static void updateHudHiding(Minecraft minecraft) {
      boolean wanted = drone != null || isFpvStatic() || DroneSignalLoss.isActive();
      if (wanted != hudHiddenByUs) {
         if (wanted) {
            savedHideGui = minecraft.options.hideGui;
            minecraft.options.hideGui = true;
         } else {
            minecraft.options.hideGui = savedHideGui;
         }

         hudHiddenByUs = wanted;
      }
   }

   private static void restoreHud() {
      if (hudHiddenByUs) {
         Minecraft.getInstance().options.hideGui = savedHideGui;
         hudHiddenByUs = false;
      }
   }

   public static boolean isFpvStatic() {
      return fpvStaticTicks >= 0;
   }

   public static boolean isPictureHeld() {
      return fpvStaticTicks >= 0 || impactPredictedTicks >= 0;
   }

   public static float fpvStaticProgress() {
      return fpvStaticTicks >= 0 ? Mth.clamp(fpvStaticTicks / 100.0F, 0.0F, 1.0F) : 0.0F;
   }

   public static void endHeldPicture() {
      if (fpvStaticTicks >= 0) {
         fpvStaticTicks = -1;
         sendStopRequest();
         stop();
      }
   }

   public static boolean isActive() {
      return drone != null;
   }

   public static boolean holdsTheScreen() {
      return isActive() || isFpvStatic();
   }

   public static boolean isProtectedEntity(int entityId) {
      return !replacingEntity && drone != null && flyingId == entityId && (!DroneSignalLoss.isActive() || cameraImpactTicks >= 0) && !isFpvStatic();
   }

   public static void deferRemoval(int entityId, RemovalReason reason) {
      deferredRemovalId = entityId;
      deferredRemovalReason = reason;
   }

   private static void applyDeferredRemoval() {
      if (deferredRemovalId >= 0 && !isProtectedEntity(deferredRemovalId)) {
         int id = deferredRemovalId;
         RemovalReason reason = deferredRemovalReason != null ? deferredRemovalReason : RemovalReason.DISCARDED;
         deferredRemovalId = -1;
         deferredRemovalReason = null;
         Minecraft minecraft = Minecraft.getInstance();
         if (minecraft.level != null && minecraft.level.getEntity(id) != null) {
            minecraft.level.removeEntity(id, reason);
         }
      }
   }

   public static void beginTrackerReplacement(Entity incoming) {
      if (incoming.getId() == deferredRemovalId) {
         deferredRemovalId = -1;
         deferredRemovalReason = null;
      }

      DroneEntity current = drone;
      if (current != null && incoming != current && incoming.getId() == flyingId && incoming instanceof DroneEntity fresh) {
         replacingEntity = true;
         DroneFlightState carried = new DroneFlightState();
         current.captureFlightState(carried);
         fresh.restoreFlightState(carried);
         fresh.setPos(current.getX(), current.getY(), current.getZ());
         fresh.xo = current.getX();
         fresh.yo = current.getY();
         fresh.zo = current.getZ();
         fresh.setYRot(current.getYRot());
         fresh.setXRot(current.getXRot());
         fresh.yRotO = current.getYRot();
         fresh.xRotO = current.getXRot();
         fresh.setDeltaMovement(current.getDeltaMovement());
         if (fresh instanceof InterceptorDroneEntity freshAirframe && current instanceof InterceptorDroneEntity oldAirframe) {
            freshAirframe.adoptAttitudeFrom(oldAirframe);
         }
      }
   }

   public static void finishTrackerReplacement(Entity incoming) {
      if (replacingEntity) {
         replacingEntity = false;
         if (incoming instanceof DroneEntity fresh && incoming.getId() == flyingId) {
            rebind(fresh, drone);
         }
      }
   }

   @Nullable
   public static DroneEntity drone() {
      return drone;
   }

   public static boolean isFlying(Entity entity) {
      return drone != null && drone == entity;
   }

   public static float zoom() {
      return zoom;
   }

   public static int flightSeconds() {
      return flightTicks / 20;
   }

   public static double controlRange() {
      if (serverControlRange > 0.0) {
         return serverControlRange;
      } else {
         DroneEntity current = drone;
         return current != null ? current.controlRange() : 1.0;
      }
   }

   public static void start(StartControlPayload payload) {
      Minecraft minecraft = Minecraft.getInstance();
      if (minecraft.level != null && minecraft.player != null) {
         DroneEntity target = minecraft.level.getEntity(payload.entityId()) instanceof DroneEntity present ? present : placeFarDrone(minecraft, payload);
         if (target != null) {
            stop();
            drone = target;
            flyingId = payload.entityId();
            if (target instanceof InterceptorDroneEntity interceptor) {
               cameraTilt = interceptor.tiltableCamera()
                  ? TILT_BY_TYPE.getOrDefault(target.getType(), interceptor.defaultCameraTilt())
                  : interceptor.defaultCameraTilt();
            }

            missingTicks = 0;
            target.clearPilotPrediction();
            target.setArmed(payload.armed());
            target.setCharge(payload.charge());
            target.locallyControlled = true;
            armWanted = payload.armed();
            armRequested = false;
            serverControlRange = payload.controlRange();
            zoom = 1.0F;
            zoomTarget = 1.0F;
            target.setPos(payload.x(), payload.y(), payload.z());
            target.xo = payload.x();
            target.yo = payload.y();
            target.zo = payload.z();
            target.setYRot(payload.yRot());
            target.setXRot(payload.xRot());
            target.yRotO = payload.yRot();
            target.xRotO = payload.xRot();
            PREDICTION.reset();
            PREDICTION.forceResync();
            armedFlashTicks = 0;
            wasArmed = target.isArmed();
            if (target.osdStyle().isFlightController()) {
               BetaflightOsd.setHome(target);
               if (target.isArmed()) {
                  FpvBattery.arm(target);
               } else {
                  FpvBattery.disarm(target);
               }
            }

            minecraft.setCameraEntity(target);
            minecraft.player.setDeltaMovement(Vec3.ZERO);
            pilotAnchor = minecraft.player.position();
            pilotAnchorOnSubLevel = SableCompat.stickyPosition(minecraft.player);
            clearSticks();
            RadioInput.beginFlight();
            armRefusedTicks = 0;
         }
      }
   }

   public static void stop() {
      Minecraft minecraft = Minecraft.getInstance();
      if (drone != null) {
         drone.locallyControlled = false;
         drone.clearPilotPrediction();
         drone = null;
      }

      PREDICTION.reset();
      replacingEntity = false;
      armRequested = false;
      pendingYaw = 0.0;
      pendingPitch = 0.0;
      clearSticks();
      serverControlRange = 0.0;
      fpvStaticTicks = -1;
      impactPredictedTicks = -1;
      cameraImpactTicks = -1;
      flyingId = -1;
      missingTicks = 0;
      DroneSignalLoss.clear();
      DroneFeedFreeze.release();
      ThermalVision.clear();
      FpvBattery.reset();
      BetaflightOsd.clearHome();
      zoom = 1.0F;
      zoomTarget = 1.0F;
      dropCharge = 0;
      dropFlashTicks = 0;
      releaseButtonDown = false;
      armedFlashTicks = 0;
      wasArmed = false;
      pilotAnchor = null;
      pilotAnchorOnSubLevel = null;
      if (minecraft.player != null) {
         minecraft.setCameraEntity(minecraft.player);
      }

      restoreHud();
      applyDeferredRemoval();
   }

   @Nullable
   private static DroneEntity placeFarDrone(Minecraft minecraft, StartControlPayload payload) {
      EntityType<?> type = (EntityType<?>)BuiltInRegistries.ENTITY_TYPE.byId(payload.typeId());
      if (type != null && type.create(minecraft.level) instanceof DroneEntity placed) {
         placed.setId(payload.entityId());
         placed.setPos(payload.x(), payload.y(), payload.z());
         placed.setYRot(payload.yRot());
         placed.setXRot(payload.xRot());
         minecraft.level.addEntity(placed);
         return placed;
      } else {
         return null;
      }
   }

   public static void requestStop() {
      if (DroneSignalLoss.isActive()) {
         endSignalLoss();
      } else {
         sendStopRequest();
         stop();
      }
   }

   private static void sendStopRequest() {
      if (flyingId >= 0 && Minecraft.getInstance().getConnection() != null) {
         PacketDistributor.sendToServer(new StopControlRequestPayload(flyingId), new CustomPacketPayload[0]);
      }
   }

   public static void acceptLink(DroneLinkPayload payload) {
      Minecraft minecraft = Minecraft.getInstance();
      if (minecraft.level != null && flyingId == payload.entityId()) {
         DroneFlightState state = payload.state();
         if (minecraft.level.getEntity(payload.entityId()) instanceof DroneEntity present) {
            if (present != drone) {
               rebind(present, drone);
               PREDICTION.forceResync();
            }
         } else {
            EntityType<?> type = (EntityType<?>)BuiltInRegistries.ENTITY_TYPE.byId(payload.typeId());
            if (type == null || !(type.create(minecraft.level) instanceof DroneEntity restored)) {
               return;
            }

            restored.setId(payload.entityId());
            DroneEntity previous = drone;
            if (previous != null) {
               DroneFlightState carried = new DroneFlightState();
               previous.captureFlightState(carried);
               restored.restoreFlightState(carried);
               if (restored instanceof InterceptorDroneEntity freshAirframe && previous instanceof InterceptorDroneEntity oldAirframe) {
                  freshAirframe.adoptAttitudeFrom(oldAirframe);
               }
            } else {
               restored.restoreFlightState(state);
            }

            restored.xo = restored.getX();
            restored.yo = restored.getY();
            restored.zo = restored.getZ();
            restored.yRotO = restored.getYRot();
            restored.xRotO = restored.getXRot();
            minecraft.level.addEntity(restored);
            rebind(restored, previous);
            PREDICTION.forceResync();
         }

         PREDICTION.acceptServerState(payload.ackSeq(), state);
      }
   }

   private static void rebind(DroneEntity restored, @Nullable DroneEntity previous) {
      if (previous != null) {
         previous.locallyControlled = false;
      }

      drone = restored;
      restored.locallyControlled = true;
      missingTicks = 0;
      Minecraft.getInstance().setCameraEntity(restored);
   }

   public static void steer(double yawDegrees, double pitchDegrees, double rawX, double rawY, double frameSeconds) {
      DroneEntity current = drone;
      if (onSticks()) {
         if (current != null && !DroneSignalLoss.isActive() && !current.isWrecked()) {
            feedSticks(rawX, rawY, frameSeconds);
         }
      } else {
         if (current != null && !DroneSignalLoss.isActive() && !current.isWrecked()) {
            double gearing = current.lookGearing() / zoom;
            pendingYaw += yawDegrees * gearing;
            pendingPitch += pitchDegrees * gearing;
         }

         easeGimbal(current, frameSeconds);
      }
   }

   private static void easeGimbal(@Nullable DroneEntity current, double frameSeconds) {
      if (current != null && !DroneSignalLoss.isActive() && !current.isWrecked()) {
         if (Math.abs(pendingYaw) < 1.0E-4 && Math.abs(pendingPitch) < 1.0E-4) {
            pendingYaw = 0.0;
            pendingPitch = 0.0;
         } else {
            double lag = current.gimbalLag();
            double share = lag > 0.0 ? 1.0 - Math.exp(-Math.max(frameSeconds, 0.0) / lag) : 0.35;
            double yawStep = pendingYaw * share;
            double pitchStep = pendingPitch * share;
            pendingYaw -= yawStep;
            pendingPitch -= pitchStep;
            current.turnGimbal(yawStep, pitchStep);
         }
      } else {
         pendingYaw = 0.0;
         pendingPitch = 0.0;
      }
   }

   public static void addZoom(double scrollDelta) {
      if (!DroneSignalLoss.isActive()) {
         zoomTarget = Mth.clamp(zoomTarget * (float)Math.pow(1.12, scrollDelta), 1.0F, maxZoom());
      }
   }

   public static void easeZoom() {
      long now = System.nanoTime();
      double dt = zoomClock == 0L ? 0.0 : Math.min(0.1, (now - zoomClock) / 1.0E9);
      zoomClock = now;
      double k = 1.0 - Math.exp(-dt * 12.0);
      double eased = Mth.lerp(k, Math.log(zoom), Math.log(zoomTarget));
      zoom = Math.abs(zoomTarget - (float)Math.exp(eased)) < 0.001F ? zoomTarget : (float)Math.exp(eased);
   }

   public static boolean isArmedFlash() {
      return armedFlashTicks > 0;
   }

   public static void toggleArm() {
      DroneEntity current = drone;
      if (current != null) {
         setArmed(current, !current.isArmed());
      }
   }

   private static void setArmed(DroneEntity current, boolean wanted) {
      if (wanted != current.isArmed() && !isFpvStatic() && !DroneSignalLoss.isActive() && !current.isWrecked() && current.requiresArming()) {
         if (wanted && RadioInput.active() && !RadioInput.throttleLow()) {
            armRefusedTicks = 40;
         } else {
            armWanted = wanted;
            armRequested = true;
         }
      }
   }

   public static boolean isArmRefused() {
      return armRefusedTicks > 0;
   }

   private static void tickRadioSwitches(DroneEntity current) {
      RadioProfile setup = RadioInput.profile();
      int arm = RadioInput.armEdge();
      if (arm != 0) {
         if (setup.arm.mode == RadioProfile.AuxMode.SWITCH) {
            setArmed(current, arm > 0);
         } else if (arm > 0) {
            setArmed(current, !current.isArmed());
         }
      }

      if (RadioInput.selfDestructEdge() > 0) {
         selfDestruct();
      }

      int thermal = RadioInput.thermalEdge();
      if (thermal != 0) {
         if (setup.thermal.mode == RadioProfile.AuxMode.SWITCH) {
            if (thermal > 0 != ThermalVision.isOn()) {
               toggleThermal();
            }
         } else if (thermal > 0) {
            toggleThermal();
         }
      }

      float level = RadioInput.cameraMove();
      if (!Float.isNaN(level) && onSticks() && tiltableCamera(drone)) {
         cameraTilt = level * 90.0F;
         if (drone != null) {
            TILT_BY_TYPE.put(drone.getType(), cameraTilt);
         }
      }
   }

   public static void selfDestruct() {
      DroneEntity current = drone;
      if (current instanceof InterceptorDroneEntity && !current.isWrecked() && !DroneSignalLoss.isActive()) {
         PacketDistributor.sendToServer(new DroneSelfDestructPayload(current.getId(), inputSeq), new CustomPacketPayload[0]);
         if (impactPredictedTicks < 0 && fpvStaticTicks < 0) {
            current.settleInterpolation();
            BetaflightOsd.captureSignalLoss(current);
            DroneFeedFreeze.armHold();
            impactPredictedTicks = 0;
         }
      }
   }

   public static void toggleThermal() {
      DroneEntity current = drone;
      if (current != null && !DroneSignalLoss.isActive()) {
         if (!ThermalVision.isAvailable(current)) {
            DroneMod.LOGGER.info("Thermal asked for on {}, which has no thermal camera", current.getType());
         } else {
            ThermalVision.toggle(current);
            DroneMod.LOGGER.info("Thermal camera {}", ThermalVision.isOn() ? "on" : "off");
         }
      }
   }

   private static boolean tiltableCamera(@Nullable DroneEntity current) {
      return !(current instanceof InterceptorDroneEntity interceptor && !interceptor.tiltableCamera());
   }

   public static void scrollCameraPitch(double scrollDelta) {
      DroneEntity current = drone;
      if (current != null && !DroneSignalLoss.isActive() && !current.isWrecked()) {
         if (!onSticks()) {
            pendingPitch += -scrollDelta * 8.0;
            easeGimbal(current, 0.016666666666666666);
         } else if (tiltableCamera(current)) {
            cameraTilt = Mth.clamp(cameraTilt + (float)(scrollDelta * 8.0), 0.0F, 90.0F);
            TILT_BY_TYPE.put(current.getType(), cameraTilt);
         }
      }
   }

   public static void tick() {
      Minecraft minecraft = Minecraft.getInstance();
      updateHudHiding(minecraft);
      replacingEntity = false;
      if (fpvStaticTicks >= 0) {
         tickHeldPicture(minecraft);
      } else if (DroneSignalLoss.isActive()) {
         tickSignalLoss(minecraft);
      } else {
         DroneEntity current = drone;
         if (current != null) {
            if (minecraft.level == null || minecraft.player == null || current.level() != minecraft.level) {
               stop();
            } else if (current.isRemoved()) {
               if (++missingTicks > 200) {
                  DroneMod.LOGGER.warn("Long-range drone {} was gone for {} ticks with no link update — ending the flight", current.getId(), missingTicks);
                  sendStopRequest();
                  stop();
               }
            } else {
               missingTicks = 0;
               if (!minecraft.player.isAlive()) {
                  requestStop();
               } else if (!minecraft.isPaused()) {
                  flightTicks++;
                  boolean armed = current.isArmed();
                  if (armed != wasArmed) {
                     if (armed) {
                        armedFlashTicks = 20;
                        FpvBattery.armedNow(current);
                     } else {
                        FpvBattery.disarm(current);
                     }

                     wasArmed = armed;
                  }

                  if (armedFlashTicks > 0) {
                     armedFlashTicks--;
                  }

                  if (current.osdStyle().isFlightController()) {
                     if (armed) {
                        FpvBattery.tick(current);
                     } else {
                        FpvBattery.rest(current);
                     }
                  }

                  boolean sticks = onSticks();
                  if (!sticks) {
                     float wrapped = Mth.wrapDegrees(current.getYRot());
                     current.yRotO = current.yRotO + (wrapped - current.getYRot());
                     current.setYRot(wrapped);
                  }

                  byte keys = DroneInputPayload.pack(
                     minecraft.options.keyUp.isDown(),
                     minecraft.options.keyDown.isDown(),
                     minecraft.options.keyLeft.isDown(),
                     minecraft.options.keyRight.isDown(),
                     minecraft.options.keyJump.isDown(),
                     minecraft.options.keyShift.isDown()
                  );
                  float roll = 0.0F;
                  float pitch = 0.0F;
                  float yaw = 0.0F;
                  float throttle = 0.0F;
                  if (sticks && RadioInput.active()) {
                     RadioInput.latchTick();
                     roll = RadioInput.roll();
                     pitch = -RadioInput.pitch();
                     yaw = RadioInput.yaw();
                     throttle = RadioInput.throttle();
                     clearSticks();
                  } else if (sticks) {
                     tickStickKeys(minecraft);
                     if (stickSampleTime > 1.0E-6) {
                        roll = (float)Mth.clamp(stickRollIntegral / stickSampleTime, -1.0, 1.0);
                        pitch = (float)Mth.clamp(stickPitchIntegral / stickSampleTime, -1.0, 1.0);
                     }

                     stickRollIntegral = 0.0;
                     stickPitchIntegral = 0.0;
                     stickSampleTime = 0.0;
                     yaw = (float)stickYaw;
                     throttle = (float)stickThrottle;
                  }

                  sendAndFly(current, keys, sticks, roll, pitch, yaw, throttle);
                  tickPredictedImpact(current);
                  if (RadioInput.active()) {
                     tickRadioSwitches(current);
                  }

                  if (armRefusedTicks > 0) {
                     armRefusedTicks--;
                  }

                  tickGrenadeDrop(minecraft, current);
                  pinPilot(minecraft.player);
               }
            }
         }
      }
   }

   private static void sendAndFly(DroneEntity current, byte keys, boolean sticks, float roll, float pitch, float yaw, float throttle) {
      int stamped = keys;
      if (armRequested) {
         stamped = keys | 64 | (armWanted ? 128 : 0);
      }

      PilotInput input = new PilotInput(
         ++inputSeq, (byte)stamped, sticks ? Float.NaN : current.getYRot(), sticks ? Float.NaN : current.getXRot(), roll, pitch, yaw, throttle
      );
      PacketDistributor.sendToServer(new DroneInputPayload(current.getId(), input), new CustomPacketPayload[0]);
      if (current.locallyControlled && !current.isWrecked()) {
         PREDICTION.step(current, input);
      }
   }

   private static void tickPredictedImpact(DroneEntity current) {
      if (current.osdStyle() == DroneEntity.Osd.CAMERA) {
         if (current.consumePredictedImpact()) {
            current.settleInterpolation();
            DroneSignalLoss.begin(DroneSignalLoss.Cause.CRASH);
            clearGrenadeDrop();
            Minecraft minecraft = Minecraft.getInstance();
            DroneFeedFreeze.arm(minecraft.player != null ? DroneTelemetry.read(minecraft, current, minecraft.player) : null);
            cameraImpactTicks = 0;
            reportPredictedRam(current);
         }
      } else if (impactPredictedTicks < 0) {
         if (current.consumePredictedImpact()) {
            current.settleInterpolation();
            BetaflightOsd.captureSignalLoss(current);
            DroneFeedFreeze.armHold();
            impactPredictedTicks = 0;
            reportPredictedRam(current);
         }
      } else {
         current.consumePredictedImpact();
         if (++impactPredictedTicks > 20) {
            impactPredictedTicks = -1;
            DroneFeedFreeze.release();
         }
      }
   }

   private static void reportPredictedRam(DroneEntity current) {
      if (current.predictedRamId() >= 0) {
         PacketDistributor.sendToServer(new DroneRamPayload(current.getId(), current.predictedRamId()), new CustomPacketPayload[0]);
      }
   }

   private static void tickHeldPicture(Minecraft minecraft) {
      if (minecraft.level == null || minecraft.player == null || !minecraft.player.isAlive()) {
         endHeldPicture();
      } else if (!minecraft.isPaused()) {
         pinPilot(minecraft.player);
         if (DroneFeedFreeze.isFrameReady() && minecraft.getCameraEntity() != minecraft.player) {
            minecraft.setCameraEntity(minecraft.player);
         }

         letGoOfTheCopy();
         if (++fpvStaticTicks >= 100) {
            endHeldPicture();
         }
      }
   }

   private static void tickSignalLoss(Minecraft minecraft) {
      if (minecraft.level == null || minecraft.player == null || !minecraft.player.isAlive()) {
         endSignalLoss();
      } else if (!minecraft.isPaused()) {
         if (cameraImpactTicks >= 0 && ++cameraImpactTicks > 20) {
            cameraImpactTicks = -1;
            DroneSignalLoss.clear();
            DroneFeedFreeze.release();
            DroneEntity current = drone;
            if (current != null && !current.isRemoved()) {
               minecraft.setCameraEntity(current);
               PREDICTION.forceResync();
            }
         } else {
            DroneEntity current = drone;
            if (cameraImpactTicks >= 0 && current != null && current.locallyControlled && !current.isRemoved()) {
               sendAndFly(current, (byte)0, false, 0.0F, 0.0F, 0.0F, 0.0F);
               current.consumePredictedImpact();
            }

            DroneSignalLoss.tick();
            pinPilot(minecraft.player);
            if (DroneFeedFreeze.isFrameReady() && minecraft.getCameraEntity() != minecraft.player) {
               minecraft.setCameraEntity(minecraft.player);
            }

            letGoOfTheCopy();
         }
      }
   }

   private static void letGoOfTheCopy() {
      DroneEntity current = drone;
      if (current != null && current.locallyControlled && DroneFeedFreeze.isFrameReady() && cameraImpactTicks < 0) {
         current.locallyControlled = false;
      }
   }

   public static void beginSignalLoss(DroneSignalLoss.Cause cause) {
      DroneEntity current = drone;
      if (current == null) {
         stop();
      } else {
         clearGrenadeDrop();
         if (fpvStaticTicks < 0) {
            if (current.osdStyle() != DroneEntity.Osd.CAMERA) {
               if (impactPredictedTicks >= 0) {
                  impactPredictedTicks = -1;
               } else {
                  BetaflightOsd.captureSignalLoss(current);
                  DroneFeedFreeze.armHold();
                  DroneFeedFreeze.useFrameBefore();
               }

               fpvStaticTicks = 0;
               applyDeferredRemoval();
            } else {
               if (cameraImpactTicks >= 0 && DroneSignalLoss.isActive()) {
                  cameraImpactTicks = -1;
               } else {
                  if (!DroneSignalLoss.begin(cause)) {
                     return;
                  }

                  Minecraft minecraft = Minecraft.getInstance();
                  DroneFeedFreeze.arm(minecraft.player != null ? DroneTelemetry.read(minecraft, current, minecraft.player) : null);
                  DroneFeedFreeze.useFrameBefore();
               }

               applyDeferredRemoval();
            }
         }
      }
   }

   private static void endSignalLoss() {
      if (cameraImpactTicks >= 0) {
         sendStopRequest();
      }

      DroneSignalLoss.clear();
      DroneFeedFreeze.release();
      stop();
   }

   public static void setReleaseButton(boolean down) {
      releaseButtonDown = down;
   }

   private static void tickGrenadeDrop(Minecraft minecraft, DroneEntity current) {
      if (dropFlashTicks > 0) {
         dropFlashTicks--;
      }

      boolean held = minecraft.screen == null && (releaseButtonDown || minecraft.options.keyAttack.isDown());
      if (held && GrenadeAttachments.isDroppable(current.getAttachment())) {
         if (++dropCharge >= 20) {
            PacketDistributor.sendToServer(new DroneDropPayload(current.getId(), inputSeq), new CustomPacketPayload[0]);
            dropCharge = 0;
            dropFlashTicks = 70;
         }
      } else {
         dropCharge = 0;
      }
   }

   private static void clearGrenadeDrop() {
      dropCharge = 0;
      dropFlashTicks = 0;
   }

   public static float dropProgress() {
      return dropCharge > 0 ? Math.min(1.0F, dropCharge / 20.0F) : 0.0F;
   }

   public static float dropFlashAlpha() {
      if (dropFlashTicks <= 0) {
         return 0.0F;
      } else {
         int elapsed = 70 - dropFlashTicks;
         if (elapsed < 4) {
            return elapsed / 4.0F;
         } else {
            return dropFlashTicks < 12 ? dropFlashTicks / 12.0F : 1.0F;
         }
      }
   }

   private static void pinPilot(LocalPlayer player) {
      player.setJumping(false);
      player.input.up = false;
      player.input.down = false;
      player.input.left = false;
      player.input.right = false;
      player.input.jumping = false;
      player.input.shiftKeyDown = false;
      player.input.forwardImpulse = 0.0F;
      player.input.leftImpulse = 0.0F;
      player.setDeltaMovement(Vec3.ZERO);
      Vec3 anchor = pilotAnchorOnSubLevel != null ? pilotAnchorOnSubLevel.get() : pilotAnchor;
      if (anchor != null) {
         player.setPos(anchor.x, anchor.y, anchor.z);
         player.fallDistance = 0.0F;
      }
   }

   private DroneControl() {
   }
}
