package dev.krutlexik.skyfront.drone.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.krutlexik.skyfront.drone.DroneMod;
import dev.krutlexik.skyfront.drone.entity.DroneStandEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

public class DroneStandRenderer extends EntityRenderer<DroneStandEntity> {
   public static final ResourceLocation MODEL = DroneMod.id("models/entity/fpv_stand.glb");
   private static final float MODEL_HEIGHT = 0.1625F;
   private static final float SINK = 0.0075000003F;

   public DroneStandRenderer(Context context) {
      super(context);
      this.shadowRadius = 0.0F;
   }

   public void render(DroneStandEntity stand, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int light) {
      GlbModel glb = DroneRenderer.model(MODEL);
      if (glb != null) {
         float scale = 1.2F;
         float upright = 1.4307693F;
         poseStack.pushPose();
         poseStack.mulPose(Axis.YP.rotationDegrees(180.0F - stand.getYRot()));
         poseStack.scale(scale, upright, scale);
         glb.render(poseStack, buffers, light, OverlayTexture.NO_OVERLAY, 0.0F);
         poseStack.popPose();
      }

      super.render(stand, entityYaw, partialTick, poseStack, buffers, light);
   }

   public ResourceLocation getTextureLocation(DroneStandEntity stand) {
      return MODEL;
   }
}
