package dev.krutlexik.skyfront.drone.client;

import dev.krutlexik.skyfront.config.SkyfrontConfig;
import dev.krutlexik.skyfront.drone.entity.DroneEntity;
import dev.krutlexik.skyfront.drone.entity.FpvDroneEntity;
import dev.krutlexik.skyfront.drone.entity.InterceptorDroneEntity;
import dev.krutlexik.skyfront.drone.entity.MolniyaDroneEntity;
import dev.krutlexik.skyfront.drone.registry.DroneSounds;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;

public class InterceptorSoundInstance extends AbstractTickableSoundInstance {
   private static final float IDLE_VOLUME = 0.5F;
   private static final float MAX_VOLUME = 1.0F;
   private static final float IDLE_PITCH = 1.0F;
   private static final float MAX_PITCH = 1.75F;
   private static final float VOLUME_STEP = 0.06F;
   private static final float PITCH_STEP = 0.05F;
   private static final float DISARM_STEP = 0.12F;
   private final DroneEntity drone;

   public InterceptorSoundInstance(DroneEntity drone) {
      super(loopFor(drone), SoundSource.NEUTRAL, SoundInstance.createUnseededRandom());
      this.drone = drone;
      this.looping = true;
      this.delay = 0;
      this.volume = 0.0F;
      this.pitch = 1.0F;
      this.x = drone.getX();
      this.y = drone.getY();
      this.z = drone.getZ();
   }

   private static SoundEvent loopFor(DroneEntity drone) {
      if (drone instanceof FpvDroneEntity) {
         return (SoundEvent)DroneSounds.FPV_LOOP.get();
      } else {
         return drone instanceof MolniyaDroneEntity ? (SoundEvent)DroneSounds.MOLNIYA_LOOP.get() : (SoundEvent)DroneSounds.INTERCEPTOR_LOOP.get();
      }
   }

   public boolean canStartSilent() {
      return true;
   }

   public void tick() {
      if (!this.drone.isRemoved()) {
         this.x = this.drone.getX();
         this.y = this.drone.getY();
         this.z = this.drone.getZ();
      }

      if (this.drone.motorsDead()) {
         this.volume = approach(this.volume, 0.0F, 0.12F);
         this.pitch = approach(this.pitch, 1.0F, 0.12F);
         if (this.drone.isRemoved() && this.volume <= 0.001F) {
            this.stop();
         }
      } else {
         double topSpeed = Math.max(
            1.0, this.drone instanceof InterceptorDroneEntity interceptor ? interceptor.topSpeedKmh() : (Double)SkyfrontConfig.INTERCEPTOR_TOP_SPEED.get()
         );
         double speedKmh = this.drone.getDeltaMovement().length() * 72.0;
         float drive = (float)Mth.clamp(speedKmh / topSpeed, 0.0, 1.0);
         this.volume = approach(this.volume, Mth.lerp(drive, 0.5F, 1.0F), 0.06F);
         this.pitch = approach(this.pitch, Mth.lerp(drive, 1.0F, 1.75F), 0.05F);
      }
   }

   private static float approach(float value, float goal, float step) {
      return value < goal ? Math.min(value + step, goal) : Math.max(value - step, goal);
   }
}
