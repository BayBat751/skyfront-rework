package dev.krutlexik.skyfront.drone.radio;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.util.Mth;

public final class RadioProfile {
   public boolean enabled = false;
   public String deviceGuid = "";
   public String deviceName = "";
   public RadioProfile.Channel roll = new RadioProfile.Channel(0);
   public RadioProfile.Channel pitch = new RadioProfile.Channel(1);
   public RadioProfile.Channel throttle = new RadioProfile.Channel(2);
   public RadioProfile.Channel yaw = new RadioProfile.Channel(3);
   public RadioProfile.Aux arm = new RadioProfile.Aux();
   public RadioProfile.Aux thermal = new RadioProfile.Aux();
   public RadioProfile.Aux camera = new RadioProfile.Aux();
   public RadioProfile.Aux selfDestruct = new RadioProfile.Aux();
   public float deadband = 0.02F;
   public boolean gamepad = false;
   public List<RadioProfile.Calibration> calibration = new ArrayList<>();
   public static final float MAX_DEADBAND = 0.15F;
   private static final RadioProfile.Calibration IDENTITY = new RadioProfile.Calibration();
   private static final float MIN_TRAVEL = 0.2F;

   public RadioProfile.Calibration calibrationFor(int axis) {
      return axis >= 0 && axis < this.calibration.size() && this.calibration.get(axis) != null ? this.calibration.get(axis) : IDENTITY;
   }

   public static float centred(float raw, RadioProfile.Calibration cal) {
      if (cal.max - cal.min < 0.2F) {
         return Mth.clamp(raw, -1.0F, 1.0F);
      } else {
         float centre = Mth.clamp(cal.centre, cal.min + 0.01F, cal.max - 0.01F);
         return raw >= centre
            ? Mth.clamp((raw - centre) / Math.max(0.01F, cal.max - centre), 0.0F, 1.0F)
            : Mth.clamp((raw - centre) / Math.max(0.01F, centre - cal.min), -1.0F, 0.0F);
      }
   }

   public static float span(float raw, RadioProfile.Calibration cal) {
      return cal.max - cal.min < 0.2F ? Mth.clamp((raw + 1.0F) * 0.5F, 0.0F, 1.0F) : Mth.clamp((raw - cal.min) / (cal.max - cal.min), 0.0F, 1.0F);
   }

   public static float deadband(float value, float deadband) {
      float band = Mth.clamp(deadband, 0.0F, 0.15F);
      float magnitude = Math.abs(value);
      if (magnitude <= band) {
         return 0.0F;
      } else {
         float scaled = Math.min(1.0F, (magnitude - band) / (1.0F - band));
         return value < 0.0F ? -scaled : scaled;
      }
   }

   public float stick(RadioProfile.Channel channel, float[] axes) {
      if (channel.axis >= 0 && channel.axis < axes.length) {
         float value = centred(axes[channel.axis], this.calibrationFor(channel.axis));
         if (channel.reverse) {
            value = -value;
         }

         return deadband(value, this.deadband);
      } else {
         return 0.0F;
      }
   }

   public float throttleOf(float[] axes) {
      if (this.gamepad) {
         return Math.max(0.0F, this.throttleStick(axes));
      } else if (this.throttle.axis >= 0 && this.throttle.axis < axes.length) {
         float value = span(axes[this.throttle.axis], this.calibrationFor(this.throttle.axis));
         return this.throttle.reverse ? 1.0F - value : value;
      } else {
         return 0.0F;
      }
   }

   public float throttleStick(float[] axes) {
      return this.gamepad ? this.stick(this.throttle, axes) : this.throttleOf(axes) * 2.0F - 1.0F;
   }

   public boolean auxOn(RadioProfile.Aux aux, float[] axes, boolean[] buttons) {
      switch (aux.source) {
         case AXIS:
            if (aux.index >= 0 && aux.index < axes.length) {
               float level = span(axes[aux.index], this.calibrationFor(aux.index)) * 2.0F - 1.0F;
               if (aux.reverse) {
                  level = -level;
               }

               return level > 0.5F;
            }

            return false;
         case BUTTON:
            if (aux.index >= 0 && aux.index < buttons.length) {
               return buttons[aux.index] != aux.reverse;
            }

            return false;
         default:
            return false;
      }
   }

   public float auxLevel(RadioProfile.Aux aux, float[] axes) {
      if (aux.source == RadioProfile.Source.AXIS && aux.index >= 0 && aux.index < axes.length) {
         float value = span(axes[aux.index], this.calibrationFor(aux.index));
         return aux.reverse ? 1.0F - value : value;
      } else {
         return 0.0F;
      }
   }

   public static final class Aux {
      public RadioProfile.Source source = RadioProfile.Source.NONE;
      public int index;
      public boolean reverse;
      public RadioProfile.AuxMode mode = RadioProfile.AuxMode.SWITCH;

      public boolean assigned() {
         return this.source != RadioProfile.Source.NONE;
      }
   }

   public static enum AuxMode {
      SWITCH,
      BUTTON;
   }

   public static final class Calibration {
      public float min = -1.0F;
      public float centre = 0.0F;
      public float max = 1.0F;

      public Calibration() {
      }

      public Calibration(float min, float centre, float max) {
         this.min = min;
         this.centre = centre;
         this.max = max;
      }
   }

   public static final class Capture {
      private float[] min = new float[0];
      private float[] max = new float[0];

      public void accumulate(float[] axes) {
         if (axes.length > this.min.length) {
            int old = this.min.length;
            this.min = Arrays.copyOf(this.min, axes.length);
            this.max = Arrays.copyOf(this.max, axes.length);

            for (int i = old; i < axes.length; i++) {
               this.min[i] = axes[i];
               this.max[i] = axes[i];
            }
         }

         for (int i = 0; i < axes.length; i++) {
            this.min[i] = Math.min(this.min[i], axes[i]);
            this.max[i] = Math.max(this.max[i], axes[i]);
         }
      }

      public float travel(int axis) {
         return axis < this.min.length ? this.max[axis] - this.min[axis] : 0.0F;
      }

      public List<RadioProfile.Calibration> finish(float[] resting) {
         List<RadioProfile.Calibration> result = new ArrayList<>();

         for (int i = 0; i < this.min.length; i++) {
            if (this.max[i] - this.min[i] < 0.2F) {
               result.add(new RadioProfile.Calibration());
            } else {
               float centre = i < resting.length ? resting[i] : (this.min[i] + this.max[i]) * 0.5F;
               result.add(new RadioProfile.Calibration(this.min[i], Mth.clamp(centre, this.min[i], this.max[i]), this.max[i]));
            }
         }

         return result;
      }
   }

   public static final class Channel {
      public int axis;
      public boolean reverse;

      public Channel() {
      }

      public Channel(int axis) {
         this.axis = axis;
      }
   }

   public static final class Detection {
      private final float[] baseAxes;
      private final boolean[] baseButtons;
      private final boolean buttons;
      private static final float THRESHOLD = 0.5F;

      public Detection(float[] axes, boolean[] buttons, boolean acceptButtons) {
         this.baseAxes = (float[])axes.clone();
         this.baseButtons = (boolean[])buttons.clone();
         this.buttons = acceptButtons;
      }

      public RadioProfile.Found poll(float[] axes, boolean[] currentButtons) {
         int best = -1;
         float bestDelta = 0.0F;

         for (int i = 0; i < Math.min(axes.length, this.baseAxes.length); i++) {
            float delta = axes[i] - this.baseAxes[i];
            if (Math.abs(delta) > Math.abs(bestDelta)) {
               best = i;
               bestDelta = delta;
            }
         }

         if (best >= 0 && Math.abs(bestDelta) >= 0.5F) {
            return new RadioProfile.Found(RadioProfile.Source.AXIS, best, bestDelta < 0.0F);
         } else {
            if (this.buttons) {
               for (int ix = 0; ix < Math.min(currentButtons.length, this.baseButtons.length); ix++) {
                  if (currentButtons[ix] != this.baseButtons[ix]) {
                     return new RadioProfile.Found(RadioProfile.Source.BUTTON, ix, !currentButtons[ix]);
                  }
               }
            }

            return null;
         }
      }
   }

   public record Found(RadioProfile.Source source, int index, boolean reverse) {
   }

   public static enum Source {
      NONE,
      AXIS,
      BUTTON;
   }
}
