package dev.krutlexik.skyfront.drone.network;

import dev.krutlexik.skyfront.drone.DroneMod;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;

public record StopControlPayload(StopControlPayload.Reason reason, double x, double y, double z) implements CustomPacketPayload {
   private static final StopControlPayload.Reason[] REASONS = StopControlPayload.Reason.values();
   public static final Type<StopControlPayload> TYPE = new Type(DroneMod.id("stop_control"));
   public static final StreamCodec<FriendlyByteBuf, StopControlPayload> STREAM_CODEC = StreamCodec.of((buf, payload) -> {
      buf.writeByte(payload.reason.ordinal());
      buf.writeDouble(payload.x);
      buf.writeDouble(payload.y);
      buf.writeDouble(payload.z);
   }, buf -> new StopControlPayload(REASONS[buf.readByte()], buf.readDouble(), buf.readDouble(), buf.readDouble()));

   public Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }

   public static enum Reason {
      NORMAL,
      OUT_OF_RANGE,
      DESTROYED,
      CRASHED,
      BATTERY;
   }
}
