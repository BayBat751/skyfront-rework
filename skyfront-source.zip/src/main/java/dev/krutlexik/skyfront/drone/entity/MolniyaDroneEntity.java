package dev.krutlexik.skyfront.drone.entity;

import dev.krutlexik.skyfront.config.SkyfrontConfig;
import dev.krutlexik.skyfront.drone.registry.DroneItems;
import dev.krutlexik.skyfront.entity.DebrisEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class MolniyaDroneEntity extends InterceptorDroneEntity {
   public static final float MODEL_SCALE = 1.4F;
   public static final float LEVEL_AT_PITCH = -21.1F;
   private static final float MODEL_MIN_Y = -0.05F;
   private static final float MODEL_MID_Y = 0.2835F;
   private static final float MODEL_CENTRE_Z = 0.0384F;
   private static final Vector3f WARHEAD_MIN = new Vector3f(-0.1875F, -0.05F, -1.39375F);
   private static final Vector3f WARHEAD_MAX = new Vector3f(0.1875F, 0.2F, -0.76875F);
   private static final float WARHEAD_HIT_MARGIN = 0.15F;
   private static final double MELEE_REACH = 4.5;
   private static final double SHOT_LINE = 64.0;

   public MolniyaDroneEntity(EntityType<? extends MolniyaDroneEntity> type, Level level) {
      super(type, level);
   }

   @Override
   public boolean fliesAsAircraft() {
      return true;
   }

   @Override
   protected double maxHitpoints() {
      return (Double)SkyfrontConfig.MOLNIYA_HITPOINTS.get();
   }

   @Override
   public boolean rateMode() {
      return true;
   }

   @Override
   public double topSpeedKmh() {
      return 113.0;
   }

   @Override
   public float defaultCameraTilt() {
      return 10.0F;
   }

   @Override
   public boolean tiltableCamera() {
      return false;
   }

   @Override
   public boolean noseFused() {
      return true;
   }

   @Override
   public boolean analogVideo() {
      return true;
   }

   @Override
   public DroneEntity.Osd osdStyle() {
      return DroneEntity.Osd.INAV;
   }

   @Override
   protected float warheadBlast() {
      return (float)((Double)SkyfrontConfig.MOLNIYA_BLAST.get()).doubleValue();
   }

   @Override
   protected float warheadVehicleDamage() {
      return (float)((Double)SkyfrontConfig.MOLNIYA_VEHICLE_DAMAGE.get()).doubleValue();
   }

   @Override
   protected float warheadVehicleRadius() {
      return (float)((Double)SkyfrontConfig.MOLNIYA_VEHICLE_RADIUS.get()).doubleValue();
   }

   @Override
   protected boolean setsOffCharge(DamageSource source) {
      if ((Boolean)SkyfrontConfig.MOLNIYA_WARHEAD_SHOT.get() && !source.is(DamageTypeTags.IS_EXPLOSION)) {
         Entity direct = source.getDirectEntity();
         Vec3 from;
         Vec3 along;
         if (direct != null && direct != source.getEntity()) {
            Vec3 motion = direct.getDeltaMovement();
            along = motion.lengthSqr() > 1.0E-6 ? motion.normalize() : this.position().subtract(direct.position()).normalize();
            from = direct.position().subtract(along.scale(64.0));
         } else {
            if (!(direct instanceof LivingEntity shooter) || !(shooter.distanceTo(this) > 4.5)) {
               return false;
            }

            along = shooter.getViewVector(1.0F);
            from = shooter.getEyePosition();
         }

         return along.lengthSqr() > 1.0E-6 && this.lineHitsWarhead(from, along.scale(128.0));
      } else {
         return false;
      }
   }

   private boolean lineHitsWarhead(Vec3 from, Vec3 span) {
      Quaternionf undo = this.modelAttitude().conjugate();
      Vector3f start = new Vector3f((float)(from.x - this.getX()), (float)(from.y - this.getY() + -0.07F), (float)(from.z - this.getZ()));
      undo.transform(start).div(1.4F).sub(0.0F, 0.2835F, 0.0F);
      Vector3f step = undo.transform(new Vector3f((float)span.x, (float)span.y, (float)span.z)).div(1.4F);
      float trim = this.isWrecked() ? 0.0F : this.cruiseTrim();
      if (trim != 0.0F) {
         Quaternionf untrim = new Quaternionf().rotationX(-trim * (float) (Math.PI / 180.0));
         untrim.transform(start);
         untrim.transform(step);
      }

      start.add(0.0F, 0.2835F, 0.0384F);
      float margin = 0.107142866F;
      float enter = 0.0F;
      float leave = 1.0F;

      for (int axis = 0; axis < 3; axis++) {
         float origin = start.get(axis);
         float delta = step.get(axis);
         float min = WARHEAD_MIN.get(axis) - margin;
         float max = WARHEAD_MAX.get(axis) + margin;
         if (Math.abs(delta) < 1.0E-7F) {
            if (origin < min || origin > max) {
               return false;
            }
         } else {
            float t0 = (min - origin) / delta;
            float t1 = (max - origin) / delta;
            enter = Math.max(enter, Math.min(t0, t1));
            leave = Math.min(leave, Math.max(t0, t1));
            if (enter > leave) {
               return false;
            }
         }
      }

      return true;
   }

   private Quaternionf modelAttitude() {
      Quaternionf attitude = this.isWrecked() ? this.wreckRotation(1.0F) : this.renderRotation(1.0F);
      if (attitude != null) {
         return attitude;
      } else {
         float pitch = this.isWrecked() ? -this.getViewXRot(1.0F) : this.bodyPitch(1.0F);
         float roll = this.isWrecked() ? this.getRoll(1.0F) : this.bodyRoll(1.0F);
         return new Quaternionf()
            .rotationY((180.0F - this.getYRot()) * (float) (Math.PI / 180.0))
            .rotateX(pitch * (float) (Math.PI / 180.0))
            .rotateZ(roll * (float) (Math.PI / 180.0));
      }
   }

   private float cruiseTrim() {
      double speed = Math.sqrt(this.distanceToSqr(this.xo, this.yo, this.zo));
      double cruise = this.trimSpeed();
      double top = this.topSpeedPerTick();
      double span = top * top - cruise * cruise;
      if (span <= 1.0E-6) {
         return 0.0F;
      } else {
         float t = (float)Mth.clamp((speed * speed - cruise * cruise) / span, 0.0, 1.0);
         return 21.1F * t * t * (3.0F - 2.0F * t);
      }
   }

   @Override
   protected void goOff(ServerLevel level, @Nullable Entity attacker) {
      super.goOff(level, attacker);
      Quaternionf attitude = this.renderRotation(1.0F);
      if (attitude == null) {
         attitude = new Quaternionf().rotationY((180.0F - this.getYRot()) * (float) (Math.PI / 180.0));
      }

      DebrisEntity.burst(level, DebrisEntity.Airframe.MOLNIYA, this.position(), attitude, this.getDeltaMovement());
   }

   @Override
   public ItemStack packedItem() {
      return new ItemStack((ItemLike)DroneItems.MOLNIYA_DRONE.get());
   }
}
