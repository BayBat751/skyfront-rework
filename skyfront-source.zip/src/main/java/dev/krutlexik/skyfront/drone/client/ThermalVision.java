package dev.krutlexik.skyfront.drone.client;

import dev.krutlexik.skyfront.drone.entity.DroneEntity;
import org.jetbrains.annotations.Nullable;

public final class ThermalVision {
   private static boolean active;

   public static boolean isOn() {
      return active;
   }

   public static boolean isAvailable(@Nullable DroneEntity drone) {
      return drone != null && drone.hasThermalCamera();
   }

   public static void toggle(@Nullable DroneEntity drone) {
      if (isAvailable(drone)) {
         active = !active;
      }
   }

   public static void clear() {
      active = false;
   }

   private ThermalVision() {
   }
}
