package dev.krutlexik.skyfront.drone.client;

import dev.krutlexik.skyfront.drone.client.radio.RadioSettingsScreen;
import dev.krutlexik.skyfront.drone.client.render.AnalogFeedPass;
import dev.krutlexik.skyfront.drone.client.render.DroneItemRenderer;
import dev.krutlexik.skyfront.drone.client.render.DroneRenderer;
import dev.krutlexik.skyfront.drone.client.render.DroneStandRenderer;
import dev.krutlexik.skyfront.drone.client.render.ThermalBadge;
import dev.krutlexik.skyfront.drone.client.render.ThermalPackPass;
import dev.krutlexik.skyfront.drone.client.render.ThermalScreenPass;
import dev.krutlexik.skyfront.drone.registry.DroneEntities;
import dev.krutlexik.skyfront.drone.registry.DroneItems;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.ItemLike;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.EventBusSubscriber.Bus;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.RegisterClientReloadListenersEvent;
import net.neoforged.neoforge.client.event.RegisterItemDecorationsEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent.RegisterRenderers;
import net.neoforged.neoforge.client.extensions.common.IClientItemExtensions;
import net.neoforged.neoforge.client.extensions.common.RegisterClientExtensionsEvent;
import net.neoforged.neoforge.client.gui.IConfigScreenFactory;

@EventBusSubscriber(
   modid = "sfw",
   bus = Bus.MOD,
   value = {Dist.CLIENT}
)
public final class DroneClientSetup {
   @SubscribeEvent
   public static void registerRenderers(RegisterRenderers event) {
      event.registerEntityRenderer((EntityType)DroneEntities.DRONE.get(), DroneRenderer::new);
      event.registerEntityRenderer((EntityType)DroneEntities.THERMAL_DRONE.get(), DroneRenderer::new);
      event.registerEntityRenderer(
         (EntityType)DroneEntities.INTERCEPTOR_DRONE.get(),
         context -> new DroneRenderer(context, DroneRenderer.FPV_MODEL, 1.0F, true, DroneRenderer.tailSitter(-40.7F))
      );
      event.registerEntityRenderer(
         (EntityType)DroneEntities.THERMAL_INTERCEPTOR_DRONE.get(),
         context -> new DroneRenderer(context, DroneRenderer.FPV_MODEL, 1.0F, true, DroneRenderer.tailSitter(-40.7F))
      );
      event.registerEntityRenderer(
         (EntityType)DroneEntities.FPV_DRONE.get(),
         context -> new DroneRenderer(context, DroneRenderer.FPV_QUAD_MODEL, 1.2F, true, DroneRenderer.gentlerLean(0.45F))
      );
      event.registerEntityRenderer((EntityType)DroneEntities.DRONE_STAND.get(), DroneStandRenderer::new);
      event.registerEntityRenderer(
         (EntityType)DroneEntities.MOLNIYA_DRONE.get(),
         context -> new DroneRenderer(context, DroneRenderer.MOLNIYA_MODEL, 1.4F, true, DroneRenderer.fastCruise(-21.1F))
      );
   }

   @SubscribeEvent
   public static void registerReloadListeners(RegisterClientReloadListenersEvent event) {
      event.registerReloadListener((ResourceManagerReloadListener)resources -> {
         DroneRenderer.reload(resources);
         ThermalScreenPass.unload();
         ThermalPackPass.unload();
         AnalogFeedPass.unload();
      });
   }

   @SubscribeEvent
   public static void registerKeyMappings(RegisterKeyMappingsEvent event) {
      event.register(DroneKeys.ARM);
      event.register(DroneKeys.THERMAL);
      event.register(DroneKeys.RADIO_SETTINGS);
      event.register(DroneKeys.SELF_DESTRUCT);
   }

   @SubscribeEvent
   public static void clientSetup(FMLClientSetupEvent event) {
      event.enqueueWork(
         () -> ModList.get()
            .getModContainerById("sfw")
            .ifPresent(
               container -> container.registerExtensionPoint(IConfigScreenFactory.class, (IConfigScreenFactory)(mod, parent) -> new RadioSettingsScreen(parent))
            )
      );
   }

   @SubscribeEvent
   public static void registerClientExtensions(RegisterClientExtensionsEvent event) {
      registerDroneIcon(event, DroneRenderer.RECON_MODEL, (Item)DroneItems.DRONE.get(), (Item)DroneItems.THERMAL_DRONE.get());
      registerDroneIcon(event, DroneRenderer.FPV_MODEL, (Item)DroneItems.INTERCEPTOR_DRONE.get(), (Item)DroneItems.THERMAL_INTERCEPTOR_DRONE.get());
      registerDroneIcon(event, DroneRenderer.MOLNIYA_MODEL, (Item)DroneItems.MOLNIYA_DRONE.get());
      registerDroneIcon(event, DroneRenderer.FPV_QUAD_MODEL, (Item)DroneItems.FPV_DRONE.get());
   }

   @SubscribeEvent
   public static void registerItemDecorations(RegisterItemDecorationsEvent event) {
      ThermalBadge badge = new ThermalBadge();
      event.register((ItemLike)DroneItems.THERMAL_DRONE.get(), badge);
      event.register((ItemLike)DroneItems.THERMAL_INTERCEPTOR_DRONE.get(), badge);
   }

   private static void registerDroneIcon(RegisterClientExtensionsEvent event, ResourceLocation model, Item... items) {
      final DroneItemRenderer renderer = new DroneItemRenderer(model);
      event.registerItem(new IClientItemExtensions() {
         public BlockEntityWithoutLevelRenderer getCustomRenderer() {
            return renderer;
         }
      }, items);
   }

   private DroneClientSetup() {
   }
}
