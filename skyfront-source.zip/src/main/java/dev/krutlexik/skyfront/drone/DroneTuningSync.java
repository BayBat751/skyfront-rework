package dev.krutlexik.skyfront.drone;

import dev.krutlexik.skyfront.drone.network.DroneTuningPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent.PlayerLoggedInEvent;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(
   modid = "sfw"
)
public final class DroneTuningSync {
   @SubscribeEvent
   public static void onLogin(PlayerLoggedInEvent event) {
      if (event.getEntity() instanceof ServerPlayer player && player.connection.hasChannel(DroneTuningPayload.TYPE)) {
         PacketDistributor.sendToPlayer(player, DroneTuningPayload.current(), new CustomPacketPayload[0]);
      }
   }

   public static void broadcast(MinecraftServer server) {
      for (ServerPlayer player : server.getPlayerList().getPlayers()) {
         if (player.connection.hasChannel(DroneTuningPayload.TYPE)) {
            PacketDistributor.sendToPlayer(player, DroneTuningPayload.current(), new CustomPacketPayload[0]);
         }
      }
   }

   private DroneTuningSync() {
   }
}
