package dev.krutlexik.skyfront.drone.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.platform.InputConstants.Type;
import net.minecraft.client.KeyMapping;
import net.neoforged.neoforge.client.settings.KeyConflictContext;

public final class DroneKeys {
   public static final String CATEGORY = "key.categories.sfw.drone";
   public static final KeyMapping ARM = new KeyMapping("key.sfw.drone_arm", KeyConflictContext.IN_GAME, Type.KEYSYM, 258, "key.categories.sfw.drone");
   public static final KeyMapping THERMAL = new KeyMapping("key.sfw.drone_thermal", KeyConflictContext.IN_GAME, Type.KEYSYM, 84, "key.categories.sfw.drone");
   public static final KeyMapping RADIO_SETTINGS = new KeyMapping(
      "key.sfw.radio_settings", KeyConflictContext.IN_GAME, Type.KEYSYM, InputConstants.UNKNOWN.getValue(), "key.categories.sfw.drone"
   );
   public static final KeyMapping SELF_DESTRUCT = new KeyMapping(
      "key.sfw.drone_self_destruct", KeyConflictContext.IN_GAME, Type.KEYSYM, InputConstants.UNKNOWN.getValue(), "key.categories.sfw.drone"
   );

   private DroneKeys() {
   }
}
