package dev.krutlexik.skyfront.drone.client.render;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import dev.krutlexik.skyfront.drone.DroneMod;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.MissingTextureAtlasSprite;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.util.GsonHelper;
import org.joml.AxisAngle4f;
import org.joml.Matrix3fc;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public final class GlbModel {
   private static final int MAGIC = 1179937895;
   private static final int CHUNK_JSON = 1313821514;
   private static final int CHUNK_BIN = 5130562;
   private static final int MODE_TRIANGLES = 4;
   private static final int FLOAT = 5126;
   private static final int UNSIGNED_BYTE = 5121;
   private static final int UNSIGNED_SHORT = 5123;
   private static final int UNSIGNED_INT = 5125;
   private static final float SPIN_RADIANS = 1.0F;
   private final List<GlbModel.Part> staticParts;
   private final List<GlbModel.AnimatedGroup> animatedGroups;
   private final float minY;
   private final float centreX;
   private final float centreZ;
   private final float sizeX;
   private final float sizeZ;
   private final float height;

   private static boolean isPropeller(JsonObject node) {
      String name = GsonHelper.getAsString(node, "name", "");
      return name.matches("(?i)^prop(eller)?[_ -]?\\d+$");
   }

   private GlbModel(List<GlbModel.Part> staticParts, List<GlbModel.AnimatedGroup> animatedGroups) {
      this.staticParts = staticParts;
      this.animatedGroups = animatedGroups;
      float[] bounds = new float[]{Float.MAX_VALUE, Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE, Float.MAX_VALUE, -Float.MAX_VALUE};

      for (GlbModel.Part part : staticParts) {
         measure(part.positions(), null, bounds);
      }

      for (GlbModel.AnimatedGroup group : animatedGroups) {
         for (GlbModel.Part part : group.parts()) {
            measure(part.positions(), group.restTransform(), bounds);
         }
      }

      boolean empty = bounds[0] == Float.MAX_VALUE;
      this.centreX = empty ? 0.0F : (bounds[0] + bounds[2]) / 2.0F;
      this.centreZ = empty ? 0.0F : (bounds[1] + bounds[3]) / 2.0F;
      this.minY = empty ? 0.0F : bounds[4];
      this.sizeX = empty ? 0.0F : bounds[2] - bounds[0];
      this.sizeZ = empty ? 0.0F : bounds[3] - bounds[1];
      this.height = empty ? 0.0F : bounds[5] - bounds[4];
   }

   private static void measure(float[] positions, @Nullable Matrix4f restTransform, float[] bounds) {
      Vector3f scratch = new Vector3f();

      for (int i = 0; i + 2 < positions.length; i += 3) {
         scratch.set(positions[i], positions[i + 1], positions[i + 2]);
         if (restTransform != null) {
            restTransform.transformPosition(scratch);
         }

         bounds[0] = Math.min(bounds[0], scratch.x);
         bounds[1] = Math.min(bounds[1], scratch.z);
         bounds[2] = Math.max(bounds[2], scratch.x);
         bounds[3] = Math.max(bounds[3], scratch.z);
         bounds[4] = Math.min(bounds[4], scratch.y);
         bounds[5] = Math.max(bounds[5], scratch.y);
      }
   }

   public float sizeX() {
      return this.sizeX;
   }

   public float sizeZ() {
      return this.sizeZ;
   }

   public float height() {
      return this.height;
   }

   public int triangleCount() {
      int total = this.staticParts.stream().mapToInt(part -> part.indices().length / 3).sum();

      for (GlbModel.AnimatedGroup group : this.animatedGroups) {
         total += group.parts().stream().mapToInt(part -> part.indices().length / 3).sum();
      }

      return total;
   }

   public int animatedGroupCount() {
      return this.animatedGroups.size();
   }

   public float minY() {
      return this.minY;
   }

   public float centreX() {
      return this.centreX;
   }

   public float centreZ() {
      return this.centreZ;
   }

   public float[] silhouette(Matrix3fc rotation) {
      float[] out = new float[]{Float.MAX_VALUE, -Float.MAX_VALUE, Float.MAX_VALUE, -Float.MAX_VALUE, 0.0F};
      Vector3f scratch = new Vector3f();

      for (GlbModel.Part part : this.staticParts) {
         project(part.positions(), null, rotation, scratch, out);
      }

      for (GlbModel.AnimatedGroup group : this.animatedGroups) {
         for (GlbModel.Part part : group.parts()) {
            project(part.positions(), group.restTransform(), rotation, scratch, out);
         }
      }

      if (out[0] == Float.MAX_VALUE) {
         return new float[5];
      } else {
         out[4] = rotation.transform(this.centreX, this.minY + this.height / 2.0F, this.centreZ, scratch).z;
         return out;
      }
   }

   private static void project(float[] positions, @Nullable Matrix4f restTransform, Matrix3fc rotation, Vector3f scratch, float[] out) {
      for (int i = 0; i + 2 < positions.length; i += 3) {
         scratch.set(positions[i], positions[i + 1], positions[i + 2]);
         if (restTransform != null) {
            restTransform.transformPosition(scratch);
         }

         rotation.transform(scratch);
         out[0] = Math.min(out[0], scratch.x);
         out[1] = Math.max(out[1], scratch.x);
         out[2] = Math.min(out[2], scratch.y);
         out[3] = Math.max(out[3], scratch.y);
      }
   }

   public static GlbModel load(ResourceManager resources, ResourceLocation location, boolean spinPropellers) throws IOException {
      byte[] bytes;
      try (InputStream stream = resources.getResourceOrThrow(location).open()) {
         bytes = stream.readAllBytes();
      }

      ByteBuffer file = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
      if (file.remaining() >= 12 && file.getInt() == 1179937895) {
         file.getInt();
         file.getInt();
         JsonObject gltf = null;
         byte[] binary = new byte[0];

         while (file.remaining() >= 8) {
            int chunkLength = file.getInt();
            int chunkType = file.getInt();
            byte[] chunk = new byte[Math.min(chunkLength, file.remaining())];
            file.get(chunk);
            if (chunkType == 1313821514) {
               gltf = GsonHelper.parse(new String(chunk, StandardCharsets.UTF_8));
            } else if (chunkType == 5130562) {
               binary = chunk;
            }
         }

         if (gltf == null) {
            throw new IOException(location + " has no JSON chunk");
         } else {
            ResourceLocation[] textures = uploadTextures(gltf, binary, location);
            Map<Integer, GlbModel.AnimTrack> tracks = readAnimationTracks(gltf, binary);
            List<GlbModel.Part> staticParts = new ArrayList<>();
            List<GlbModel.AnimatedGroup> animatedGroups = new ArrayList<>();

            for (int nodeIndex : sceneRoots(gltf)) {
               collectNode(gltf, binary, nodeIndex, new Matrix4f(), textures, staticParts, animatedGroups, tracks, null, spinPropellers);
            }

            if (staticParts.isEmpty() && animatedGroups.isEmpty()) {
               throw new IOException(location + " contains no triangle geometry");
            } else {
               return new GlbModel(staticParts, animatedGroups);
            }
         }
      } else {
         throw new IOException(location + " is not a glb file");
      }
   }

   public void render(PoseStack poseStack, MultiBufferSource buffers, int light, int overlay, float animTime) {
      renderParts(this.staticParts, poseStack.last(), buffers, light, overlay);

      for (int i = 0; i < this.animatedGroups.size(); i++) {
         this.renderGroup(i, poseStack, buffers, light, overlay, animTime);
      }
   }

   public Vector3f groupPivot(int index) {
      return this.animatedGroups.get(index).restTransform().getTranslation(new Vector3f());
   }

   public Vector3f groupCentre(int index) {
      GlbModel.AnimatedGroup group = this.animatedGroups.get(index);
      Vector3f min = new Vector3f(Float.POSITIVE_INFINITY);
      Vector3f max = new Vector3f(Float.NEGATIVE_INFINITY);

      for (GlbModel.Part part : group.parts()) {
         float[] positions = part.positions();

         for (int i = 0; i + 2 < positions.length; i += 3) {
            min.min(new Vector3f(positions[i], positions[i + 1], positions[i + 2]));
            max.max(new Vector3f(positions[i], positions[i + 1], positions[i + 2]));
         }
      }

      return min.x > max.x ? this.groupPivot(index) : group.restTransform().transformPosition(min.add(max).mul(0.5F));
   }

   public void renderGroup(int index, PoseStack poseStack, MultiBufferSource buffers, int light, int overlay, float animTime) {
      GlbModel.AnimatedGroup group = this.animatedGroups.get(index);
      poseStack.pushPose();
      Vector3f translation = group.restTransform().getTranslation(new Vector3f());
      Quaternionf baseRotation = group.restTransform().getNormalizedRotation(new Quaternionf());
      poseStack.translate(translation.x, translation.y, translation.z);
      poseStack.mulPose(baseRotation);
      poseStack.mulPose(group.track() != null ? group.track().sample(animTime) : new Quaternionf().rotateY(animTime * 1.0F));
      renderParts(group.parts(), poseStack.last(), buffers, light, overlay);
      poseStack.popPose();
   }

   private static void renderParts(List<GlbModel.Part> parts, Pose pose, MultiBufferSource buffers, int light, int overlay) {
      for (GlbModel.Part part : parts) {
         VertexConsumer consumer = buffers.getBuffer(RenderType.entityCutoutNoCull(part.texture()));
         float[] positions = part.positions();
         float[] normals = part.normals();
         float[] uvs = part.uvs();
         int[] indices = part.indices();

         for (int i = 0; i + 2 < indices.length; i += 3) {
            int a = indices[i];
            int b = indices[i + 1];
            int c = indices[i + 2];
            vertex(consumer, pose, positions, normals, uvs, a, light, overlay);
            vertex(consumer, pose, positions, normals, uvs, b, light, overlay);
            vertex(consumer, pose, positions, normals, uvs, c, light, overlay);
            vertex(consumer, pose, positions, normals, uvs, c, light, overlay);
         }
      }
   }

   private static void vertex(VertexConsumer consumer, Pose pose, float[] positions, float[] normals, float[] uvs, int index, int light, int overlay) {
      consumer.addVertex(pose, positions[index * 3], positions[index * 3 + 1], positions[index * 3 + 2])
         .setColor(255, 255, 255, 255)
         .setUv(uvs[index * 2], uvs[index * 2 + 1])
         .setOverlay(overlay)
         .setLight(light)
         .setNormal(pose, normals[index * 3], normals[index * 3 + 1], normals[index * 3 + 2]);
   }

   private static int[] sceneRoots(JsonObject gltf) {
      int sceneIndex = GsonHelper.getAsInt(gltf, "scene", 0);
      JsonArray scenes = GsonHelper.getAsJsonArray(gltf, "scenes", new JsonArray());
      if (sceneIndex < scenes.size()) {
         JsonArray nodes = GsonHelper.getAsJsonArray(scenes.get(sceneIndex).getAsJsonObject(), "nodes", new JsonArray());
         int[] roots = new int[nodes.size()];

         for (int i = 0; i < roots.length; i++) {
            roots[i] = nodes.get(i).getAsInt();
         }

         return roots;
      } else {
         int count = GsonHelper.getAsJsonArray(gltf, "nodes", new JsonArray()).size();
         int[] roots = new int[count];
         int i = 0;

         while (i < count) {
            roots[i] = i++;
         }

         return roots;
      }
   }

   private static void collectNode(
      JsonObject gltf,
      byte[] binary,
      int nodeIndex,
      Matrix4f parent,
      ResourceLocation[] textures,
      List<GlbModel.Part> staticOut,
      List<GlbModel.AnimatedGroup> animatedOut,
      Map<Integer, GlbModel.AnimTrack> tracks,
      List<GlbModel.Part> activeGroup,
      boolean spinPropellers
   ) {
      JsonObject node = GsonHelper.getAsJsonArray(gltf, "nodes").get(nodeIndex).getAsJsonObject();
      Matrix4f transform = new Matrix4f(parent).mul(localTransform(node));
      Matrix4f bakeTransform = transform;
      List<GlbModel.Part> target = activeGroup;
      GlbModel.AnimTrack track = tracks.get(nodeIndex);
      if (track != null || spinPropellers && isPropeller(node)) {
         List<GlbModel.Part> group = new ArrayList<>();
         animatedOut.add(new GlbModel.AnimatedGroup(new Matrix4f(transform), track, group));
         target = group;
         bakeTransform = new Matrix4f();
      }

      if (node.has("mesh")) {
         JsonObject mesh = GsonHelper.getAsJsonArray(gltf, "meshes").get(GsonHelper.getAsInt(node, "mesh")).getAsJsonObject();

         for (JsonElement element : GsonHelper.getAsJsonArray(mesh, "primitives")) {
            GlbModel.Part part = readPrimitive(gltf, binary, element.getAsJsonObject(), bakeTransform, textures);
            if (part != null) {
               (target != null ? target : staticOut).add(part);
            }
         }
      }

      for (JsonElement child : GsonHelper.getAsJsonArray(node, "children", new JsonArray())) {
         collectNode(gltf, binary, child.getAsInt(), bakeTransform, textures, staticOut, animatedOut, tracks, target, spinPropellers);
      }
   }

   private static Map<Integer, GlbModel.AnimTrack> readAnimationTracks(JsonObject gltf, byte[] binary) {
      Map<Integer, GlbModel.AnimTrack> tracks = new HashMap<>();

      for (JsonElement animElement : GsonHelper.getAsJsonArray(gltf, "animations", new JsonArray())) {
         JsonObject animation = animElement.getAsJsonObject();
         JsonArray samplers = GsonHelper.getAsJsonArray(animation, "samplers");

         for (JsonElement channelElement : GsonHelper.getAsJsonArray(animation, "channels")) {
            JsonObject channel = channelElement.getAsJsonObject();
            JsonObject target = GsonHelper.getAsJsonObject(channel, "target");
            if (target.has("node") && "rotation".equals(GsonHelper.getAsString(target, "path"))) {
               JsonObject sampler = samplers.get(GsonHelper.getAsInt(channel, "sampler")).getAsJsonObject();
               float[] times = readFloats(gltf, binary, GsonHelper.getAsInt(sampler, "input"), 1);
               float[] rotations = readFloats(gltf, binary, GsonHelper.getAsInt(sampler, "output"), 4);
               tracks.put(GsonHelper.getAsInt(target, "node"), new GlbModel.AnimTrack(times, rotations));
            }
         }
      }

      return tracks;
   }

   private static Matrix4f localTransform(JsonObject node) {
      if (node.has("matrix")) {
         float[] values = floats(GsonHelper.getAsJsonArray(node, "matrix"));
         return new Matrix4f().set(values);
      } else {
         float[] translation = node.has("translation") ? floats(GsonHelper.getAsJsonArray(node, "translation")) : new float[]{0.0F, 0.0F, 0.0F};
         float[] rotation = node.has("rotation") ? floats(GsonHelper.getAsJsonArray(node, "rotation")) : new float[]{0.0F, 0.0F, 0.0F, 1.0F};
         float[] scale = node.has("scale") ? floats(GsonHelper.getAsJsonArray(node, "scale")) : new float[]{1.0F, 1.0F, 1.0F};
         return new Matrix4f()
            .translationRotateScale(
               translation[0], translation[1], translation[2], rotation[0], rotation[1], rotation[2], rotation[3], scale[0], scale[1], scale[2]
            );
      }
   }

   private static GlbModel.Part readPrimitive(JsonObject gltf, byte[] binary, JsonObject primitive, Matrix4f transform, ResourceLocation[] textures) {
      if (GsonHelper.getAsInt(primitive, "mode", 4) != 4) {
         return null;
      } else {
         JsonObject attributes = GsonHelper.getAsJsonObject(primitive, "attributes");
         if (!attributes.has("POSITION")) {
            return null;
         } else {
            float[] positions = readFloats(gltf, binary, GsonHelper.getAsInt(attributes, "POSITION"), 3);
            int vertexCount = positions.length / 3;
            float[] normals = attributes.has("NORMAL") ? readFloats(gltf, binary, GsonHelper.getAsInt(attributes, "NORMAL"), 3) : new float[positions.length];
            float[] uvs = attributes.has("TEXCOORD_0")
               ? readFloats(gltf, binary, GsonHelper.getAsInt(attributes, "TEXCOORD_0"), 2)
               : new float[vertexCount * 2];
            Vector3f scratch = new Vector3f();

            for (int i = 0; i < vertexCount; i++) {
               scratch.set(positions[i * 3], positions[i * 3 + 1], positions[i * 3 + 2]);
               transform.transformPosition(scratch);
               positions[i * 3] = scratch.x;
               positions[i * 3 + 1] = scratch.y;
               positions[i * 3 + 2] = scratch.z;
               scratch.set(normals[i * 3], normals[i * 3 + 1], normals[i * 3 + 2]);
               if (scratch.lengthSquared() > 1.0E-8F) {
                  transform.transformDirection(scratch).normalize();
               } else {
                  scratch.set(0.0F, 1.0F, 0.0F);
               }

               normals[i * 3] = scratch.x;
               normals[i * 3 + 1] = scratch.y;
               normals[i * 3 + 2] = scratch.z;
            }

            int[] indices;
            if (primitive.has("indices")) {
               indices = readIndices(gltf, binary, GsonHelper.getAsInt(primitive, "indices"));
            } else {
               indices = new int[vertexCount];
               int i = 0;

               while (i < vertexCount) {
                  indices[i] = i++;
               }
            }

            int material = GsonHelper.getAsInt(primitive, "material", -1);
            ResourceLocation texture = material >= 0 && material < textures.length && textures[material] != null
               ? textures[material]
               : MissingTextureAtlasSprite.getLocation();
            return new GlbModel.Part(positions, normals, uvs, indices, texture);
         }
      }
   }

   private static ResourceLocation[] uploadTextures(JsonObject gltf, byte[] binary, ResourceLocation source) {
      JsonArray materials = GsonHelper.getAsJsonArray(gltf, "materials", new JsonArray());
      JsonArray textures = GsonHelper.getAsJsonArray(gltf, "textures", new JsonArray());
      JsonArray images = GsonHelper.getAsJsonArray(gltf, "images", new JsonArray());
      String prefix = source.getPath().replaceAll("^.*/", "").replaceAll("\\.glb$", "").toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_]", "_");
      ResourceLocation[] uploaded = new ResourceLocation[images.size()];

      for (int i = 0; i < images.size(); i++) {
         JsonObject image = images.get(i).getAsJsonObject();
         if (!image.has("bufferView")) {
            DroneMod.LOGGER.warn("{}: image {} has no bufferView (external URIs are unsupported)", source, i);
         } else {
            try {
               byte[] png = readBufferView(gltf, binary, GsonHelper.getAsInt(image, "bufferView"));
               NativeImage nativeImage = NativeImage.read(new ByteArrayInputStream(png));
               ResourceLocation id = DroneMod.id("glb/" + prefix + "_" + i);
               Minecraft.getInstance().getTextureManager().register(id, new DynamicTexture(nativeImage));
               uploaded[i] = id;
            } catch (Exception var13) {
               DroneMod.LOGGER.error("{}: failed to decode embedded image {}", new Object[]{source, i, var13});
            }
         }
      }

      ResourceLocation[] byMaterial = new ResourceLocation[Math.max(materials.size(), 1)];

      for (int ix = 0; ix < materials.size(); ix++) {
         JsonObject pbr = GsonHelper.getAsJsonObject(materials.get(ix).getAsJsonObject(), "pbrMetallicRoughness", new JsonObject());
         if (pbr.has("baseColorTexture")) {
            int textureIndex = GsonHelper.getAsInt(GsonHelper.getAsJsonObject(pbr, "baseColorTexture"), "index");
            if (textureIndex >= 0 && textureIndex < textures.size()) {
               int imageIndex = GsonHelper.getAsInt(textures.get(textureIndex).getAsJsonObject(), "source", -1);
               if (imageIndex >= 0 && imageIndex < uploaded.length) {
                  byMaterial[ix] = uploaded[imageIndex];
               }
            }
         }
      }

      return byMaterial;
   }

   private static float[] readFloats(JsonObject gltf, byte[] binary, int accessorIndex, int components) {
      JsonObject accessor = GsonHelper.getAsJsonArray(gltf, "accessors").get(accessorIndex).getAsJsonObject();
      int componentType = GsonHelper.getAsInt(accessor, "componentType");
      if (componentType != 5126) {
         throw new IllegalArgumentException("accessor " + accessorIndex + ": only float attributes are supported");
      } else {
         int count = GsonHelper.getAsInt(accessor, "count");
         ByteBuffer buffer = accessorBuffer(gltf, binary, accessor);
         int stride = accessorStride(gltf, accessor, components * 4);
         float[] values = new float[count * components];

         for (int i = 0; i < count; i++) {
            int base = i * stride;

            for (int c = 0; c < components; c++) {
               values[i * components + c] = buffer.getFloat(base + c * 4);
            }
         }

         return values;
      }
   }

   private static int[] readIndices(JsonObject gltf, byte[] binary, int accessorIndex) {
      JsonObject accessor = GsonHelper.getAsJsonArray(gltf, "accessors").get(accessorIndex).getAsJsonObject();
      int componentType = GsonHelper.getAsInt(accessor, "componentType");
      int count = GsonHelper.getAsInt(accessor, "count");
      ByteBuffer buffer = accessorBuffer(gltf, binary, accessor);

      int size = switch (componentType) {
         case 5121 -> 1;
         default -> throw new IllegalArgumentException("accessor " + accessorIndex + ": bad index type " + componentType);
         case 5123 -> 2;
         case 5125 -> 4;
      };
      int stride = accessorStride(gltf, accessor, size);
      int[] indices = new int[count];

      for (int i = 0; i < count; i++) {
         int at = i * stride;

         indices[i] = switch (size) {
            case 1 -> buffer.get(at) & 255;
            case 2 -> buffer.getShort(at) & '\uffff';
            default -> buffer.getInt(at);
         };
      }

      return indices;
   }

   private static ByteBuffer accessorBuffer(JsonObject gltf, byte[] binary, JsonObject accessor) {
      int viewIndex = GsonHelper.getAsInt(accessor, "bufferView");
      JsonObject view = GsonHelper.getAsJsonArray(gltf, "bufferViews").get(viewIndex).getAsJsonObject();
      int offset = GsonHelper.getAsInt(view, "byteOffset", 0) + GsonHelper.getAsInt(accessor, "byteOffset", 0);
      return ByteBuffer.wrap(binary, offset, binary.length - offset).slice().order(ByteOrder.LITTLE_ENDIAN);
   }

   private static int accessorStride(JsonObject gltf, JsonObject accessor, int packedSize) {
      JsonObject view = GsonHelper.getAsJsonArray(gltf, "bufferViews").get(GsonHelper.getAsInt(accessor, "bufferView")).getAsJsonObject();
      int stride = GsonHelper.getAsInt(view, "byteStride", 0);
      return stride > 0 ? stride : packedSize;
   }

   private static byte[] readBufferView(JsonObject gltf, byte[] binary, int viewIndex) {
      JsonObject view = GsonHelper.getAsJsonArray(gltf, "bufferViews").get(viewIndex).getAsJsonObject();
      int offset = GsonHelper.getAsInt(view, "byteOffset", 0);
      int length = GsonHelper.getAsInt(view, "byteLength");
      byte[] slice = new byte[length];
      System.arraycopy(binary, offset, slice, 0, length);
      return slice;
   }

   private static float[] floats(JsonArray array) {
      float[] values = new float[array.size()];

      for (int i = 0; i < values.length; i++) {
         values[i] = array.get(i).getAsFloat();
      }

      return values;
   }

   private static final class AnimTrack {
      private final float[] times;
      private final Quaternionf[] values;
      private final float duration;
      private final AxisAngle4f perLap;

      AnimTrack(float[] times, float[] flatRotations) {
         this.times = times;
         this.values = new Quaternionf[times.length];

         for (int i = 0; i < times.length; i++) {
            this.values[i] = new Quaternionf(flatRotations[i * 4], flatRotations[i * 4 + 1], flatRotations[i * 4 + 2], flatRotations[i * 4 + 3]);
         }

         this.duration = times[times.length - 1];
         Quaternionf net = new Quaternionf(this.values[this.values.length - 1]).mul(new Quaternionf(this.values[0]).conjugate());
         this.perLap = new AxisAngle4f(net);
      }

      Quaternionf sample(float time) {
         if (!(this.duration <= 0.0F) && this.times.length != 1) {
            int lap = (int)Math.floor(time / this.duration);
            float localTime = time - lap * this.duration;
            int hi = 1;

            while (hi < this.times.length - 1 && this.times[hi] < localTime) {
               hi++;
            }

            int lo = hi - 1;
            float span = this.times[hi] - this.times[lo];
            float factor = span > 0.0F ? (localTime - this.times[lo]) / span : 0.0F;
            factor = Math.max(0.0F, Math.min(1.0F, factor));
            Quaternionf local = new Quaternionf(this.values[lo]).slerp(this.values[hi], factor);
            if (lap == 0) {
               return local;
            } else {
               Quaternionf accumulated = new Quaternionf().fromAxisAngleRad(this.perLap.x, this.perLap.y, this.perLap.z, this.perLap.angle * lap);
               return accumulated.mul(local);
            }
         } else {
            return new Quaternionf(this.values[0]);
         }
      }
   }

   private record AnimatedGroup(Matrix4f restTransform, @Nullable GlbModel.AnimTrack track, List<GlbModel.Part> parts) {
   }

   private record Part(float[] positions, float[] normals, float[] uvs, int[] indices, ResourceLocation texture) {
   }
}
