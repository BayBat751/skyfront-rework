package dev.krutlexik.skyfront.drone.client.render;

import com.mojang.blaze3d.platform.TextureUtil;
import com.mojang.blaze3d.shaders.Uniform;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat.Mode;
import dev.krutlexik.skyfront.drone.client.ThermalVision;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import org.lwjgl.opengl.GL11;

public final class ThermalScreenPass {
   private static int texture = -1;
   private static int width;
   private static int height;

   public static void render(float partialTick) {
      render(partialTick, 0);
   }

   public static void render(float partialTick, int bodyMask) {
      if (ThermalVision.isOn()) {
         ShaderInstance shader = ThermalShaders.screen();
         if (shader != null) {
            Minecraft minecraft = Minecraft.getInstance();
            int w = minecraft.getMainRenderTarget().width;
            int h = minecraft.getMainRenderTarget().height;
            if (w > 0 && h > 0) {
               if (texture == -1 || w != width || h != height) {
                  if (texture != -1) {
                     TextureUtil.releaseTextureId(texture);
                  }

                  texture = TextureUtil.generateTextureId();
                  RenderSystem.bindTexture(texture);
                  TextureUtil.prepareImage(texture, 0, w, h);
                  width = w;
                  height = h;
               }

               RenderSystem.bindTexture(texture);
               GL11.glCopyTexSubImage2D(3553, 0, 0, 0, 0, 0, w, h);
               setUniforms(shader, minecraft, partialTick);
               Uniform useMask = shader.getUniform("UseMask");
               if (useMask != null) {
                  useMask.set(bodyMask != 0 ? 1.0F : 0.0F);
               }

               RenderSystem.setShader(() -> shader);
               RenderSystem.setShaderTexture(0, texture);
               RenderSystem.setShaderTexture(1, bodyMask);
               RenderSystem.disableBlend();
               RenderSystem.disableDepthTest();
               RenderSystem.depthMask(false);
               BufferBuilder buffer = Tesselator.getInstance().begin(Mode.QUADS, DefaultVertexFormat.POSITION_TEX);
               buffer.addVertex(-1.0F, -1.0F, 0.0F).setUv(0.0F, 0.0F);
               buffer.addVertex(1.0F, -1.0F, 0.0F).setUv(1.0F, 0.0F);
               buffer.addVertex(1.0F, 1.0F, 0.0F).setUv(1.0F, 1.0F);
               buffer.addVertex(-1.0F, 1.0F, 0.0F).setUv(0.0F, 1.0F);
               BufferUploader.drawWithShader(buffer.buildOrThrow());
               RenderSystem.depthMask(true);
               RenderSystem.enableDepthTest();
            }
         }
      }
   }

   private static void setUniforms(ShaderInstance shader, Minecraft minecraft, float partialTick) {
      float ambient = 0.16F;
      Level level = minecraft.level;
      if (level != null && minecraft.getCameraEntity() != null) {
         float biome = ((Biome)level.getBiome(minecraft.getCameraEntity().blockPosition()).value()).getBaseTemperature();
         float normalised = Math.max(0.0F, Math.min(1.0F, (biome + 0.5F) / 2.5F));
         ambient = 0.1F + normalised * 0.1F + (level.isDay() ? 0.04F : 0.0F);
      }

      Uniform uniform = shader.getUniform("ambientTemp");
      if (uniform != null) {
         uniform.set(ambient);
      }

      uniform = shader.getUniform("Time");
      if (uniform != null) {
         uniform.set((float)(System.currentTimeMillis() % 100000L) / 1000.0F);
      }
   }

   public static void unload() {
      if (texture != -1) {
         TextureUtil.releaseTextureId(texture);
         texture = -1;
      }

      width = 0;
      height = 0;
   }

   public static boolean isRendering() {
      return ThermalShaders.screen() != null;
   }

   private ThermalScreenPass() {
   }
}
