package dev.krutlexik.skyfront.drone.client;

import dev.krutlexik.skyfront.drone.DroneTuning;
import dev.krutlexik.skyfront.drone.RateModeFlight;
import dev.krutlexik.skyfront.drone.client.radio.RadioInput;
import dev.krutlexik.skyfront.drone.client.radio.RadioSettingsScreen;
import dev.krutlexik.skyfront.drone.client.render.FpvCockpitView;
import dev.krutlexik.skyfront.drone.client.render.IrisCompat;
import dev.krutlexik.skyfront.drone.client.render.ThermalHeatRenderer;
import dev.krutlexik.skyfront.drone.client.render.ThermalPackPass;
import dev.krutlexik.skyfront.drone.client.render.ThermalScreenPass;
import dev.krutlexik.skyfront.drone.entity.DroneEntity;
import dev.krutlexik.skyfront.drone.entity.InterceptorDroneEntity;
import java.util.Set;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.player.Input;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.MovementInputUpdateEvent;
import net.neoforged.neoforge.client.event.RenderHandEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent.LoggingOut;
import net.neoforged.neoforge.client.event.ClientTickEvent.Post;
import net.neoforged.neoforge.client.event.InputEvent.InteractionKeyMappingTriggered;
import net.neoforged.neoforge.client.event.InputEvent.MouseScrollingEvent;
import net.neoforged.neoforge.client.event.RenderFrameEvent.Pre;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent.Stage;
import net.neoforged.neoforge.client.event.ScreenEvent.Opening;
import net.neoforged.neoforge.client.event.ViewportEvent.ComputeCameraAngles;
import net.neoforged.neoforge.client.event.ViewportEvent.ComputeFov;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;

@EventBusSubscriber(
   modid = "sfw",
   value = {Dist.CLIENT}
)
public final class DroneClientEvents {
   private static final float CAMERA_ROLL_SHARE = 0.5F;
   private static final DroneOsd CAMERA_OSD = new DroneOsd();
   private static final BetaflightOsd FPV_OSD = new BetaflightOsd();
   private static final Set<ResourceLocation> HIDDEN_WHILE_FLYING = Set.of(
      VanillaGuiLayers.CROSSHAIR,
      VanillaGuiLayers.HOTBAR,
      VanillaGuiLayers.EXPERIENCE_BAR,
      VanillaGuiLayers.EXPERIENCE_LEVEL,
      VanillaGuiLayers.JUMP_METER,
      VanillaGuiLayers.PLAYER_HEALTH,
      VanillaGuiLayers.ARMOR_LEVEL,
      VanillaGuiLayers.FOOD_LEVEL,
      VanillaGuiLayers.AIR_LEVEL,
      VanillaGuiLayers.SELECTED_ITEM_NAME,
      VanillaGuiLayers.TAB_LIST,
      VanillaGuiLayers.SCOREBOARD_SIDEBAR
   );

   @SubscribeEvent
   public static void onClientTick(Post event) {
      boolean flying = DroneControl.isActive();

      while (DroneKeys.ARM.consumeClick()) {
         if (flying) {
            DroneControl.toggleArm();
         }
      }

      while (DroneKeys.THERMAL.consumeClick()) {
         if (flying) {
            DroneControl.toggleThermal();
         }
      }

      while (DroneKeys.SELF_DESTRUCT.consumeClick()) {
         if (flying) {
            DroneControl.selfDestruct();
         }
      }

      while (DroneKeys.RADIO_SETTINGS.consumeClick()) {
         Minecraft minecraft = Minecraft.getInstance();
         if (minecraft.screen == null) {
            minecraft.setScreen(new RadioSettingsScreen(null));
         }
      }

      DroneControl.tick();
   }

   @SubscribeEvent
   public static void onRenderFrame(Pre event) {
      DroneFeedFreeze.newFrame();
      if (DroneControl.isActive()) {
         RadioInput.sampleFrame();
      }
   }

   @SubscribeEvent
   public static void onClientTickPre(net.neoforged.neoforge.client.event.ClientTickEvent.Pre event) {
      if (DroneControl.holdsTheScreen()) {
         Minecraft minecraft = Minecraft.getInstance();

         while (minecraft.options.keyDrop.consumeClick()) {
         }
      }

      if (DroneControl.isActive()) {
         Minecraft minecraft = Minecraft.getInstance();

         while (minecraft.options.keyTogglePerspective.consumeClick()) {
         }

         if (minecraft.options.getCameraType() != CameraType.FIRST_PERSON) {
            minecraft.options.setCameraType(CameraType.FIRST_PERSON);
         }
      }
   }

   @SubscribeEvent
   public static void onScreenOpening(Opening event) {
      if (DroneControl.holdsTheScreen()) {
         Screen screen = event.getNewScreen();
         if (screen instanceof ChatScreen || screen instanceof InventoryScreen || screen instanceof CreativeModeInventoryScreen) {
            event.setCanceled(true);
         }
      }
   }

   @SubscribeEvent
   public static void onMovementInput(MovementInputUpdateEvent event) {
      if (DroneControl.holdsTheScreen()) {
         Input input = event.getInput();
         input.forwardImpulse = 0.0F;
         input.leftImpulse = 0.0F;
         input.up = false;
         input.down = false;
         input.left = false;
         input.right = false;
         input.jumping = false;
         input.shiftKeyDown = false;
      }
   }

   @SubscribeEvent
   public static void onInteractionKey(InteractionKeyMappingTriggered event) {
      if (DroneControl.holdsTheScreen()) {
         event.setSwingHand(false);
         event.setCanceled(true);
         if (DroneControl.isFpvStatic()) {
            if (event.isUseItem()) {
               DroneControl.endHeldPicture();
            }
         } else {
            if (event.isUseItem()) {
               DroneControl.requestStop();
            }
         }
      }
   }

   @SubscribeEvent
   public static void onScroll(MouseScrollingEvent event) {
      if (DroneControl.isActive()) {
         DroneEntity drone = DroneControl.drone();
         if (drone != null && !drone.hasCameraZoom()) {
            DroneControl.scrollCameraPitch(event.getScrollDeltaY());
         } else {
            DroneControl.addZoom(event.getScrollDeltaY());
         }

         event.setCanceled(true);
      }
   }

   @SubscribeEvent
   public static void onCameraAngles(ComputeCameraAngles event) {
      DroneEntity drone = DroneControl.drone();
      if (drone != null) {
         float partialTick = (float)event.getPartialTick();
         if (DroneControl.onSticks() && drone instanceof InterceptorDroneEntity interceptor) {
            float[] camera = interceptor.cameraAngles(partialTick, DroneControl.cameraTilt());
            event.setYaw(camera[0]);
            event.setPitch(camera[1]);
            event.setRoll(camera[2]);
         } else {
            float roll = drone.bodyRoll(partialTick);
            if (roll != 0.0F) {
               event.setRoll(RateModeFlight.cameraRoll(roll) * 0.5F);
            }
         }
      }
   }

   @SubscribeEvent
   public static void onComputeFov(ComputeFov event) {
      if (DroneControl.isActive()) {
         double lens = DroneControl.zoom();
         if (event.usedConfiguredFov()) {
            DroneControl.easeZoom();
            lens = DroneControl.zoom();
            DroneEntity drone = DroneControl.drone();
            if (drone != null && drone.osdStyle() == DroneEntity.Osd.CAMERA) {
               lens *= 1.1F;
            }
         }

         event.setFOV(event.getFOV() / lens);
      }
   }

   @SubscribeEvent
   public static void onRenderHand(RenderHandEvent event) {
      if (DroneControl.holdsTheScreen()) {
         event.setCanceled(true);
      }
   }

   @SubscribeEvent
   public static void onRenderGuiPre(net.neoforged.neoforge.client.event.RenderGuiEvent.Pre event) {
      FpvCockpitView.render(event.getPartialTick().getGameTimeDeltaPartialTick(false));
      if (DroneControl.isActive() && IrisCompat.shaderPackInUse()) {
         ThermalPackPass.render(event.getPartialTick().getGameTimeDeltaPartialTick(false));
      }
   }

   @SubscribeEvent
   public static void onRenderGui(net.neoforged.neoforge.client.event.RenderGuiEvent.Post event) {
      if (DroneControl.isActive() || DroneControl.isFpvStatic()) {
         CAMERA_OSD.render(event.getGuiGraphics(), event.getPartialTick());
         FPV_OSD.render(event.getGuiGraphics(), event.getPartialTick());
      }
   }

   @SubscribeEvent
   public static void onRenderGuiLayer(net.neoforged.neoforge.client.event.RenderGuiLayerEvent.Pre event) {
      if ((DroneControl.isActive() || DroneControl.isFpvStatic()) && HIDDEN_WHILE_FLYING.contains(event.getName())) {
         event.setCanceled(true);
      }
   }

   @SubscribeEvent
   public static void onRenderLevelStage(RenderLevelStageEvent event) {
      if (event.getStage() == Stage.AFTER_WEATHER && IrisCompat.shaderPackInUse()) {
         ThermalPackPass.capture(event);
      } else {
         if (event.getStage() == Stage.AFTER_WEATHER) {
            float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(false);
            ThermalHeatRenderer.render(event.getPoseStack(), event.getCamera(), partialTick);
            ThermalScreenPass.render(partialTick);
         }
      }
   }

   @SubscribeEvent
   public static void onEntityJoin(EntityJoinLevelEvent event) {
      if (event.getLevel().isClientSide && event.getEntity() instanceof DroneEntity drone && drone.hasEngineSound()) {
         Minecraft.getInstance()
            .getSoundManager()
            .play((SoundInstance)(drone.requiresArming() ? new InterceptorSoundInstance(drone) : new DroneSoundInstance(drone)));
      }
   }

   @SubscribeEvent
   public static void onLoggingOut(LoggingOut event) {
      DroneControl.stop();
      DroneTuning.clear();
   }

   private DroneClientEvents() {
   }
}
