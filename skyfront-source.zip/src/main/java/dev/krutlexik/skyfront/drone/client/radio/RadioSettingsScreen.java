package dev.krutlexik.skyfront.drone.client.radio;

import dev.krutlexik.skyfront.client.gui.ConsoleStyle;
import dev.krutlexik.skyfront.client.gui.TerminalButton;
import dev.krutlexik.skyfront.drone.radio.RadioProfile;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button.OnPress;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import org.jetbrains.annotations.Nullable;

public final class RadioSettingsScreen extends Screen {
   @Nullable
   private final Screen parent;
   private RadioSettingsScreen.Tab tab = RadioSettingsScreen.Tab.DEVICE;
   private RadioSettingsScreen.Mode mode = RadioSettingsScreen.Mode.NORMAL;
   @Nullable
   private RadioProfile.Detection detection;
   @Nullable
   private Consumer<RadioProfile.Found> onFound;
   private Component prompt = Component.empty();
   @Nullable
   private RadioProfile.Capture capture;
   private int left;
   private int top;
   private int panelWidth;
   private int panelHeight;
   private int labelWidth;
   private static final int PAD = 12;
   private static final int ROW = 24;
   private static final int GAP = 3;
   private static final int BEZEL = 3;
   private static final int LABEL = -1909052;
   private static final int LABEL_DIM = -6514044;
   private static final int CALIBRATE_W = 88;
   private static final int[] DEADBANDS = new int[]{0, 1, 2, 3, 5, 8, 10, 15};
   private static final String[] STICK_LABELS = new String[]{
      "gui.sfw.radio.channel.roll", "gui.sfw.radio.channel.pitch", "gui.sfw.radio.channel.yaw", "gui.sfw.radio.channel.throttle", "gui.sfw.radio.controller"
   };
   private static final int AXIS_W = 50;
   private static final int REVERSE_W = 76;
   private static final int DETECT_W = 68;
   private static final String[] AUX_LABELS = new String[]{
      "gui.sfw.radio.aux.arm", "gui.sfw.radio.aux.thermal", "gui.sfw.radio.aux.camera", "gui.sfw.radio.aux.self_destruct"
   };
   private static final int STATE_W = 34;
   private static final int AUX_DETECT_W = 68;
   private static final int AUX_REVERSE_W = 76;
   private static final int AUX_MODE_W = 52;
   private static final int AUX_CLEAR_W = 40;

   public RadioSettingsScreen(@Nullable Screen parent) {
      super(Component.translatable("gui.sfw.radio.title"));
      this.parent = parent;
   }

   private static RadioProfile profile() {
      return RadioInput.profile();
   }

   protected void init() {
      this.panelWidth = Math.min(440, this.width - 16);
      this.panelHeight = Math.min(258, this.height - 8);
      this.left = (this.width - this.panelWidth) / 2;
      this.top = Math.max(4, (this.height - this.panelHeight) / 2);
      if (this.mode != RadioSettingsScreen.Mode.NORMAL) {
         this.initOverlay();
      } else {
         int tabWidth = (this.innerWidth() - 6) / 3;
         int tabY = this.top + 22;
         this.addTab(RadioSettingsScreen.Tab.DEVICE, "gui.sfw.radio.tab.device", this.left + 12, tabY, tabWidth);
         this.addTab(RadioSettingsScreen.Tab.STICKS, "gui.sfw.radio.tab.sticks", this.left + 12 + tabWidth + 3, tabY, tabWidth);
         this.addTab(
            RadioSettingsScreen.Tab.SWITCHES, "gui.sfw.radio.tab.switches", this.left + 12 + 2 * (tabWidth + 3), tabY, this.innerWidth() - 2 * (tabWidth + 3)
         );
         switch (this.tab) {
            case DEVICE:
               this.initDevice();
               break;
            case STICKS:
               this.initSticks();
               break;
            case SWITCHES:
               this.initSwitches();
         }

         int doneWidth = 100;
         this.addRenderableWidget(
            key(
               Component.translatable("gui.sfw.radio.done"),
               this.left + (this.panelWidth - doneWidth) / 2,
               this.bottomRowY(),
               doneWidth,
               button -> this.onClose()
            )
         );
      }
   }

   private void addTab(RadioSettingsScreen.Tab which, String key, int x, int y, int width) {
      this.addRenderableWidget(key(Component.translatable(key), x, y, width, b -> {
         if (this.tab != which) {
            this.tab = which;
            this.rebuildWidgets();
         }
      }).style(this.tab == which ? TerminalButton.Style.LIT : TerminalButton.Style.KEY));
   }

   private static TerminalButton key(Component label, int x, int y, int width, OnPress onPress) {
      return new TerminalButton(x, y, width, 20, label, onPress);
   }

   private int contentTop() {
      return this.top + 50;
   }

   private int innerWidth() {
      return this.panelWidth - 24;
   }

   private int bottom() {
      return this.top + this.panelHeight;
   }

   private int bottomRowY() {
      return this.bottom() - 28;
   }

   private int contentBottom() {
      return this.bottomRowY() - 5 - 3;
   }

   private int widest(String... keys) {
      int widest = 0;

      for (String key : keys) {
         widest = Math.max(widest, this.font.width(Component.translatable(key)));
      }

      return widest;
   }

   private void initDevice() {
      int x = this.left + 12;
      int y = this.contentTop();
      int half = (this.innerWidth() - 3) / 2;
      this.addRenderableWidget(key(this.enabledLabel(), x, y, half, button -> {
         profile().enabled = !profile().enabled;
         this.rebuildWidgets();
      }).style(profile().enabled ? TerminalButton.Style.LIT : TerminalButton.Style.KEY));
      this.addRenderableWidget(key(this.deadbandLabel(), x + half + 3, y, this.innerWidth() - half - 3, button -> {
         this.cycleDeadband();
         this.rebuildWidgets();
      }));
      this.addRenderableWidget(key(this.deviceLabel(), x, y + 24, this.innerWidth() - 88 - 3, button -> {
         this.cycleDevice();
         this.rebuildWidgets();
      }));
      this.addRenderableWidget(key(Component.translatable("gui.sfw.radio.calibrate"), x + this.innerWidth() - 88, y + 24, 88, button -> {
         this.capture = new RadioProfile.Capture();
         this.mode = RadioSettingsScreen.Mode.SWEEP;
         this.rebuildWidgets();
      }));
   }

   private int[] deviceScreen() {
      return new int[]{this.left + 12 + 3, this.contentTop() + 48 + 2 + 3, this.left + this.panelWidth - 12 - 3, this.contentBottom()};
   }

   private Component enabledLabel() {
      return Component.translatable("gui.sfw.radio.enabled", new Object[]{onOff(profile().enabled)});
   }

   private Component deviceLabel() {
      RadioProfile setup = profile();
      return setup.deviceName.isEmpty()
         ? Component.translatable(
            "gui.sfw.radio.device",
            new Object[]{Component.translatable(RadioInput.devices().isEmpty() ? "gui.sfw.radio.device.nothing" : "gui.sfw.radio.device.none")}
         )
         : Component.translatable("gui.sfw.radio.device", new Object[]{setup.deviceName});
   }

   private void cycleDevice() {
      List<RadioInput.Device> devices = RadioInput.devices();
      if (!devices.isEmpty()) {
         RadioProfile setup = profile();
         int current = -1;

         for (int i = 0; i < devices.size(); i++) {
            RadioInput.Device device = devices.get(i);
            if (device.guid().equals(setup.deviceGuid) && device.name().equals(setup.deviceName)) {
               current = i;
               break;
            }
         }

         RadioInput.select(devices.get((current + 1) % devices.size()));
      }
   }

   private Component deadbandLabel() {
      return Component.translatable("gui.sfw.radio.deadband", new Object[]{Math.round(profile().deadband * 100.0F)});
   }

   private void cycleDeadband() {
      int now = Math.round(profile().deadband * 100.0F);
      int next = DEADBANDS[0];

      for (int step : DEADBANDS) {
         if (step > now) {
            next = step;
            break;
         }
      }

      profile().deadband = next / 100.0F;
   }

   private void initSticks() {
      RadioProfile setup = profile();
      this.labelWidth = this.widest(STICK_LABELS) + 10;
      int y = this.contentTop();
      this.addChannelRow(y, setup.roll, "gui.sfw.radio.prompt.roll");
      this.addChannelRow(y + 24, setup.pitch, "gui.sfw.radio.prompt.pitch");
      this.addChannelRow(y + 48, setup.yaw, "gui.sfw.radio.prompt.yaw");
      this.addChannelRow(y + 72, setup.throttle, "gui.sfw.radio.prompt.throttle");
      this.addRenderableWidget(key(controllerLabel(), this.left + 12 + this.labelWidth, y + 96, 200, button -> {
         profile().gamepad = !profile().gamepad;
         this.rebuildWidgets();
      }).style(profile().gamepad ? TerminalButton.Style.LIT : TerminalButton.Style.KEY));
   }

   private static Component controllerLabel() {
      return Component.translatable(profile().gamepad ? "gui.sfw.radio.controller.gamepad" : "gui.sfw.radio.controller.radio");
   }

   private int stickRowsEnd() {
      return this.left + 12 + this.labelWidth + 50 + 76 + 68 + 6;
   }

   private void addChannelRow(int y, RadioProfile.Channel channel, String promptKey) {
      int x = this.left + 12 + this.labelWidth;
      this.addRenderableWidget(key(Component.translatable("gui.sfw.radio.axis", new Object[]{channel.axis + 1}), x, y, 50, button -> {
         int count = Math.max(RadioInput.axes().length, 8);
         channel.axis = (channel.axis + 1) % count;
         this.rebuildWidgets();
      }));
      x += 53;
      this.addRenderableWidget(key(reverseLabel(channel.reverse), x, y, 76, button -> {
         channel.reverse = !channel.reverse;
         this.rebuildWidgets();
      }).style(channel.reverse ? TerminalButton.Style.LIT : TerminalButton.Style.KEY));
      x += 79;
      this.addRenderableWidget(
         key(Component.translatable("gui.sfw.radio.detect"), x, y, 68, button -> this.beginDetect(Component.translatable(promptKey), false, found -> {
            channel.axis = found.index();
            channel.reverse = found.reverse();
         }))
      );
   }

   private static Component reverseLabel(boolean reverse) {
      return Component.translatable("gui.sfw.radio.reverse", new Object[]{Component.translatable(reverse ? "gui.sfw.radio.yes" : "gui.sfw.radio.no")});
   }

   private void initSwitches() {
      RadioProfile setup = profile();
      this.labelWidth = Math.max(
            this.widest(AUX_LABELS),
            Math.max(this.font.width(Component.translatable("gui.sfw.radio.button", new Object[]{32})), this.widest("gui.sfw.radio.unassigned"))
         )
         + 10;
      int y = this.contentTop();
      this.addAuxRow(y, setup.arm, "gui.sfw.radio.prompt.switch", true);
      this.addAuxRow(y + 24, setup.thermal, "gui.sfw.radio.prompt.switch", true);
      this.addAuxRow(y + 48, setup.camera, "gui.sfw.radio.prompt.camera", false);
      this.addAuxRow(y + 72, setup.selfDestruct, "gui.sfw.radio.prompt.switch", false);
   }

   private int auxKeysX() {
      return this.left + this.panelWidth - 12 - 245;
   }

   private int stateX() {
      return Math.max(this.left + 12 + this.labelWidth + 3, this.auxKeysX() - 6 - 3 - 34);
   }

   private void addAuxRow(int y, RadioProfile.Aux aux, String promptKey, boolean hasMode) {
      int x = Math.max(this.auxKeysX(), this.stateX() + 34 + 3 + 6);
      this.addRenderableWidget(
         key(Component.translatable("gui.sfw.radio.detect"), x, y, 68, button -> this.beginDetect(Component.translatable(promptKey), hasMode, found -> {
            aux.source = found.source();
            aux.index = found.index();
            aux.reverse = found.reverse();
         }))
      );
      x += 71;
      TerminalButton reverse = key(reverseLabel(aux.reverse), x, y, 76, button -> {
         aux.reverse = !aux.reverse;
         this.rebuildWidgets();
      }).style(aux.reverse ? TerminalButton.Style.LIT : TerminalButton.Style.KEY);
      reverse.active = aux.assigned();
      this.addRenderableWidget(reverse);
      x += 79;
      if (hasMode) {
         TerminalButton modeButton = key(
            Component.translatable(aux.mode == RadioProfile.AuxMode.SWITCH ? "gui.sfw.radio.mode.switch" : "gui.sfw.radio.mode.button"), x, y, 52, button -> {
               aux.mode = aux.mode == RadioProfile.AuxMode.SWITCH ? RadioProfile.AuxMode.BUTTON : RadioProfile.AuxMode.SWITCH;
               this.rebuildWidgets();
            }
         );
         modeButton.active = aux.assigned();
         this.addRenderableWidget(modeButton);
      }

      x += 55;
      TerminalButton clear = key(Component.translatable("gui.sfw.radio.clear"), x, y, 40, button -> {
         aux.source = RadioProfile.Source.NONE;
         this.rebuildWidgets();
      });
      clear.active = aux.assigned();
      this.addRenderableWidget(clear);
   }

   private int[] helpScreen() {
      int rows = this.tab == RadioSettingsScreen.Tab.STICKS ? 5 : 4;
      return new int[]{this.left + 12 + 3, this.contentTop() + rows * 24 + 2 + 3, this.left + this.panelWidth - 12 - 3, this.contentBottom()};
   }

   private void beginDetect(Component prompt, boolean acceptButtons, Consumer<RadioProfile.Found> then) {
      RadioInput.poll();
      this.detection = new RadioProfile.Detection(RadioInput.axes(), RadioInput.buttons(), acceptButtons);
      this.onFound = then;
      this.prompt = prompt;
      this.mode = RadioSettingsScreen.Mode.DETECT;
      this.rebuildWidgets();
   }

   private void initOverlay() {
      int width = 100;
      int y = this.bottomRowY();
      int centre = this.left + this.panelWidth / 2;
      switch (this.mode) {
         case DETECT:
            this.addRenderableWidget(key(Component.translatable("gui.sfw.radio.cancel"), centre - width / 2, y, width, button -> this.backToNormal()));
            break;
         case SWEEP:
            this.addRenderableWidget(key(Component.translatable("gui.sfw.radio.cancel"), centre - width - 3, y, width, button -> this.backToNormal()));
            this.addRenderableWidget(key(Component.translatable("gui.sfw.radio.next"), centre + 3, y, width, button -> {
               this.mode = RadioSettingsScreen.Mode.CENTRE;
               this.rebuildWidgets();
            }).style(TerminalButton.Style.LIT));
            break;
         case CENTRE:
            this.addRenderableWidget(key(Component.translatable("gui.sfw.radio.cancel"), centre - width - 3, y, width, button -> this.backToNormal()));
            this.addRenderableWidget(key(Component.translatable("gui.sfw.radio.done"), centre + 3, y, width, button -> {
               if (this.capture != null) {
                  RadioInput.poll();
                  profile().calibration = this.capture.finish(RadioInput.axes());
               }

               this.backToNormal();
            }).style(TerminalButton.Style.LIT));
      }
   }

   private void backToNormal() {
      this.mode = RadioSettingsScreen.Mode.NORMAL;
      this.detection = null;
      this.onFound = null;
      this.capture = null;
      this.rebuildWidgets();
   }

   public void tick() {
      super.tick();
      RadioInput.poll();
      switch (this.mode) {
         case DETECT:
            if (this.detection != null) {
               RadioProfile.Found found = this.detection.poll(RadioInput.axes(), RadioInput.buttons());
               if (found != null && this.onFound != null) {
                  this.onFound.accept(found);
                  this.backToNormal();
               }
            }
            break;
         case SWEEP:
         case CENTRE:
            if (this.capture != null) {
               this.capture.accumulate(RadioInput.axes());
            }
      }
   }

   public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
      super.renderBackground(graphics, mouseX, mouseY, partialTick);
      int right = this.left + this.panelWidth;
      ConsoleStyle.panel(graphics, this.left, this.top, right, this.bottom());
      ConsoleStyle.plate(graphics, this.font, this.left + this.panelWidth / 2, this.top + 6, this.title);
      boolean connected = RadioInput.connected();
      ConsoleStyle.lamps(graphics, this.left + 12, this.bottom() - 15, connected ? -12788666 : -10872812, profile().enabled ? -1005016 : -10872812);
   }

   public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
      super.render(graphics, mouseX, mouseY, partialTick);
      if (this.mode != RadioSettingsScreen.Mode.NORMAL) {
         this.renderOverlay(graphics);
      } else {
         switch (this.tab) {
            case DEVICE:
               this.renderDevice(graphics);
               break;
            case STICKS:
               this.renderSticks(graphics);
               break;
            case SWITCHES:
               this.renderSwitches(graphics);
         }
      }
   }

   private void renderDevice(GuiGraphics graphics) {
      int[] s = this.deviceScreen();
      ConsoleStyle.crt(graphics, s[0], s[1], s[2], s[3]);
      int x = s[0] + 6;
      int y = s[1] + 5;
      boolean connected = RadioInput.connected();
      graphics.drawString(
         this.font,
         Component.translatable(connected ? "gui.sfw.radio.status.connected" : "gui.sfw.radio.status.missing"),
         x,
         y,
         connected ? -8853886 : -20420,
         false
      );
      if (!connected) {
         this.wrap(graphics, Component.translatable("gui.sfw.radio.help.connect"), x, y + 14, s[2] - s[0] - 12, -12541880);
      } else {
         RadioProfile setup = profile();
         float[] axes = RadioInput.axes();
         int gimbalTop = y + 14;
         int size = Math.min(64, s[3] - gimbalTop - 14);
         int gx = x + 4;
         this.gimbal(
            graphics, gx, gimbalTop, size, setup.stick(setup.yaw, axes), setup.throttleStick(axes), Component.translatable("gui.sfw.radio.gimbal.left")
         );
         this.gimbal(
            graphics,
            gx + size + 14,
            gimbalTop,
            size,
            setup.stick(setup.roll, axes),
            setup.stick(setup.pitch, axes),
            Component.translatable("gui.sfw.radio.gimbal.right")
         );
         int sliderX = gx + 2 * size + 14 + 20;
         graphics.drawString(this.font, Component.translatable("gui.sfw.radio.axes"), sliderX, y, -12541880, false);
         int shown = 0;
         int maxSliders = Math.max(0, (s[2] - 70 - sliderX) / 14);

         for (int i = 0; i < Math.min(axes.length, 16) && shown < maxSliders; i++) {
            if (i != setup.roll.axis && i != setup.pitch.axis && i != setup.yaw.axis && i != setup.throttle.axis) {
               this.slider(graphics, sliderX + shown * 14, gimbalTop, size, axes[i], i + 1);
               shown++;
            }
         }

         boolean[] buttons = RadioInput.buttons();
         int lampX = s[2] - 62;
         graphics.drawString(this.font, Component.translatable("gui.sfw.radio.buttons"), lampX, y, -12541880, false);
         int perRow = 8;
         int rows = Math.max(1, Math.min(4, (size + 4) / 9));

         for (int ix = 0; ix < Math.min(buttons.length, perRow * rows); ix++) {
            int lx = lampX + ix % perRow * 7;
            int ly = gimbalTop + ix / perRow * 9;
            graphics.fill(lx, ly, lx + 5, ly + 5, -16644092);
            graphics.fill(lx + 1, ly + 1, lx + 4, ly + 4, buttons[ix] ? -8853886 : -15318500);
         }
      }
   }

   private void renderSticks(GuiGraphics graphics) {
      RadioProfile setup = profile();
      float[] axes = RadioInput.axes();
      int y = this.contentTop();

      for (int i = 0; i < STICK_LABELS.length; i++) {
         graphics.drawString(this.font, Component.translatable(STICK_LABELS[i]), this.left + 12, y + i * 24 + 6, -1909052);
      }

      int x0 = this.stickRowsEnd() + 8 + 3;
      int x1 = this.left + this.panelWidth - 12 - 3;
      int y0 = y + 3;
      int y1 = y + 120 - 4 - 3;
      ConsoleStyle.crt(graphics, x0, y0, x1, y1);
      int size = Math.max(16, Math.min(y1 - y0 - 16, (x1 - x0 - 18) / 2));
      int spare = x1 - x0 - 2 * size - 10;
      int gx = x0 + spare / 2;
      int gy = y0 + Math.max(4, (y1 - y0 - size - 12) / 2);
      this.gimbal(graphics, gx, gy, size, setup.stick(setup.yaw, axes), setup.throttleStick(axes), Component.translatable("gui.sfw.radio.gimbal.left"));
      this.gimbal(
         graphics,
         gx + size + 10,
         gy,
         size,
         setup.stick(setup.roll, axes),
         setup.stick(setup.pitch, axes),
         Component.translatable("gui.sfw.radio.gimbal.right")
      );
      this.help(graphics, RadioInput.connected() ? "gui.sfw.radio.help.sticks" : "gui.sfw.radio.help.nodevice");
   }

   private void renderSwitches(GuiGraphics graphics) {
      RadioProfile setup = profile();
      float[] axes = RadioInput.axes();
      boolean[] buttons = RadioInput.buttons();
      int y = this.contentTop();
      RadioProfile.Aux[] slots = new RadioProfile.Aux[]{setup.arm, setup.thermal, setup.camera, setup.selfDestruct};

      for (int i = 0; i < slots.length; i++) {
         int rowY = y + i * 24;
         RadioProfile.Aux aux = slots[i];
         graphics.drawString(this.font, Component.translatable(AUX_LABELS[i]), this.left + 12, rowY + 1, -1909052);
         Component where = !aux.assigned()
            ? Component.translatable("gui.sfw.radio.unassigned")
            : Component.translatable(aux.source == RadioProfile.Source.AXIS ? "gui.sfw.radio.axis" : "gui.sfw.radio.button", new Object[]{aux.index + 1});
         graphics.drawString(this.font, where, this.left + 12, rowY + 11, -6514044, false);
         int sx = this.stateX();
         ConsoleStyle.lcd(graphics, sx, rowY + 4, sx + 34, rowY + 16);
         String state;
         int colour;
         if (!aux.assigned()) {
            state = "—";
            colour = -6657496;
         } else if (aux == setup.camera) {
            state = Math.round(setup.auxLevel(aux, axes) * 90.0F) + "°";
            colour = -20420;
         } else {
            boolean on = setup.auxOn(aux, axes, buttons);
            state = onOff(on).getString();
            colour = on ? -20420 : -6657496;
         }

         graphics.drawCenteredString(this.font, state, sx + 17, rowY + 6, colour);
      }

      this.help(graphics, RadioInput.connected() ? "gui.sfw.radio.help.switches" : "gui.sfw.radio.help.nodevice");
   }

   private void help(GuiGraphics graphics, String key) {
      int[] s = this.helpScreen();
      if (s[3] - s[1] >= 12) {
         ConsoleStyle.crt(graphics, s[0], s[1], s[2], s[3]);
         this.wrap(graphics, Component.translatable(key), s[0] + 5, s[1] + 4, s[2] - s[0] - 10, -12541880, (s[3] - s[1] - 4) / 10);
      }
   }

   private void renderOverlay(GuiGraphics graphics) {
      int x0 = this.left + 12 + 3;
      int x1 = this.left + this.panelWidth - 12 - 3;
      int y0 = this.top + 24 + 3;
      int y1 = this.contentBottom();
      ConsoleStyle.crt(graphics, x0, y0, x1, y1);
      int centre = (x0 + x1) / 2;
      int y = y0 + 8;
      Component heading;
      Component body;
      switch (this.mode) {
         case DETECT:
            heading = Component.translatable("gui.sfw.radio.detect");
            body = this.prompt;
            break;
         case SWEEP:
            heading = Component.translatable("gui.sfw.radio.calibrate");
            body = Component.translatable("gui.sfw.radio.calibrate.sweep");
            break;
         default:
            heading = Component.translatable("gui.sfw.radio.calibrate");
            body = Component.translatable("gui.sfw.radio.calibrate.centre");
      }

      this.centred(graphics, heading, centre, y, -8853886);
      List<FormattedCharSequence> lines = this.font.split(body, x1 - x0 - 24);

      for (int i = 0; i < lines.size(); i++) {
         graphics.drawString(this.font, lines.get(i), centre - this.font.width(lines.get(i)) / 2, y + 16 + i * 11, -12541880, false);
      }

      int readoutY = y + 16 + lines.size() * 11 + 10;
      if (!RadioInput.connected()) {
         this.centred(graphics, Component.translatable("gui.sfw.radio.status.missing"), centre, readoutY, -20420);
      } else if (this.mode == RadioSettingsScreen.Mode.DETECT) {
         if (System.currentTimeMillis() / 500L % 2L == 0L) {
            this.centred(graphics, Component.translatable("gui.sfw.radio.waiting"), centre, readoutY, -12541880);
         }
      } else {
         if (this.capture != null) {
            float[] axes = RadioInput.axes();
            int shown = Math.min(axes.length, 8);
            int width = 30;
            int total = shown * width + (shown - 1) * 3;
            int x = centre - total / 2;

            for (int i = 0; i < shown; i++) {
               float travel = Math.min(1.0F, this.capture.travel(i) / 2.0F);
               this.centred(graphics, Component.literal(String.valueOf(i + 1)), x + width / 2, readoutY, -12541880);
               spanBar(graphics, x, readoutY + 11, width, 6, travel);
               x += width + 3;
            }
         }
      }
   }

   private void gimbal(GuiGraphics graphics, int x, int y, int size, float stickX, float stickY, Component caption) {
      int x1 = x + size;
      int y1 = y + size;
      int cx = x + size / 2;
      int cy = y + size / 2;
      graphics.fill(x, y, x1, y1, 805306368);
      graphics.fill(x, y, x1, y + 1, -15318500);
      graphics.fill(x, y1 - 1, x1, y1, -15318500);
      graphics.fill(x, y, x + 1, y1, -15318500);
      graphics.fill(x1 - 1, y, x1, y1, -15318500);
      graphics.fill(x + 1, cy, x1 - 1, cy + 1, -15318500);
      graphics.fill(cx, y + 1, cx + 1, y1 - 1, -15318500);

      for (int k = 1; k < 4; k++) {
         if (k != 2) {
            int tx = x + size * k / 4;
            int ty = y + size * k / 4;
            graphics.fill(tx, cy - 2, tx + 1, cy + 3, -15318500);
            graphics.fill(cx - 2, ty, cx + 3, ty + 1, -15318500);
         }
      }

      int reach = size / 2 - 3;
      int dx = cx + Math.round(clamp(stickX) * reach);
      int dy = cy - Math.round(clamp(stickY) * reach);
      int steps = Math.max(Math.abs(dx - cx), Math.abs(dy - cy));

      for (int kx = 0; kx < steps; kx++) {
         int px = cx + Math.round((float)(dx - cx) * kx / steps);
         int py = cy + Math.round((float)(dy - cy) * kx / steps);
         graphics.fill(px, py, px + 1, py + 1, -12541880);
      }

      graphics.fill(dx - 2, dy - 1, dx + 3, dy + 2, -12541880);
      graphics.fill(dx - 1, dy - 2, dx + 2, dy + 3, -12541880);
      graphics.fill(dx - 1, dy - 1, dx + 2, dy + 2, -8853886);
      int captionWidth = this.font.width(caption);
      if (captionWidth <= size + 10) {
         graphics.drawString(this.font, caption, cx - captionWidth / 2, y1 + 3, -12541880, false);
      }
   }

   private void slider(GuiGraphics graphics, int x, int y, int height, float value, int number) {
      int cx = x + 3;
      graphics.fill(cx - 1, y, cx + 2, y + height, -15318500);
      graphics.fill(cx, y + 1, cx + 1, y + height - 1, -16644092);
      int at = y + height / 2 - Math.round(clamp(value) * (height / 2.0F - 2.0F));
      graphics.fill(cx - 3, at - 1, cx + 4, at + 2, -8853886);
      String label = String.valueOf(number);
      graphics.drawString(this.font, label, cx - this.font.width(label) / 2 + 1, y + height + 3, -12541880, false);
   }

   private static void spanBar(GuiGraphics graphics, int x, int y, int width, int height, float value) {
      graphics.fill(x, y, x + width, y + height, -15318500);
      int reach = Math.round(Math.max(0.0F, Math.min(1.0F, value)) * width);
      if (reach > 0) {
         graphics.fill(x, y, x + reach, y + height, -8853886);
      }
   }

   private static float clamp(float value) {
      return Math.max(-1.0F, Math.min(1.0F, value));
   }

   private void centred(GuiGraphics graphics, Component text, int centre, int y, int colour) {
      graphics.drawString(this.font, text, centre - this.font.width(text) / 2, y, colour, false);
   }

   private void wrap(GuiGraphics graphics, Component text, int x, int y, int width, int colour) {
      this.wrap(graphics, text, x, y, width, colour, Integer.MAX_VALUE);
   }

   private void wrap(GuiGraphics graphics, Component text, int x, int y, int width, int colour, int maxLines) {
      List<FormattedCharSequence> lines = this.font.split(text, width);

      for (int i = 0; i < Math.min(lines.size(), maxLines); i++) {
         graphics.drawString(this.font, lines.get(i), x, y + i * 10, colour, false);
      }
   }

   private static Component onOff(boolean on) {
      return Component.translatable(on ? "gui.sfw.radio.on" : "gui.sfw.radio.off");
   }

   public void onClose() {
      RadioInput.save();
      RadioInput.rebaseline();
      if (this.minecraft != null) {
         this.minecraft.setScreen(this.parent);
      }
   }

   private static enum Mode {
      NORMAL,
      DETECT,
      SWEEP,
      CENTRE;
   }

   private static enum Tab {
      DEVICE,
      STICKS,
      SWITCHES;
   }
}
