package dev.krutlexik.skyfront.drone;

import net.minecraft.util.Mth;

public final class FpvPack {
   public static final double CELL_FULL = 4.2;
   public static final double CELL_LOW = 3.5;
   public static final double CELL_LAND = 3.0;
   public static final double CELL_CUTOFF = 2.75;
   public static final double CELL_EMPTY = 2.6;
   private static final double[][] CELL_CURVE = new double[][]{
      {0.0, 2.6}, {0.03, 2.75}, {0.06, 2.88}, {0.1, 3.0}, {0.25, 3.2}, {0.475, 3.5}, {0.7, 3.8}, {0.85, 4.0}, {1.0, 4.2}
   };
   private static final double FADE_AT_CUTOFF = 0.45;
   private static final double FADE_AT_EMPTY = 0.0;

   public static double openCircuitCellVolts(float charge) {
      double soc = Mth.clamp(charge, 0.0F, 1.0F);

      for (int i = 1; i < CELL_CURVE.length; i++) {
         if (soc <= CELL_CURVE[i][0]) {
            double span = CELL_CURVE[i][0] - CELL_CURVE[i - 1][0];
            double factor = span > 0.0 ? (soc - CELL_CURVE[i - 1][0]) / span : 0.0;
            return Mth.lerp(factor, CELL_CURVE[i - 1][1], CELL_CURVE[i][1]);
         }
      }

      return CELL_CURVE[CELL_CURVE.length - 1][1];
   }

   public static float powerFade(double cellVolts) {
      if (cellVolts >= 3.0) {
         return 1.0F;
      } else if (cellVolts >= 2.75) {
         double through = (3.0 - cellVolts) / 0.25;
         return (float)Mth.lerp(Mth.clamp(through, 0.0, 1.0), 1.0, 0.45);
      } else {
         double through = (2.75 - cellVolts) / 0.1499999999999999;
         return (float)Mth.lerp(Mth.clamp(through, 0.0, 1.0), 0.45, 0.0);
      }
   }

   private FpvPack() {
   }
}
