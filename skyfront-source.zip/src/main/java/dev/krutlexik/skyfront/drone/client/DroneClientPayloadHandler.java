package dev.krutlexik.skyfront.drone.client;

import dev.krutlexik.skyfront.drone.DroneTuning;
import dev.krutlexik.skyfront.drone.entity.DroneEntity;
import dev.krutlexik.skyfront.drone.network.DroneLinkPayload;
import dev.krutlexik.skyfront.drone.network.DroneStatePayload;
import dev.krutlexik.skyfront.drone.network.DroneTuningPayload;
import dev.krutlexik.skyfront.drone.network.StartControlPayload;
import dev.krutlexik.skyfront.drone.network.StopControlPayload;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public final class DroneClientPayloadHandler {
   public static void linkUpdate(DroneLinkPayload payload, IPayloadContext context) {
      context.enqueueWork(() -> DroneControl.acceptLink(payload));
   }

   public static void droneState(DroneStatePayload payload, IPayloadContext context) {
      context.enqueueWork(() -> {
         Minecraft minecraft = Minecraft.getInstance();
         if (minecraft.level != null && minecraft.level.getEntity(payload.entityId()) instanceof DroneEntity drone) {
            drone.acceptSnapshot(payload);
         }
      });
   }

   public static void tuning(DroneTuningPayload payload, IPayloadContext context) {
      context.enqueueWork(() -> DroneTuning.acceptFromServer(payload.values()));
   }

   public static void startControl(StartControlPayload payload, IPayloadContext context) {
      context.enqueueWork(() -> DroneControl.start(payload));
   }

   public static void stopControl(StopControlPayload payload, IPayloadContext context) {
      context.enqueueWork(() -> {
         switch (payload.reason()) {
            case OUT_OF_RANGE:
               message("message.sfw.drone.out_of_range");
               DroneControl.beginSignalLoss(DroneSignalLoss.Cause.OUT_OF_RANGE);
               break;
            case DESTROYED:
               message("message.sfw.drone.destroyed");
               DroneControl.beginSignalLoss(DroneSignalLoss.Cause.DESTROYED);
               break;
            case CRASHED:
               DroneControl.beginSignalLoss(DroneSignalLoss.Cause.CRASH);
               break;
            case BATTERY:
               DroneControl.beginSignalLoss(DroneSignalLoss.Cause.OUT_OF_RANGE);
               break;
            default:
               DroneControl.stop();
         }
      });
   }

   private static void message(String key) {
      Minecraft minecraft = Minecraft.getInstance();
      if (minecraft.player != null) {
         minecraft.player.displayClientMessage(Component.translatable(key), true);
      }
   }

   private DroneClientPayloadHandler() {
   }
}
