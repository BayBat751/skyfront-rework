package dev.krutlexik.skyfront.drone.client.render;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.VertexFormat.Mode;
import dev.krutlexik.skyfront.drone.DroneMod;
import dev.krutlexik.skyfront.drone.client.DroneControl;
import dev.krutlexik.skyfront.drone.client.DroneSignalLoss;
import dev.krutlexik.skyfront.drone.client.ThermalVision;
import dev.krutlexik.skyfront.drone.entity.DroneEntity;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource.BufferSource;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.AreaEffectCloud;
import net.minecraft.world.entity.Display;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Marker;
import net.minecraft.world.entity.decoration.HangingEntity;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import org.joml.Vector4f;

public final class ThermalHeatRenderer {
   private static final double REACH = 320.0;
   private static final int HOT = -1;
   private static final int WARM = -3618616;
   private static final float SIGNATURE_HOT = 0.95F;
   private static final float SIGNATURE_WARM = 0.84F;
   private static BufferSource packBuffer;
   private static int warmNear;
   private static long lastReport;
   private static String firstOnScreen = "-";
   static boolean bodyInFront;
   static float bodyNdcX;
   static float bodyNdcY;
   static int bodiesDrawn;
   private static final Set<Integer> IN_SIGHT = new HashSet<>();
   private static long sightTick = Long.MIN_VALUE;

   public static void render(PoseStack poseStack, Camera camera, float partialTick) {
      Minecraft minecraft = Minecraft.getInstance();
      DroneEntity drone = DroneControl.drone();
      if (ThermalVision.isOn() && minecraft.level != null && ThermalVision.isAvailable(drone) && !DroneSignalLoss.isActive()) {
         Vec3 view = camera.getPosition();
         if (!ThermalShaders.loaded()) {
            EntityRenderDispatcher dispatcher = minecraft.getEntityRenderDispatcher();
            BufferSource buffers = minecraft.renderBuffers().bufferSource();
            ThermalHeatRenderer.HeatBuffers heat = new ThermalHeatRenderer.HeatBuffers(buffers.getBuffer(ThermalRenderTypes.HEAT));
            dispatcher.setRenderShadow(false);

            try {
               for (Entity entity : minecraft.level.entitiesForRendering()) {
                  if (entity != drone && entity != minecraft.getCameraEntity() && !entity.isRemoved()) {
                     int warmth = warmthOf(entity);
                     if (warmth != 0 && !(entity.distanceToSqr(view) > 102400.0)) {
                        heat.color = warmth;
                        heat.machine = !(entity instanceof LivingEntity);
                        double x = Mth.lerp(partialTick, entity.xOld, entity.getX()) - view.x;
                        double y = Mth.lerp(partialTick, entity.yOld, entity.getY()) - view.y;
                        double z = Mth.lerp(partialTick, entity.zOld, entity.getZ()) - view.z;
                        float yaw = Mth.lerp(partialTick, entity.yRotO, entity.getYRot());
                        dispatcher.render(entity, x, y, z, yaw, partialTick, poseStack, heat, 15728880);
                     }
                  }
               }
            } finally {
               dispatcher.setRenderShadow(true);
            }

            buffers.endBatch(ThermalRenderTypes.HEAT);
         }
      }
   }

   public static void renderSignatures(PoseStack poseStack, Vec3 view, float partialTick) {
      bodiesDrawn = 0;
      bodyInFront = false;
      Minecraft minecraft = Minecraft.getInstance();
      DroneEntity drone = DroneControl.drone();
      if (minecraft.level != null && ThermalVision.isAvailable(drone) && !DroneSignalLoss.isActive()) {
         refreshSight(minecraft, view);
         EntityRenderDispatcher dispatcher = minecraft.getEntityRenderDispatcher();
         BufferSource buffers = packBuffers();
         ThermalHeatRenderer.HeatBuffers heat = ThermalShaders.mask() != null
            ? new ThermalHeatRenderer.HeatBuffers(buffers)
            : new ThermalHeatRenderer.HeatBuffers(buffers.getBuffer(ThermalRenderTypes.HEAT_MASK));
         int drawn = 0;
         dispatcher.setRenderShadow(false);

         try {
            for (Entity entity : minecraft.level.entitiesForRendering()) {
               if (entity != drone && entity != minecraft.getCameraEntity() && !entity.isRemoved() && IN_SIGHT.contains(entity.getId())) {
                  int warmth = warmthOf(entity);
                  if (warmth != 0) {
                     double x = Mth.lerp(partialTick, entity.xOld, entity.getX()) - view.x;
                     double y = Mth.lerp(partialTick, entity.yOld, entity.getY()) - view.y;
                     double z = Mth.lerp(partialTick, entity.zOld, entity.getZ()) - view.z;
                     heat.heat.grade((float)y, Math.max(0.2F, entity.getBbHeight()), warmth == -1 ? 0.95F : 0.84F);
                     heat.machine = !(entity instanceof LivingEntity);
                     float yaw = Mth.lerp(partialTick, entity.yRotO, entity.getYRot());
                     dispatcher.render(entity, x, y, z, yaw, partialTick, poseStack, heat, 15728880);
                     if (drawn == 0) {
                        Vector4f clip = new Vector4f((float)x, (float)y + entity.getBbHeight() * 0.5F, (float)z, 1.0F);
                        RenderSystem.getModelViewMatrix().transform(clip);
                        RenderSystem.getProjectionMatrix().transform(clip);
                        firstOnScreen = clip.w > 0.0F ? String.format(Locale.ROOT, "(%.2f, %.2f)", clip.x / clip.w, clip.y / clip.w) : "behind the camera";
                        bodyInFront = clip.w > 0.0F;
                        bodyNdcX = bodyInFront ? clip.x / clip.w : 0.0F;
                        bodyNdcY = bodyInFront ? clip.y / clip.w : 0.0F;
                     }

                     drawn++;
                  }
               }
            }
         } finally {
            dispatcher.setRenderShadow(true);
            heat.heat.ungrade();
         }

         buffers.endBatch();
         bodiesDrawn = drawn;
      }
   }

   private static BufferSource packBuffers() {
      if (packBuffer == null) {
         packBuffer = MultiBufferSource.immediate(new ByteBufferBuilder(262144));
      }

      return packBuffer;
   }

   static void report(String probe) {
      lastReport = System.currentTimeMillis();
      DroneMod.LOGGER
         .info(
            "Thermal under a shader pack: {} warm bodies in reach, {} in sight, {} drawn, first at {}{}",
            new Object[]{warmNear, IN_SIGHT.size(), bodiesDrawn, bodiesDrawn > 0 ? firstOnScreen : "-", probe}
         );
   }

   static boolean reportDue() {
      return System.currentTimeMillis() - lastReport >= 5000L;
   }

   private static void refreshSight(Minecraft minecraft, Vec3 view) {
      long tick = minecraft.level.getGameTime();
      if (tick != sightTick) {
         sightTick = tick;
         IN_SIGHT.clear();
         warmNear = 0;
         Entity viewer = minecraft.getCameraEntity();

         for (Entity entity : minecraft.level.entitiesForRendering()) {
            if (entity != viewer && warmthOf(entity) != 0 && !(entity.distanceToSqr(view) > 102400.0)) {
               warmNear++;
               if (inSight(minecraft, view, entity, viewer)) {
                  IN_SIGHT.add(entity.getId());
               }
            }
         }
      }
   }

   private static boolean inSight(Minecraft minecraft, Vec3 eye, Entity entity, @Nullable Entity viewer) {
      AABB box = entity.getBoundingBox();
      Vec3 centre = box.getCenter();

      for (double share : new double[]{0.15, 0.5, 0.9}) {
         Vec3 point = new Vec3(centre.x, box.minY + box.getYsize() * share, centre.z);
         BlockHitResult hit = minecraft.level.clip(new ClipContext(eye, point, Block.COLLIDER, Fluid.NONE, viewer != null ? viewer : entity));
         if (hit.getType() == Type.MISS) {
            return true;
         }
      }

      return false;
   }

   private static int warmthOf(Entity entity) {
      if (entity.isOnFire() || entity instanceof Player) {
         return -1;
      } else if (entity instanceof LivingEntity) {
         return -3618616;
      } else if (!(entity instanceof ItemEntity)
         && !(entity instanceof ExperienceOrb)
         && !(entity instanceof HangingEntity)
         && !(entity instanceof FallingBlockEntity)
         && !(entity instanceof Display)
         && !(entity instanceof Marker)
         && !(entity instanceof AreaEffectCloud)
         && !(entity instanceof AbstractArrow)) {
         return -3618616;
      } else {
         return entity.getPassengers().isEmpty() ? 0 : -3618616;
      }
   }

   private ThermalHeatRenderer() {
   }

   private static final class DiscardVertices implements VertexConsumer {
      public VertexConsumer addVertex(float x, float y, float z) {
         return this;
      }

      public VertexConsumer setColor(int red, int green, int blue, int alpha) {
         return this;
      }

      public VertexConsumer setUv(float u, float v) {
         return this;
      }

      public VertexConsumer setUv1(int u, int v) {
         return this;
      }

      public VertexConsumer setUv2(int u, int v) {
         return this;
      }

      public VertexConsumer setNormal(float x, float y, float z) {
         return this;
      }
   }

   private static final class HeatBuffers implements MultiBufferSource {
      private final ThermalHeatRenderer.HeatVertices heat;
      private final VertexConsumer discard = new ThermalHeatRenderer.DiscardVertices();
      private int color;
      private boolean machine;
      @Nullable
      private final BufferSource textured;

      private HeatBuffers(VertexConsumer target) {
         this.heat = new ThermalHeatRenderer.HeatVertices(target);
         this.textured = null;
      }

      private HeatBuffers(BufferSource textured) {
         this.heat = new ThermalHeatRenderer.HeatVertices(null);
         this.textured = textured;
      }

      public VertexConsumer getBuffer(RenderType type) {
         if (type.mode() == Mode.QUADS && !isText(type) && (!this.machine || isHeatedEntityType(type))) {
            if (this.textured != null) {
               if (type.format() != DefaultVertexFormat.NEW_ENTITY) {
                  return this.discard;
               }

               this.heat.target = this.textured.getBuffer(ThermalRenderTypes.maskTypeOf(type));
               this.heat.passThrough = true;
            }

            this.heat.color = this.color;
            return this.heat;
         } else {
            return this.discard;
         }
      }

      private static boolean isText(RenderType type) {
         return nameOf(type).startsWith("text");
      }

      private static boolean isHeatedEntityType(RenderType type) {
         String name = nameOf(type);
         return name.equals("entity_cutout_no_cull") || name.equals("entity_cutout_no_cull_z_offset") || name.equals("entity_translucent");
      }

      private static String nameOf(RenderType type) {
         String description = type.toString();
         if (!description.startsWith("RenderType[")) {
            return description;
         } else {
            int end = description.indexOf(58, 11);
            return end < 0 ? description.substring(11) : description.substring(11, end);
         }
      }
   }

   private static final class HeatVertices implements VertexConsumer {
      private VertexConsumer delegate;
      private int color;
      @Nullable
      private VertexConsumer target;
      private boolean passThrough;
      private float lastTemperature;
      private boolean graded;
      private float floorY;
      private float height;
      private float temperature;

      private HeatVertices(VertexConsumer delegate) {
         this.delegate = delegate;
      }

      private void grade(float floorY, float height, float temperature) {
         this.graded = true;
         this.floorY = floorY;
         this.height = height;
         this.temperature = temperature;
      }

      private void ungrade() {
         this.graded = false;
      }

      public VertexConsumer addVertex(float x, float y, float z) {
         if (this.passThrough) {
            float up = Mth.clamp((y - this.floorY) / this.height, 0.0F, 1.0F);
            this.lastTemperature = this.temperature * (0.86F + 0.14F * up);
            this.target.addVertex(x, y, z);
            return this;
         } else if (!this.graded) {
            this.delegate.addVertex(x, y, z).setColor(this.color);
            return this;
         } else {
            float up = Mth.clamp((y - this.floorY) / this.height, 0.0F, 1.0F);
            float t = this.temperature * (0.86F + 0.14F * up);
            this.delegate.addVertex(x, y, z).setColor(t, t, t * 0.9F, 1.0F);
            return this;
         }
      }

      public VertexConsumer setColor(int red, int green, int blue, int alpha) {
         if (this.passThrough) {
            float t = this.lastTemperature;
            this.target.setColor(t, t, t, alpha / 255.0F);
         }

         return this;
      }

      public VertexConsumer setUv(float u, float v) {
         if (this.passThrough) {
            this.target.setUv(u, v);
         }

         return this;
      }

      public VertexConsumer setUv1(int u, int v) {
         if (this.passThrough) {
            this.target.setUv1(u, v);
         }

         return this;
      }

      public VertexConsumer setUv2(int u, int v) {
         if (this.passThrough) {
            this.target.setUv2(u, v);
         }

         return this;
      }

      public VertexConsumer setNormal(float x, float y, float z) {
         if (this.passThrough) {
            this.target.setNormal(x, y, z);
         }

         return this;
      }
   }
}
