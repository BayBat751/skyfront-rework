package dev.krutlexik.skyfront.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.Item.Properties;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredRegister.Items;

public class ModItems {
   public static final Items ITEMS = DeferredRegister.createItems("sfw");
   public static final DeferredItem<Item> SHAHED_136 = ITEMS.register("shahed_136", () -> new ShahedItem(new Properties()));
   public static final DeferredItem<Item> LAUNCHER = ITEMS.register("launcher", () -> new LauncherItem(new Properties().stacksTo(16)));

   public static void register(IEventBus eventBus) {
      ITEMS.register(eventBus);
   }
}
