package dev.krutlexik.skyfront.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import dev.krutlexik.skyfront.config.SkyfrontConfig;
import dev.krutlexik.skyfront.drone.DroneTuningSync;
import dev.krutlexik.skyfront.entity.ShahedEntity;
import dev.krutlexik.skyfront.util.ChunkLoadHelper;
import dev.krutlexik.skyfront.worldmap.WorldMapData;
import dev.krutlexik.skyfront.worldmap.WorldMapScanner;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.coordinates.BlockPosArgument;
import net.minecraft.commands.arguments.coordinates.Vec3Argument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;

public class SkyfrontCommand {
   private static final int TITLE = 16777045;
   private static final int LABEL = 11184810;
   private static final int VALUE = 5636095;
   private static final int GOOD = 5635925;
   private static final int BAD = 16733525;

   private static MutableComponent onOff(boolean value) {
      return value
         ? Component.translatable("command.sfw.config.on").withStyle(s -> s.withColor(5635925))
         : Component.translatable("command.sfw.config.off").withStyle(s -> s.withColor(16733525));
   }

   private static LiteralArgumentBuilder<CommandSourceStack> configCommand() {
      return (LiteralArgumentBuilder<CommandSourceStack>)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal(
                           "config"
                        )
                        .executes(SkyfrontCommand::showConfig))
                     .then(Commands.literal("reload").executes(SkyfrontCommand::reloadConfig)))
                  .then(
                     ((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("particles").executes(context -> {
                              say(context, line("command.sfw.config.particles", onOff(SkyfrontConfig.areExplosionParticlesEnabled())));
                              say(context, line("command.sfw.config.particle_mult", value(SkyfrontConfig.getParticleMultiplier())));
                              return 1;
                           })).then(change("enable", () -> SkyfrontConfig.setExplosionParticlesEnabled(true), "command.sfw.config.particles.enabled", 5635925)))
                           .then(change("disable", () -> SkyfrontConfig.setExplosionParticlesEnabled(false), "command.sfw.config.particles.disabled", 16733525)))
                        .then(
                           Commands.literal("multiplier")
                              .then(
                                 Commands.argument("value", IntegerArgumentType.integer(0, 500))
                                    .executes(
                                       context -> {
                                          int value = IntegerArgumentType.getInteger(context, "value");
                                          SkyfrontConfig.setParticleMultiplier(value);
                                          ((CommandSourceStack)context.getSource())
                                             .sendSuccess(
                                                () -> Component.translatable("command.sfw.config.particle_mult.set", new Object[]{value})
                                                   .withStyle(s -> s.withColor(5635925)),
                                                true
                                             );
                                          return 1;
                                       }
                                    )
                              )
                        )
                  ))
               .then(
                  toggle("blockDamage", "command.sfw.config.block_damage", SkyfrontConfig::doExplosionsBreakBlocks, SkyfrontConfig::setExplosionsBreakBlocks)
               ))
            .then(
               toggle("sounds", "command.sfw.config.sounds", SkyfrontConfig::areCustomExplosionSoundsEnabled, SkyfrontConfig::setCustomExplosionSoundsEnabled)
            ))
         .then(
            ((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("zone").executes(context -> {
                  say(context, line("command.sfw.config.blacklist", blacklistState()));
                  say(context, line("command.sfw.config.whitelist", whitelistState()));
                  return 1;
               })).then(toggle("blacklist", "command.sfw.config.blacklist", SkyfrontConfig::isBlacklistEnabled, SkyfrontConfig::setBlacklistEnabled)))
               .then(toggle("whitelist", "command.sfw.config.whitelist", SkyfrontConfig::isWhitelistEnabled, SkyfrontConfig::setWhitelistEnabled))
         );
   }

   private static int reloadConfig(CommandContext<CommandSourceStack> context) {
      SkyfrontConfig.ReloadResult result = SkyfrontConfig.reloadFromFile();
      if (!result.fileFound()) {
         ((CommandSourceStack)context.getSource())
            .sendFailure(Component.translatable("command.sfw.config.reload.missing", new Object[]{"config/skyfront-common.toml"}));
         return 0;
      } else {
         DroneTuningSync.broadcast(((CommandSourceStack)context.getSource()).getServer());
         ((CommandSourceStack)context.getSource())
            .sendSuccess(
               () -> Component.translatable("command.sfw.config.reload.done", new Object[]{result.changed()}).withStyle(s -> s.withColor(5635925)), true
            );
         if (!result.rejected().isEmpty()) {
            ((CommandSourceStack)context.getSource())
               .sendFailure(Component.translatable("command.sfw.config.reload.rejected", new Object[]{String.join(", ", result.rejected())}));
         }

         return 1;
      }
   }

   private static int showConfig(CommandContext<CommandSourceStack> context) {
      ((CommandSourceStack)context.getSource())
         .sendSuccess(() -> Component.translatable("command.sfw.config.title").withStyle(s -> s.withColor(16777045)), false);
      say(context, line("command.sfw.config.particles", onOff(SkyfrontConfig.areExplosionParticlesEnabled())));
      say(context, line("command.sfw.config.particle_mult", value(SkyfrontConfig.getParticleMultiplier())));
      say(context, line("command.sfw.config.block_damage", onOff(SkyfrontConfig.doExplosionsBreakBlocks())));
      say(context, line("command.sfw.config.sounds", onOff(SkyfrontConfig.areCustomExplosionSoundsEnabled())));
      say(context, line("command.sfw.config.blacklist", blacklistState()));
      say(context, line("command.sfw.config.whitelist", whitelistState()));
      say(context, line("command.sfw.config.file", Component.literal("config/skyfront-common.toml").withStyle(s -> s.withColor(5636095))));
      return 1;
   }

   private static LiteralArgumentBuilder<CommandSourceStack> toggle(String name, String key, BooleanSupplier current, Consumer<Boolean> set) {
      return (LiteralArgumentBuilder<CommandSourceStack>)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal(name).executes(context -> {
            say(context, line(key, onOff(current.getAsBoolean())));
            return 1;
         })).then(change("enable", () -> set.accept(true), key + ".enabled", 5635925)))
         .then(change("disable", () -> set.accept(false), key + ".disabled", 16733525));
   }

   private static LiteralArgumentBuilder<CommandSourceStack> change(String name, Runnable apply, String doneKey, int colour) {
      return (LiteralArgumentBuilder<CommandSourceStack>)Commands.literal(name).executes(context -> {
         apply.run();
         ((CommandSourceStack)context.getSource()).sendSuccess(() -> Component.translatable(doneKey).withStyle(s -> s.withColor(colour)), true);
         return 1;
      });
   }

   private static MutableComponent blacklistState() {
      return zoneState(SkyfrontConfig.isBlacklistEnabled(), (List<? extends String>)SkyfrontConfig.FORBIDDEN_ZONES.get());
   }

   private static MutableComponent whitelistState() {
      return zoneState(SkyfrontConfig.isWhitelistEnabled(), (List<? extends String>)SkyfrontConfig.ALLOWED_ZONES.get());
   }

   private static MutableComponent zoneState(boolean enabled, List<? extends String> zones) {
      int count = SkyfrontConfig.packZones(zones).length / 4;
      return onOff(enabled).append(Component.translatable("command.sfw.config.zone_count", new Object[]{count}).withStyle(s -> s.withColor(11184810)));
   }

   private static MutableComponent value(Object value) {
      return Component.literal(String.valueOf(value)).withStyle(s -> s.withColor(5636095));
   }

   private static MutableComponent line(String key, Component argument) {
      return Component.translatable(key, new Object[]{argument}).withStyle(s -> s.withColor(11184810));
   }

   private static void say(CommandContext<CommandSourceStack> context, Component message) {
      ((CommandSourceStack)context.getSource()).sendSuccess(() -> message, false);
   }

   public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
      dispatcher.register(
         (LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("skyfront")
                     .requires(source -> source.hasPermission(2)))
                  .then(
                     Commands.literal("attack")
                        .then(
                           Commands.literal("shahed")
                              .then(
                                 Commands.argument("start", Vec3Argument.vec3())
                                    .then(
                                       ((RequiredArgumentBuilder)Commands.argument("target", BlockPosArgument.blockPos())
                                             .then(
                                                Commands.literal("low")
                                                   .executes(
                                                      context -> {
                                                         Vec3 startPos = Vec3Argument.getVec3(context, "start");
                                                         BlockPos targetPos = BlockPosArgument.getBlockPos(context, "target");
                                                         ServerLevel level = ((CommandSourceStack)context.getSource()).getLevel();
                                                         preloadChunks(level, startPos, Vec3.atCenterOf(targetPos));
                                                         ShahedEntity shahed = new ShahedEntity(level, startPos, targetPos, "low");
                                                         level.addFreshEntity(shahed);
                                                         ((CommandSourceStack)context.getSource())
                                                            .sendSuccess(
                                                               () -> Component.translatable("command.sfw.shahed.low").withStyle(s -> s.withColor(5635925)),
                                                               true
                                                            );
                                                         return 1;
                                                      }
                                                   )
                                             ))
                                          .then(
                                             Commands.literal("high")
                                                .executes(
                                                   context -> {
                                                      Vec3 startPos = Vec3Argument.getVec3(context, "start");
                                                      BlockPos targetPos = BlockPosArgument.getBlockPos(context, "target");
                                                      ServerLevel level = ((CommandSourceStack)context.getSource()).getLevel();
                                                      preloadChunks(level, startPos, Vec3.atCenterOf(targetPos));
                                                      ShahedEntity shahed = new ShahedEntity(level, startPos, targetPos, "high");
                                                      level.addFreshEntity(shahed);
                                                      ((CommandSourceStack)context.getSource())
                                                         .sendSuccess(
                                                            () -> Component.translatable("command.sfw.shahed.high").withStyle(s -> s.withColor(5635925)), true
                                                         );
                                                      return 1;
                                                   }
                                                )
                                          )
                                    )
                              )
                        )
                  ))
               .then(configCommand()))
            .then(
               ((LiteralArgumentBuilder)Commands.literal("map").then(Commands.literal("rescan").executes(context -> {
                     ServerLevel level = ((CommandSourceStack)context.getSource()).getLevel();
                     WorldMapData mapData = WorldMapData.get(level);
                     mapData.clear();
                     WorldMapScanner.getInstance().startScan(level);
                     ((CommandSourceStack)context.getSource())
                        .sendSuccess(() -> Component.literal("Map rescan started").withStyle(s -> s.withColor(5635925)), true);
                     return 1;
                  })))
                  .then(
                     Commands.literal("status")
                        .executes(
                           context -> {
                              WorldMapScanner scanner = WorldMapScanner.getInstance();
                              ServerLevel level = ((CommandSourceStack)context.getSource()).getLevel();
                              WorldMapData mapData = WorldMapData.get(level);
                              if (scanner.isScanning()) {
                                 ((CommandSourceStack)context.getSource())
                                    .sendSuccess(
                                       () -> Component.literal(String.format("Scanning: %d/%d chunks", scanner.getProgress(), scanner.getTotalChunks()))
                                          .withStyle(s -> s.withColor(16777045)),
                                       false
                                    );
                              } else if (mapData.isScanComplete()) {
                                 ((CommandSourceStack)context.getSource())
                                    .sendSuccess(
                                       () -> Component.literal(String.format("Scan complete: %d chunk colors", mapData.getColorCount()))
                                          .withStyle(s -> s.withColor(5635925)),
                                       false
                                    );
                              } else {
                                 ((CommandSourceStack)context.getSource())
                                    .sendSuccess(() -> Component.literal("Map not scanned").withStyle(s -> s.withColor(16733525)), false);
                              }

                              return 1;
                           }
                        )
                  )
            )
      );
   }

   private static void preloadChunks(ServerLevel level, Vec3 from, Vec3 to) {
      ChunkLoadHelper.keepTicking(level, ChunkLoadHelper.chunkAt(from.x, from.z));
   }
}
