package dev.krutlexik.skyfront.client.renderer;

import dev.krutlexik.skyfront.client.model.ShahedItemModel;
import dev.krutlexik.skyfront.item.ShahedItem;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import software.bernie.geckolib.renderer.GeoItemRenderer;

@OnlyIn(Dist.CLIENT)
public class ShahedItemRenderer extends GeoItemRenderer<ShahedItem> {
   public ShahedItemRenderer() {
      super(new ShahedItemModel());
   }
}
