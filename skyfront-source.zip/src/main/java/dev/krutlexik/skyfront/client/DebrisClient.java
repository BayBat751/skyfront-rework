package dev.krutlexik.skyfront.client;

import dev.krutlexik.skyfront.entity.DebrisEntity;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.SectionPos;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public final class DebrisClient {
   public static void spawn(List<DebrisEntity.Spawn> pieces) {
      ClientLevel level = Minecraft.getInstance().level;
      if (level != null && !pieces.isEmpty()) {
         Vec3 first = pieces.get(0).position();
         if (level.hasChunk(SectionPos.blockToSectionCoord(first.x), SectionPos.blockToSectionCoord(first.z))) {
            DebrisEntity.spawnLocally(level, pieces, level::addEntity);
         }
      }
   }

   private DebrisClient() {
   }
}
