package dev.krutlexik.skyfront.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.krutlexik.skyfront.block.ShahedTerminalBlock;
import dev.krutlexik.skyfront.block.entity.ShahedTerminalBlockEntity;
import dev.krutlexik.skyfront.drone.DroneMod;
import dev.krutlexik.skyfront.drone.client.render.DroneRenderer;
import dev.krutlexik.skyfront.drone.client.render.GlbModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider.Context;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.AABB;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ShahedTerminalRenderer implements BlockEntityRenderer<ShahedTerminalBlockEntity> {
   public static final ResourceLocation MODEL = DroneMod.id("models/block/shahed_terminal.glb");

   public ShahedTerminalRenderer(Context context) {
   }

   public void render(ShahedTerminalBlockEntity terminal, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int light, int overlay) {
      GlbModel glb = DroneRenderer.model(MODEL);
      if (glb != null) {
         Direction facing = (Direction)terminal.getBlockState().getValue(ShahedTerminalBlock.FACING);
         poseStack.pushPose();
         poseStack.translate(0.5F, 0.0F, 0.5F);
         poseStack.mulPose(Axis.YP.rotationDegrees(frontToward(facing)));
         poseStack.translate(-0.5F, 0.0F, -0.5F);
         glb.render(poseStack, buffers, light, overlay, 0.0F);
         poseStack.popPose();
      }
   }

   static float frontToward(Direction facing) {
      return -facing.toYRot() - 90.0F;
   }

   public AABB getRenderBoundingBox(ShahedTerminalBlockEntity terminal) {
      return new AABB(terminal.getBlockPos()).expandTowards(0.0, 0.75, 0.0);
   }
}
