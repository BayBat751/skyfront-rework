package dev.krutlexik.skyfront.client;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

public final class ClientViewpoint {
   public static Vec3 position() {
      Minecraft minecraft = Minecraft.getInstance();
      Entity camera = minecraft.getCameraEntity();
      if (camera != null) {
         return camera.position();
      } else {
         return minecraft.player != null ? minecraft.player.position() : Vec3.ZERO;
      }
   }

   private ClientViewpoint() {
   }
}
