package dev.krutlexik.skyfront.client.gui;

import dev.krutlexik.skyfront.network.NetworkHandler;
import dev.krutlexik.skyfront.network.TerminalActionPacket;
import dev.krutlexik.skyfront.network.TerminalDataPacket;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ShahedTerminalScreen extends Screen {
   private static final int ROW_HEIGHT = 24;
   private static final int VISIBLE_ROWS = 6;
   private static final int PANEL_W = 340;
   private static final int SIDE_GAP = 6;
   private static final int SIDE_MIN_W = 80;
   private static final int SIDE_MAX_W = 152;
   private static final int SLOT_SIZE = 20;
   private final BlockPos terminalPos;
   public List<TerminalDataPacket.Row> rows;
   private TerminalDataPacket.MapSlot map;
   public int scrollOffset = 0;
   private int refreshTimer = 0;
   private boolean draggingScroll = false;
   private static final int SCROLLBAR_W = 5;

   public ShahedTerminalScreen(BlockPos terminalPos, List<TerminalDataPacket.Row> rows, TerminalDataPacket.MapSlot map) {
      super(Component.translatable("gui.sfw.terminal.title"));
      this.terminalPos = terminalPos;
      this.rows = new ArrayList<>(rows);
      this.map = map;
   }

   public TerminalDataPacket.MapSlot getMap() {
      return this.map;
   }

   public void setMap(TerminalDataPacket.MapSlot map) {
      this.map = map;
   }

   public BlockPos getTerminalPos() {
      return this.terminalPos;
   }

   public void updateData(List<TerminalDataPacket.Row> rows, TerminalDataPacket.MapSlot map) {
      this.rows = new ArrayList<>(rows);
      this.map = map;
      if (this.scrollOffset > Math.max(0, this.rows.size() - 6)) {
         this.scrollOffset = Math.max(0, this.rows.size() - 6);
      }

      this.rebuildWidgets();
   }

   private int sideWidth() {
      return Mth.clamp(this.width - 360 - 6 - 8, 80, 152);
   }

   public int panelLeft() {
      return (this.width - (366 + this.sideWidth())) / 2 + 10;
   }

   private int sideLeft() {
      return this.panelLeft() + 340 + 10 + 6;
   }

   private int slotLeft() {
      return this.sideLeft() + 8;
   }

   private int slotTop() {
      return this.listTop() - 30 + 22;
   }

   private boolean overSlot(double mouseX, double mouseY) {
      return mouseX >= this.slotLeft() && mouseX < this.slotLeft() + 20 && mouseY >= this.slotTop() && mouseY < this.slotTop() + 20;
   }

   public int listTop() {
      return this.height / 2 - 62;
   }

   private int maxScroll() {
      return Math.max(0, this.rows.size() - 6);
   }

   private boolean needsScrollbar() {
      return this.maxScroll() > 0;
   }

   private int trackLeft() {
      return this.panelLeft() + 340 - 5;
   }

   private int trackHeight() {
      return 140;
   }

   private int thumbHeight() {
      return Math.max(20, this.trackHeight() * 6 / Math.max(1, this.rows.size()));
   }

   private int thumbY() {
      int travel = this.trackHeight() - this.thumbHeight();
      return this.listTop() + (this.maxScroll() == 0 ? 0 : travel * this.scrollOffset / this.maxScroll());
   }

   private void scrollToMouse(double mouseY) {
      int travel = this.trackHeight() - this.thumbHeight();
      if (travel > 0) {
         double rel = mouseY - this.listTop() - this.thumbHeight() / 2.0;
         int target = (int)Math.round(rel / travel * this.maxScroll());
         int clamped = Mth.clamp(target, 0, this.maxScroll());
         if (clamped != this.scrollOffset) {
            this.scrollOffset = clamped;
            this.rebuildWidgets();
         }
      }
   }

   protected void init() {
      int listTop = this.listTop();
      int right = this.panelLeft() + 340 - 5 - 4;
      int shown = Math.min(6, this.rows.size() - this.scrollOffset);

      for (int i = 0; i < shown; i++) {
         TerminalDataPacket.Row row = this.rows.get(this.scrollOffset + i);
         int y = listTop + i * 24;
         if (row.status() != 3) {
            this.addRenderableWidget(
               new TerminalButton(
                  right - 122,
                  y,
                  96,
                  20,
                  Component.translatable("gui.sfw.terminal.manage"),
                  b -> this.minecraft.setScreen(new ShahedRouteScreen(this, this.terminalPos, row, this.rows))
               )
            );
         }

         this.addRenderableWidget(
            new TerminalButton(
               right - 20, y, 20, 20, Component.literal("✕"), b -> NetworkHandler.sendToServer(TerminalActionPacket.unbind(this.terminalPos, row.uuid()))
            )
         );
      }
   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      if (super.mouseClicked(mouseX, mouseY, button)) {
         return true;
      } else if (button == 0 && this.overSlot(mouseX, mouseY)) {
         NetworkHandler.sendToServer(this.map.isEmpty() ? TerminalActionPacket.putMap(this.terminalPos) : TerminalActionPacket.takeMap(this.terminalPos));
         this.minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
         return true;
      } else if (button == 0
         && this.needsScrollbar()
         && mouseX >= this.trackLeft()
         && mouseX <= this.trackLeft() + 5
         && mouseY >= this.listTop()
         && mouseY <= this.listTop() + this.trackHeight()) {
         this.draggingScroll = true;
         this.scrollToMouse(mouseY);
         return true;
      } else {
         return false;
      }
   }

   public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
      if (this.draggingScroll && button == 0) {
         this.scrollToMouse(mouseY);
         return true;
      } else {
         return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
      }
   }

   public boolean mouseReleased(double mouseX, double mouseY, int button) {
      if (button == 0) {
         this.draggingScroll = false;
      }

      return super.mouseReleased(mouseX, mouseY, button);
   }

   public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
      if (this.needsScrollbar()) {
         int next = Mth.clamp(this.scrollOffset - (int)Math.signum(scrollY), 0, this.maxScroll());
         if (next != this.scrollOffset) {
            this.scrollOffset = next;
            this.rebuildWidgets();
         }

         return true;
      } else {
         return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
      }
   }

   public void tick() {
      super.tick();
      if (++this.refreshTimer >= 40) {
         this.refreshTimer = 0;
         NetworkHandler.sendToServer(TerminalActionPacket.refresh(this.terminalPos));
      }
   }

   public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
      this.renderBlurredBackground(partialTick);
      int left = this.panelLeft();
      int listTop = this.listTop();
      int top = listTop - 30;
      int screenTop = listTop - 6;
      int screenBottom = listTop + 144 + 2;
      int bottom = screenBottom + 21;
      ConsoleStyle.panel(graphics, left - 10, top, left + 340 + 10, bottom);
      ConsoleStyle.plate(graphics, this.font, left + 170, top + 6, this.title);
      ConsoleStyle.crt(graphics, left - 2, screenTop, left + 340 + 2, screenBottom);
      if (this.rows.isEmpty()) {
         List<FormattedCharSequence> lines = this.font.split(Component.translatable("gui.sfw.terminal.empty"), 316);
         int y = (screenTop + screenBottom) / 2 - lines.size() * 11 / 2;

         for (FormattedCharSequence line : lines) {
            graphics.drawCenteredString(this.font, line, left + 170, y, -12541880);
            y += 11;
         }
      }

      int shown = Math.min(6, this.rows.size() - this.scrollOffset);

      for (int i = 0; i < shown; i++) {
         TerminalDataPacket.Row row = this.rows.get(this.scrollOffset + i);
         int y = listTop + i * 24 + 6;
         graphics.drawString(this.font, Component.translatable("gui.sfw.terminal.entry", new Object[]{row.number()}).getString(), left + 4, y, -2039584);
         graphics.drawString(this.font, statusText(row).getString(), left + 78, y, statusColor(row.status()));
         if (i < shown - 1) {
            graphics.fill(left + 2, y + 17, left + 340 - 5 - 4, y + 18, -15318500);
         }
      }

      ConsoleStyle.lamps(graphics, left - 2, bottom - 13, -12788666, -12788666, -1005016);
      graphics.drawString(this.font, Component.translatable("gui.sfw.terminal.lamps"), left + 22, bottom - 15, -4275040);
      Component post = Component.literal("ПУ-136");
      ConsoleStyle.plate(graphics, this.font, left + 340 - this.font.width(post) / 2 - 4, bottom - 16, post);
      this.renderScrollbar(graphics, mouseX, mouseY);
      this.renderMapPanel(graphics, mouseX, mouseY, top, bottom);
      super.render(graphics, mouseX, mouseY, partialTick);
      if (this.overSlot(mouseX, mouseY)) {
         graphics.renderTooltip(
            this.font, Component.translatable(this.map.isEmpty() ? "gui.sfw.terminal.map.put" : "gui.sfw.terminal.map.take"), mouseX, mouseY
         );
      }
   }

   private void renderMapPanel(GuiGraphics graphics, int mouseX, int mouseY, int top, int bottom) {
      int x0 = this.sideLeft();
      int x1 = x0 + this.sideWidth();
      ConsoleStyle.panel(graphics, x0, top, x1, bottom);
      ConsoleStyle.plate(graphics, this.font, (x0 + x1) / 2, top + 6, Component.translatable("gui.sfw.terminal.map"));
      int sx = this.slotLeft();
      int sy = this.slotTop();
      ConsoleStyle.bezel(graphics, sx, sy, sx + 20, sy + 20);
      graphics.fill(sx + 1, sy + 1, sx + 20 - 1, sy + 20 - 1, this.overSlot(mouseX, mouseY) ? -14796254 : -16245748);
      if (!this.map.isEmpty()) {
         graphics.renderItem(this.map.stack(), sx + 2, sy + 2);
         String name = this.font.plainSubstrByWidth(this.map.stack().getHoverName().getString(), x1 - (sx + 20 + 6) - 6);
         graphics.drawString(this.font, name, sx + 20 + 6, sy + 2, -2039584);
         graphics.drawString(this.font, "1:" + (1 << this.map.scale()), sx + 20 + 6, sy + 11, -12541880);
      }

      int screenTop = sy + 20 + 8;
      int screenBottom = bottom - 8;
      int size = Math.min(x1 - x0 - 16, screenBottom - screenTop - 4);
      int mx = (x0 + x1 - size) / 2;
      int my = screenTop + 2;
      ConsoleStyle.crt(graphics, mx - 2, screenTop, mx + size + 2, screenBottom);
      if (!this.map.isEmpty() && TerminalMapPicture.isLoaded(this.map)) {
         TerminalMapPicture.render(graphics, this.map, mx, my, size);
      } else {
         Component hint = Component.translatable(this.map.isEmpty() ? "gui.sfw.terminal.map.empty" : "gui.sfw.terminal.map.loading");
         List<FormattedCharSequence> lines = this.font.split(hint, size - 6);
         int y = (screenTop + screenBottom) / 2 - lines.size() * 10 / 2;

         for (FormattedCharSequence line : lines) {
            graphics.drawCenteredString(this.font, line, mx + size / 2, y, -12541880);
            y += 10;
         }
      }
   }

   private void renderScrollbar(GuiGraphics graphics, int mouseX, int mouseY) {
      if (this.needsScrollbar()) {
         int x0 = this.trackLeft();
         int x1 = x0 + 5;
         int top = this.listTop();
         int bottom = top + this.trackHeight();
         graphics.fill(x0, top, x1, bottom, -16445689);
         graphics.fill(x0, top, x1, top + 1, -15318500);
         graphics.fill(x0, bottom - 1, x1, bottom, -15318500);
         int thumbTop = this.thumbY();
         int thumbBottom = thumbTop + this.thumbHeight();
         boolean hovered = this.draggingScroll || mouseX >= x0 && mouseX <= x1 && mouseY >= thumbTop && mouseY <= thumbBottom;
         graphics.fill(x0, thumbTop, x1, thumbBottom, hovered ? -12541880 : -15318500);
         graphics.fill(x0, thumbTop, x0 + 1, thumbBottom, -8853886);
      }
   }

   static void drawPanel(GuiGraphics graphics, int x0, int y0, int x1, int y1) {
      ConsoleStyle.panel(graphics, x0, y0, x1, y1);
   }

   static Component statusText(TerminalDataPacket.Row row) {
      if (row.status() == 4) {
         return Component.translatable("gui.sfw.terminal.status.seeker");
      } else {
         return switch (row.status()) {
            case 0 -> Component.translatable("gui.sfw.terminal.status.ready");
            case 1 -> Component.translatable("gui.sfw.terminal.status.flight");
            case 2 -> Component.translatable("gui.sfw.terminal.status.down");
            default -> Component.translatable("gui.sfw.terminal.status.no_signal");
         };
      }
   }

   static int statusColor(int status) {
      if (status == 4) {
         return -11141121;
      } else {
         return switch (status) {
            case 0 -> -11141291;
            case 1 -> -11141121;
            case 2 -> -43691;
            default -> -7697782;
         };
      }
   }

   public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
   }

   public boolean isPauseScreen() {
      return false;
   }
}
