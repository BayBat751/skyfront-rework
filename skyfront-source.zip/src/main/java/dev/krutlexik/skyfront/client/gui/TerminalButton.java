package dev.krutlexik.skyfront.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Button.OnPress;
import net.minecraft.network.chat.Component;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class TerminalButton extends Button {
   private TerminalButton.Style style = TerminalButton.Style.KEY;

   public TerminalButton(int x, int y, int width, int height, Component message, OnPress onPress) {
      super(x, y, width, height, message, onPress, DEFAULT_NARRATION);
   }

   public TerminalButton style(TerminalButton.Style style) {
      this.style = style;
      return this;
   }

   protected void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
      if (this.style == TerminalButton.Style.LAUNCH) {
         this.renderLaunch(graphics);
      } else {
         int x0 = this.getX();
         int y0 = this.getY();
         int x1 = x0 + this.width;
         int y1 = y0 + this.height;
         boolean hover = this.active && this.isHoveredOrFocused();
         boolean lit = this.style == TerminalButton.Style.LIT && this.active;
         int cap;
         int highlight;
         int text;
         if (!this.active) {
            cap = -14145240;
            highlight = -12960966;
            text = -10723750;
         } else if (lit) {
            cap = hover ? -13741008 : -14137816;
            highlight = -10840486;
            text = -5570646;
         } else {
            cap = hover ? -12829124 : -13750226;
            highlight = hover ? -9539476 : -11118508;
            text = hover ? -1 : -1907492;
         }

         graphics.fill(x0, y0, x1, y1, -13092296);
         graphics.fill(x0 + 1, y0 + 1, x1 - 1, y1 - 1, cap);
         graphics.fill(x0 + 1, y0 + 1, x1 - 1, y0 + 2, highlight);
         graphics.fill(x0 + 1, y0 + 1, x0 + 2, y1 - 1, highlight);
         graphics.fill(x0 + 1, y1 - 2, x1 - 1, y1 - 1, -15329514);
         graphics.fill(x1 - 2, y0 + 1, x1 - 1, y1 - 1, -15329514);
         renderScrollingString(graphics, Minecraft.getInstance().font, this.getMessage(), x0 + 3, y0, x1 - 3, y1, text);
      }
   }

   private void renderLaunch(GuiGraphics graphics) {
      int x0 = this.getX();
      int y0 = this.getY();
      int x1 = x0 + this.width;
      int y1 = y0 + this.height;

      for (int y = y0; y < y1; y++) {
         boolean band = y - y0 < 2 || y1 - 1 - y < 2;
         if (band) {
            stripeRun(graphics, x0, x1, y);
         } else {
            stripeRun(graphics, x0, x0 + 2, y);
            stripeRun(graphics, x1 - 2, x1, y);
         }
      }

      boolean hover = this.active && this.isHoveredOrFocused();
      int cap = !this.active ? -10868700 : (hover ? -2611170 : -4317672);
      int lit = !this.active ? -9554896 : -1025462;
      graphics.fill(x0 + 2, y0 + 2, x1 - 2, y1 - 2, -13092296);
      graphics.fill(x0 + 3, y0 + 3, x1 - 3, y1 - 3, cap);
      graphics.fill(x0 + 3, y0 + 3, x1 - 3, y0 + 4, lit);
      graphics.fill(x0 + 3, y1 - 4, x1 - 3, y1 - 3, -12841974);
      int text = this.active ? -6436 : -6918038;
      graphics.drawCenteredString(Minecraft.getInstance().font, this.getMessage(), x0 + this.width / 2, y0 + (this.height - 8) / 2, text);
   }

   private static void stripeRun(GuiGraphics graphics, int from, int to, int y) {
      int start = from;
      boolean yellow = (from + y) / 3 % 2 == 0;

      for (int x = from + 1; x <= to; x++) {
         boolean next = x < to && (x + y) / 3 % 2 == 0;
         if (x == to || next != yellow) {
            graphics.fill(start, y, x, y + 1, yellow ? -1920482 : -15198702);
            start = x;
            yellow = next;
         }
      }
   }

   public static enum Style {
      KEY,
      LIT,
      LAUNCH;
   }
}
