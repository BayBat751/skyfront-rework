package dev.krutlexik.skyfront.client;

import dev.krutlexik.skyfront.client.gui.ShahedRouteScreen;
import dev.krutlexik.skyfront.client.gui.ShahedTerminalScreen;
import dev.krutlexik.skyfront.network.TerminalDataPacket;
import dev.krutlexik.skyfront.seeker.SeekerTerminalScreen;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ClientProxy {
   public static void handleTerminalData(
      BlockPos terminalPos,
      boolean openScreen,
      int maxWaypoints,
      int minSpacing,
      int minLaunchDistance,
      int maxAltitude,
      boolean whitelistEnabled,
      int[] whitelistZones,
      boolean blacklistEnabled,
      int[] blacklistZones,
      List<TerminalDataPacket.Row> rows,
      TerminalDataPacket.MapSlot map
   ) {
      ClientTerminalLimits.update(maxWaypoints, minSpacing, minLaunchDistance, maxAltitude, whitelistEnabled, whitelistZones, blacklistEnabled, blacklistZones);
      Minecraft mc = Minecraft.getInstance();
      Screen current = mc.screen;
      if (current instanceof ShahedTerminalScreen list && list.getTerminalPos().equals(terminalPos)) {
         list.updateData(rows, map);
      } else if (current instanceof ShahedRouteScreen route && route.getTerminalPos().equals(terminalPos)) {
         route.updateData(rows);
         route.getParent().setMap(map);
      } else {
         if (openScreen) {
            mc.setScreen(new SeekerTerminalScreen(terminalPos, rows, map));
         }
      }
   }
}
