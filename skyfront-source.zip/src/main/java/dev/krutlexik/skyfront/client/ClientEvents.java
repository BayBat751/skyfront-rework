package dev.krutlexik.skyfront.client;

import dev.krutlexik.skyfront.block.ModBlocks;
import dev.krutlexik.skyfront.block.entity.ModBlockEntities;
import dev.krutlexik.skyfront.client.renderer.DebrisRenderer;
import dev.krutlexik.skyfront.client.renderer.LauncherRenderer;
import dev.krutlexik.skyfront.client.renderer.ShahedRenderer;
import dev.krutlexik.skyfront.client.renderer.ShahedTerminalRenderer;
import dev.krutlexik.skyfront.drone.client.render.DroneItemRenderer;
import dev.krutlexik.skyfront.entity.ModEntities;
import dev.krutlexik.skyfront.item.ModItems;
import dev.krutlexik.skyfront.particle.BlackSmokeParticle;
import dev.krutlexik.skyfront.particle.DebrisParticle;
import dev.krutlexik.skyfront.particle.EmberParticle;
import dev.krutlexik.skyfront.particle.FlashParticle;
import dev.krutlexik.skyfront.particle.ModParticles;
import dev.krutlexik.skyfront.particle.ShrapnelParticle;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.EventBusSubscriber.Bus;
import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent.RegisterRenderers;
import net.neoforged.neoforge.client.extensions.common.IClientItemExtensions;
import net.neoforged.neoforge.client.extensions.common.RegisterClientExtensionsEvent;

@OnlyIn(Dist.CLIENT)
@EventBusSubscriber(
   modid = "sfw",
   bus = Bus.MOD,
   value = {Dist.CLIENT}
)
public class ClientEvents {
   @SubscribeEvent
   public static void registerRenderers(RegisterRenderers event) {
      event.registerEntityRenderer((EntityType)ModEntities.SHAHED.get(), ShahedRenderer::new);
      event.registerBlockEntityRenderer((BlockEntityType)ModBlockEntities.SHAHED_TERMINAL.get(), ShahedTerminalRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.LAUNCHER.get(), LauncherRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.DEBRIS.get(), DebrisRenderer::new);
      System.out.println("[SFW] Renderer registered for ShahedEntity!");
   }

   @SubscribeEvent
   public static void registerClientExtensions(RegisterClientExtensionsEvent event) {
      final DroneItemRenderer renderer = new DroneItemRenderer(ShahedTerminalRenderer.MODEL);
      event.registerItem(new IClientItemExtensions() {
         public BlockEntityWithoutLevelRenderer getCustomRenderer() {
            return renderer;
         }
      }, new Item[]{((Block)ModBlocks.SHAHED_TERMINAL.get()).asItem()});
      final DroneItemRenderer launcher = new DroneItemRenderer(LauncherRenderer.MODEL);
      event.registerItem(new IClientItemExtensions() {
         public BlockEntityWithoutLevelRenderer getCustomRenderer() {
            return launcher;
         }
      }, new Item[]{(Item)ModItems.LAUNCHER.get()});
   }

   @SubscribeEvent
   public static void registerParticles(RegisterParticleProvidersEvent event) {
      event.registerSpriteSet((ParticleType)ModParticles.DEBRIS.get(), DebrisParticle.Provider::new);
      event.registerSpriteSet((ParticleType)ModParticles.EXPLOSION_FLASH.get(), FlashParticle.Provider::new);
      event.registerSpriteSet((ParticleType)ModParticles.EMBER.get(), EmberParticle.Provider::new);
      event.registerSpriteSet((ParticleType)ModParticles.BLACK_SMOKE.get(), BlackSmokeParticle.Provider::new);
      event.registerSpriteSet((ParticleType)ModParticles.SHRAPNEL.get(), ShrapnelParticle.Provider::new);
      System.out.println("[SFW] Particles registered!");
   }
}
