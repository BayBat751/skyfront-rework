package dev.krutlexik.skyfront.client.gui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ShahedWaypointEditScreen extends Screen {
   private static final int PANEL_W = 200;
   private final ShahedRouteScreen parent;
   private final int editIndex;
   private boolean farDive;
   private EditBox xInput;
   private EditBox zInput;
   private EditBox numberInput;
   private boolean rejected;

   public ShahedWaypointEditScreen(ShahedRouteScreen parent, int editIndex) {
      super(Component.translatable(editIndex >= 0 ? "gui.sfw.waypoint.edit" : "gui.sfw.waypoint.add"));
      this.parent = parent;
      this.editIndex = editIndex;
      this.farDive = parent.isFarDive();
   }

   private boolean editingFinal() {
      return this.editIndex >= 0 && this.editIndex == this.parent.waypointCount() - 1;
   }

   private int panelLeft() {
      return this.width / 2 - 100;
   }

   private int panelTop() {
      return this.height / 2 - 64;
   }

   protected void init() {
      int left = this.panelLeft();
      int top = this.panelTop();
      int[] existing = this.editIndex >= 0 ? this.parent.waypoint(this.editIndex) : null;
      int defaultNumber = this.editIndex >= 0 ? this.editIndex + 1 : this.parent.waypointCount() + 1;
      this.xInput = this.makeInput(left + 70, top + 24, existing != null ? String.valueOf(existing[0]) : "0", true);
      this.zInput = this.makeInput(left + 70, top + 44, existing != null ? String.valueOf(existing[1]) : "0", true);
      this.numberInput = this.makeInput(left + 70, top + 64, String.valueOf(defaultNumber), false);
      this.addRenderableWidget(this.xInput);
      this.addRenderableWidget(this.zInput);
      this.addRenderableWidget(this.numberInput);
      int y = top + 84;
      if (this.editingFinal()) {
         this.addRenderableWidget(new TerminalButton(left + 8, y, 184, 16, this.diveLabel(), b -> {
            this.farDive = !this.farDive;
            b.setMessage(this.diveLabel());
         }));
         y += 20;
      }

      this.addRenderableWidget(new TerminalButton(left + 8, y, 90, 18, Component.translatable("gui.sfw.waypoint.ok"), b -> this.confirm()));
      this.addRenderableWidget(new TerminalButton(left + 100 + 2, y, 90, 18, Component.translatable("gui.sfw.waypoint.cancel"), b -> this.onClose()));
   }

   private Component diveLabel() {
      return Component.translatable(
         "gui.sfw.control.dive", new Object[]{Component.translatable(this.farDive ? "gui.sfw.control.dive.far" : "gui.sfw.control.dive.near")}
      );
   }

   private EditBox makeInput(int x, int y, String value, boolean signed) {
      EditBox box = new EditBox(this.font, x + 3, y + 3, 118, 12, Component.empty());
      box.setBordered(false);
      box.setMaxLength(8);
      box.setTextColor(-4653109);
      box.setValue(value);
      box.setFilter(s -> s.isEmpty() || (signed ? s.matches("-?\\d*") : s.matches("\\d*")));
      return box;
   }

   private void confirm() {
      int x = parseOr(this.xInput.getValue(), 0);
      int z = parseOr(this.zInput.getValue(), 0);
      int count = this.parent.waypointCount();
      if (!this.parent.isAllowedPosition(x, z)) {
         this.rejected = true;
      } else {
         if (this.editIndex >= 0) {
            int number = Mth.clamp(parseOr(this.numberInput.getValue(), this.editIndex + 1), 1, count);
            this.parent.setWaypoint(this.editIndex, x, z);
            if (number - 1 != this.editIndex) {
               this.parent.moveWaypoint(this.editIndex, number - 1);
            }

            if (this.editingFinal()) {
               this.parent.setFarDive(this.farDive);
            }
         } else {
            int numberx = Mth.clamp(parseOr(this.numberInput.getValue(), count + 1), 1, count + 1);
            this.parent.addWaypoint(x, z, numberx - 1);
         }

         this.minecraft.setScreen(this.parent);
      }
   }

   private static int parseOr(String value, int fallback) {
      try {
         return Integer.parseInt(value.trim());
      } catch (NumberFormatException var3) {
         return fallback;
      }
   }

   public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
      this.renderBlurredBackground(partialTick);
      int left = this.panelLeft();
      int top = this.panelTop();
      int bottom = top + (this.editingFinal() ? 126 : 106);
      ShahedTerminalScreen.drawPanel(graphics, left, top, left + 200, bottom);
      graphics.drawCenteredString(this.font, this.title, this.width / 2, top + 6, -12320917);
      graphics.fill(left + 8, top + 18, left + 200 - 8, top + 19, -14779852);
      graphics.drawString(this.font, Component.translatable("gui.sfw.control.x"), left + 10, top + 27, -12320917);
      graphics.drawString(this.font, Component.translatable("gui.sfw.control.z"), left + 10, top + 47, -12320917);
      graphics.drawString(this.font, Component.translatable("gui.sfw.waypoint.number"), left + 10, top + 67, -12320917);
      drawInputFrame(graphics, left + 70, top + 24, left + 200 - 10, top + 40);
      drawInputFrame(graphics, left + 70, top + 44, left + 200 - 10, top + 60);
      drawInputFrame(graphics, left + 70, top + 64, left + 200 - 10, top + 80);
      if (this.rejected) {
         graphics.drawCenteredString(
            this.font, Component.translatable("gui.sfw.waypoint.forbidden"), this.width / 2, top + 84 + (this.editingFinal() ? 20 : 0) - 12, -43691
         );
      }

      super.render(graphics, mouseX, mouseY, partialTick);
   }

   private static void drawInputFrame(GuiGraphics graphics, int x0, int y0, int x1, int y1) {
      graphics.fill(x0, y0, x1, y1, -16575478);
      graphics.fill(x0, y0, x1, y0 + 1, -14779852);
      graphics.fill(x0, y1 - 1, x1, y1, -14779852);
      graphics.fill(x0, y0, x0 + 1, y1, -14779852);
      graphics.fill(x1 - 1, y0, x1, y1, -14779852);
   }

   public void onClose() {
      this.minecraft.setScreen(this.parent);
   }

   public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
   }

   public boolean isPauseScreen() {
      return false;
   }
}
