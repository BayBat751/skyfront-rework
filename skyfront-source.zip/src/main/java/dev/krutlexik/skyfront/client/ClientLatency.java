package dev.krutlexik.skyfront.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;

public final class ClientLatency {
   private static final double MS_PER_TICK = 50.0;
   private static final double MAX_LEAD_TICKS = 6.0;

   public static double packetAgeTicks() {
      Minecraft minecraft = Minecraft.getInstance();
      if (minecraft.player != null && minecraft.getConnection() != null) {
         PlayerInfo info = minecraft.getConnection().getPlayerInfo(minecraft.player.getUUID());
         if (info == null) {
            return 0.0;
         } else {
            double oneWayMs = Math.max(0, info.getLatency()) / 2.0;
            return Math.min(oneWayMs / 50.0, 6.0);
         }
      } else {
         return 0.0;
      }
   }

   private ClientLatency() {
   }
}
