package dev.krutlexik.skyfront.client.model;

import dev.krutlexik.skyfront.item.ShahedItem;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import software.bernie.geckolib.model.GeoModel;

@OnlyIn(Dist.CLIENT)
public class ShahedItemModel extends GeoModel<ShahedItem> {
   public ResourceLocation getModelResource(ShahedItem item) {
      return ResourceLocation.fromNamespaceAndPath("sfw", "geo/shahed.geo.json");
   }

   public ResourceLocation getTextureResource(ShahedItem item) {
      return ResourceLocation.fromNamespaceAndPath("sfw", "textures/entity/shahed.png");
   }

   public ResourceLocation getAnimationResource(ShahedItem item) {
      return ResourceLocation.fromNamespaceAndPath("sfw", "animations/shahed.animation.json");
   }
}
