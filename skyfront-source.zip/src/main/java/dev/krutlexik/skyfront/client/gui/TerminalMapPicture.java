package dev.krutlexik.skyfront.client.gui;

import dev.krutlexik.skyfront.network.TerminalDataPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.MapItem;
import net.minecraft.world.level.saveddata.maps.MapId;
import net.minecraft.world.level.saveddata.maps.MapItemSavedData;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.jetbrains.annotations.Nullable;

@OnlyIn(Dist.CLIENT)
final class TerminalMapPicture {
   static final int MAP_PIXELS = 128;

   private TerminalMapPicture() {
   }

   static boolean isLoaded(TerminalDataPacket.MapSlot map) {
      return data(map) != null;
   }

   static void render(GuiGraphics graphics, TerminalDataPacket.MapSlot map, float x, float y, float size) {
      render(graphics, map, x, y, size, 1.0F);
   }

   static void render(GuiGraphics graphics, TerminalDataPacket.MapSlot map, float x, float y, float size, float brightness) {
      MapItemSavedData data = data(map);
      MapId id = (MapId)map.stack().get(DataComponents.MAP_ID);
      if (data != null && id != null && !(size <= 0.0F)) {
         float scale = size / 128.0F;
         graphics.pose().pushPose();
         graphics.pose().translate(x, y, 1.0F);
         graphics.pose().scale(scale, scale, 1.0F);
         if (brightness != 1.0F) {
            graphics.setColor(brightness, brightness, brightness, 1.0F);
         }

         Minecraft.getInstance().gameRenderer.getMapRenderer().render(graphics.pose(), graphics.bufferSource(), id, data, true, 15728880);
         graphics.flush();
         if (brightness != 1.0F) {
            graphics.setColor(1.0F, 1.0F, 1.0F, 1.0F);
         }

         graphics.pose().popPose();
      }
   }

   @Nullable
   private static MapItemSavedData data(TerminalDataPacket.MapSlot map) {
      Minecraft minecraft = Minecraft.getInstance();
      if (!map.isEmpty() && minecraft.level != null) {
         MapId id = (MapId)map.stack().get(DataComponents.MAP_ID);
         return id == null ? null : MapItem.getSavedData(id, minecraft.level);
      } else {
         return null;
      }
   }
}
