package dev.krutlexik.skyfront.client.gui;

import com.mojang.math.Axis;
import dev.krutlexik.skyfront.client.ClientTerminalLimits;
import dev.krutlexik.skyfront.network.NetworkHandler;
import dev.krutlexik.skyfront.network.RequestWorldMapPacket;
import dev.krutlexik.skyfront.network.TerminalActionPacket;
import dev.krutlexik.skyfront.network.TerminalDataPacket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ShahedRouteScreen extends Screen {
   private static final int MAP_RADIUS = 2000;
   private static final int PANEL_W = 150;
   private static final int LIST_ROWS = 6;
   private static final ResourceLocation DRONE_ICON = ResourceLocation.fromNamespaceAndPath("sfw", "textures/gui/shahed_icon.png");
   private static final int ICON_SIZE = 24;
   private static final int ICON_TEX_SIZE = 32;
   private final ShahedTerminalScreen parent;
   private final BlockPos terminalPos;
   private TerminalDataPacket.Row row;
   private List<TerminalDataPacket.Row> allRows;
   private final double originX;
   private final double originZ;
   private final TerrainMapView mapView = new TerrainMapView(ResourceLocation.fromNamespaceAndPath("sfw", "dynamic/terminal_map"));
   private final List<int[]> waypoints = new ArrayList<>();
   private int selected = -1;
   private int listScroll = 0;
   private boolean farDive;
   private float zoom = 1.0F;
   private float offsetX;
   private float offsetZ;
   private boolean dragging;
   private static final double PAN_THRESHOLD = 3.0;
   private boolean pressedInMap;
   private boolean pannedWhilePressed;
   private double pressX;
   private double pressY;
   private EditBox altInput;
   private TerminalButton launchButton;
   private int refreshTimer;

   public ShahedRouteScreen(ShahedTerminalScreen parent, BlockPos terminalPos, TerminalDataPacket.Row row, List<TerminalDataPacket.Row> allRows) {
      super(Component.translatable("gui.sfw.route.title", new Object[]{row.number()}));
      this.parent = parent;
      this.terminalPos = terminalPos;
      this.row = row;
      this.allRows = allRows;
      this.originX = row.lx();
      this.originZ = row.lz();
      this.farDive = row.farDive();
      this.readRoute(row.route());
   }

   private void readRoute(int[] flat) {
      this.waypoints.clear();

      for (int i = 0; i + 1 < flat.length; i += 2) {
         this.waypoints.add(new int[]{flat[i], flat[i + 1]});
      }
   }

   public BlockPos getTerminalPos() {
      return this.terminalPos;
   }

   public ShahedTerminalScreen getParent() {
      return this.parent;
   }

   private double originX() {
      return this.originX;
   }

   private double originZ() {
      return this.originZ;
   }

   private boolean canEdit() {
      return this.row.status() == 0;
   }

   public void updateData(List<TerminalDataPacket.Row> rows) {
      this.allRows = rows;

      for (TerminalDataPacket.Row fresh : rows) {
         if (fresh.uuid().equals(this.row.uuid())) {
            boolean wasEditable = this.canEdit();
            this.row = fresh;
            if (!Arrays.equals(fresh.route(), this.flatRoute())) {
               this.readRoute(fresh.route());
               if (this.selected >= this.waypoints.size()) {
                  this.selected = -1;
               }
            }

            if (wasEditable != this.canEdit()) {
               this.rebuildWidgets();
            }

            if (this.launchButton != null) {
               this.launchButton.active = this.canEdit() && !this.waypoints.isEmpty();
            }

            return;
         }
      }

      this.minecraft.setScreen(this.parent);
   }

   private int mapSize() {
      return Math.min(this.width - 150 - 40, this.height - 50);
   }

   private int layoutLeft() {
      return (this.width - (this.mapSize() + 12 + 150)) / 2;
   }

   private int mapCenterX() {
      return this.layoutLeft() + this.mapSize() / 2;
   }

   private int mapCenterY() {
      return this.height / 2;
   }

   private int panelLeft() {
      return this.layoutLeft() + this.mapSize() + 12;
   }

   private float scale() {
      return this.mapSize() / 2 / (2000.0F / this.zoom);
   }

   protected void init() {
      int left = this.panelLeft();
      int top = this.mapCenterY() - this.mapSize() / 2;
      int listTop = top + 54;
      int buttonsTop = listTop + 72 + 6;
      this.altInput = new EditBox(this.font, left + 54, buttonsTop + 3, 92, 12, Component.empty());
      this.altInput.setBordered(false);
      this.altInput.setMaxLength(4);
      this.altInput.setTextColor(-20420);
      this.altInput.setValue(String.valueOf(this.row.altitude()));
      this.altInput.setFilter(s -> s.isEmpty() || s.matches("\\d{1,4}"));
      this.addRenderableWidget(this.altInput);
      boolean editable = this.canEdit();
      this.altInput.setEditable(editable);
      TerminalButton diveButton = (TerminalButton)this.addRenderableWidget(new TerminalButton(left, buttonsTop + 18, 150, 16, this.diveLabel(), b -> {
         this.farDive = !this.farDive;
         b.setMessage(this.diveLabel());
         this.pushRoute();
      }).style(TerminalButton.Style.LIT));
      diveButton.active = editable;
      TerminalButton manualButton = (TerminalButton)this.addRenderableWidget(
         new TerminalButton(
            left,
            buttonsTop + 36,
            150,
            16,
            Component.translatable("gui.sfw.route.manual"),
            b -> this.minecraft.setScreen(new ShahedWaypointEditScreen(this, this.selected))
         )
      );
      manualButton.active = editable;
      TerminalButton deleteButton = (TerminalButton)this.addRenderableWidget(
         new TerminalButton(left, buttonsTop + 54, 73, 16, Component.translatable("gui.sfw.route.delete"), b -> this.removeSelected())
      );
      deleteButton.active = editable;
      TerminalButton clearButton = (TerminalButton)this.addRenderableWidget(
         new TerminalButton(left + 75 + 2, buttonsTop + 54, 73, 16, Component.translatable("gui.sfw.route.clear"), b -> {
            this.waypoints.clear();
            this.selected = -1;
            this.pushRoute();
         })
      );
      clearButton.active = editable;
      this.launchButton = (TerminalButton)this.addRenderableWidget(
         new TerminalButton(left, buttonsTop + 74, 150, 18, Component.translatable("gui.sfw.control.launch"), b -> {
            this.pushRoute();
            NetworkHandler.sendToServer(new TerminalActionPacket(this.terminalPos, 2, this.row.uuid(), this.flatRoute(), this.altitudeValue(), this.farDive));
            this.minecraft.setScreen(this.parent);
         }).style(TerminalButton.Style.LAUNCH)
      );
      this.launchButton.active = editable && !this.waypoints.isEmpty();
      this.addRenderableWidget(new TerminalButton(left, buttonsTop + 96, 150, 16, Component.translatable("gui.sfw.control.back"), b -> this.onClose()));
      NetworkHandler.sendToServer(new RequestWorldMapPacket((int)this.originX, (int)this.originZ, 2000));
   }

   private Component diveLabel() {
      return Component.translatable(
         "gui.sfw.control.dive", new Object[]{Component.translatable(this.farDive ? "gui.sfw.control.dive.far" : "gui.sfw.control.dive.near")}
      );
   }

   private int altitudeValue() {
      try {
         return Mth.clamp(Integer.parseInt(this.altInput.getValue().trim()), 70, ClientTerminalLimits.maxAltitude());
      } catch (NumberFormatException var2) {
         return this.row.altitude();
      }
   }

   private int[] flatRoute() {
      int[] flat = new int[this.waypoints.size() * 2];

      for (int i = 0; i < this.waypoints.size(); i++) {
         flat[i * 2] = this.waypoints.get(i)[0];
         flat[i * 2 + 1] = this.waypoints.get(i)[1];
      }

      return flat;
   }

   private void pushRoute() {
      NetworkHandler.sendToServer(new TerminalActionPacket(this.terminalPos, 1, this.row.uuid(), this.flatRoute(), this.altitudeValue(), this.farDive));
      if (this.launchButton != null) {
         this.launchButton.active = this.row.status() == 0 && !this.waypoints.isEmpty();
      }
   }

   private boolean canPlace(int x, int z, int atIndex) {
      if (this.waypoints.size() >= ClientTerminalLimits.maxWaypoints()) {
         return false;
      } else {
         double dx = x - this.originX();
         double dz = z - this.originZ();
         double fromLaunchSq = dx * dx + dz * dz;
         if (fromLaunchSq > 4000000.0) {
            return false;
         } else {
            int minLaunch = ClientTerminalLimits.minLaunchDistance();
            if (fromLaunchSq < (double)minLaunch * minLaunch) {
               return false;
            } else if (ClientTerminalLimits.isForbidden(x, z)) {
               return false;
            } else {
               int prev = atIndex - 1;
               return prev >= 0 && prev < this.waypoints.size() && dist(this.waypoints.get(prev), x, z) < minSpacing()
                  ? false
                  : atIndex >= this.waypoints.size() || !(dist(this.waypoints.get(atIndex), x, z) < minSpacing());
            }
         }
      }
   }

   private static double minSpacing() {
      return ClientTerminalLimits.minSpacing();
   }

   private static double dist(int[] wp, int x, int z) {
      double dx = wp[0] - x;
      double dz = wp[1] - z;
      return Math.sqrt(dx * dx + dz * dz);
   }

   void addWaypoint(int x, int z, int atIndex) {
      int index = Mth.clamp(atIndex, 0, this.waypoints.size());
      this.waypoints.add(index, new int[]{x, z});
      this.selected = index;
      this.pushRoute();
   }

   boolean isAllowedPosition(int x, int z) {
      double dx = x - this.originX();
      double dz = z - this.originZ();
      return dx * dx + dz * dz <= 4000000.0 && !ClientTerminalLimits.isForbidden(x, z);
   }

   void setWaypoint(int index, int x, int z) {
      if (index >= 0 && index < this.waypoints.size()) {
         this.waypoints.set(index, new int[]{x, z});
         this.pushRoute();
      }
   }

   void moveWaypoint(int from, int to) {
      if (from >= 0 && from < this.waypoints.size()) {
         int[] wp = this.waypoints.remove(from);
         this.waypoints.add(Mth.clamp(to, 0, this.waypoints.size()), wp);
         this.selected = Mth.clamp(to, 0, this.waypoints.size() - 1);
         this.pushRoute();
      }
   }

   private void removeSelected() {
      if (this.selected >= 0 && this.selected < this.waypoints.size()) {
         this.waypoints.remove(this.selected);
         this.selected = -1;
         this.pushRoute();
      }
   }

   int waypointCount() {
      return this.waypoints.size();
   }

   int[] waypoint(int index) {
      return this.waypoints.get(index);
   }

   boolean isFarDive() {
      return this.farDive;
   }

   void setFarDive(boolean farDive) {
      this.farDive = farDive;
      this.pushRoute();
   }

   private int worldToScreenX(double worldX) {
      return this.mapCenterX() + Math.round((float)((worldX - this.originX() + this.offsetX) * this.scale()));
   }

   private int worldToScreenY(double worldZ) {
      return this.mapCenterY() + Math.round((float)((worldZ - this.originZ() + this.offsetZ) * this.scale()));
   }

   private boolean inMap(double mouseX, double mouseY) {
      int half = this.mapSize() / 2;
      return Math.abs(mouseX - this.mapCenterX()) <= half && Math.abs(mouseY - this.mapCenterY()) <= half;
   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      if (super.mouseClicked(mouseX, mouseY, button)) {
         return true;
      } else {
         int left = this.panelLeft();
         int listTop = this.mapCenterY() - this.mapSize() / 2 + 54;
         if (mouseX >= left && mouseX <= left + 150 && mouseY >= listTop && mouseY < listTop + 72) {
            int index = this.listScroll + (int)((mouseY - listTop) / 12.0);
            if (index < this.waypoints.size()) {
               this.selected = index;
            }

            return true;
         } else {
            if (this.inMap(mouseX, mouseY)) {
               if (button == 1) {
                  this.dragging = true;
                  return true;
               }

               if (button == 0) {
                  this.pressedInMap = true;
                  this.pannedWhilePressed = false;
                  this.pressX = mouseX;
                  this.pressY = mouseY;
                  return true;
               }
            }

            return false;
         }
      }
   }

   private void handleMapClick(double mouseX, double mouseY) {
      for (int i = 0; i < this.waypoints.size(); i++) {
         int[] wp = this.waypoints.get(i);
         if (Math.abs(mouseX - this.worldToScreenX(wp[0])) <= 5.0 && Math.abs(mouseY - this.worldToScreenY(wp[1])) <= 5.0) {
            this.selected = i;
            return;
         }
      }

      if (this.canEdit()) {
         float s = this.scale();
         int worldX = (int)Math.round(this.originX() + (mouseX - this.mapCenterX()) / s - this.offsetX);
         int worldZ = (int)Math.round(this.originZ() + (mouseY - this.mapCenterY()) / s - this.offsetZ);
         if (this.canPlace(worldX, worldZ, this.waypoints.size())) {
            this.addWaypoint(worldX, worldZ, this.waypoints.size());
         }
      }
   }

   public boolean mouseReleased(double mouseX, double mouseY, int button) {
      if (button == 1) {
         this.dragging = false;
      }

      if (button == 0 && this.pressedInMap) {
         this.pressedInMap = false;
         if (!this.pannedWhilePressed) {
            this.handleMapClick(mouseX, mouseY);
         }

         return true;
      } else {
         return super.mouseReleased(mouseX, mouseY, button);
      }
   }

   private float maxPan() {
      return Math.max(0.0F, 2000.0F - 2000.0F / this.zoom);
   }

   private void clampPan() {
      float max = this.maxPan();
      this.offsetX = Mth.clamp(this.offsetX, -max, max);
      this.offsetZ = Mth.clamp(this.offsetZ, -max, max);
   }

   public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
      if (button == 0 && this.pressedInMap) {
         if (!this.pannedWhilePressed && Math.abs(mouseX - this.pressX) + Math.abs(mouseY - this.pressY) > 3.0) {
            this.pannedWhilePressed = true;
         }

         if (this.pannedWhilePressed) {
            this.panBy(dragX, dragY);
         }

         return true;
      } else if (this.dragging && button == 1) {
         this.panBy(dragX, dragY);
         return true;
      } else {
         return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
      }
   }

   private void panBy(double dragX, double dragY) {
      float s = this.scale();
      this.offsetX += (float)(dragX / s);
      this.offsetZ += (float)(dragY / s);
      this.clampPan();
   }

   public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
      if (this.inMap(mouseX, mouseY)) {
         this.zoom = scrollY > 0.0 ? Math.min(this.zoom * 1.2F, 10.0F) : Math.max(this.zoom / 1.2F, 1.0F);
         this.clampPan();
         return true;
      } else if (mouseY > this.mapCenterY() && this.waypoints.size() > 6) {
         this.listScroll = Mth.clamp(this.listScroll - (int)Math.signum(scrollY), 0, this.waypoints.size() - 6);
         return true;
      } else {
         return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
      }
   }

   public void tick() {
      super.tick();
      if (++this.refreshTimer >= 10) {
         this.refreshTimer = 0;
         NetworkHandler.sendToServer(TerminalActionPacket.refresh(this.terminalPos));
      }
   }

   public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
      this.renderBlurredBackground(partialTick);
      int size = this.mapSize();
      int half = size / 2;
      int cx = this.mapCenterX();
      int cy = this.mapCenterY();
      ConsoleStyle.panel(graphics, cx - half - 8, cy - half - 19, cx + half + 7, cy + half + 7);
      ConsoleStyle.bezel(graphics, cx - half, cy - half, cx + half, cy + half);
      graphics.fill(cx - half, cy - half, cx + half, cy + half, -16777216);
      this.mapView.render(graphics, cx, cy, half, this.originX(), this.originZ(), this.scale(), this.offsetX, this.offsetZ, 0.5F);
      graphics.enableScissor(cx - half, cy - half, cx + half, cy + half);
      this.renderPaperMap(graphics);
      graphics.pose().pushPose();
      graphics.pose().translate(0.0F, 0.0F, 2.0F);
      this.renderRangeRing(graphics, cx, cy);
      this.renderDrones(graphics);
      this.renderRoute(graphics);
      graphics.pose().popPose();
      graphics.disableScissor();
      this.renderPanel(graphics, mouseX, mouseY);
      ConsoleStyle.plate(graphics, this.font, cx, cy - half - 16, this.title);
      ConsoleStyle.hintStrip(graphics, cx - half - 8, cy + half + 9, cx + half + 7, cy + half + 20);
      graphics.drawString(this.font, Component.translatable("gui.sfw.route.controls"), cx - half - 4, cy + half + 11, -12541880);
      super.render(graphics, mouseX, mouseY, partialTick);
   }

   private void renderPaperMap(GuiGraphics graphics) {
      TerminalDataPacket.MapSlot map = this.parent.getMap();
      if (!map.isEmpty() && map.here() && TerminalMapPicture.isLoaded(map)) {
         float blocks = 128.0F * (1 << map.scale());
         float s = this.scale();
         float x = this.mapCenterX() + (float)((map.centerX() - blocks / 2.0F - this.originX() + this.offsetX) * s);
         float y = this.mapCenterY() + (float)((map.centerZ() - blocks / 2.0F - this.originZ() + this.offsetZ) * s);
         TerminalMapPicture.render(graphics, map, x, y, blocks * s, 0.8F);
      }
   }

   private void renderRangeRing(GuiGraphics graphics, int cx, int cy) {
      float s = this.scale();
      int r = Math.round(2000.0F * s);
      int ox = cx + Math.round(this.offsetX * s);
      int oy = cy + Math.round(this.offsetZ * s);
      int segments = 96;

      for (int i = 0; i < segments; i++) {
         double a1 = (Math.PI * 2) * i / segments;
         double a2 = (Math.PI * 2) * (i + 1) / segments;
         drawLine(graphics, ox + (int)(Math.cos(a1) * r), oy + (int)(Math.sin(a1) * r), ox + (int)(Math.cos(a2) * r), oy + (int)(Math.sin(a2) * r), -13804995);
      }
   }

   private void renderDrones(GuiGraphics graphics) {
      for (TerminalDataPacket.Row other : this.allRows) {
         if (other.status() != 3) {
            int x = this.worldToScreenX(other.ex());
            int y = this.worldToScreenY(other.ez());
            boolean self = other.uuid().equals(this.row.uuid());
            graphics.pose().pushPose();
            graphics.pose().translate(x, y, 0.0F);
            graphics.pose().mulPose(Axis.ZP.rotationDegrees(180.0F - other.yaw()));
            graphics.pose().translate(-12.0F, -12.0F, 0.0F);
            if (self) {
               graphics.setColor(1.0F, 1.0F, 1.0F, 1.0F);
            } else {
               graphics.setColor(0.45F, 0.5F, 0.45F, 0.8F);
            }

            graphics.blit(DRONE_ICON, 0, 0, 24, 24, 0.0F, 0.0F, 32, 32, 32, 32);
            graphics.setColor(1.0F, 1.0F, 1.0F, 1.0F);
            graphics.pose().popPose();
            graphics.drawString(this.font, "#" + other.number(), x + 12 + 2, y - 4, self ? -1513240 : -6645094, false);
         }
      }
   }

   private void renderRoute(GuiGraphics graphics) {
      int px = this.worldToScreenX(this.originX());
      int py = this.worldToScreenZ_();

      for (int i = 0; i < this.waypoints.size(); i++) {
         int[] wp = this.waypoints.get(i);
         int x = this.worldToScreenX(wp[0]);
         int y = this.worldToScreenY(wp[1]);
         boolean last = i == this.waypoints.size() - 1;
         drawLine(graphics, px, py, x, y, last ? -1711319723 : -1717526368);
         px = x;
         py = y;
         int color = last ? -48060 : -11141291;
         graphics.fill(x - 3, y - 3, x + 4, y + 4, -16777216);
         graphics.fill(x - 2, y - 2, x + 3, y + 3, color);
         if (i == this.selected) {
            drawRect(graphics, x - 5, y - 5, x + 6, y + 6, -1);
         }

         graphics.drawString(this.font, String.valueOf(i + 1), x + 5, y - 9, color, false);
      }
   }

   private int worldToScreenZ_() {
      return this.worldToScreenY(this.originZ());
   }

   private void renderPanel(GuiGraphics graphics, int mouseX, int mouseY) {
      int left = this.panelLeft();
      int top = this.mapCenterY() - this.mapSize() / 2;
      int bottom = top + this.mapSize() + 2;
      ConsoleStyle.panel(graphics, left - 4, top - 2, left + 150 + 4, bottom);
      int listTop = top + 54;
      int lx0 = left + 3;
      int lx1 = left + 150 - 3;
      int tx = lx0 + 3;
      ConsoleStyle.lcd(graphics, lx0, top + 4, lx1, listTop + 72 + 1);
      graphics.drawString(
         this.font,
         Component.translatable("gui.sfw.route.points", new Object[]{this.waypoints.size(), ClientTerminalLimits.maxWaypoints()}),
         tx,
         top + 7,
         -20420,
         false
      );
      if (this.selected >= 0 && this.selected < this.waypoints.size()) {
         int[] wp = this.waypoints.get(this.selected);
         boolean last = this.selected == this.waypoints.size() - 1;
         graphics.drawString(
            this.font, Component.translatable("gui.sfw.route.point", new Object[]{this.selected + 1}), tx, top + 18, last ? -42436 : -20420, false
         );
         graphics.drawString(this.font, "X " + wp[0] + "  Z " + wp[1], tx, top + 28, -20420, false);
         int d = (int)Math.round(dist(wp, (int)this.originX(), (int)this.originZ()));
         graphics.drawString(this.font, Component.translatable("gui.sfw.route.dist", new Object[]{d}), tx, top + 38, -6657496, false);
      } else {
         graphics.drawString(this.font, Component.translatable("gui.sfw.route.nosel"), tx, top + 18, -6657496, false);
      }

      for (int i = 0; i < 6; i++) {
         int index = this.listScroll + i;
         if (index >= this.waypoints.size()) {
            break;
         }

         int[] wp = this.waypoints.get(index);
         int y = listTop + i * 12;
         boolean last = index == this.waypoints.size() - 1;
         if (index == this.selected) {
            graphics.fill(lx0, y - 1, lx1, y + 10, 1090498620);
         }

         graphics.drawString(this.font, index + 1 + ". " + wp[0] + ", " + wp[1], tx, y, last ? -42436 : -20420, false);
      }

      int buttonsTop = listTop + 72 + 6;
      Component alt = Component.translatable("gui.sfw.control.alt");
      int plateW = this.font.width(alt) + 10;
      if (plateW <= 48) {
         ConsoleStyle.plate(graphics, this.font, left + plateW / 2, buttonsTop + 2, alt);
      } else {
         graphics.drawString(this.font, alt, left, buttonsTop + 4, -3226218);
      }

      ConsoleStyle.lcd(graphics, left + 52, buttonsTop + 1, left + 150 - 3, buttonsTop + 15);
      if (bottom - 12 > buttonsTop + 118) {
         ConsoleStyle.lamps(graphics, left, bottom - 10, -12788666, -1005016, -10872812);
      }
   }

   private static void drawRect(GuiGraphics graphics, int x0, int y0, int x1, int y1, int color) {
      graphics.fill(x0, y0, x1, y0 + 1, color);
      graphics.fill(x0, y1 - 1, x1, y1, color);
      graphics.fill(x0, y0, x0 + 1, y1, color);
      graphics.fill(x1 - 1, y0, x1, y1, color);
   }

   private static void drawLine(GuiGraphics graphics, int x1, int y1, int x2, int y2, int color) {
      int dx = Math.abs(x2 - x1);
      int dy = Math.abs(y2 - y1);
      int sx = x1 < x2 ? 1 : -1;
      int sy = y1 < y2 ? 1 : -1;
      int err = dx - dy;
      int guard = 0;

      while (guard++ < 8192) {
         graphics.fill(x1, y1, x1 + 1, y1 + 1, color);
         if (x1 == x2 && y1 == y2) {
            break;
         }

         int e2 = 2 * err;
         if (e2 > -dy) {
            err -= dy;
            x1 += sx;
         }

         if (e2 < dx) {
            err += dx;
            y1 += sy;
         }
      }
   }

   public void onClose() {
      this.pushRoute();
      this.minecraft.setScreen(this.parent);
   }

   public void removed() {
      super.removed();
      this.mapView.close();
   }

   public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
   }

   public boolean isPauseScreen() {
      return false;
   }
}
