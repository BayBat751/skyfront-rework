package dev.krutlexik.skyfront.client.sound;

import dev.krutlexik.skyfront.client.ClientViewpoint;
import dev.krutlexik.skyfront.entity.ShahedEntity;
import dev.krutlexik.skyfront.sound.ModSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance.Attenuation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ShahedSoundInstance extends AbstractTickableSoundInstance {
   private final Minecraft client;
   private final ShahedEntity entity;
   private double lastDistance;
   private int fade = 0;
   private boolean die = false;
   private int soundTick = 0;
   private float damagePitchOffset = 0.0F;

   public ShahedSoundInstance(ShahedEntity entity) {
      super((SoundEvent)ModSounds.SHAHED_ENGINE.get(), SoundSource.AMBIENT, entity.level().getRandom());
      this.client = Minecraft.getInstance();
      this.entity = entity;
      this.looping = true;
      this.delay = 0;
      this.volume = 0.0F;
      this.pitch = 1.0F;
      this.attenuation = Attenuation.NONE;
   }

   public void tick() {
      LocalPlayer player = this.client.player;
      if (!this.entity.isRemoved() && player != null) {
         if (this.die) {
            if (this.fade > 0) {
               this.fade--;
            } else if (this.fade == 0) {
               this.stop();
               return;
            }
         } else if (this.fade < 5) {
            this.fade++;
         }

         double distanceToPlayer = this.entity.position().distanceTo(ClientViewpoint.position());
         float maxDistance = 150.0F;
         float distanceFactor = Math.max(0.0F, 1.0F - (float)(distanceToPlayer / maxDistance));
         float baseVolume = 1.0F;
         this.volume = baseVolume * (distanceFactor * distanceFactor) * (this.fade / 5.0F);
         this.x = this.entity.getX();
         this.y = this.entity.getY();
         this.z = this.entity.getZ();
         if (player.getVehicle() != this.entity) {
            double distance = this.entity.position().subtract(ClientViewpoint.position()).length();
            this.pitch = 1.0F + (float)(0.16 * Math.atan(this.lastDistance - distance));
            this.lastDistance = distance;
         } else {
            this.lastDistance = 0.0;
            this.pitch = 1.0F;
         }

         this.soundTick++;
         float offsetTarget = 0.0F;
         int launchState = this.entity.getLaunchState();
         if (this.entity.getIsFalling()) {
            offsetTarget = 0.35F + (float)Math.sin(this.soundTick * 0.45) * 0.03F;
            this.volume = Math.min(1.0F, this.volume * 1.3F);
         } else if (this.entity.getHealthFraction() <= 0.25F) {
            offsetTarget = (float)Math.sin(this.soundTick * 0.06) * 0.05F;
         } else if (launchState == 2 || launchState == 3 || launchState == 4) {
            float throttle = (float)Math.min(this.entity.getDeltaMovement().length() / 1.5, 1.0);
            offsetTarget = -0.4F * (1.0F - Math.max(0.25F, throttle));
            this.volume = this.volume * (0.3F + 0.7F * Math.max(0.25F, throttle));
         }

         this.damagePitchOffset = this.damagePitchOffset + (offsetTarget - this.damagePitchOffset) * 0.05F;
         this.pitch = this.pitch + this.damagePitchOffset;
         this.pitch = Math.max(0.5F, Math.min(2.0F, this.pitch));
      } else {
         this.stop();
      }
   }
}
