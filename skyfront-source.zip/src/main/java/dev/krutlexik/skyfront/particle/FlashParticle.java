package dev.krutlexik.skyfront.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class FlashParticle extends TextureSheetParticle {
   private final float baseSize;

   protected FlashParticle(ClientLevel level, double x, double y, double z, SpriteSet sprites) {
      super(level, x, y, z);
      this.lifetime = 11;
      this.hasPhysics = false;
      this.gravity = 0.0F;
      this.baseSize = 9.0F + this.random.nextFloat() * 3.0F;
      this.quadSize = this.baseSize;
      this.rCol = 1.0F;
      this.gCol = 0.88F;
      this.bCol = 0.5F;
      this.alpha = 0.9F;
      this.pickSprite(sprites);
   }

   public void tick() {
      this.xo = this.x;
      this.yo = this.y;
      this.zo = this.z;
      if (this.age++ >= this.lifetime) {
         this.remove();
      } else {
         float progress = (float)this.age / this.lifetime;
         float fade = (1.0F - progress) * (1.0F - progress);
         this.alpha = 0.9F * fade;
         this.gCol = 0.88F - 0.18F * progress;
         this.bCol = 0.5F - 0.25F * progress;
      }
   }

   public float getQuadSize(float partialTick) {
      float progress = (this.age + partialTick) / this.lifetime;
      return this.baseSize * (1.0F + 0.5F * Math.min(progress * 2.0F, 1.0F));
   }

   public int getLightColor(float partialTick) {
      return 15728880;
   }

   public ParticleRenderType getRenderType() {
      return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
   }

   @OnlyIn(Dist.CLIENT)
   public static class Provider implements ParticleProvider<SimpleParticleType> {
      private final SpriteSet sprites;

      public Provider(SpriteSet sprites) {
         this.sprites = sprites;
      }

      public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double vx, double vy, double vz) {
         return new FlashParticle(level, x, y, z, this.sprites);
      }
   }
}
