package dev.krutlexik.skyfront.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.SimpleParticleType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class EmberParticle extends TextureSheetParticle {
   private final float baseSize;

   protected EmberParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, SpriteSet sprites) {
      super(level, x, y, z);
      this.xd = vx;
      this.yd = vy;
      this.zd = vz;
      this.lifetime = 45 + this.random.nextInt(45);
      this.hasPhysics = true;
      this.gravity = 0.55F + this.random.nextFloat() * 0.35F;
      this.baseSize = 0.14F + this.random.nextFloat() * 0.18F;
      this.quadSize = this.baseSize;
      this.rCol = 1.0F;
      this.gCol = 0.92F;
      this.bCol = 0.6F;
      this.alpha = 1.0F;
      this.pickSprite(sprites);
   }

   public void tick() {
      this.xo = this.x;
      this.yo = this.y;
      this.zo = this.z;
      if (this.age++ >= this.lifetime) {
         this.remove();
      } else {
         this.yd = this.yd - 0.04 * this.gravity;
         this.move(this.xd, this.yd, this.zd);
         this.xd *= 0.96;
         this.yd *= 0.98;
         this.zd *= 0.96;
         if (this.onGround) {
            this.xd *= 0.5;
            this.zd *= 0.5;
            this.age += 2;
         } else if (this.random.nextInt(4) == 0) {
            this.level.addParticle(ParticleTypes.SMOKE, this.x, this.y, this.z, 0.0, 0.01, 0.0);
         }

         float progress = (float)this.age / this.lifetime;
         this.gCol = Math.max(0.15F, 0.92F - 0.72F * progress * progress);
         this.bCol = Math.max(0.02F, 0.6F - 0.8F * progress);
         this.quadSize = this.baseSize * (1.0F - 0.5F * progress);
         if (progress > 0.75F) {
            this.alpha = Math.max(0.0F, 1.0F - (progress - 0.75F) * 4.0F);
         }
      }
   }

   public int getLightColor(float partialTick) {
      return 15728880;
   }

   public ParticleRenderType getRenderType() {
      return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
   }

   @OnlyIn(Dist.CLIENT)
   public static class Provider implements ParticleProvider<SimpleParticleType> {
      private final SpriteSet sprites;

      public Provider(SpriteSet sprites) {
         this.sprites = sprites;
      }

      public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double vx, double vy, double vz) {
         return new EmberParticle(level, x, y, z, vx, vy, vz, this.sprites);
      }
   }
}
