package dev.krutlexik.skyfront.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class BlackSmokeParticle extends TextureSheetParticle {
   private final float baseSize;
   private final float spin;
   private final boolean fiery;
   private final int fireTicks;
   private final float smokeShade;

   protected BlackSmokeParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, SpriteSet sprites) {
      super(level, x, y, z);
      this.xd = vx;
      this.yd = vy;
      this.zd = vz;
      this.lifetime = 160 + this.random.nextInt(160);
      this.hasPhysics = true;
      this.baseSize = 1.0F + this.random.nextFloat() * 2.0F;
      this.quadSize = this.baseSize * 0.5F;
      this.smokeShade = 0.18F + this.random.nextFloat() * 0.22F;
      this.fiery = vy > 0.15 ? this.random.nextFloat() < 0.8F : this.random.nextFloat() < 0.06F;
      if (this.fiery) {
         this.fireTicks = 40 + this.random.nextInt(50);
         this.rCol = 1.0F;
         this.gCol = 0.35F + this.random.nextFloat() * 0.3F;
         this.bCol = 0.08F;
      } else {
         this.fireTicks = 0;
         this.rCol = this.smokeShade;
         this.gCol = this.smokeShade;
         this.bCol = this.smokeShade * 1.05F;
      }

      this.alpha = 0.95F;
      this.spin = (this.random.nextFloat() - 0.5F) * 0.08F;
      this.roll = this.random.nextFloat() * (float) (Math.PI * 2);
      this.oRoll = this.roll;
      this.pickSprite(sprites);
   }

   public void tick() {
      this.xo = this.x;
      this.yo = this.y;
      this.zo = this.z;
      if (this.age++ >= this.lifetime) {
         this.remove();
      } else {
         this.oRoll = this.roll;
         this.roll = this.roll + this.spin;
         this.move(this.xd, this.yd, this.zd);
         this.xd *= 0.92;
         this.zd *= 0.92;
         this.yd = this.yd * 0.92 + 0.0025;
         float progress = (float)this.age / this.lifetime;
         this.quadSize = this.baseSize * (0.5F + 2.0F * Math.min(this.age / 50.0F, 1.0F));
         if (this.fiery && this.age <= this.fireTicks) {
            this.gCol = Math.max(0.15F, this.gCol - 0.004F);
         } else if (this.fiery && this.rCol > this.smokeShade) {
            this.rCol = Math.max(this.smokeShade, this.rCol - 0.012F);
            this.gCol = Math.max(this.smokeShade, this.gCol - 0.008F);
            this.bCol = Math.min(this.smokeShade * 1.05F, this.bCol + 0.008F);
         } else {
            this.rCol = Math.min(0.5F, this.rCol + 0.0015F);
            this.gCol = Math.min(0.5F, this.gCol + 0.0015F);
            this.bCol = Math.min(0.52F, this.bCol + 0.0015F);
         }

         if (progress > 0.7F) {
            this.alpha = 0.95F * (1.0F - (progress - 0.7F) / 0.3F);
         }
      }
   }

   public int getLightColor(float partialTick) {
      return this.fiery && this.rCol > 0.5F ? 15728880 : super.getLightColor(partialTick);
   }

   public ParticleRenderType getRenderType() {
      return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
   }

   @OnlyIn(Dist.CLIENT)
   public static class Provider implements ParticleProvider<SimpleParticleType> {
      private final SpriteSet sprites;

      public Provider(SpriteSet sprites) {
         this.sprites = sprites;
      }

      public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double vx, double vy, double vz) {
         return new BlackSmokeParticle(level, x, y, z, vx, vy, vz, this.sprites);
      }
   }
}
