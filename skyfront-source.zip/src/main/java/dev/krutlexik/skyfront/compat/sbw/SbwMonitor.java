package dev.krutlexik.skyfront.compat.sbw;

import dev.krutlexik.skyfront.drone.entity.DroneEntity;
import java.util.UUID;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import org.jetbrains.annotations.Nullable;

public final class SbwMonitor {
   private static final ResourceLocation MONITOR_ID = ResourceLocation.fromNamespaceAndPath("superbwarfare", "monitor");
   private static final String LINKED = "Linked";
   private static final String LINKED_DRONE = "LinkedDrone";
   private static final String SKYFRONT_FLAG = "SkyfrontDrone";

   private SbwMonitor() {
   }

   private static CompoundTag tagOf(ItemStack stack) {
      CustomData data = (CustomData)stack.get(DataComponents.CUSTOM_DATA);
      return data != null ? data.copyTag() : new CompoundTag();
   }

   private static void save(ItemStack stack, CompoundTag tag) {
      stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
   }

   public static ItemStack newMonitor() {
      return BuiltInRegistries.ITEM.getOptional(MONITOR_ID).<ItemStack>map(ItemStack::new).orElse(ItemStack.EMPTY);
   }

   public static boolean isMonitor(ItemStack stack) {
      return !stack.isEmpty() && MONITOR_ID.equals(BuiltInRegistries.ITEM.getKey(stack.getItem()));
   }

   public static boolean isLinked(ItemStack stack) {
      return isMonitor(stack) && tagOf(stack).getBoolean("Linked");
   }

   public static boolean isFlaggedAta(ItemStack stack) {
      return isMonitor(stack) && tagOf(stack).getBoolean("SkyfrontDrone");
   }

   public static boolean isLinkedTo(ItemStack stack, DroneEntity drone) {
      return isMonitor(stack) && drone.getStringUUID().equals(tagOf(stack).getString("LinkedDrone"));
   }

   @Nullable
   public static UUID linkedDrone(ItemStack stack) {
      if (!isMonitor(stack)) {
         return null;
      } else {
         String id = tagOf(stack).getString("LinkedDrone");

         try {
            return UUID.fromString(id);
         } catch (IllegalArgumentException var3) {
            return null;
         }
      }
   }

   public static void link(ItemStack stack, DroneEntity drone) {
      CompoundTag tag = tagOf(stack);
      tag.putBoolean("Linked", true);
      tag.putString("LinkedDrone", drone.getStringUUID());
      tag.putBoolean("SkyfrontDrone", true);
      save(stack, tag);
   }

   public static void unlink(ItemStack stack, Player player) {
      CompoundTag tag = tagOf(stack);
      tag.putBoolean("Linked", false);
      tag.putString("LinkedDrone", "none");
      tag.remove("SkyfrontDrone");
      save(stack, tag);
   }

   public static void clearSkyfrontFlag(ItemStack stack) {
      CompoundTag tag = tagOf(stack);
      tag.remove("SkyfrontDrone");
      save(stack, tag);
   }

   public static void unlinkMatching(Player player, DroneEntity drone) {
      String id = drone.getStringUUID();
      Inventory inventory = player.getInventory();

      for (int slot = 0; slot < inventory.getContainerSize(); slot++) {
         ItemStack stack = inventory.getItem(slot);
         if (isMonitor(stack) && id.equals(tagOf(stack).getString("LinkedDrone"))) {
            unlink(stack, player);
         }
      }
   }

   public static void unlinkEverywhere(DroneEntity drone) {
      MinecraftServer server = drone.level().getServer();
      if (server != null) {
         for (Player player : server.getPlayerList().getPlayers()) {
            unlinkMatching(player, drone);
         }
      }
   }
}
