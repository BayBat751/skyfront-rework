package dev.krutlexik.skyfront.compat.sable;

import java.util.function.Supplier;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.fml.ModList;
import org.jetbrains.annotations.Nullable;

public final class SableCompat {
   public static final String MOD_ID = "sable";

   private SableCompat() {
   }

   public static boolean isLoaded() {
      return ModList.get().isLoaded("sable");
   }

   @Nullable
   public static Supplier<Vec3> stickyPosition(Entity entity) {
      if (!isLoaded()) {
         return null;
      } else {
         try {
            return SableSubLevels.stickyPosition(entity);
         } catch (LinkageError var2) {
            return null;
         }
      }
   }
}
