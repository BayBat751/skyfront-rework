package dev.krutlexik.skyfront.compat.sbw;

import net.neoforged.fml.ModList;

public final class SbwCompat {
   public static final String MOD_ID = "superbwarfare";

   private SbwCompat() {
   }

   public static boolean isLoaded() {
      return ModList.get().isLoaded("superbwarfare");
   }
}
