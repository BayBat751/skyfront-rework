package dev.krutlexik.skyfront.compat.sbw;

import com.atsuishio.superbwarfare.entity.vehicle.base.VehicleEntity;
import com.atsuishio.superbwarfare.init.ModDamageTypes;
import com.atsuishio.superbwarfare.tools.DamageHandler;
import com.atsuishio.superbwarfare.tools.ParticleTool;
import com.atsuishio.superbwarfare.tools.ParticleTool.ParticleType;
import javax.annotation.Nullable;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public final class SbwVehicles {
   private SbwVehicles() {
   }

   public static void damageVehiclesAround(ServerLevel level, Entity source, @Nullable Entity attacker, Vec3 center, float damage, float radius) {
      double diameter = radius * 2.0;
      AABB box = new AABB(center, center).inflate(diameter);

      for (VehicleEntity vehicle : level.getEntitiesOfClass(VehicleEntity.class, box)) {
         double distanceRate = Math.sqrt(vehicle.distanceToSqr(center)) / diameter;
         if (!(distanceRate > 1.0)) {
            double damagePercent = 1.0 - distanceRate;
            float damageFinal = (float)((damagePercent * damagePercent + damagePercent) / 2.0 * damage);
            DamageSource damageSource = ModDamageTypes.causeCustomExplosionDamage(level.registryAccess(), source, attacker);
            vehicle.invulnerableTime = 0;
            DamageHandler.doDamage(vehicle, damageSource, damageFinal);
         }
      }
   }

   public static void spawnExplosionEffect(ServerLevel level, Vec3 at, int scale) {
      ParticleType type = switch (Math.max(0, Math.min(scale, 3))) {
         case 0 -> ParticleType.MEDIUM;
         case 1 -> ParticleType.LARGE;
         case 2 -> ParticleType.HUGE;
         default -> ParticleType.GIANT;
      };
      ParticleTool.spawnExplosionParticles(type, level, at);
   }

   public static boolean isVehicle(Entity entity) {
      return entity instanceof VehicleEntity;
   }

   public static void damageVehicleDirectHit(Entity entity, Entity source, @Nullable Entity attacker, float damage) {
      if (entity instanceof VehicleEntity vehicle) {
         DamageSource damageSource = ModDamageTypes.causeProjectileHitDamage(entity.level().registryAccess(), source, attacker);
         vehicle.invulnerableTime = 0;
         DamageHandler.doDamage(vehicle, damageSource, damage);
      }
   }
}
