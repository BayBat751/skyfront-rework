package dev.krutlexik.skyfront.compat.sable;

import dev.ryanhcode.sable.companion.SableCompanion;
import dev.ryanhcode.sable.companion.SubLevelAccess;
import java.util.function.Supplier;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

final class SableSubLevels {
   private SableSubLevels() {
   }

   @Nullable
   static Supplier<Vec3> stickyPosition(Entity entity) {
      SubLevelAccess subLevel = SableCompanion.INSTANCE.getTrackingOrVehicleSubLevel(entity);
      if (subLevel == null) {
         return null;
      } else {
         Vec3 local = subLevel.logicalPose().transformPositionInverse(entity.position());
         return () -> subLevel.logicalPose().transformPosition(local);
      }
   }
}
