package dev.krutlexik.skyfront.seeker;

import dev.krutlexik.skyfront.block.entity.ShahedTerminalBlockEntity;
import dev.krutlexik.skyfront.drone.MonitorControlEvents;
import dev.krutlexik.skyfront.entity.ModEntities;
import dev.krutlexik.skyfront.entity.ShahedEntity;
import dev.krutlexik.skyfront.network.NetworkHandler;
import dev.krutlexik.skyfront.network.TerminalActionPacket;
import dev.krutlexik.skyfront.network.TerminalDataPacket;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Entry points called from the patched Skyfront classes. */
public final class SeekerHooks {
   public static final int ACTION_CONNECT = 6;
   public static final int STATUS_SEEKER_FLIGHT = 4;

   private SeekerHooks() {
   }

   public static Item seekerItem() {
      return (Item)SeekerRegistry.SEEKER_ITEM.get();
   }

   public static boolean isSeeker(ShahedEntity shahed) {
      return shahed.getType() == SeekerRegistry.SEEKER.get();
   }

   /** LauncherEntity: which shahed does the item in hand turn into. */
   public static ShahedEntity newShahed(ItemStack stack, ServerLevel level) {
      EntityType<ShahedEntity> type = stack.is(seekerItem()) ? (EntityType<ShahedEntity>)SeekerRegistry.SEEKER.get() : (EntityType<ShahedEntity>)ModEntities.SHAHED.get();
      return new ShahedEntity(type, level);
   }

   /** ShahedEntity.toItem: the item the entity packs back into. */
   public static ItemLike itemFor(ShahedEntity shahed) {
      return isSeeker(shahed) ? (ItemLike)SeekerRegistry.SEEKER_ITEM.get() : (ItemLike)dev.krutlexik.skyfront.item.ModItems.SHAHED_136.get();
   }

   /** Terminal row status of a shahed that is neither parked nor falling. */
   public static int flightStatus(ShahedEntity shahed) {
      return isSeeker(shahed) && shahed.getLaunchState() == 0 ? STATUS_SEEKER_FLIGHT : 1;
   }

   /** Server side of TerminalActionPacket; returns true when the packet was ours (action 6). */
   public static boolean onTerminalAction(TerminalActionPacket packet, IPayloadContext ctx) {
      if (packet.action != ACTION_CONNECT) {
         return false;
      }

      if (ctx.player() instanceof ServerPlayer player && player.level() instanceof ServerLevel level) {
         if (!(player.position().distanceToSqr(packet.terminalPos.getCenter()) > 64.0)
            && level.getBlockEntity(packet.terminalPos) instanceof ShahedTerminalBlockEntity terminal) {
            connect(level, player, terminal, packet.uuid);
            NetworkHandler.sendToPlayer(player, TerminalDataPacket.build(level, packet.terminalPos, terminal, false));
         }
      }

      return true;
   }

   private static void say(ServerPlayer player, String key) {
      player.displayClientMessage(Component.translatable(key).withStyle(ChatFormatting.RED), true);
   }

   /** Swap the autonomous seeker for a pilotable airframe in the same spot, same velocity, and hand it to the player. */
   public static void connect(ServerLevel level, ServerPlayer pilot, ShahedTerminalBlockEntity terminal, UUID id) {
      if (terminal.findByUuid(id) == null) {
         return;
      }

      if (!(level.getEntity(id) instanceof ShahedEntity shahed) || !shahed.isAlive() || !isSeeker(shahed)) {
         say(pilot, "msg.sfw.seeker.no_link");
         return;
      }

      if (shahed.getLaunchState() != 0 || shahed.getIsFalling()) {
         say(pilot, "msg.sfw.seeker.not_flying");
         return;
      }

      SeekerDroneEntity drone = (SeekerDroneEntity)((EntityType)SeekerRegistry.SEEKER_DRONE.get()).create(level);
      if (drone == null) {
         return;
      }

      Vec3 pos = shahed.position();
      Vec3 motion = shahed.getDeltaMovement();
      double horizontal = Math.sqrt(motion.x * motion.x + motion.z * motion.z);
      float yaw = horizontal > 1.0E-4 ? (float)(Math.atan2(-motion.x, motion.z) * (180.0 / Math.PI)) : -shahed.getYRot();
      float pitch = horizontal > 1.0E-4 ? (float)(-Math.atan2(motion.y, horizontal) * (180.0 / Math.PI)) : 0.0F;
      shahed.discardAsItem();
      drone.moveTo(pos.x, pos.y, pos.z, yaw, pitch);
      drone.setUUID(id);
      drone.setDeltaMovement(motion);
      drone.setArmed(true);
      level.addFreshEntity(drone);
      MonitorControlEvents.connect(pilot, drone);
   }
}
