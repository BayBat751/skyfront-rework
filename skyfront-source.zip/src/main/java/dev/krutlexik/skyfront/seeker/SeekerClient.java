package dev.krutlexik.skyfront.seeker;

import dev.krutlexik.skyfront.client.renderer.ShahedRenderer;
import dev.krutlexik.skyfront.drone.client.render.DroneRenderer;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.EventBusSubscriber.Bus;
import net.neoforged.neoforge.client.event.EntityRenderersEvent.RegisterRenderers;

@EventBusSubscriber(modid = "sfw", bus = Bus.MOD, value = Dist.CLIENT)
public final class SeekerClient {
   public static final ResourceLocation MODEL = ResourceLocation.fromNamespaceAndPath("sfw", "models/entity/shahed_seeker.glb");

   private SeekerClient() {
   }

   @SubscribeEvent
   public static void registerRenderers(RegisterRenderers event) {
      event.registerEntityRenderer(SeekerRegistry.SEEKER.get(), ShahedRenderer::new);
      event.registerEntityRenderer(
         SeekerRegistry.SEEKER_DRONE.get(), context -> new DroneRenderer<SeekerDroneEntity>(context, MODEL, 1.0F, true, DroneRenderer.fastCruise(-21.1F))
      );
   }
}
