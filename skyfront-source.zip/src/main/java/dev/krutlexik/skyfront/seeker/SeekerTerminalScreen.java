package dev.krutlexik.skyfront.seeker;

import dev.krutlexik.skyfront.client.gui.ShahedTerminalScreen;
import dev.krutlexik.skyfront.client.gui.TerminalButton;
import dev.krutlexik.skyfront.network.NetworkHandler;
import dev.krutlexik.skyfront.network.TerminalActionPacket;
import dev.krutlexik.skyfront.network.TerminalDataPacket;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

/** Terminal screen with a CONNECT button on every flying Shahed-Seeker. */
public class SeekerTerminalScreen extends ShahedTerminalScreen {
   public SeekerTerminalScreen(BlockPos terminalPos, List<TerminalDataPacket.Row> rows, TerminalDataPacket.MapSlot map) {
      super(terminalPos, rows, map);
   }

   @Override
   protected void init() {
      super.init();
      int listTop = this.listTop();
      int right = this.panelLeft() + 340 - 5 - 4;
      int shown = Math.min(6, this.rows.size() - this.scrollOffset);

      for (int i = 0; i < shown; i++) {
         TerminalDataPacket.Row row = this.rows.get(this.scrollOffset + i);
         if (row.status() == SeekerHooks.STATUS_SEEKER_FLIGHT) {
            int y = listTop + i * 24;
            this.addRenderableWidget(
               new TerminalButton(right - 122 - 62, y, 58, 20, Component.translatable("gui.sfw.terminal.connect"), b -> {
                  NetworkHandler.sendToServer(new TerminalActionPacket(this.getTerminalPos(), 6, row.uuid(), new int[0], 0, true));
                  this.minecraft.setScreen(null);
               })
            );
         }
      }
   }
}
