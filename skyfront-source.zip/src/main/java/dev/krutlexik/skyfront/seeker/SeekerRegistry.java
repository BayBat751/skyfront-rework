package dev.krutlexik.skyfront.seeker;

import dev.krutlexik.skyfront.entity.ShahedEntity;
import dev.krutlexik.skyfront.item.ShahedItem;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Registry entries for the Shahed-Seeker (flying shahed + the piloted airframe it turns into). */
public final class SeekerRegistry {
   public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(BuiltInRegistries.ENTITY_TYPE, "sfw");
   public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems("sfw");

   public static final DeferredHolder<EntityType<?>, EntityType<ShahedEntity>> SEEKER = ENTITIES.register(
      "shahed_seeker",
      () -> EntityType.Builder.<ShahedEntity>of(ShahedEntity::new, MobCategory.MISC)
         .sized(3.0F, 1.5F)
         .clientTrackingRange(600)
         .updateInterval(1)
         .setShouldReceiveVelocityUpdates(true)
         .build("shahed_seeker")
   );
   public static final DeferredHolder<EntityType<?>, EntityType<SeekerDroneEntity>> SEEKER_DRONE = ENTITIES.register(
      "shahed_seeker_drone",
      () -> EntityType.Builder.<SeekerDroneEntity>of(SeekerDroneEntity::new, MobCategory.MISC)
         .sized(3.0F, 1.0F)
         .clientTrackingRange(16)
         .updateInterval(1)
         .build("shahed_seeker_drone")
   );
   public static final DeferredItem<Item> SEEKER_ITEM = ITEMS.register("shahed_seeker", () -> new ShahedItem(new Item.Properties()));

   private SeekerRegistry() {
   }

   public static void register(IEventBus bus) {
      ENTITIES.register(bus);
      ITEMS.register(bus);
   }
}
