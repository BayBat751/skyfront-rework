package dev.krutlexik.skyfront.seeker;

import dev.krutlexik.skyfront.drone.GrenadeAttachments;
import dev.krutlexik.skyfront.drone.entity.MolniyaDroneEntity;
import dev.krutlexik.skyfront.entity.DebrisEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;

/**
 * The Shahed-Seeker once a pilot has taken over: a Molniya airframe (stick controls, nose camera,
 * analogue feed, INAV OSD, self-destruct) wearing the Shahed's body, with the Shahed's full dive speed.
 */
public class SeekerDroneEntity extends MolniyaDroneEntity {
   public SeekerDroneEntity(EntityType<? extends SeekerDroneEntity> type, Level level) {
      super(type, level);
   }

   /** 3.6 blocks/tick: the Shahed's dive speed, so taking control never slows it down. */
   @Override
   public double topSpeedKmh() {
      return 259.2;
   }

   @Override
   public double controlRange() {
      return Math.max(super.controlRange(), 4000.0);
   }

   @Override
   public int fullFlightTicks() {
      return 72000;
   }

   @Override
   public ItemStack packedItem() {
      return new ItemStack((ItemLike)SeekerRegistry.SEEKER_ITEM.get());
   }

   @Override
   protected void goOff(ServerLevel level, @Nullable Entity attacker) {
      GrenadeAttachments.detonateWarhead(
         level, this.position(), this, attacker, this.warheadBlast(), this.warheadVehicleDamage(), this.warheadVehicleRadius(), 2
      );
      Quaternionf attitude = this.renderRotation(1.0F);
      if (attitude == null) {
         attitude = new Quaternionf().rotationY((180.0F - this.getYRot()) * (float) (Math.PI / 180.0));
      }

      // debris pieces are modelled nose-to-+z, the drone frame is nose-to--z
      DebrisEntity.burst(level, DebrisEntity.Airframe.SHAHED, this.position(), new Quaternionf(attitude).rotateY((float) Math.PI), this.getDeltaMovement());
   }
}
