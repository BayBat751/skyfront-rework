# Skyfront (sfw) 1.4.0 + Shahed-Seeker: source

Mod id `sfw`, NeoForge, Minecraft 1.21.1, Java 21.

## Layout
- `src/main/java`      – Java sources.
- `src/main/resources` – assets, data, `META-INF/neoforge.mods.toml`, mixin config.

## What is original source and what is decompiled
The original Skyfront project shipped without sources, so everything under `src/main/java`
**except** `dev/krutlexik/skyfront/seeker/` was produced by decompiling the jar (Vineflower).
Decompiled code is readable and faithful, but it is not guaranteed to compile unchanged
(generics, lambdas and synthetic accessors sometimes need small manual fixes).
The `seeker` package is the real hand-written source of the Shahed-Seeker.

## Shahed-Seeker (package `dev.krutlexik.skyfront.seeker`)
- `SeekerRegistry`       – entity types `shahed_seeker` (flying) and `shahed_seeker_drone` (piloted), item `shahed_seeker`.
- `SeekerDroneEntity`    – Molniya airframe with the Shahed body, 259.2 km/h top speed, Shahed debris on detonation.
- `SeekerHooks`          – hook entry points called from patched classes; `connect(...)` swaps the flying shahed for the piloted drone.
- `SeekerTerminalScreen` – terminal screen with a CONNECT button for flying seekers.
- `SeekerClient`/`SeekerEvents` – renderers and creative-tab entry.
- `assets/sfw/models/entity/shahed_seeker.glb` – model assembled from the shahed debris parts (nose to -z, prop node `prop1`).

## Changes made inside existing classes (already visible in the decompiled code)
- `LauncherEntity.interact`        -> `SeekerHooks.newShahed(stack, level)`
- `ShahedEntity.toItem`            -> `SeekerHooks.itemFor(this)`
- `ShahedItem.registerClientExtensions` – also registers the seeker item
- `TerminalActionPacket`           – public fields, early hook for action 6 (connect)
- `TerminalDataPacket.build`       – status 4 for a flying, controllable seeker
- `ShahedTerminalScreen`           – status 4 text/colour, members made public for the subclass
- `ClientProxy`                    – opens `SeekerTerminalScreen`
- `MonitorControlEvents.connect`   – made public
- `ModEntities.register`           – also calls `SeekerRegistry.register(bus)`
- `DroneLongRange.streamRadius()`  – fixed at 8 chunks (was config `longRangeChunkRadius`, default 4)

LICENSE: see `src/main/resources/LICENSE` (the mod's original licence applies).
