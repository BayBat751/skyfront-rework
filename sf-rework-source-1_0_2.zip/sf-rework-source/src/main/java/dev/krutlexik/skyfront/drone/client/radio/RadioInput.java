package dev.krutlexik.skyfront.drone.client.radio;

import dev.krutlexik.skyfront.drone.DroneMod;
import dev.krutlexik.skyfront.drone.radio.RadioProfile;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.List;
import org.lwjgl.glfw.GLFW;

public final class RadioInput {
   private static RadioProfile profile;
   private static int joystick = -1;
   private static long lastScanNanos;
   private static final long RESCAN_NANOS = 1000000000L;
   private static float[] axes = new float[0];
   private static boolean[] buttons = new boolean[0];
   private static double rollSum;
   private static double pitchSum;
   private static double yawSum;
   private static double throttleSum;
   private static double sampleTime;
   private static long lastFrameNanos;
   private static float roll;
   private static float pitch;
   private static float yaw;
   private static float throttle;
   private static boolean throttleSeenLow;
   public static final float THROTTLE_LOW = 0.05F;
   private static boolean armWas;
   private static boolean thermalWas;
   private static boolean selfDestructWas;
   private static float cameraWas = 0.0F / 0.0F;

   public static RadioProfile profile() {
      if (profile == null) {
         profile = RadioStore.load();
      }

      return profile;
   }

   public static void save() {
      RadioStore.save(profile());
   }

   public static List<RadioInput.Device> devices() {
      List<RadioInput.Device> found = new ArrayList<>();

      for (int id = 0; id <= 15; id++) {
         if (GLFW.glfwJoystickPresent(id)) {
            String name = GLFW.glfwGetJoystickName(id);
            String guid = GLFW.glfwGetJoystickGUID(id);
            found.add(new RadioInput.Device(id, name != null ? name : "#" + id, guid != null ? guid : ""));
         }
      }

      return found;
   }

   public static void select(RadioInput.Device device) {
      RadioProfile setup = profile();
      setup.deviceGuid = device.guid();
      setup.deviceName = device.name();
      joystick = device.id();
      throttleSeenLow = false;
      DroneMod.LOGGER.info("Radio set to {} ({})", device.name(), device.guid());
   }

   public static boolean connected() {
      return joystick >= 0;
   }

   public static String deviceName() {
      return profile().deviceName;
   }

   public static boolean active() {
      return profile().enabled && connected();
   }

   public static void poll() {
      RadioProfile setup = profile();
      if (joystick >= 0 && !GLFW.glfwJoystickPresent(joystick)) {
         DroneMod.LOGGER.info("Radio {} unplugged", setup.deviceName);
         joystick = -1;
      }

      if (joystick < 0) {
         long now = System.nanoTime();
         if (now - lastScanNanos < 1000000000L) {
            clearReadings();
            return;
         }

         lastScanNanos = now;
         joystick = find(setup);
         if (joystick < 0) {
            clearReadings();
            return;
         }

         throttleSeenLow = false;
         DroneMod.LOGGER.info("Radio {} found", setup.deviceName);
      }

      FloatBuffer axisBuffer = GLFW.glfwGetJoystickAxes(joystick);
      ByteBuffer buttonBuffer = GLFW.glfwGetJoystickButtons(joystick);
      if (axisBuffer == null) {
         clearReadings();
      } else {
         if (axes.length != axisBuffer.remaining()) {
            axes = new float[axisBuffer.remaining()];
         }

         axisBuffer.get(axes);
         int buttonCount = buttonBuffer != null ? buttonBuffer.remaining() : 0;
         if (buttons.length != buttonCount) {
            buttons = new boolean[buttonCount];
         }

         for (int i = 0; i < buttonCount; i++) {
            buttons[i] = buttonBuffer.get(i) == 1;
         }
      }
   }

   private static int find(RadioProfile setup) {
      if (setup.deviceGuid.isEmpty() && setup.deviceName.isEmpty()) {
         return -1;
      } else {
         int byName = -1;

         for (RadioInput.Device device : devices()) {
            if (!setup.deviceGuid.isEmpty() && device.guid().equals(setup.deviceGuid)) {
               return device.id();
            }

            if (byName < 0 && device.name().equals(setup.deviceName)) {
               byName = device.id();
            }
         }

         return byName;
      }
   }

   private static void clearReadings() {
      if (axes.length != 0) {
         axes = new float[0];
      }

      if (buttons.length != 0) {
         buttons = new boolean[0];
      }
   }

   public static float[] axes() {
      return axes;
   }

   public static boolean[] buttons() {
      return buttons;
   }

   public static void sampleFrame() {
      long now = System.nanoTime();
      double dt = lastFrameNanos == 0L ? 0.0 : Math.min((double)(now - lastFrameNanos) / 1.0E9, 0.2);
      lastFrameNanos = now;
      poll();
      if (active() && !(dt <= 0.0)) {
         RadioProfile setup = profile();
         rollSum = rollSum + (double)setup.stick(setup.roll, axes) * dt;
         pitchSum = pitchSum + (double)setup.stick(setup.pitch, axes) * dt;
         yawSum = yawSum + (double)setup.stick(setup.yaw, axes) * dt;
         throttleSum = throttleSum + (double)setup.throttleOf(axes) * dt;
         sampleTime += dt;
      }
   }

   public static void latchTick() {
      RadioProfile setup = profile();
      if (sampleTime > 1.0E-6) {
         roll = (float)(rollSum / sampleTime);
         pitch = (float)(pitchSum / sampleTime);
         yaw = (float)(yawSum / sampleTime);
         throttle = (float)(throttleSum / sampleTime);
      } else {
         poll();
         roll = setup.stick(setup.roll, axes);
         pitch = setup.stick(setup.pitch, axes);
         yaw = setup.stick(setup.yaw, axes);
         throttle = setup.throttleOf(axes);
      }

      rollSum = 0.0;
      pitchSum = 0.0;
      yawSum = 0.0;
      throttleSum = 0.0;
      sampleTime = 0.0;
      if (throttle <= 0.05F) {
         throttleSeenLow = true;
      }
   }

   public static float roll() {
      return roll;
   }

   public static float pitch() {
      return pitch;
   }

   public static float yaw() {
      return yaw;
   }

   public static float throttle() {
      return throttleSeenLow ? throttle : 0.0F;
   }

   public static boolean throttleLow() {
      return throttle <= 0.05F;
   }

   public static void beginFlight() {
      throttleSeenLow = false;
      rebaseline();
      cameraWas = 0.0F / 0.0F;
   }

   public static void rebaseline() {
      poll();
      RadioProfile setup = profile();
      armWas = setup.auxOn(setup.arm, axes, buttons);
      thermalWas = setup.auxOn(setup.thermal, axes, buttons);
      selfDestructWas = setup.auxOn(setup.selfDestruct, axes, buttons);
      cameraWas = setup.camera.assigned() ? setup.auxLevel(setup.camera, axes) : 0.0F / 0.0F;
   }

   public static int armEdge() {
      RadioProfile setup = profile();
      boolean now = setup.auxOn(setup.arm, axes, buttons);
      int edge = now == armWas ? 0 : (now ? 1 : -1);
      armWas = now;
      return edge;
   }

   public static int thermalEdge() {
      RadioProfile setup = profile();
      boolean now = setup.auxOn(setup.thermal, axes, buttons);
      int edge = now == thermalWas ? 0 : (now ? 1 : -1);
      thermalWas = now;
      return edge;
   }

   public static int selfDestructEdge() {
      RadioProfile setup = profile();
      boolean now = setup.auxOn(setup.selfDestruct, axes, buttons);
      int edge = now == selfDestructWas ? 0 : (now ? 1 : -1);
      selfDestructWas = now;
      return edge;
   }

   public static float cameraMove() {
      RadioProfile setup = profile();
      if (!setup.camera.assigned()) {
         return 0.0F / 0.0F;
      } else {
         float now = setup.auxLevel(setup.camera, axes);
         if (!Float.isNaN(cameraWas) && Math.abs(now - cameraWas) < 0.01F) {
            return 0.0F / 0.0F;
         } else {
            cameraWas = now;
            return now;
         }
      }
   }

   private RadioInput() {
   }

   public static record Device(int id, String name, String guid) {
   }
}
