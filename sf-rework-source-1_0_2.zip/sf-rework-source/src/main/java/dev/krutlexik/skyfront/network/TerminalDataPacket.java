package dev.krutlexik.skyfront.network;

import dev.krutlexik.skyfront.block.entity.ShahedTerminalBlockEntity;
import dev.krutlexik.skyfront.client.ClientProxy;
import dev.krutlexik.skyfront.config.SkyfrontConfig;
import dev.krutlexik.skyfront.entity.ShahedEntity;
import dev.krutlexik.skyfront.seeker.SeekerHooks;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.network.protocol.game.ClientboundMapItemDataPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.MapItem;
import net.minecraft.world.level.saveddata.maps.MapDecoration;
import net.minecraft.world.level.saveddata.maps.MapId;
import net.minecraft.world.level.saveddata.maps.MapItemSavedData;
import net.minecraft.world.level.saveddata.maps.MapItemSavedData.MapPatch;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public class TerminalDataPacket implements CustomPacketPayload {
   public static final Type<TerminalDataPacket> TYPE = new Type(ResourceLocation.fromNamespaceAndPath("sfw", "terminaldatapacket"));
   public static final StreamCodec<RegistryFriendlyByteBuf, TerminalDataPacket> STREAM_CODEC = StreamCodec.ofMember(
      TerminalDataPacket::toBytes, TerminalDataPacket::new
   );
   public static final int STATUS_READY = 0;
   public static final int STATUS_FLIGHT = 1;
   public static final int STATUS_DOWN = 2;
   public static final int STATUS_NO_SIGNAL = 3;
   private final BlockPos terminalPos;
   private final boolean openScreen;
   private final int maxWaypoints;
   private final int minSpacing;
   private final int minLaunchDistance;
   private final int maxAltitude;
   private final boolean whitelistEnabled;
   private final int[] whitelistZones;
   private final boolean blacklistEnabled;
   private final int[] blacklistZones;
   private final List<TerminalDataPacket.Row> rows;
   private final TerminalDataPacket.MapSlot map;

   public TerminalDataPacket(
      BlockPos terminalPos,
      boolean openScreen,
      int maxWaypoints,
      int minSpacing,
      int minLaunchDistance,
      int maxAltitude,
      boolean whitelistEnabled,
      int[] whitelistZones,
      boolean blacklistEnabled,
      int[] blacklistZones,
      List<TerminalDataPacket.Row> rows,
      TerminalDataPacket.MapSlot map
   ) {
      this.terminalPos = terminalPos;
      this.openScreen = openScreen;
      this.maxWaypoints = maxWaypoints;
      this.minSpacing = minSpacing;
      this.minLaunchDistance = minLaunchDistance;
      this.maxAltitude = maxAltitude;
      this.whitelistEnabled = whitelistEnabled;
      this.whitelistZones = whitelistZones;
      this.blacklistEnabled = blacklistEnabled;
      this.blacklistZones = blacklistZones;
      this.rows = rows;
      this.map = map;
   }

   public TerminalDataPacket(RegistryFriendlyByteBuf buf) {
      this.terminalPos = buf.readBlockPos();
      this.openScreen = buf.readBoolean();
      this.maxWaypoints = buf.readVarInt();
      this.minSpacing = buf.readVarInt();
      this.minLaunchDistance = buf.readVarInt();
      this.maxAltitude = buf.readVarInt();
      this.whitelistEnabled = buf.readBoolean();
      this.whitelistZones = buf.readVarIntArray();
      this.blacklistEnabled = buf.readBoolean();
      this.blacklistZones = buf.readVarIntArray();
      int size = buf.readInt();
      this.rows = new ArrayList<>(size);

      for (int i = 0; i < size; i++) {
         this.rows
            .add(
               new TerminalDataPacket.Row(
                  buf.readInt(),
                  buf.readUUID(),
                  buf.readByte(),
                  buf.readInt(),
                  buf.readInt(),
                  buf.readInt(),
                  buf.readInt(),
                  buf.readInt(),
                  buf.readFloat(),
                  buf.readInt(),
                  buf.readBoolean(),
                  buf.readVarIntArray()
               )
            );
      }

      ItemStack mapStack = (ItemStack)ItemStack.OPTIONAL_STREAM_CODEC.decode(buf);
      this.map = mapStack.isEmpty()
         ? TerminalDataPacket.MapSlot.EMPTY
         : new TerminalDataPacket.MapSlot(mapStack, buf.readInt(), buf.readInt(), buf.readByte(), buf.readBoolean());
   }

   public void toBytes(RegistryFriendlyByteBuf buf) {
      buf.writeBlockPos(this.terminalPos);
      buf.writeBoolean(this.openScreen);
      buf.writeVarInt(this.maxWaypoints);
      buf.writeVarInt(this.minSpacing);
      buf.writeVarInt(this.minLaunchDistance);
      buf.writeVarInt(this.maxAltitude);
      buf.writeBoolean(this.whitelistEnabled);
      buf.writeVarIntArray(this.whitelistZones);
      buf.writeBoolean(this.blacklistEnabled);
      buf.writeVarIntArray(this.blacklistZones);
      buf.writeInt(this.rows.size());

      for (TerminalDataPacket.Row row : this.rows) {
         buf.writeInt(row.number());
         buf.writeUUID(row.uuid());
         buf.writeByte(row.status());
         buf.writeInt(row.ex());
         buf.writeInt(row.ey());
         buf.writeInt(row.ez());
         buf.writeInt(row.lx());
         buf.writeInt(row.lz());
         buf.writeFloat(row.yaw());
         buf.writeInt(row.altitude());
         buf.writeBoolean(row.farDive());
         buf.writeVarIntArray(row.route());
      }

      ItemStack.OPTIONAL_STREAM_CODEC.encode(buf, this.map.stack());
      if (!this.map.isEmpty()) {
         buf.writeInt(this.map.centerX());
         buf.writeInt(this.map.centerZ());
         buf.writeByte(this.map.scale());
         buf.writeBoolean(this.map.here());
      }
   }

   public Type<TerminalDataPacket> type() {
      return TYPE;
   }

   public void handle(IPayloadContext ctx) {
      ctx.enqueueWork(
         () -> ClientProxy.handleTerminalData(
               this.terminalPos,
               this.openScreen,
               this.maxWaypoints,
               this.minSpacing,
               this.minLaunchDistance,
               this.maxAltitude,
               this.whitelistEnabled,
               this.whitelistZones,
               this.blacklistEnabled,
               this.blacklistZones,
               this.rows,
               this.map
            )
      );
   }

   public static TerminalDataPacket build(ServerLevel level, BlockPos pos, ShahedTerminalBlockEntity terminal, boolean openScreen) {
      List<TerminalDataPacket.Row> rows = new ArrayList<>();

      for (ShahedTerminalBlockEntity.Entry entry : terminal.getEntries()) {
         int status = 3;
         int ex = 0;
         int ey = 0;
         int ez = 0;
         int lx = pos.getX();
         int lz = pos.getZ();
         float yaw = 0.0F;
         if (level.getEntity(entry.uuid) instanceof ShahedEntity shahed && shahed.isAlive()) {
            ex = (int)Math.round(shahed.getX());
            ey = (int)Math.round(shahed.getY());
            ez = (int)Math.round(shahed.getZ());
            yaw = shahed.getYRot();
            Vec3 origin = shahed.getLaunchOrigin();
            lx = (int)Math.round(origin != null ? origin.x : shahed.getX());
            lz = (int)Math.round(origin != null ? origin.z : shahed.getZ());
            if (shahed.getIsFalling()) {
               status = 2;
            } else if (shahed.isParked()) {
               status = 0;
            } else {
               status = SeekerHooks.flightStatus(shahed);
            }
         }

         rows.add(new TerminalDataPacket.Row(entry.number, entry.uuid, status, ex, ey, ez, lx, lz, yaw, entry.altitude, entry.farDive, entry.route));
      }

      return new TerminalDataPacket(
         pos,
         openScreen,
         SkyfrontConfig.getMaxWaypoints(),
         SkyfrontConfig.getMinWaypointDistance(),
         (Integer)SkyfrontConfig.MIN_LAUNCH_DISTANCE.get(),
         SkyfrontConfig.getMaxAltitude(),
         SkyfrontConfig.isWhitelistEnabled(),
         SkyfrontConfig.packZones((List<? extends String>)SkyfrontConfig.ALLOWED_ZONES.get()),
         SkyfrontConfig.isBlacklistEnabled(),
         SkyfrontConfig.packZones((List<? extends String>)SkyfrontConfig.FORBIDDEN_ZONES.get()),
         rows,
         mapSlot(level, terminal.getMap())
      );
   }

   private static TerminalDataPacket.MapSlot mapSlot(ServerLevel level, ItemStack stack) {
      MapItemSavedData data = stack.isEmpty() ? null : MapItem.getSavedData(stack, level);
      if (data == null) {
         return stack.isEmpty() ? TerminalDataPacket.MapSlot.EMPTY : new TerminalDataPacket.MapSlot(stack, 0, 0, 0, false);
      } else {
         return new TerminalDataPacket.MapSlot(stack, data.centerX, data.centerZ, data.scale, data.dimension == level.dimension());
      }
   }

   public static void sendMapPicture(ServerPlayer player, ServerLevel level, ShahedTerminalBlockEntity terminal) {
      ItemStack stack = terminal.getMap();
      MapId id = stack.isEmpty() ? null : (MapId)stack.get(DataComponents.MAP_ID);
      MapItemSavedData data = id == null ? null : MapItem.getSavedData(id, level);
      if (data != null) {
         List<MapDecoration> decorations = new ArrayList<>();
         data.getDecorations().forEach(decorations::add);
         player.connection
            .send(
               new ClientboundMapItemDataPacket(
                  id, data.scale, data.locked, Optional.of(decorations), Optional.of(new MapPatch(0, 0, 128, 128, (byte[])data.colors.clone()))
               )
            );
      }
   }

   public static record MapSlot(ItemStack stack, int centerX, int centerZ, int scale, boolean here) {
      public static final TerminalDataPacket.MapSlot EMPTY = new TerminalDataPacket.MapSlot(ItemStack.EMPTY, 0, 0, 0, false);

      public boolean isEmpty() {
         return this.stack.isEmpty();
      }
   }

   public static record Row(int number, UUID uuid, int status, int ex, int ey, int ez, int lx, int lz, float yaw, int altitude, boolean farDive, int[] route) {
   }
}
