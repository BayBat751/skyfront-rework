package dev.krutlexik.skyfront.seeker;

import dev.krutlexik.skyfront.client.JetExhaustEffects;
import dev.krutlexik.skyfront.entity.ShahedEntity;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

public final class SeekerFx {
   private static final int BOOSTER_TICKS = 32;
   private static final Map<ShahedEntity, int[]> BOOST = new WeakHashMap<>();

   private SeekerFx() {
   }

   public static void clientTick(ShahedEntity var0) {
      if (var0.level().isClientSide && !var0.isRemoved() && SeekerHooks.is238(var0)) {
         JetExhaustEffects.tick(var0);
      }
   }

   public static void droneTick(Entity var0) {
      if (var0.level().isClientSide && !var0.isRemoved()) {
         SeekerFxClient.droneTick(var0);
      }
   }

   public static boolean boosterLit(ShahedEntity var0) {
      if (!SeekerHooks.is238(var0)) {
         return false;
      } else {
         int var1 = var0.getLaunchState();
         int[] var2 = BOOST.get(var0);
         if (var2 == null) {
            var2 = new int[]{-1, 0};
            BOOST.put(var0, var2);
         }

         boolean var3 = var1 == 2 || var1 == 5;
         if (var3 && var2[0] != 2 && var2[0] != 5) {
            var2[1] = var2[0] == -1 ? var0.tickCount - 1000 : var0.tickCount;
         }

         var2[0] = var1;
         return var3 && var0.tickCount - var2[1] < 32;
      }
   }

   public static Vec3 enginePosition(ShahedEntity var0) {
      double var1 = Math.toRadians((double)var0.getYRot());
      double var3 = Math.toRadians((double)var0.getXRot());
      double var5 = Math.sin(var1) * Math.cos(var3);
      double var7 = Math.sin(var3);
      double var9 = Math.cos(var1) * Math.cos(var3);
      double var11 = -Math.sin(var1) * Math.sin(var3);
      double var13 = Math.cos(var3);
      double var15 = -Math.cos(var1) * Math.sin(var3);
      boolean var17 = SeekerHooks.is238(var0);
      double var18 = var17 ? 2.05 : 2.0;
      double var20 = var17 ? 0.19 : 0.27;
      Vec3 var22 = var0.position();
      return new Vec3(var22.x - var5 * var18 + var11 * var20, var22.y - var7 * var18 + var13 * var20, var22.z - var9 * var18 + var15 * var20);
   }
}
