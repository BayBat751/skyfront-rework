package dev.krutlexik.skyfront.client.sound;

import net.minecraft.world.phys.Vec3;

public final class BoosterSound {
   private BoosterSound() {
   }

   public static BoosterSound lit(Vec3 var0, boolean var1) {
      return null;
   }

   public void burning(Vec3 var1) {
   }

   public void burntOut() {
   }
}
