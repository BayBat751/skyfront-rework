package dev.krutlexik.skyfront.client;

public class ClientWorldMapData {
   private static final ClientWorldMapData INSTANCE = new ClientWorldMapData();
   private int centerChunkX;
   private int centerChunkZ;
   private int radiusChunks;
   private int[] colors;
   private int version;
   private boolean scanComplete;
   private int scanProgress;
   private int totalChunks;

   private ClientWorldMapData() {
   }

   public static ClientWorldMapData getInstance() {
      return INSTANCE;
   }

   public void update(int centerChunkX, int centerChunkZ, int radiusChunks, int[] colors, boolean scanComplete, int scanProgress, int totalChunks) {
      this.centerChunkX = centerChunkX;
      this.centerChunkZ = centerChunkZ;
      this.radiusChunks = radiusChunks;
      this.colors = colors;
      this.scanComplete = scanComplete;
      this.scanProgress = scanProgress;
      this.totalChunks = totalChunks;
      this.version++;
   }

   public int getCenterChunkX() {
      return this.centerChunkX;
   }

   public int getCenterChunkZ() {
      return this.centerChunkZ;
   }

   public int getRadiusChunks() {
      return this.radiusChunks;
   }

   public int[] getColors() {
      return this.colors;
   }

   public int getVersion() {
      return this.version;
   }

   public boolean hasData() {
      return this.colors != null && this.colors.length > 0;
   }

   public boolean isScanComplete() {
      return this.scanComplete;
   }

   public int getScanProgress() {
      return this.scanProgress;
   }

   public int getTotalChunks() {
      return this.totalChunks;
   }

   public float getScanPercent() {
      return this.totalChunks == 0 ? 100.0F : (float)this.scanProgress / (float)this.totalChunks * 100.0F;
   }

   public void clear() {
      this.colors = null;
      this.version++;
   }
}
