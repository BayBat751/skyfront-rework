package dev.krutlexik.skyfront.seeker;

import dev.krutlexik.skyfront.client.renderer.ShahedRenderer;
import dev.krutlexik.skyfront.drone.client.render.DroneRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.EventBusSubscriber.Bus;
import net.neoforged.neoforge.client.event.EntityRenderersEvent.RegisterRenderers;

@EventBusSubscriber(
   modid = "sfw",
   bus = Bus.MOD,
   value = {Dist.CLIENT}
)
public final class SeekerClient {
   public static final ResourceLocation MODEL = ResourceLocation.fromNamespaceAndPath("sfw", "models/entity/shahed_seeker.glb");
   public static final ResourceLocation MODEL_238 = ResourceLocation.fromNamespaceAndPath("sfw", "models/entity/shahed_238.glb");

   private SeekerClient() {
   }

   @SubscribeEvent
   public static void registerRenderers(RegisterRenderers var0) {
      var0.registerEntityRenderer((EntityType)SeekerRegistry.SEEKER.get(), ShahedRenderer::new);
      var0.registerEntityRenderer(
         (EntityType)SeekerRegistry.SEEKER_DRONE.get(), var0x -> new DroneRenderer(var0x, MODEL, 1.0F, true, DroneRenderer.fastCruise(-21.1F))
      );
      var0.registerEntityRenderer((EntityType)SeekerRegistry.SHAHED_238.get(), ShahedRenderer::new);
      var0.registerEntityRenderer(
         (EntityType)SeekerRegistry.SHAHED_238_DRONE.get(), var0x -> new DroneRenderer(var0x, MODEL_238, 1.0F, true, DroneRenderer.fastCruise(-21.1F))
      );
   }
}
