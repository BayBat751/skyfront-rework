package dev.krutlexik.skyfront.drone.client;

import org.jetbrains.annotations.Nullable;

public final class DroneSignalLoss {
   static final int COLOUR_TICKS = 12;
   private static final int GREY_TICKS = 8;
   @Nullable
   private static DroneSignalLoss.Cause cause;
   private static int ticks;

   public static boolean isActive() {
      return cause != null;
   }

   public static boolean isBlanked() {
      return isActive() && ticks >= 12;
   }

   public static boolean showNoSignal() {
      return isActive() && ticks >= 20;
   }

   static int elapsed() {
      return ticks;
   }

   @Nullable
   public static DroneSignalLoss.Cause cause() {
      return cause;
   }

   public static boolean begin(DroneSignalLoss.Cause reason) {
      if (cause != null) {
         return false;
      } else {
         cause = reason;
         ticks = 0;
         return true;
      }
   }

   public static void tick() {
      if (cause != null) {
         ticks++;
      }
   }

   public static void clear() {
      cause = null;
      ticks = 0;
   }

   private DroneSignalLoss() {
   }

   public static enum Cause {
      CRASH,
      OUT_OF_RANGE,
      DESTROYED;

      private Cause() {
      }
   }
}
