package dev.krutlexik.skyfront.drone.client.render;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.client.IItemDecorator;

public final class ThermalBadge implements IItemDecorator {
   private static final int BACK = -267386864;
   private static final int BORDER_TOP = 1347420415;
   private static final int BORDER_BOTTOM = 1344798847;
   private static final int TEXT = -1;
   private static final String WORD = "THERMAL";
   private static final String[][] GLYPHS = new String[][]{
      {"###", ".#.", ".#.", ".#.", ".#."},
      {"#.#", "#.#", "###", "#.#", "#.#"},
      {"##", "#.", "##", "#.", "##"},
      {"##.", "#.#", "##.", "#.#", "#.#"},
      {"#...#", "##.##", "#.#.#", "#...#", "#...#"},
      {".#.", "#.#", "###", "#.#", "#.#"},
      {"#.", "#.", "#.", "#.", "##"}
   };
   private static final int ROWS = 5;
   private static final int[][] RUNS;
   private static final int WIDTH;
   private static final int HEIGHT = 7;

   public ThermalBadge() {
   }

   public boolean render(GuiGraphics graphics, Font font, ItemStack stack, int xOffset, int yOffset) {
      graphics.pose().pushPose();
      graphics.pose().translate((float)xOffset, (float)yOffset, 200.0F);
      graphics.pose().scale(0.5F, 0.5F, 1.0F);
      int right = WIDTH - 1;
      int bottom = 6;
      graphics.fill(1, 0, right, 7, -267386864);
      graphics.fill(0, 1, 1, bottom, -267386864);
      graphics.fill(right, 1, WIDTH, bottom, -267386864);
      graphics.fill(1, 0, right, 1, 1347420415);
      graphics.fill(1, bottom, right, 7, 1344798847);
      graphics.fillGradient(0, 1, 1, bottom, 1347420415, 1344798847);
      graphics.fillGradient(right, 1, WIDTH, bottom, 1347420415, 1344798847);

      for (int[] run : RUNS) {
         graphics.fill(run[0], run[1], run[2], run[1] + 1, -1);
      }

      graphics.pose().popPose();
      return false;
   }

   static {
      List<int[]> runs = new ArrayList<>();
      int x = 1;

      for (String[] glyph : GLYPHS) {
         for (int row = 0; row < 5; row++) {
            String line = glyph[row];
            int start = -1;

            for (int col = 0; col <= line.length(); col++) {
               boolean lit = col < line.length() && line.charAt(col) == '#';
               if (lit && start < 0) {
                  start = col;
               } else if (!lit && start >= 0) {
                  runs.add(new int[]{x + start, 1 + row, x + col});
                  start = -1;
               }
            }
         }

         x += glyph[0].length() + 1;
      }

      RUNS = runs.toArray(new int[0][]);
      WIDTH = x;
   }
}
