package dev.krutlexik.skyfront.compat.sbw;

import dev.krutlexik.skyfront.drone.entity.DroneEntity;
import dev.krutlexik.skyfront.entity.ShahedEntity;
import java.util.List;
import java.util.function.Predicate;

/**
 * Lets Superb Warfare's lock-on weapons (Igla, Javelin, vehicle missiles, ...) pick Skyfront
 * aircraft as targets.
 *
 * SBW's {@code SeekTool.Builder} drops targets that are too low ({@code heightRange}) or too
 * small ({@code sizeBiggerThan}). Mavic/FPV drones fail both, so missiles never lock them.
 * The mixin wraps those two filters so that a flying Skyfront drone always passes them;
 * every other entity is still judged by the original filter.
 *
 * Kept outside the mixin package on purpose: mixin classes cannot be referenced directly.
 */
public final class SbwSeekPatch {
    private SbwSeekPatch() {
    }

    /** A Skyfront aircraft that should be lockable regardless of size / altitude. */
    public static boolean isLockable(Object entity) {
        if (entity instanceof DroneEntity) {
            // a drone that is already falling (shot down) goes back to the normal rules
            return !((DroneEntity) entity).isWrecked();
        }
        return entity instanceof ShahedEntity;
    }

    public static Predicate<Object> orLockable(Predicate<Object> original) {
        return entity -> isLockable(entity) || original.test(entity);
    }

    /**
     * Called after SBW added exactly one filter; wraps that last filter.
     * If the list did not grow by exactly one (different SBW internals), nothing is touched.
     */
    public static void wrapLast(List<Predicate<Object>> filters, int sizeBefore) {
        if (filters == null) {
            return;
        }
        int size = filters.size();
        if (size != sizeBefore + 1) {
            return;
        }
        Predicate<Object> original = filters.get(size - 1);
        if (original == null) {
            return;
        }
        filters.set(size - 1, orLockable(original));
    }
}
