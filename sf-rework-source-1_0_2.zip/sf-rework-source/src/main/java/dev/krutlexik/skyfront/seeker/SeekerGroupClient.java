package dev.krutlexik.skyfront.seeker;

import dev.krutlexik.skyfront.client.gui.GroupStrikeScreen;
import dev.krutlexik.skyfront.client.gui.TerminalButton;
import dev.krutlexik.skyfront.network.TerminalDataPacket;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

public final class SeekerGroupClient {
   private SeekerGroupClient() {
   }

   public static TerminalButton button(SeekerTerminalScreen var0) {
      int var1 = var0.panelLeft() - 10;
      int var2 = Math.max(2, var0.listTop() - 30 - 22);
      TerminalButton var3 = new TerminalButton(
         var1, var2, 360, 18, Component.translatable("gui.sfw.group.open"), var1x -> Minecraft.getInstance().setScreen(new GroupStrikeScreen(var0))
      );
      boolean var4 = false;

      for (TerminalDataPacket.Row var6 : var0.rows) {
         if (var6.status() == 0) {
            var4 = true;
         }
      }

      var3.active = var4;
      return var3.style(TerminalButton.Style.LIT);
   }

   public static boolean intercept(BlockPos var0, List<TerminalDataPacket.Row> var1, TerminalDataPacket.MapSlot var2) {
      if (Minecraft.getInstance().screen instanceof GroupStrikeScreen var4 && var4.getTerminalPos().equals(var0)) {
         var4.updateData(var1, var2);
         return true;
      }

      return false;
   }
}
