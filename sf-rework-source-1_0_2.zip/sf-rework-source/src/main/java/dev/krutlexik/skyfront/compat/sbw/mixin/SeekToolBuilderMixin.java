package dev.krutlexik.skyfront.compat.sbw.mixin;

import dev.krutlexik.skyfront.compat.sbw.SbwSeekPatch;
import java.util.List;
import java.util.function.Predicate;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Superb Warfare: com.atsuishio.superbwarfare.tools.SeekTool$Builder
 * Wraps the filters added by heightRange(min, max) and sizeBiggerThan(size) so Skyfront drones
 * and Shaheds are not rejected for being small / flying low.
 */
@Pseudo
@Mixin(targets = {"com.atsuishio.superbwarfare.tools.SeekTool$Builder"}, remap = false)
public abstract class SeekToolBuilderMixin {
    @Shadow(remap = false)
    @Final
    private List<Predicate<Object>> filters;

    @Unique
    private int sfw$sizeBefore;

    @Inject(method = {"heightRange"}, at = {@At("HEAD")}, require = 0, remap = false)
    private void sfw$heightHead(double min, double max, CallbackInfoReturnable<Object> cir) {
        this.sfw$sizeBefore = this.filters.size();
    }

    @Inject(method = {"heightRange"}, at = {@At("RETURN")}, require = 0, remap = false)
    private void sfw$heightTail(double min, double max, CallbackInfoReturnable<Object> cir) {
        SbwSeekPatch.wrapLast(this.filters, this.sfw$sizeBefore);
    }

    @Inject(method = {"sizeBiggerThan"}, at = {@At("HEAD")}, require = 0, remap = false)
    private void sfw$sizeHead(double size, CallbackInfoReturnable<Object> cir) {
        this.sfw$sizeBefore = this.filters.size();
    }

    @Inject(method = {"sizeBiggerThan"}, at = {@At("RETURN")}, require = 0, remap = false)
    private void sfw$sizeTail(double size, CallbackInfoReturnable<Object> cir) {
        SbwSeekPatch.wrapLast(this.filters, this.sfw$sizeBefore);
    }
}
