package dev.krutlexik.skyfront.drone.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.Tesselator;
import dev.krutlexik.skyfront.drone.client.render.ThermalShaders;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.client.renderer.texture.TextureManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Pseudo
@Mixin(
   targets = {"com.atsuishio.superbwarfare.client.renderer.ModParticleRenderTypes$PARTICLE_SHEET_SOFT_TRANSLUCENT$1", "com.atsuishio.superbwarfare.client.renderer.ModParticleRenderTypes$1"},
   remap = false
)
public class SbwSoftParticleMixin {
   public SbwSoftParticleMixin() {
   }

   @Inject(
      method = {"begin"},
      at = {@At("RETURN")},
      require = 0
   )
   private void sfw$thermal(Tesselator tesselator, TextureManager textures, CallbackInfoReturnable<BufferBuilder> cir) {
      ShaderInstance thermal = ThermalShaders.active() ? ThermalShaders.particle() : null;
      if (thermal != null) {
         RenderSystem.setShader(() -> thermal);
      }
   }
}
