package dev.krutlexik.skyfront.client.gui;

import dev.krutlexik.skyfront.client.ClientWorldMapData;
import dev.krutlexik.skyfront.network.NetworkHandler;
import dev.krutlexik.skyfront.network.RequestRadarUpdatePacket;
import dev.krutlexik.skyfront.network.RequestWorldMapPacket;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ShahedRadarScreen extends Screen {
   private final BlockPos radarPos;
   private static final int MAP_RADIUS = 2000;
   private int droneDetectRadius = 1000;
   private static final int UPDATE_INTERVAL = 60;
   private static final int MAP_UPDATE_INTERVAL = 200;
   private final TerrainMapView mapView = new TerrainMapView(ResourceLocation.fromNamespaceAndPath("sfw", "dynamic/radar_map"));
   private static ShahedRadarScreen currentInstance = null;
   private List<Vec3> shahedPositions = new CopyOnWriteArrayList<>();
   private int tickCounter = 0;
   private int mapTickCounter = 0;
   private float scanAngle = 0.0F;
   private float zoom = 1.0F;
   private float offsetX = 0.0F;
   private float offsetZ = 0.0F;
   private boolean isDragging = false;
   private int lastMouseX;
   private int lastMouseY;

   public ShahedRadarScreen(BlockPos radarPos) {
      super(Component.translatable("gui.sfw.radar.title"));
      this.radarPos = radarPos;
   }

   public static void open(BlockPos pos) {
      ShahedRadarScreen screen = new ShahedRadarScreen(pos);
      currentInstance = screen;
      Minecraft.getInstance().setScreen(screen);
   }

   public static void updateDronePositions(BlockPos radarPos, int detectRange, List<Vec3> positions) {
      if (currentInstance != null && currentInstance.radarPos.equals(radarPos)) {
         currentInstance.droneDetectRadius = detectRange;
         currentInstance.shahedPositions.clear();
         currentInstance.shahedPositions.addAll(positions);
      }
   }

   protected void init() {
      super.init();
      this.requestRadarUpdate();
      this.requestMapUpdate();
   }

   public void removed() {
      super.removed();
      currentInstance = null;
      this.mapView.close();
   }

   public void tick() {
      super.tick();
      if (Minecraft.getInstance().player != null) {
         double distance = Minecraft.getInstance().player.position().distanceTo(Vec3.atCenterOf(this.radarPos));
         if (distance > 7.0) {
            this.onClose();
            return;
         }
      }

      this.tickCounter++;
      this.mapTickCounter++;
      this.scanAngle += 2.0F;
      if (this.scanAngle >= 360.0F) {
         this.scanAngle -= 360.0F;
      }

      if (this.tickCounter >= 60) {
         this.tickCounter = 0;
         this.requestRadarUpdate();
      }

      if (this.mapTickCounter >= 200) {
         this.mapTickCounter = 0;
         this.requestMapUpdate();
      }
   }

   private void requestRadarUpdate() {
      NetworkHandler.sendToServer(new RequestRadarUpdatePacket(this.radarPos));
   }

   private void requestMapUpdate() {
      NetworkHandler.sendToServer(new RequestWorldMapPacket(this.radarPos.getX(), this.radarPos.getZ(), 2000));
   }

   public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
      graphics.fill(0, 0, this.width, this.height, -2013265920);
   }

   public void renderBlurredBackground(float partialTick) {
   }

   public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
      this.renderBackground(graphics, mouseX, mouseY, partialTick);
      int centerX = this.width / 2;
      int centerY = this.height / 2;
      int mapSize = Math.min(this.width, this.height) - 60;
      int mapHalf = mapSize / 2;
      graphics.fill(centerX - mapHalf - 2, centerY - mapHalf - 2, centerX + mapHalf + 2, centerY + mapHalf + 2, -15066578);
      graphics.fill(centerX - mapHalf, centerY - mapHalf, centerX + mapHalf, centerY + mapHalf, -16777216);
      this.renderTerrain(graphics, centerX, centerY, mapHalf);
      this.renderGrid(graphics, centerX, centerY, mapHalf);
      this.renderRadarSweep(graphics, centerX, centerY, mapHalf);
      this.renderDrones(graphics, centerX, centerY, mapHalf, mouseX, mouseY);
      this.renderRadarCenter(graphics, centerX, centerY);
      this.renderUI(graphics, centerX, centerY, mapHalf);
      super.render(graphics, mouseX, mouseY, partialTick);
   }

   private void renderTerrain(GuiGraphics graphics, int centerX, int centerY, int mapHalf) {
      float scale = (float)mapHalf / (2000.0F / this.zoom);
      this.mapView.render(graphics, centerX, centerY, mapHalf, (double)this.radarPos.getX(), (double)this.radarPos.getZ(), scale, this.offsetX, this.offsetZ);
   }

   private void renderGrid(GuiGraphics graphics, int centerX, int centerY, int mapHalf) {
      int gridColor = -15058406;
      float scale = (float)mapHalf / (2000.0F / this.zoom);
      int gridSpacing = 1000;
      int radarX = this.radarPos.getX();
      int radarZ = this.radarPos.getZ();
      int startX = (int)((float)radarX - 2000.0F / this.zoom - this.offsetX);
      int endX = (int)((float)radarX + 2000.0F / this.zoom - this.offsetX);
      int startZ = (int)((float)radarZ - 2000.0F / this.zoom - this.offsetZ);
      int endZ = (int)((float)radarZ + 2000.0F / this.zoom - this.offsetZ);
      startX = startX / gridSpacing * gridSpacing;
      startZ = startZ / gridSpacing * gridSpacing;

      for (int x = startX; x <= endX; x += gridSpacing) {
         float relX = ((float)(x - radarX) + this.offsetX) * scale;
         if (Math.abs(relX) <= (float)mapHalf) {
            int screenX = centerX + (int)relX;
            graphics.vLine(screenX, centerY - mapHalf, centerY + mapHalf, gridColor);
         }
      }

      for (int z = startZ; z <= endZ; z += gridSpacing) {
         float relZ = ((float)(z - radarZ) + this.offsetZ) * scale;
         if (Math.abs(relZ) <= (float)mapHalf) {
            int screenY = centerY + (int)relZ;
            graphics.hLine(centerX - mapHalf, centerX + mapHalf, screenY, gridColor);
         }
      }

      graphics.hLine(centerX - mapHalf, centerX + mapHalf, centerY, -13804995);
      graphics.vLine(centerX, centerY - mapHalf, centerY + mapHalf, -13804995);
   }

   private void renderRadarSweep(GuiGraphics graphics, int centerX, int centerY, int mapHalf) {
      float scale = (float)mapHalf / (2000.0F / this.zoom);
      int droneRadiusOnScreen = (int)((float)this.droneDetectRadius * scale);
      int originX = centerX + (int)(this.offsetX * scale);
      int originY = centerY + (int)(this.offsetZ * scale);
      graphics.enableScissor(centerX - mapHalf, centerY - mapHalf, centerX + mapHalf, centerY + mapHalf);
      if (droneRadiusOnScreen > 10) {
         this.drawCircle(graphics, originX, originY, droneRadiusOnScreen, -13804995);
      }

      double scanRad = Math.toRadians((double)this.scanAngle);
      int scanEndX = originX + (int)(Math.cos(scanRad) * (double)droneRadiusOnScreen);
      int scanEndY = originY - (int)(Math.sin(scanRad) * (double)droneRadiusOnScreen);
      this.drawLine(graphics, originX, originY, scanEndX, scanEndY, -2013200640);
      graphics.disableScissor();
   }

   private void renderDrones(GuiGraphics graphics, int centerX, int centerY, int mapHalf, int mouseX, int mouseY) {
      float scale = (float)mapHalf / (2000.0F / this.zoom);
      int radarX = this.radarPos.getX();
      int radarZ = this.radarPos.getZ();
      graphics.enableScissor(centerX - mapHalf, centerY - mapHalf, centerX + mapHalf, centerY + mapHalf);

      for (Vec3 shahedPos : this.shahedPositions) {
         float relX = (float)(shahedPos.x - (double)radarX + (double)this.offsetX) * scale;
         float relZ = (float)(shahedPos.z - (double)radarZ + (double)this.offsetZ) * scale;
         if (!(Math.abs(relX) > (float)mapHalf) && !(Math.abs(relZ) > (float)mapHalf)) {
            int dotX = centerX + (int)relX;
            int dotY = centerY + (int)relZ;
            int alpha = (int)(200.0 + 55.0 * Math.sin((double)this.tickCounter * 0.3));
            int color = alpha << 24 | 0xFF0000;
            this.drawFilledCircle(graphics, dotX, dotY, 4, color);
            double distance = Math.sqrt(Math.pow(shahedPos.x - (double)radarX, 2.0) + Math.pow(shahedPos.z - (double)radarZ, 2.0));
            if (Math.abs(mouseX - dotX) < 10 && Math.abs(mouseY - dotY) < 10) {
               String distText = Component.translatable("gui.sfw.radar.distance", new Object[]{String.format("%.0f", distance)}).getString();
               graphics.drawString(this.font, distText, dotX + 8, dotY - 4, 16777215);
            }
         }
      }

      graphics.disableScissor();
   }

   private void renderRadarCenter(GuiGraphics graphics, int centerX, int centerY) {
      int mapHalf = (Math.min(this.width, this.height) - 60) / 2;
      float scale = (float)mapHalf / (2000.0F / this.zoom);
      int markerX = centerX + (int)(this.offsetX * scale);
      int markerY = centerY + (int)(this.offsetZ * scale);
      graphics.enableScissor(centerX - mapHalf, centerY - mapHalf, centerX + mapHalf, centerY + mapHalf);
      this.drawFilledCircle(graphics, markerX, markerY, 4, -16711936);
      graphics.drawString(this.font, "R", markerX - 3, markerY - 4, -16777216);
      graphics.disableScissor();
   }

   private void renderUI(GuiGraphics graphics, int centerX, int centerY, int mapHalf) {
      graphics.drawCenteredString(this.font, Component.translatable("gui.sfw.radar.title").getString(), centerX, centerY - mapHalf - 15, 65280);
      String countText = Component.translatable("gui.sfw.radar.detected", new Object[]{this.shahedPositions.size()}).getString();
      graphics.drawCenteredString(this.font, countText, centerX, centerY + mapHalf + 5, 16777215);
      ClientWorldMapData mapData = ClientWorldMapData.getInstance();
      if (!mapData.isScanComplete() && mapData.getTotalChunks() > 0) {
         String scanText = Component.translatable(
               "gui.sfw.radar.scanning", new Object[]{String.format("%.1f", mapData.getScanPercent()), mapData.getScanProgress(), mapData.getTotalChunks()}
            )
            .getString();
         graphics.drawCenteredString(this.font, scanText, centerX, centerY + mapHalf + 17, 16755200);
      }

      String zoomText = Component.translatable("gui.sfw.radar.zoom", new Object[]{String.format("%.1f", this.zoom)}).getString();
      graphics.drawString(this.font, zoomText, 5, 5, 11184810);
      String coordText = Component.translatable("gui.sfw.radar.center", new Object[]{this.radarPos.getX(), this.radarPos.getZ()}).getString();
      graphics.drawString(this.font, coordText, 5, 17, 11184810);
      graphics.drawString(this.font, Component.translatable("gui.sfw.radar.controls").getString(), 5, this.height - 12, 5592405);
   }

   private void drawFilledCircle(GuiGraphics graphics, int centerX, int centerY, int radius, int color) {
      for (int y = -radius; y <= radius; y++) {
         int halfWidth = (int)Math.sqrt((double)(radius * radius - y * y));
         graphics.hLine(centerX - halfWidth, centerX + halfWidth, centerY + y, color);
      }
   }

   private void drawCircle(GuiGraphics graphics, int centerX, int centerY, int radius, int color) {
      int segments = 64;

      for (int i = 0; i < segments; i++) {
         double angle1 = 6.283185307179586 * (double)i / (double)segments;
         double angle2 = 6.283185307179586 * (double)(i + 1) / (double)segments;
         int x1 = centerX + (int)(Math.cos(angle1) * (double)radius);
         int y1 = centerY + (int)(Math.sin(angle1) * (double)radius);
         int x2 = centerX + (int)(Math.cos(angle2) * (double)radius);
         int y2 = centerY + (int)(Math.sin(angle2) * (double)radius);
         this.drawLine(graphics, x1, y1, x2, y2, color);
      }
   }

   private void drawLine(GuiGraphics graphics, int x1, int y1, int x2, int y2, int color) {
      int dx = Math.abs(x2 - x1);
      int dy = Math.abs(y2 - y1);
      int sx = x1 < x2 ? 1 : -1;
      int sy = y1 < y2 ? 1 : -1;
      int err = dx - dy;

      while (true) {
         graphics.fill(x1, y1, x1 + 1, y1 + 1, color);
         if (x1 == x2 && y1 == y2) {
            return;
         }

         int e2 = 2 * err;
         if (e2 > -dy) {
            err -= dy;
            x1 += sx;
         }

         if (e2 < dx) {
            err += dx;
            y1 += sy;
         }
      }
   }

   private float maxPan() {
      return Math.max(0.0F, 2000.0F - 2000.0F / this.zoom);
   }

   private void clampPan() {
      float max = this.maxPan();
      this.offsetX = Mth.clamp(this.offsetX, -max, max);
      this.offsetZ = Mth.clamp(this.offsetZ, -max, max);
   }

   public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
      if (scrollY > 0.0) {
         this.zoom = Math.min(this.zoom * 1.2F, 10.0F);
      } else {
         this.zoom = Math.max(this.zoom / 1.2F, 1.0F);
      }

      this.clampPan();
      return true;
   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      if (button == 0) {
         this.isDragging = true;
         this.lastMouseX = (int)mouseX;
         this.lastMouseY = (int)mouseY;
         return true;
      } else {
         return super.mouseClicked(mouseX, mouseY, button);
      }
   }

   public boolean mouseReleased(double mouseX, double mouseY, int button) {
      if (button == 0) {
         this.isDragging = false;
         return true;
      } else {
         return super.mouseReleased(mouseX, mouseY, button);
      }
   }

   public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
      if (this.isDragging && button == 0) {
         int mapHalf = (Math.min(this.width, this.height) - 60) / 2;
         float scale = (float)mapHalf / (2000.0F / this.zoom);
         this.offsetX += (float)(dragX / (double)scale);
         this.offsetZ += (float)(dragY / (double)scale);
         this.clampPan();
         return true;
      } else {
         return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
      }
   }

   public boolean isPauseScreen() {
      return false;
   }
}
