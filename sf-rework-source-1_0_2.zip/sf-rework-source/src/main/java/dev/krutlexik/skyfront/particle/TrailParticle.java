package dev.krutlexik.skyfront.particle;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.TextureSheetParticle;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public abstract class TrailParticle extends TextureSheetParticle {
   private float appearAt;

   protected TrailParticle(ClientLevel level, double x, double y, double z) {
      super(level, x, y, z);
   }

   public TrailParticle appearAt(float share) {
      this.appearAt = share;
      return this;
   }

   public void render(VertexConsumer buffer, Camera camera, float partialTicks) {
      if (this.age != 0 || !(partialTicks < this.appearAt)) {
         super.render(buffer, camera, partialTicks);
      }
   }
}
