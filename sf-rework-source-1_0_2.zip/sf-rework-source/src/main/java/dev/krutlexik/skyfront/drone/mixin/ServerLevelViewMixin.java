package dev.krutlexik.skyfront.drone.mixin;

import dev.krutlexik.skyfront.drone.DroneLinks;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundExplodePacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.ExplosionDamageCalculator;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({ServerLevel.class})
public abstract class ServerLevelViewMixin {
   private static final double SFW_EXPLOSION_REACH_SQR = 4096.0;

   public ServerLevelViewMixin() {
   }

   @Inject(
      method = {"explode(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/damagesource/DamageSource;Lnet/minecraft/world/level/ExplosionDamageCalculator;DDDFZLnet/minecraft/world/level/Level$ExplosionInteraction;Lnet/minecraft/core/particles/ParticleOptions;Lnet/minecraft/core/particles/ParticleOptions;Lnet/minecraft/core/Holder;)Lnet/minecraft/world/level/Explosion;"},
      at = {@At("RETURN")}
   )
   private void sfw$explosionSeenFromDrone(
      @Nullable Entity source,
      @Nullable DamageSource damageSource,
      @Nullable ExplosionDamageCalculator damageCalculator,
      double x,
      double y,
      double z,
      float radius,
      boolean fire,
      ExplosionInteraction interaction,
      ParticleOptions small,
      ParticleOptions large,
      Holder<SoundEvent> sound,
      CallbackInfoReturnable<Explosion> cir
   ) {
      Explosion explosion = (Explosion)cir.getReturnValue();
      DroneLinks.forEachPilotView(
         (pilot, view) -> {
            if (pilot.level() == this && pilot.distanceToSqr(x, y, z) >= 4096.0 && view.distanceToSqr(x, y, z) < 4096.0) {
               pilot.connection
                  .send(
                     new ClientboundExplodePacket(
                        x,
                        y,
                        z,
                        radius,
                        explosion.getToBlow(),
                        (Vec3)explosion.getHitPlayers().get(pilot),
                        explosion.getBlockInteraction(),
                        explosion.getSmallExplosionParticles(),
                        explosion.getLargeExplosionParticles(),
                        explosion.getExplosionSound()
                     )
                  );
            }
         }
      );
   }

   @Inject(
      method = {"sendParticles(Lnet/minecraft/server/level/ServerPlayer;ZDDDLnet/minecraft/network/protocol/Packet;)Z"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void sfw$particlesSeenFromDrone(
      ServerPlayer player, boolean longDistance, double x, double y, double z, Packet<?> packet, CallbackInfoReturnable<Boolean> cir
   ) {
      if (player.level() == this) {
         Vec3 view = DroneLinks.pilotView(player);
         double reach = longDistance ? 512.0 : 32.0;
         if (view != null && view.distanceToSqr(x, y, z) < reach * reach) {
            player.connection.send(packet);
            cir.setReturnValue(true);
         }
      }
   }
}
