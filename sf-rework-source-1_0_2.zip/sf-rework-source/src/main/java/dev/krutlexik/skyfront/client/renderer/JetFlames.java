package dev.krutlexik.skyfront.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import dev.krutlexik.skyfront.client.JetExhaustEffects;
import dev.krutlexik.skyfront.entity.ShahedEntity;
import dev.krutlexik.skyfront.seeker.SeekerFx;
import dev.krutlexik.skyfront.seeker.SeekerHooks;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.joml.Quaternionf;

@OnlyIn(Dist.CLIENT)
public final class JetFlames {
   private static final RenderType GLOW = RenderType.eyes(ResourceLocation.fromNamespaceAndPath("sfw", "textures/effect/exhaust_glow.png"));
   private static final float[][] PLUME = new float[][]{
      {0.05F, 0.95F, 1.0F, 0.98F, 0.9F, 1.0F},
      {0.45F, 1.15F, 1.0F, 0.9F, 0.62F, 0.95F},
      {0.95F, 1.05F, 1.0F, 0.75F, 0.4F, 0.85F},
      {1.55F, 0.9F, 1.0F, 0.6F, 0.25F, 0.7F},
      {2.2F, 0.72F, 1.0F, 0.48F, 0.16F, 0.5F},
      {2.9F, 0.52F, 0.95F, 0.38F, 0.1F, 0.32F}
   };

   private JetFlames() {
   }

   public static void render(ShahedEntity jet, float partialTick, PoseStack poseStack, MultiBufferSource buffers, Quaternionf camera, Vec3 cameraPos) {
      if (jet.getLaunchState() != 1 && !jet.getIsFalling()) {
         float yaw = Mth.rotLerp(partialTick, jet.yRotO, jet.getYRot());
         float pitch = Mth.lerp(partialTick, jet.xRotO, jet.getXRot());
         Vec3 nose = JetExhaustEffects.nose(yaw, pitch);
         Vec3 top = JetExhaustEffects.top(yaw, pitch);
         VertexConsumer buffer = buffers.getBuffer(GLOW);
         if (SeekerFx.boosterLit(jet)) {
            int age = Math.max(0, JetExhaustEffects.boosterAge(jet));
            float rise = Mth.clamp(((float)age + partialTick) / 3.0F, 0.25F, 1.0F);
            float fall = Mth.clamp(((float)(32 - age) - partialTick) / 4.0F, 0.3F, 1.0F);
            float power = rise * fall;
            Vec3 nozzle = JetExhaustEffects.boosterNozzle(nose, top);
            Vec3 blast = JetExhaustEffects.boosterBlast(nose, top);
            quad(buffer, poseStack, camera, nozzle.add(blast.scale(0.8)), 3.6F * power, 1.0F, 0.55F, 0.22F, 0.3F * power);

            for (int i = 0; i < PLUME.length; i++) {
               float[] glow = PLUME[i];
               float flicker = 0.82F + 0.36F * noise(jet.tickCount, i);
               quad(
                  buffer,
                  poseStack,
                  camera,
                  nozzle.add(blast.scale((double)(glow[0] * power * flicker))),
                  glow[1] * flicker * (0.6F + 0.4F * power),
                  glow[2],
                  glow[3],
                  glow[4],
                  glow[5] * power
               );
            }
         } else if (SeekerHooks.is238(jet)) {
            Vec3 nozzle = JetExhaustEffects.engineNozzle(nose, top);
            Vec3 back = nose.scale(-1.0);
            Vec3 toCamera = cameraPos.subtract(jet.getPosition(partialTick).add(nozzle)).normalize();
            float facing = (float)Math.max(0.0, toCamera.dot(back));
            float glow = 0.25F + 0.75F * facing;
            quad(buffer, poseStack, camera, nozzle.add(back.scale(0.05)), 0.62F, 1.0F, 0.38F, 0.1F, 0.45F * glow);
            quad(buffer, poseStack, camera, nozzle, 0.28F, 1.0F, 0.7F, 0.35F, 0.55F * glow);
         }
      }
   }

   private static void quad(
      VertexConsumer buffer, PoseStack poseStack, Quaternionf camera, Vec3 at, float size, float red, float green, float blue, float brightness
   ) {
      int r = Mth.clamp((int)(red * brightness * 255.0F), 0, 255);
      int g = Mth.clamp((int)(green * brightness * 255.0F), 0, 255);
      int b = Mth.clamp((int)(blue * brightness * 255.0F), 0, 255);
      float half = size * 0.5F;
      poseStack.pushPose();
      poseStack.translate(at.x, at.y, at.z);
      poseStack.mulPose(camera);
      Pose pose = poseStack.last();
      vertex(buffer, pose, -half, -half, 0.0F, 1.0F, r, g, b);
      vertex(buffer, pose, half, -half, 1.0F, 1.0F, r, g, b);
      vertex(buffer, pose, half, half, 1.0F, 0.0F, r, g, b);
      vertex(buffer, pose, -half, half, 0.0F, 0.0F, r, g, b);
      poseStack.popPose();
   }

   private static void vertex(VertexConsumer buffer, Pose pose, float x, float y, float u, float v, int r, int g, int b) {
      buffer.addVertex(pose, x, y, 0.0F)
         .setColor(r, g, b, 255)
         .setUv(u, v)
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(15728880)
         .setNormal(pose, 0.0F, 1.0F, 0.0F);
   }

   private static float noise(int tick, int index) {
      int h = tick * 374761393 + index * 668265263;
      h = (h ^ h >>> 13) * 1274126177;
      return (float)((h ^ h >>> 16) & 65535) / 65535.0F;
   }
}
