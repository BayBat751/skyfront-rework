package dev.krutlexik.skyfront.client.model;

import dev.krutlexik.skyfront.entity.ShahedEntity;
import dev.krutlexik.skyfront.seeker.SeekerHooks;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import software.bernie.geckolib.model.GeoModel;

@OnlyIn(Dist.CLIENT)
public class ShahedModel extends GeoModel<ShahedEntity> {
   public ShahedModel() {
   }

   public ResourceLocation getModelResource(ShahedEntity entity) {
      return ResourceLocation.fromNamespaceAndPath("sfw", SeekerHooks.geoPath(entity));
   }

   public ResourceLocation getTextureResource(ShahedEntity entity) {
      return ResourceLocation.fromNamespaceAndPath("sfw", SeekerHooks.texPath(entity));
   }

   public ResourceLocation getAnimationResource(ShahedEntity entity) {
      return ResourceLocation.fromNamespaceAndPath("sfw", "animations/shahed.animation.json");
   }
}
