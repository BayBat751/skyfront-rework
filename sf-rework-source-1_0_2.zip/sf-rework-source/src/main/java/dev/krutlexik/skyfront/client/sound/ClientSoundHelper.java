package dev.krutlexik.skyfront.client.sound;

import dev.krutlexik.skyfront.entity.ShahedEntity;
import net.minecraft.client.Minecraft;

public class ClientSoundHelper {
   public ClientSoundHelper() {
   }

   public static void startShahedSound(ShahedEntity entity) {
      Minecraft.getInstance().getSoundManager().play(new ShahedSoundInstance(entity));
   }
}
