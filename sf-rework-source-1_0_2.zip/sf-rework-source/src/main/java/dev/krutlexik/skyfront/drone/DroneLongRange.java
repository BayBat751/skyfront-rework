package dev.krutlexik.skyfront.drone;

import dev.krutlexik.skyfront.drone.entity.DroneEntity;
import dev.krutlexik.skyfront.drone.entity.DroneFlightState;
import dev.krutlexik.skyfront.drone.network.DroneLinkPayload;
import dev.krutlexik.skyfront.seeker.SeekerChunks;
import it.unimi.dsi.fastutil.ints.IntIterator;
import it.unimi.dsi.fastutil.ints.IntOpenHashSet;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.game.ClientboundLevelChunkWithLightPacket;
import net.minecraft.network.protocol.game.ClientboundSetChunkCacheCenterPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;
import net.neoforged.neoforge.network.PacketDistributor;
import org.jetbrains.annotations.Nullable;

public final class DroneLongRange {
   private static final int REFRESH_TICKS = 2;
   private static final int CHUNK_BUDGET = 10;
   private static final Map<UUID, DroneLongRange.Feed> FEEDS = new ConcurrentHashMap<>();
   private static final Map<UUID, DroneLongRange.Reseed> RESEEDS = new HashMap<>();
   private static final int ENTITY_RESCAN_TICKS = 5;
   private static final int ENTITY_STREAM_CHUNKS = 16;

   public static int streamRadius() {
      return 8;
   }

   public static int loadedRadius() {
      return streamRadius() + 1;
   }

   private DroneLongRange() {
   }

   public static void tick(DroneEntity drone, ServerPlayer pilot) {
      try {
         if (pilot.connection.hasChannel(DroneLinkPayload.TYPE)) {
            DroneFlightState state = new DroneFlightState();
            drone.captureFlightState(state);
            PacketDistributor.sendToPlayer(
               pilot,
               new DroneLinkPayload(drone.getId(), BuiltInRegistries.ENTITY_TYPE.getId(drone.getType()), drone.linkAckSeq(), state),
               new CustomPacketPayload[0]
            );
         }

         if (drone.needsLongRangeLink() && drone.level() instanceof ServerLevel level && pilot.level() == level) {
            RESEEDS.remove(pilot.getUUID());
            DroneLongRange.Feed feed = FEEDS.get(pilot.getUUID());
            if (feed == null || feed.drone != drone) {
               if (feed != null) {
                  endFeed(pilot, feed);
               }

               feed = new DroneLongRange.Feed(drone, level);
               FEEDS.put(pilot.getUUID(), feed);
            }

            if (drone.tickCount % 1 == 0) {
               streamChunks(feed, pilot);
            }

            if (drone.tickCount % 5 == 0) {
               rescanEntities(feed, pilot);
            }
         }
      } catch (Throwable var4) {
         DroneMod.LOGGER.error("Long-range link tick failed for drone {}", drone.getId(), var4);
      }
   }

   public static boolean streams(ServerPlayer player, ServerLevel level, int x, int z) {
      if (FEEDS.isEmpty()) {
         return false;
      } else {
         DroneLongRange.Feed feed = FEEDS.get(player.getUUID());
         return feed != null && feed.level == level && feed.held.contains(ChunkPos.asLong(x, z));
      }
   }

   public static boolean shows(ServerPlayer player, Entity entity, boolean alreadyShown) {
      if (FEEDS.isEmpty()) {
         return false;
      } else {
         DroneLongRange.Feed feed = FEEDS.get(player.getUUID());
         return feed != null && feed.shows(player, entity, alreadyShown);
      }
   }

   private static void rescanEntities(DroneLongRange.Feed feed, ServerPlayer pilot) {
      DroneEntity drone = feed.drone;
      ServerLevel level = feed.level;
      double reach = 288.0;
      AABB around = new AABB(
         drone.getX() - reach,
         (double)level.getMinBuildHeight() - 64.0,
         drone.getZ() - reach,
         drone.getX() + reach,
         (double)level.getMaxBuildHeight() + 64.0,
         drone.getZ() + reach
      );
      IntOpenHashSet now = new IntOpenHashSet();

      for (Entity other : level.getEntities((Entity)null, around, entity -> true)) {
         TrackerAccess.Entry tracked = TrackerAccess.tracked(level, other.getId());
         if (tracked != null) {
            boolean seen = tracked.sfw$seenBy().contains(pilot.connection);
            if (feed.shows(pilot, other, seen)) {
               now.add(other.getId());
               if (!seen) {
                  tracked.sfw$updatePlayer(pilot);
               }
            }
         }
      }

      IntOpenHashSet left = feed.shown;
      feed.shown = now;
      left.removeAll(now);
      IntIterator var13 = left.iterator();

      while (var13.hasNext()) {
         int id = (Integer)var13.next();
         TrackerAccess.Entry tracked = TrackerAccess.tracked(level, id);
         if (tracked != null) {
            tracked.sfw$updatePlayer(pilot);
         }
      }
   }

   private static boolean worthShowing(Entity entity) {
      return !entity.isRemoved() && !entity.isSpectator() && !(entity instanceof ItemEntity) && !(entity instanceof ExperienceOrb);
   }

   private static void streamChunks(DroneLongRange.Feed feed, ServerPlayer pilot) {
      ServerLevel level = feed.level;
      LongOpenHashSet held = feed.held;
      ChunkPos centre = SeekerChunks.streamCentre(feed.drone);
      pilot.connection.send(new ClientboundSetChunkCacheCenterPacket(centre.x, centre.z));
      feed.tookGrid = true;
      LongOpenHashSet wanted = new LongOpenHashSet();
      List<Long> fresh = new ArrayList<>();
      int radius = streamRadius();

      for (int dx = -radius; dx <= radius; dx++) {
         for (int dz = -radius; dz <= radius; dz++) {
            long chunk = ChunkPos.asLong(centre.x + dx, centre.z + dz);
            wanted.add(chunk);
            if (!held.contains(chunk)) {
               fresh.add(chunk);
            }
         }
      }

      fresh.sort(Comparator.comparingLong(chunkx -> distanceSqr(chunkx, centre)));
      held.removeIf(chunkx -> !wanted.contains(chunkx));
      int budget = SeekerChunks.budget(feed.drone);

      for (long chunk : fresh) {
         LevelChunk loaded = level.getChunkSource().getChunkNow(ChunkPos.getX(chunk), ChunkPos.getZ(chunk));
         if (loaded != null) {
            sendChunk(pilot, level, loaded);
            held.add(chunk);
            if (--budget <= 0) {
               break;
            }
         }
      }
   }

   public static void release(DroneEntity drone, @Nullable ServerPlayer pilot) {
      if (pilot == null) {
         FEEDS.values().removeIf(feedx -> feedx.drone == drone);
      } else {
         DroneLongRange.Feed feed = FEEDS.get(pilot.getUUID());
         if (feed != null && feed.drone == drone) {
            endFeed(pilot, feed);
         }
      }
   }

   private static void endFeed(ServerPlayer pilot, DroneLongRange.Feed feed) {
      FEEDS.remove(pilot.getUUID(), feed);
      if (!pilot.hasDisconnected() && pilot.level() == feed.level) {
         IntIterator failure = feed.shown.iterator();

         while (failure.hasNext()) {
            int id = (Integer)failure.next();

            try {
               TrackerAccess.Entry tracked = TrackerAccess.tracked(feed.level, id);
               if (tracked != null) {
                  tracked.sfw$updatePlayer(pilot);
               }
            } catch (Throwable var6) {
               DroneMod.LOGGER.error("Could not hand a streamed entity back to the tracker for {}", pilot.getGameProfile().getName(), var6);
            }
         }

         if (feed.tookGrid) {
            try {
               queueReseed(pilot, feed.level);
            } catch (Throwable var5) {
               DroneMod.LOGGER.error("Long-range link tear-down failed for {}", pilot.getGameProfile().getName(), var5);
            }
         }
      }
   }

   private static void queueReseed(ServerPlayer pilot, ServerLevel level) {
      ChunkPos home = pilot.chunkPosition();
      pilot.connection.send(new ClientboundSetChunkCacheCenterPacket(home.x, home.z));
      int view = Math.max(2, pilot.server.getPlayerList().getViewDistance());
      List<Long> box = new ArrayList<>();

      for (int dx = -view; dx <= view; dx++) {
         for (int dz = -view; dz <= view; dz++) {
            box.add(ChunkPos.asLong(home.x + dx, home.z + dz));
         }
      }

      box.sort(Comparator.comparingLong(chunk -> distanceSqr(chunk, home)));
      RESEEDS.put(pilot.getUUID(), new DroneLongRange.Reseed(pilot.getUUID(), new ArrayDeque<>(box)));
   }

   public static void serverTick(MinecraftServer server) {
      if (!RESEEDS.isEmpty()) {
         RESEEDS.values().removeIf(reseed -> {
            try {
               ServerPlayer pilot = server.getPlayerList().getPlayer(reseed.player);
               if (pilot != null && !pilot.hasDisconnected() && pilot.level() instanceof ServerLevel level) {
                  int budget = 10;

                  while (budget > 0 && !reseed.pending.isEmpty()) {
                     long chunk = reseed.pending.poll();
                     LevelChunk loaded = level.getChunkSource().getChunkNow(ChunkPos.getX(chunk), ChunkPos.getZ(chunk));
                     if (loaded != null) {
                        sendChunk(pilot, level, loaded);
                        budget--;
                     }
                  }

                  return reseed.pending.isEmpty();
               } else {
                  return true;
               }
            } catch (Throwable var8) {
               DroneMod.LOGGER.error("Long-range reseed failed", var8);
               return true;
            }
         });
      }
   }

   private static long distanceSqr(long chunk, ChunkPos from) {
      long dx = (long)(ChunkPos.getX(chunk) - from.x);
      long dz = (long)(ChunkPos.getZ(chunk) - from.z);
      return dx * dx + dz * dz;
   }

   private static void sendChunk(ServerPlayer pilot, ServerLevel level, LevelChunk chunk) {
      pilot.connection.send(new ClientboundLevelChunkWithLightPacket(chunk, level.getLightEngine(), null, null));
   }

   private static final class Feed {
      private final DroneEntity drone;
      private final ServerLevel level;
      private final LongOpenHashSet held = new LongOpenHashSet();
      private IntOpenHashSet shown = new IntOpenHashSet();
      private boolean tookGrid;

      private Feed(DroneEntity drone, ServerLevel level) {
         this.drone = drone;
         this.level = level;
      }

      private boolean shows(ServerPlayer pilot, Entity entity, boolean alreadyShown) {
         if (this.drone.isRemoved() || entity.level() != this.level || pilot.level() != this.level) {
            return false;
         } else if (entity == this.drone) {
            return true;
         } else if (entity != pilot && DroneLongRange.worthShowing(entity)) {
            int reach = 16 + (alreadyShown ? 1 : 0);
            ChunkPos at = entity.chunkPosition();
            ChunkPos centre = this.drone.chunkPosition();
            return Math.abs(at.x - centre.x) <= reach && Math.abs(at.z - centre.z) <= reach;
         } else {
            return false;
         }
      }
   }

   private static final class Reseed {
      private final UUID player;
      private final Deque<Long> pending;

      private Reseed(UUID player, Deque<Long> pending) {
         this.player = player;
         this.pending = pending;
      }
   }
}
