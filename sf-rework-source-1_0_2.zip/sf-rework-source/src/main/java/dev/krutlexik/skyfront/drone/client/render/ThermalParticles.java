package dev.krutlexik.skyfront.drone.client.render;

import java.util.Map;
import net.minecraft.client.particle.Particle;

public final class ThermalParticles {
   private static final Map<String, ThermalParticles.Kind> NAMED = Map.ofEntries(
      Map.entry("net.minecraft.client.particle.HugeExplosionParticle", ThermalParticles.Kind.FLASH),
      Map.entry("net.minecraft.client.particle.ExplodeParticle", ThermalParticles.Kind.SMOKE),
      Map.entry("net.minecraft.client.particle.FlameParticle", ThermalParticles.Kind.FIRE),
      Map.entry("net.minecraft.client.particle.LavaParticle", ThermalParticles.Kind.FIRE),
      Map.entry("net.minecraft.client.particle.FireworkParticles$SparkParticle", ThermalParticles.Kind.FIRE),
      Map.entry("net.minecraft.client.particle.FireworkParticles$OverlayParticle", ThermalParticles.Kind.FLASH),
      Map.entry("net.minecraft.client.particle.PlayerCloudParticle", ThermalParticles.Kind.SMOKE),
      Map.entry("net.minecraft.client.particle.SmokeParticle", ThermalParticles.Kind.SMOKE),
      Map.entry("net.minecraft.client.particle.CampfireSmokeParticle", ThermalParticles.Kind.SMOKE),
      Map.entry("dev.krutlexik.skyfront.particle.FlashParticle", ThermalParticles.Kind.FLASH),
      Map.entry("dev.krutlexik.skyfront.particle.EmberParticle", ThermalParticles.Kind.FIRE),
      Map.entry("dev.krutlexik.skyfront.particle.BlackSmokeParticle", ThermalParticles.Kind.SMOKE),
      Map.entry("dev.krutlexik.skyfront.particle.ShrapnelParticle", ThermalParticles.Kind.FRAGMENT),
      Map.entry("dev.krutlexik.skyfront.particle.DebrisParticle", ThermalParticles.Kind.FRAGMENT),
      Map.entry("com.atsuishio.superbwarfare.client.particle.CustomFlareParticle", ThermalParticles.Kind.FLASH),
      Map.entry("com.atsuishio.superbwarfare.client.particle.CannonMuzzleFlareParticle", ThermalParticles.Kind.FLASH),
      Map.entry("com.atsuishio.superbwarfare.client.particle.FireStarParticle", ThermalParticles.Kind.FIRE),
      Map.entry("com.atsuishio.superbwarfare.client.particle.WhiteStarParticle", ThermalParticles.Kind.FIRE),
      Map.entry("com.atsuishio.superbwarfare.client.particle.CustomCloudParticle", ThermalParticles.Kind.SMOKE),
      Map.entry("com.atsuishio.superbwarfare.client.particle.CustomSmokeParticle", ThermalParticles.Kind.SMOKE),
      Map.entry("com.atsuishio.superbwarfare.client.particle.RisingSmokeParticle", ThermalParticles.Kind.SMOKE),
      Map.entry("com.atsuishio.superbwarfare.client.particle.ExplosionDebrisParticle", ThermalParticles.Kind.FRAGMENT)
   );
   private static final ClassValue<ThermalParticles.Kind> KINDS = new ClassValue<ThermalParticles.Kind>() {
      protected ThermalParticles.Kind computeValue(Class<?> type) {
         for (Class<?> c = type; c != null && c != Object.class; c = c.getSuperclass()) {
            ThermalParticles.Kind kind = ThermalParticles.NAMED.get(c.getName());
            if (kind != null) {
               return kind;
            }
         }

         return ThermalParticles.Kind.COLD;
      }
   };

   public static float heat(Particle particle, int age, int lifetime) {
      float life = lifetime > 0 ? Math.min(1.0F, Math.max(0.0F, (float)age / (float)lifetime)) : 0.0F;

      return switch ((ThermalParticles.Kind)KINDS.get(particle.getClass())) {
         case FLASH -> 1.0F;
         case FIRE -> 0.97F;
         case SMOKE -> 0.98F - 0.14F * life;
         case FRAGMENT -> 0.96F - 0.18F * life;
         case COLD -> 0.0F;
      };
   }

   public static boolean mottled(Particle particle) {
      ThermalParticles.Kind kind = KINDS.get(particle.getClass());
      return kind == ThermalParticles.Kind.SMOKE || kind == ThermalParticles.Kind.FRAGMENT;
   }

   private ThermalParticles() {
   }

   private static enum Kind {
      FLASH,
      FIRE,
      SMOKE,
      FRAGMENT,
      COLD;

      private Kind() {
      }
   }
}
