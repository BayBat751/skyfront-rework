package dev.krutlexik.skyfront.drone.client.render;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat.Mode;
import java.util.IdentityHashMap;
import java.util.Map;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.RenderType.CompositeState;

public abstract class ThermalRenderTypes extends RenderType {
   private static final int BUFFER_SIZE = 1536;
   public static final RenderType HEAT_MASK = create(
      "thermal_heat_mask",
      DefaultVertexFormat.POSITION_COLOR,
      Mode.QUADS,
      1536,
      false,
      false,
      CompositeState.builder()
         .setShaderState(POSITION_COLOR_SHADER)
         .setTransparencyState(NO_TRANSPARENCY)
         .setDepthTestState(NO_DEPTH_TEST)
         .setCullState(NO_CULL)
         .setWriteMaskState(COLOR_WRITE)
         .createCompositeState(false)
   );
   private static final Map<RenderType, RenderType> MASK_TYPES = new IdentityHashMap<>();
   public static final RenderType HEAT = create(
      "thermal_heat",
      DefaultVertexFormat.POSITION_COLOR,
      Mode.QUADS,
      1536,
      false,
      true,
      CompositeState.builder()
         .setShaderState(POSITION_COLOR_SHADER)
         .setTransparencyState(TRANSLUCENT_TRANSPARENCY)
         .setDepthTestState(NO_DEPTH_TEST)
         .setCullState(NO_CULL)
         .setWriteMaskState(COLOR_WRITE)
         .createCompositeState(false)
   );

   public static RenderType maskTypeOf(RenderType original) {
      return MASK_TYPES.computeIfAbsent(original, type -> new RenderType("thermal_mask", type.format(), type.mode(), type.bufferSize(), false, false, () -> {
            type.setupRenderState();
            RenderSystem.setShader(ThermalShaders::mask);
            RenderSystem.disableBlend();
            RenderSystem.disableDepthTest();
            RenderSystem.disableCull();
            RenderSystem.colorMask(true, true, true, true);
         }, type::clearRenderState) {
         });
   }

   public static void clearMaskTypes() {
      MASK_TYPES.clear();
   }

   private ThermalRenderTypes() {
      super("thermal_holder", DefaultVertexFormat.POSITION_COLOR, Mode.QUADS, 1536, false, false, () -> {
      }, () -> {
      });
      throw new UnsupportedOperationException("holder class");
   }
}
