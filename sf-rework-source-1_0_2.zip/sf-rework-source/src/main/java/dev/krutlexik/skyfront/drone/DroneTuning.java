package dev.krutlexik.skyfront.drone;

import dev.krutlexik.skyfront.config.SkyfrontConfig;
import java.util.function.Supplier;
import org.jetbrains.annotations.Nullable;

public final class DroneTuning {
   private static final DroneTuning.Value[] VALUES = DroneTuning.Value.values();
   @Nullable
   private static volatile double[] fromServer;

   public static double get(DroneTuning.Value value) {
      double[] received = fromServer;
      return received != null ? received[value.ordinal()] : value.local.get();
   }

   public static boolean flag(DroneTuning.Value value) {
      return get(value) > 0.5;
   }

   public static double[] snapshot() {
      double[] values = new double[VALUES.length];

      for (DroneTuning.Value value : VALUES) {
         values[value.ordinal()] = value.local.get();
      }

      return values;
   }

   public static void acceptFromServer(double[] values) {
      if (values.length == VALUES.length) {
         fromServer = (double[])values.clone();
      } else {
         DroneMod.LOGGER.warn("Drone tuning from the server has {} figures, expected {} — ignoring it", values.length, VALUES.length);
      }
   }

   public static void clear() {
      fromServer = null;
   }

   private DroneTuning() {
   }

   public static enum Value {
      MAVIC_CRASH_SPEED(() -> (Double)SkyfrontConfig.MAVIC_CRASH_SPEED.get()),
      MAVIC_MAX_DESCENT_SPEED(() -> (Double)SkyfrontConfig.MAVIC_MAX_DESCENT_SPEED.get()),
      MAVIC_FLIGHT_SECONDS(() -> (double)((Integer)SkyfrontConfig.MAVIC_FLIGHT_SECONDS.get()).intValue()),
      MAVIC_3T_TOP_SPEED(() -> (Double)SkyfrontConfig.MAVIC_3T_TOP_SPEED.get() * 1.5),
      MAVIC_3T_FLIGHT_SECONDS(() -> (double)((Integer)SkyfrontConfig.MAVIC_3T_FLIGHT_SECONDS.get()).intValue()),
      INTERCEPTOR_TOP_SPEED(() -> 591.09),
      INTERCEPTOR_CRASH_SPEED(() -> (Double)SkyfrontConfig.INTERCEPTOR_CRASH_SPEED.get()),
      INTERCEPTOR_FLIGHT_SECONDS(() -> (double)((Integer)SkyfrontConfig.INTERCEPTOR_FLIGHT_SECONDS.get()).intValue()),
      INTERCEPTOR_RATE_MODE(() -> SkyfrontConfig.INTERCEPTOR_RATE_MODE.get() ? 1.0 : 0.0),
      INTERCEPTOR_ROLL_PITCH_RATE(() -> (Double)SkyfrontConfig.INTERCEPTOR_ROLL_PITCH_RATE.get()),
      INTERCEPTOR_YAW_RATE(() -> (Double)SkyfrontConfig.INTERCEPTOR_YAW_RATE.get()),
      INTERCEPTOR_EXPO(() -> (Double)SkyfrontConfig.INTERCEPTOR_EXPO.get()),
      INTERCEPTOR_THRUST_TO_WEIGHT(() -> (Double)SkyfrontConfig.INTERCEPTOR_THRUST_TO_WEIGHT.get());

      private final Supplier<Double> local;

      private Value(Supplier<Double> local) {
         this.local = local;
      }
   }
}
