package dev.krutlexik.skyfront.drone.entity;

import dev.krutlexik.skyfront.client.ClientLatency;
import dev.krutlexik.skyfront.compat.sbw.SbwCompat;
import dev.krutlexik.skyfront.compat.sbw.SbwMonitor;
import dev.krutlexik.skyfront.compat.sbw.SbwVehicles;
import dev.krutlexik.skyfront.config.SkyfrontConfig;
import dev.krutlexik.skyfront.drone.DroneLinks;
import dev.krutlexik.skyfront.drone.DroneLongRange;
import dev.krutlexik.skyfront.drone.DroneMod;
import dev.krutlexik.skyfront.drone.DroneTuning;
import dev.krutlexik.skyfront.drone.GrenadeAttachments;
import dev.krutlexik.skyfront.drone.TrackerAccess;
import dev.krutlexik.skyfront.drone.network.DroneStatePayload;
import dev.krutlexik.skyfront.drone.network.StopControlPayload;
import dev.krutlexik.skyfront.drone.registry.DroneItems;
import dev.krutlexik.skyfront.entity.DebrisEntity;
import dev.krutlexik.skyfront.entity.LauncherEntity;
import dev.krutlexik.skyfront.entity.ShahedEntity;
import dev.krutlexik.skyfront.seeker.SeekerChunks;
import dev.krutlexik.skyfront.util.ChunkLoadHelper;
import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.core.Holder;
import net.minecraft.core.Holder.Reference;
import net.minecraft.core.HolderLookup.RegistryLookup;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerPlayerConnection;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.Entity.MovementEmission;
import net.minecraft.world.entity.Entity.RemovalReason;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import net.neoforged.neoforge.network.PacketDistributor;
import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;
import org.joml.Vector3f;

public class DroneEntity extends Entity {
   private int pilotArmed = -1;
   private float pilotCharge = 0.0F / 0.0F;
   public static final float MIN_PITCH = -25.0F;
   public static final float MAX_PITCH = 90.0F;
   private static final float AIR_ACCEL = 0.026F;
   protected static final float AIR_FRICTION = 0.91F;
   private static final float VERTICAL_FRICTION = 0.98F;
   private static final float INPUT_PEAK = 1.5F;
   private static final float INPUT_DECAY = 0.3F;
   protected static final float HORIZONTAL_BOOST = 1.05F;
   private static final float HORIZONTAL_HOLD = 0.95F;
   private static final float VERTICAL_BOOST = 0.99F;
   private static final float VERTICAL_HOLD = 0.87F;
   private static final double AUTOLAND_SPEED = 0.1;
   private static final double AUTOLAND_EASE = 0.012;
   private static final double AUTOLAND_DRAG = 0.93;
   private static final double GROUND_FRICTION = 0.82;
   private static final double SKID_STOP_SPEED = 0.02;
   private static final EntityDataAccessor<Optional<UUID>> DATA_CONTROLLER = SynchedEntityData.defineId(DroneEntity.class, EntityDataSerializers.OPTIONAL_UUID);
   private static final EntityDataAccessor<Float> DATA_CHARGE = SynchedEntityData.defineId(DroneEntity.class, EntityDataSerializers.FLOAT);
   private static final EntityDataAccessor<ItemStack> DATA_ATTACHMENT = SynchedEntityData.defineId(DroneEntity.class, EntityDataSerializers.ITEM_STACK);
   private static final EntityDataAccessor<Boolean> DATA_WRECKED = SynchedEntityData.defineId(DroneEntity.class, EntityDataSerializers.BOOLEAN);
   private static final EntityDataAccessor<Float> DATA_LOAD = SynchedEntityData.defineId(DroneEntity.class, EntityDataSerializers.FLOAT);
   private static final EntityDataAccessor<Boolean> DATA_ARMED = SynchedEntityData.defineId(DroneEntity.class, EntityDataSerializers.BOOLEAN);
   public boolean locallyControlled;
   private final ArrayDeque<PilotInput> inputQueue = new ArrayDeque<>();
   private PilotInput lastInput = PilotInput.NEUTRAL;
   private int lastInputSeq = -1;
   private int receivedSeq = -2147483648;
   private long lastInputNanos = System.nanoTime();
   private int owedInputs;
   private double inputCredit = 4.0;
   private long creditClock;
   private int inputSilence;
   private int simTick;
   private boolean simulatedThisTick;
   private static final int INPUT_SILENCE_LIMIT = 20;
   private static final int LINK_SILENCE_TICKS = 100;
   private static final int STALL_TOLERANCE_TICKS = 4;
   private static final int MAX_QUEUED_INPUTS = 40;
   private static final int MAX_INPUTS_PER_TICK = 40;
   private static final double INPUT_CREDIT_START = 4.0;
   private static final double MAX_INPUT_CREDIT = 40.0;
   private static final double NANOS_PER_TICK = 5.0E7;
   private static final int MAX_OWED_INPUTS = 100;
   private static final float MAX_GIMBAL_STEP = 170.0F;
   private float stickRoll;
   private float stickPitch;
   private float stickYaw;
   private float stickThrottle;
   private static final int NO_ORDER = -2147483648;
   private int dropAtSeq = -2147483648;
   private int destructAtSeq = -2147483648;
   private boolean replaying;
   public float lastCollisionSpeed;
   @Nullable
   public Entity lastRammed;
   private static final double CLOSING_LEAD = 4.0;
   private int stepsLastTick = 1;
   private static final double LEAD_REACH_PER_TICK = 8.0;
   private float health = -1.0F;
   private boolean destroyed;
   private float spin;
   private float roll;
   private float rollOld;
   private int swerve;
   protected float inputSideways;
   protected float inputVertical;
   protected float inputForward;
   private int lerpSteps;
   private double lerpX;
   private double lerpY;
   private double lerpZ;
   private double lerpYRot;
   private double lerpXRot;
   private int rotSteps;
   private Vec3 observerCorrection = Vec3.ZERO;
   private int trackerSilence;
   private final ArrayDeque<DroneEntity.Snapshot> snapshots = new ArrayDeque<>();
   private double playbackTick = 0.0 / 0.0;
   private double playbackDelay = 2.0;
   private int ticksSinceSnapshot = 1073741823;
   private int steadyTicks;
   private int observerClock;
   private double streamRate = 1.0;
   private int rateFromSim = -2147483648;
   private int rateFromClock;
   private double snapshotSpacing = 1.0;
   private Vec3 playbackCorrection = Vec3.ZERO;
   @Nullable
   protected Quaternionf playedAttitude;
   private static final int SNAPSHOT_BUFFER = 32;
   private static final int SNAPSHOT_STALE_TICKS = 10;
   private static final double SNAPSHOT_DELAY_START = 2.0;
   private static final double SNAPSHOT_DELAY_MIN = 1.5;
   private static final double SNAPSHOT_DELAY_MAX = 6.0;
   private static final double SNAPSHOT_RESYNC_TICKS = 8.0;
   private static final double SNAPSHOT_MAX_SKEW = 0.15;
   private static final double SNAPSHOT_CATCH_UP = 0.1;
   private static final int STREAM_RATE_WINDOW = 10;
   private static final double STREAM_RATE_MIN = 0.05;
   private static final double STREAM_RATE_MAX = 1.5;
   private static final double PLAYBACK_CORRECTION_KEEP = 0.7;
   private static final double SNAPSHOT_MAX_GUESS = 3.0;
   private static final int SNAPSHOT_STEADY_TICKS = 100;
   private boolean impactPredicted;
   private int predictedRamId = -1;
   private static final int RAM_REPORT_LAG_TICKS = 10;
   private static final double RAM_REPORT_MARGIN = 3.0;
   private static final double RAM_REPORT_TARGET_SPEED_CAP = 3.0;
   private static final double RAM_REPORT_SPEED_SHARE = 0.75;
   private static final double RECENT_APPROACH_KEEP = 0.85;
   private double recentApproach;
   private static final double OBSERVER_SNAP_DISTANCE = 24.0;
   private static final double OBSERVER_CORRECTION_SHARE = 0.25;
   private static final double OBSERVER_PACKET_AGE_TICKS = 2.0;
   private static final int OBSERVER_SILENCE_TICKS = 6;
   @Nullable
   private UUID lastPilotId;
   @Nullable
   private UUID downedById;
   private static final ResourceKey<DamageType> DRONE_RAM = ResourceKey.create(Registries.DAMAGE_TYPE, DroneMod.id("drone_ram"));
   static final float PROP_FLYING_RATE = 28.0F;
   private static final float PROP_AUTOLAND_RATE = 11.0F;
   private static final float PROP_SPIN_UP_STEP = 4.6666665F;
   private static final float PROP_SPIN_DOWN_STEP = 1.4F;
   private float propRate;
   private float propPhase;
   private float propPhaseOld;
   private long steppedChunk = -9223372036854775808L;
   private static final Quaternionf LEVEL = new Quaternionf();
   private static final int WRECK_LERP_STEPS = 3;
   private int wreckSteps;
   private final Quaternionf tumble = new Quaternionf();
   private final Quaternionf tumbleOld = new Quaternionf();
   private final Vector3f tumbleAxis = new Vector3f();
   private float tumbleRate;
   private boolean tumbleReady;
   private int wreckTicks;
   private static final float TUMBLE_WIND_UP = 12.0F;
   private static final double QUAD_GRAVITY = 0.06;
   private static final double QUAD_DRAG = 0.975;
   private static final double QUAD_DRAG_VERTICAL = 0.962;

   public double controlRange() {
      return 3000.0;
   }

   public double controlRangeSqr() {
      double range = this.controlRange();
      return range * range;
   }

   public int fullFlightTicks() {
      return (int)DroneTuning.get(DroneTuning.Value.MAVIC_FLIGHT_SECONDS) * 20;
   }

   protected float thrust() {
      return 0.039F;
   }

   protected double topSpeed() {
      return 0.0;
   }

   public double crashSpeedKmh() {
      return DroneTuning.get(DroneTuning.Value.MAVIC_CRASH_SPEED);
   }

   public double crashSpeed() {
      return this.crashSpeedKmh() / 72.0;
   }

   protected double ramSpeed() {
      return this.crashSpeed();
   }

   public double lookGearing() {
      return (Double)SkyfrontConfig.MAVIC_LOOK_SENSITIVITY.get();
   }

   public double gimbalLag() {
      return 0.08;
   }

   public boolean needsLongRangeLink() {
      return this.controlRange() > 128.0;
   }

   protected boolean carriesStores() {
      return true;
   }

   protected boolean canCarry(ItemStack stack) {
      return GrenadeAttachments.isAttachable(stack);
   }

   public GrenadeAttachments.Mount mountFor(ItemStack stack) {
      return GrenadeAttachments.mountOf(stack);
   }

   public boolean storesFollowAttitude() {
      return false;
   }

   protected float ramDamage() {
      return (float)((Double)SkyfrontConfig.DRONE_RAM_DAMAGE.get()).doubleValue();
   }

   public boolean hasThermalCamera() {
      return false;
   }

   public DroneEntity.Osd osdStyle() {
      return DroneEntity.Osd.CAMERA;
   }

   public boolean hasCameraZoom() {
      return true;
   }

   public boolean hasEngineSound() {
      return true;
   }

   public boolean requiresArming() {
      return false;
   }

   public boolean isArmed() {
      return !this.requiresArming() || this.armedSwitch();
   }

   private boolean armedSwitch() {
      return this.locallyControlled && this.pilotArmed >= 0 ? this.pilotArmed == 1 : (Boolean)this.entityData.get(DATA_ARMED);
   }

   public void setArmed(boolean armed) {
      if (this.locallyControlled) {
         this.pilotArmed = armed ? 1 : 0;
      } else {
         this.entityData.set(DATA_ARMED, armed);
      }
   }

   public void clearPilotPrediction() {
      this.pilotArmed = -1;
      this.pilotCharge = 0.0F / 0.0F;
   }

   public final float inputLoad() {
      return this.level().isClientSide && !this.locallyControlled ? (Float)this.entityData.get(DATA_LOAD) : this.computeInputLoad();
   }

   protected float computeInputLoad() {
      double load = Math.sqrt(
            (double)(this.inputSideways * this.inputSideways + this.inputVertical * this.inputVertical + this.inputForward * this.inputForward)
         )
         / 1.5;
      return (float)Mth.clamp(load, 0.0, 1.0);
   }

   private void syncInputLoad() {
      float quantized = (float)Math.round(this.computeInputLoad() * 16.0F) / 16.0F;
      if ((Float)this.entityData.get(DATA_LOAD) != quantized) {
         this.entityData.set(DATA_LOAD, quantized);
      }
   }

   public float minPitch() {
      return -25.0F;
   }

   public float maxPitch() {
      return 90.0F;
   }

   public float bodyPitch(float partialTick) {
      return 0.0F;
   }

   public float bodyRoll(float partialTick) {
      return 0.0F;
   }

   public void acceptPilotInput(PilotInput input) {
      if (input.seq() > this.receivedSeq) {
         this.receivedSeq = input.seq();
         this.inputQueue.addLast(input.sanitized());

         while (this.inputQueue.size() > 40) {
            PilotInput dropped = this.inputQueue.pollFirst();
            this.lastInput = dropped;
            this.lastInputSeq = dropped.seq();
            if (this.owedInputs > 0) {
               this.owedInputs--;
            }
         }

         this.inputSilence = 0;
         this.lastInputNanos = System.nanoTime();
      }
   }

   public int linkAckSeq() {
      return this.lastInputSeq < 0 ? -1 : this.lastInputSeq + this.owedInputs;
   }

   public void flyPilotStep(PilotInput input) {
      if (input.holds(64) && this.requiresArming() && !this.isWrecked()) {
         boolean wanted = input.holds(128);
         if (this.armedSwitch() != wanted) {
            this.setArmed(wanted);
         }
      }

      if (!this.isGrounded()) {
         this.drainCharge();
      }

      this.setSticks(input.roll(), input.pitch(), input.yaw(), input.throttle());
      if (!this.flownOnSticks() && input.hasGimbal()) {
         this.setGimbal(input.gimbalYaw(), input.gimbalPitch());
      }

      this.applyControlInput(input.holds(1), input.holds(2), input.holds(4), input.holds(8), input.holds(16), input.holds(32));
   }

   protected boolean isPiloted() {
      return this.locallyControlled || this.isControlled();
   }

   public boolean flownOnSticks() {
      return false;
   }

   public void setGimbal(float yaw, float pitch) {
      float step = Mth.wrapDegrees(yaw - this.getYRot());
      if (Math.abs(step) <= 170.0F) {
         this.setYRot(yaw);
      } else {
         this.setYRot(this.getYRot() + Math.copySign(170.0F, step));
      }

      this.setXRot(Mth.clamp(pitch, this.minPitch(), this.maxPitch()));
   }

   public void setSticks(float roll, float pitch, float yaw, float throttle) {
      this.stickRoll = Mth.clamp(roll, -1.0F, 1.0F);
      this.stickPitch = Mth.clamp(pitch, -1.0F, 1.0F);
      this.stickYaw = Mth.clamp(yaw, -1.0F, 1.0F);
      this.stickThrottle = Mth.clamp(throttle, 0.0F, 1.0F);
   }

   protected float stickRoll() {
      return this.stickRoll;
   }

   protected float stickPitch() {
      return this.stickPitch;
   }

   protected float stickYaw() {
      return this.stickYaw;
   }

   protected float stickThrottle() {
      return this.stickThrottle;
   }

   public float throttleStick() {
      return this.stickThrottle;
   }

   protected void releaseSticks() {
      this.stickRoll = 0.0F;
      this.stickPitch = 0.0F;
      this.stickYaw = 0.0F;
      this.stickThrottle = 0.0F;
   }

   private void resetPilotQueue() {
      this.inputQueue.clear();
      this.lastInput = PilotInput.NEUTRAL;
      this.lastInputSeq = -1;
      this.receivedSeq = -2147483648;
      this.lastInputNanos = System.nanoTime();
      this.owedInputs = 0;
      this.inputCredit = 4.0;
      this.creditClock = 0L;
      this.inputSilence = 0;
      this.dropAtSeq = -2147483648;
      this.destructAtSeq = -2147483648;
   }

   public void orderDrop(ServerPlayer pilot, int seq) {
      this.dropAtSeq = this.orderSeq(seq);
      this.carryOutOrders(pilot);
   }

   public void orderSelfDestruct(ServerPlayer pilot, int seq) {
      this.destructAtSeq = this.orderSeq(seq);
      this.carryOutOrders(pilot);
   }

   private int orderSeq(int seq) {
      return this.receivedSeq == -2147483648 ? -1 : Math.min(seq, this.receivedSeq);
   }

   private boolean carryOutOrders(@Nullable ServerPlayer pilot) {
      if (this.dropAtSeq == -2147483648 && this.destructAtSeq == -2147483648) {
         return true;
      } else {
         int reached = this.linkAckSeq();
         if (this.dropAtSeq != -2147483648 && this.dropAtSeq <= reached) {
            this.dropAtSeq = -2147483648;
            if (pilot != null) {
               this.releaseStore(pilot);
            }
         }

         if (this.destructAtSeq != -2147483648 && this.destructAtSeq <= reached) {
            this.destructAtSeq = -2147483648;
            this.selfDestruct(pilot);
            return !this.isRemoved();
         } else {
            return true;
         }
      }
   }

   public void selfDestruct(@Nullable Entity by) {
   }

   private void releaseStore(ServerPlayer pilot) {
      ItemStack attachment = this.getAttachment();
      if (GrenadeAttachments.isDroppable(attachment) && this.level() instanceof ServerLevel level) {
         this.setAttachment(ItemStack.EMPTY);
         boolean var7 = false;

         try {
            var7 = GrenadeAttachments.release(level, pilot, attachment, this.grenadeDropPoint(), this.getDeltaMovement());
         } catch (Throwable var6) {
            DroneMod.LOGGER.error("Could not release {} from the drone", BuiltInRegistries.ITEM.getKey(attachment.getItem()), var6);
         }

         if (!var7) {
            this.spawnAtLocation(attachment);
         }
      }
   }

   public void captureFlightState(DroneFlightState out) {
      out.x = this.getX();
      out.y = this.getY();
      out.z = this.getZ();
      Vec3 velocity = this.getDeltaMovement();
      out.vx = velocity.x;
      out.vy = velocity.y;
      out.vz = velocity.z;
      out.yRot = this.getYRot();
      out.xRot = this.getXRot();
      out.inputSideways = this.inputSideways;
      out.inputVertical = this.inputVertical;
      out.inputForward = this.inputForward;
      out.charge = this.getCharge();
      out.armed = this.armedSwitch();
      out.airframe = false;
   }

   public void restoreFlightState(DroneFlightState state) {
      this.setPos(state.x, state.y, state.z);
      this.setDeltaMovement(state.vx, state.vy, state.vz);
      this.setYRot(state.yRot);
      this.setXRot(state.xRot);
      this.inputSideways = state.inputSideways;
      this.inputVertical = state.inputVertical;
      this.inputForward = state.inputForward;
      if (this.getCharge() != state.charge) {
         this.setCharge(state.charge);
      }

      if (this.armedSwitch() != state.armed) {
         this.setArmed(state.armed);
      }
   }

   public void setReplaying(boolean replaying) {
      this.replaying = replaying;
   }

   protected MovementEmission getMovementEmission() {
      return this.replaying ? MovementEmission.NONE : super.getMovementEmission();
   }

   public void settleInterpolation() {
      this.xo = this.getX();
      this.yo = this.getY();
      this.zo = this.getZ();
      this.yRotO = this.getYRot();
      this.xRotO = this.getXRot();
   }

   public void notePredictedImpact() {
      if ((double)this.lastCollisionSpeed * 72.0 >= this.crashSpeedKmh()) {
         this.impactPredicted = true;
         this.predictedRamId = this.lastRammed != null ? this.lastRammed.getId() : -1;
      }
   }

   @Nullable
   private DroneEntity.Ram entityInTheWay(Vec3 from, Vec3 travel) {
      AABB start = this.getBoundingBox().move(from.x - this.getX(), from.y - this.getY(), from.z - this.getZ());
      double oneWay = this.level().isClientSide && this.locallyControlled && !this.replaying ? ClientLatency.packetAgeTicks() : 0.0;
      AABB path = start.expandTowards(travel).inflate(4.1 + oneWay * 8.0);
      DroneEntity.Ram closest = null;

      for (Entity other : this.level().getEntities(this, path, this::isSolidToDrone)) {
         Vec3 closing = travel.subtract(other.getDeltaMovement());
         AABB hull = other.getBoundingBox().inflate(0.1);
         if (oneWay > 0.0) {
            hull = hull.move(other.getDeltaMovement().scale(leadTicks(other, oneWay)));
         }

         double contact = sweptContact(start, closing, hull);
         Vec3 stride = new Vec3(other.getX() - other.xo, other.getY() - other.yo, other.getZ() - other.zo);
         if (other instanceof DroneEntity drone && drone.stepsLastTick > 1) {
            stride = stride.scale(1.0 / (double)drone.stepsLastTick);
         }

         if (stride.lengthSqr() > 1.0E-6) {
            double fromStart = sweptContact(start, travel.subtract(stride), hull.move(stride.scale(-1.0)));
            if (fromStart >= 0.0 && (contact < 0.0 || fromStart < contact)) {
               contact = fromStart;
            }
         }

         if (contact >= 0.0 && (closest == null || contact < closest.contact)) {
            closest = new DroneEntity.Ram(other, contact);
         }
      }

      return closest;
   }

   private static double leadTicks(Entity other, double oneWay) {
      if (other instanceof ShahedEntity) {
         return oneWay;
      } else {
         if (other instanceof DroneEntity watched && !Double.isNaN(watched.playbackTick)) {
            return 2.0 * oneWay + watched.playbackDelay;
         }

         return 2.0 * oneWay;
      }
   }

   private static double sweptContact(AABB self, Vec3 travel, AABB other) {
      double entry = 0.0;
      double exit = 1.0;
      double[][] axes = new double[][]{
         {travel.x, self.minX, self.maxX, other.minX, other.maxX},
         {travel.y, self.minY, self.maxY, other.minY, other.maxY},
         {travel.z, self.minZ, self.maxZ, other.minZ, other.maxZ}
      };

      for (double[] axis : axes) {
         double speed = axis[0];
         double selfMin = axis[1];
         double selfMax = axis[2];
         double otherMin = axis[3];
         double otherMax = axis[4];
         if (speed == 0.0) {
            if (selfMax <= otherMin || selfMin >= otherMax) {
               return -1.0;
            }
         } else {
            double enters = (otherMin - selfMax) / speed;
            double leaves = (otherMax - selfMin) / speed;
            entry = Math.max(entry, Math.min(enters, leaves));
            exit = Math.min(exit, Math.max(enters, leaves));
         }
      }

      return entry <= exit ? entry : -1.0;
   }

   private boolean isSolidToDrone(Entity other) {
      if (other.isRemoved()) {
         return false;
      } else if (other instanceof DroneEntity drone) {
         if (drone instanceof InterceptorDroneEntity aircraft && aircraft.fliesAsAircraft() && !aircraft.isWrecked()) {
            return true;
         }

         return false;
      } else {
         if (other instanceof Player player && player.isSpectator()) {
            return false;
         }

         if (other instanceof DebrisEntity) {
            return false;
         } else if (other instanceof LauncherEntity) {
            return false;
         } else {
            return other instanceof DroneStandEntity ? false : other.canBeCollidedWith() || other.isPickable();
         }
      }
   }

   public void acceptSnapshot(DroneStatePayload state) {
      if (!this.locallyControlled) {
         DroneEntity.Snapshot newest = this.snapshots.peekLast();
         if (newest != null && state.simTick() <= newest.simTick()) {
            if (state.simTick() >= newest.simTick() - 32) {
               return;
            }

            this.forgetSnapshots();
         }

         if (this.ticksSinceSnapshot > this.staleTicks()) {
            this.forgetSnapshots();
         } else if (!Double.isNaN(this.playbackTick) && (double)state.simTick() <= this.playbackTick) {
            this.playbackDelay = Math.min(this.maxPlaybackDelay(), this.playbackDelay + 0.5);
            this.steadyTicks = 0;
         }

         this.timeStream(this.snapshots.peekLast(), state.simTick());
         this.snapshots
            .addLast(
               new DroneEntity.Snapshot(
                  state.simTick(),
                  state.x(),
                  state.y(),
                  state.z(),
                  state.vx(),
                  state.vy(),
                  state.vz(),
                  state.yRot(),
                  state.xRot(),
                  new Quaternionf(state.qx(), state.qy(), state.qz(), state.qw()).normalize()
               )
            );

         while (this.snapshots.size() > 32) {
            this.snapshots.pollFirst();
         }

         this.ticksSinceSnapshot = 0;
      }
   }

   private void forgetSnapshots() {
      this.snapshots.clear();
      this.playbackTick = 0.0 / 0.0;
      this.ticksSinceSnapshot = 1073741823;
      this.playbackDelay = Math.max(2.0, this.minPlaybackDelay());
      this.steadyTicks = 0;
      this.rateFromSim = -2147483648;
   }

   private void timeStream(@Nullable DroneEntity.Snapshot newest, int simTick) {
      if (newest != null && simTick > newest.simTick()) {
         this.snapshotSpacing = this.snapshotSpacing + ((double)(simTick - newest.simTick()) - this.snapshotSpacing) * 0.2;
      }

      if (this.rateFromSim == -2147483648) {
         this.rateFromSim = simTick;
         this.rateFromClock = this.observerClock;
      } else {
         int elapsed = this.observerClock - this.rateFromClock;
         if (elapsed >= 10) {
            double measured = (double)(simTick - this.rateFromSim) / (double)elapsed;
            this.streamRate = this.streamRate + (Mth.clamp(measured, 0.05, 1.5) - this.streamRate) * 0.5;
            this.rateFromSim = simTick;
            this.rateFromClock = this.observerClock;
         }
      }
   }

   private double minPlaybackDelay() {
      return Math.max(1.5, this.snapshotSpacing);
   }

   private double maxPlaybackDelay() {
      return Math.max(6.0, 2.0 * this.snapshotSpacing + 1.0);
   }

   private int staleTicks() {
      double gap = this.snapshotSpacing / Math.max(this.streamRate, 0.05);
      return (int)Mth.clamp(Math.ceil(3.0 * gap), 10.0, 60.0);
   }

   private void playSnapshots() {
      DroneEntity.Snapshot newest = this.snapshots.peekLast();
      Vec3 shownBefore = this.position();
      double target = (double)newest.simTick() - this.playbackDelay;
      boolean restarted = false;
      if (Double.isNaN(this.playbackTick)) {
         this.playbackTick = (double)newest.simTick();
         restarted = true;
      } else if (Math.abs(target - this.playbackTick) > Math.max(8.0, 2.0 * this.snapshotSpacing + 2.0)) {
         this.playbackTick = target;
         restarted = true;
      } else {
         double rate = this.streamRate;
         this.playbackTick = this.playbackTick + rate + Mth.clamp((target - this.playbackTick) * 0.1, -0.15 * rate, 0.15 * rate);
      }

      if (this.playbackTick > (double)newest.simTick()) {
         this.steadyTicks = 0;
      } else if (++this.steadyTicks > 100) {
         this.playbackDelay = Math.max(this.minPlaybackDelay(), this.playbackDelay - 0.25);
         this.steadyTicks = 0;
      }

      while (this.snapshots.size() >= 2) {
         Iterator<DroneEntity.Snapshot> walk = this.snapshots.iterator();
         walk.next();
         if (!((double)walk.next().simTick() <= this.playbackTick)) {
            break;
         }

         this.snapshots.pollFirst();
      }

      Iterator<DroneEntity.Snapshot> walk = this.snapshots.iterator();
      DroneEntity.Snapshot before = walk.next();
      DroneEntity.Snapshot after = walk.hasNext() ? walk.next() : null;
      Quaternionf attitude = new Quaternionf();
      double x;
      double y;
      double z;
      Vec3 velocity;
      float yaw;
      float pitch;
      if (after != null && !(this.playbackTick <= (double)before.simTick())) {
         double t = (this.playbackTick - (double)before.simTick()) / (double)(after.simTick() - before.simTick());
         x = Mth.lerp(t, before.x(), after.x());
         y = Mth.lerp(t, before.y(), after.y());
         z = Mth.lerp(t, before.z(), after.z());
         velocity = new Vec3(Mth.lerp(t, before.vx(), after.vx()), Mth.lerp(t, before.vy(), after.vy()), Mth.lerp(t, before.vz(), after.vz()));
         yaw = Mth.rotLerp((float)t, before.yRot(), after.yRot());
         pitch = Mth.lerp((float)t, before.xRot(), after.xRot());
         before.attitude().slerp(after.attitude(), (float)t, attitude);
      } else {
         double ahead = Mth.clamp(this.playbackTick - (double)before.simTick(), 0.0, 3.0);
         x = before.x() + before.vx() * ahead;
         y = before.y() + before.vy() * ahead;
         z = before.z() + before.vz() * ahead;
         velocity = new Vec3(before.vx(), before.vy(), before.vz());
         yaw = before.yRot();
         pitch = before.xRot();
         attitude.set(before.attitude());
      }

      if (restarted) {
         Vec3 gap = shownBefore.subtract(x, y, z);
         this.playbackCorrection = gap.lengthSqr() < 576.0 ? gap : Vec3.ZERO;
      }

      if (this.playbackCorrection != Vec3.ZERO) {
         x += this.playbackCorrection.x;
         y += this.playbackCorrection.y;
         z += this.playbackCorrection.z;
         this.playbackCorrection = this.playbackCorrection.scale(0.7);
         if (this.playbackCorrection.lengthSqr() < 1.0E-6) {
            this.playbackCorrection = Vec3.ZERO;
         }
      }

      this.setPos(x, y, z);
      this.setDeltaMovement(velocity);
      this.setYRot(this.getYRot() + Mth.wrapDegrees(yaw - this.getYRot()));
      this.setXRot(pitch);
      this.playedAttitude = attitude.normalize();
   }

   public int predictedRamId() {
      return this.predictedRamId;
   }

   @Nullable
   public Vec3 reportedRamContact(Entity target) {
      if (target != this && this.isSolidToDrone(target) && target.level() == this.level()) {
         double reach = Math.min(target.getDeltaMovement().length(), 3.0) * 10.0 + this.getDeltaMovement().length() * 3.0 + 3.0;
         AABB hull = target.getBoundingBox();
         Vec3 centre = this.getBoundingBox().getCenter();
         Vec3 nearest = new Vec3(
            Mth.clamp(centre.x, hull.minX, hull.maxX), Mth.clamp(centre.y, hull.minY, hull.maxY), Mth.clamp(centre.z, hull.minZ, hull.maxZ)
         );
         return nearest.distanceTo(centre) <= reach ? nearest : null;
      } else {
         return null;
      }
   }

   public boolean acceptReportedRam(ServerPlayer pilot, Entity target) {
      if (this.isControlledBy(pilot) && !this.isWrecked() && !this.destroyed) {
         Vec3 nearest = this.reportedRamContact(target);
         if (nearest == null) {
            return false;
         } else if (!(this.recentApproach < this.ramSpeed() * 0.75) && this.nothingSolidBetween(nearest)) {
            this.setPos(nearest.x, nearest.y - (double)this.getBbHeight() * 0.5, nearest.z);
            this.setDeltaMovement(Vec3.ZERO);
            this.lastRammed = target;
            this.releaseControl(StopControlPayload.Reason.CRASHED);
            this.ram(target, pilot);
            this.destroyOnImpact(pilot);
            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean nothingSolidBetween(Vec3 contact) {
      Vec3 from = this.getBoundingBox().getCenter();
      BlockHitResult hit = this.level().clip(new ClipContext(from, contact, Block.COLLIDER, Fluid.NONE, this));
      return hit.getType() == Type.MISS || hit.getLocation().distanceToSqr(contact) < 1.0;
   }

   public boolean consumePredictedImpact() {
      boolean predicted = this.impactPredicted;
      this.impactPredicted = false;
      return predicted;
   }

   public DroneEntity(EntityType<? extends DroneEntity> type, Level level) {
      super(type, level);
      this.setNoGravity(true);
      this.noCulling = true;
   }

   protected void defineSynchedData(Builder builder) {
      builder.define(DATA_CONTROLLER, Optional.empty());
      builder.define(DATA_CHARGE, 1.0F);
      builder.define(DATA_ATTACHMENT, ItemStack.EMPTY);
      builder.define(DATA_WRECKED, false);
      builder.define(DATA_LOAD, 0.0F);
      builder.define(DATA_ARMED, false);
   }

   public boolean isWrecked() {
      return (Boolean)this.entityData.get(DATA_WRECKED);
   }

   public float getSpin() {
      return this.spin;
   }

   public float getRoll(float partialTick) {
      return Mth.lerp(partialTick, this.rollOld, this.roll);
   }

   public ItemStack getAttachment() {
      return (ItemStack)this.entityData.get(DATA_ATTACHMENT);
   }

   public boolean hasAttachment() {
      return !this.getAttachment().isEmpty();
   }

   public void setAttachment(ItemStack stack) {
      this.entityData.set(DATA_ATTACHMENT, stack);
   }

   public Vec3 grenadeDropPoint() {
      return this.position().add(0.0, -((double)this.getBbHeight() + 0.2), 0.0);
   }

   public float getCharge() {
      return this.locallyControlled && !Float.isNaN(this.pilotCharge) ? this.pilotCharge : (Float)this.entityData.get(DATA_CHARGE);
   }

   public void setCharge(float charge) {
      float clamped = Mth.clamp(charge, 0.0F, 1.0F);
      if (this.locallyControlled) {
         this.pilotCharge = clamped;
      } else {
         this.entityData.set(DATA_CHARGE, clamped);
      }
   }

   protected void drainCharge() {
      this.setCharge(this.getCharge() - 1.0F / (float)this.fullFlightTicks());
   }

   public void tickBattery(boolean draining) {
      if (draining) {
         this.drainCharge();
         if (this.getCharge() <= 0.0F) {
            this.packRanOut();
         }
      }
   }

   private void packRanOut() {
      String notice = this.autolandsWhenFlat() ? "message.sfw.drone.battery_empty" : "message.sfw.drone.battery_dead";
      this.getControllerId().map(id -> this.level().getPlayerByUUID(id)).ifPresent(pilot -> pilot.displayClientMessage(Component.translatable(notice), true));
      this.releaseControl(this.autolandsWhenFlat() ? StopControlPayload.Reason.NORMAL : StopControlPayload.Reason.BATTERY);
   }

   public Optional<UUID> getControllerId() {
      return (Optional<UUID>)this.entityData.get(DATA_CONTROLLER);
   }

   public boolean isControlledBy(Player player) {
      return this.getControllerId().filter(id -> id.equals(player.getUUID())).isPresent();
   }

   public boolean isControlled() {
      return this.getControllerId().isPresent();
   }

   public void setController(@Nullable UUID id) {
      if (id != null) {
         this.lastPilotId = id;
      }

      UUID previous = this.getControllerId().orElse(null);
      this.entityData.set(DATA_CONTROLLER, Optional.ofNullable(id));
      DroneLinks.controllerChanged(this, previous, id);
      this.resetPilotQueue();
      this.releaseSticks();
   }

   @Nullable
   protected Entity creditFor(@Nullable Entity given) {
      return (Entity)(given == null && this.lastPilotId != null ? this.level().getPlayerByUUID(this.lastPilotId) : given);
   }

   @Nullable
   private Entity downedBy() {
      Entity downer = this.downedById != null && this.level() instanceof ServerLevel serverLevel ? serverLevel.getEntity(this.downedById) : null;
      return this.creditFor(downer);
   }

   private DamageSource ramDamage(@Nullable Entity credit, boolean vehicle) {
      RegistryLookup<DamageType> types = this.level().registryAccess().lookupOrThrow(Registries.DAMAGE_TYPE);
      Reference<DamageType> flyIntoWall = types.getOrThrow(DamageTypes.FLY_INTO_WALL);
      return vehicle
         ? new DamageSource(flyIntoWall, this, credit)
         : new DamageSource(types.get(DRONE_RAM).map(holder -> (Holder)holder).orElse(flyIntoWall), this, credit);
   }

   public void releaseControl(boolean outOfRange) {
      this.releaseControl(outOfRange ? StopControlPayload.Reason.OUT_OF_RANGE : StopControlPayload.Reason.NORMAL);
   }

   public void releaseControl(StopControlPayload.Reason reason) {
      if (!this.level().isClientSide) {
         this.getControllerId().ifPresent(id -> {
            ServerPlayer pilot = this.level().getPlayerByUUID(id) instanceof ServerPlayer found ? found : null;
            if (pilot != null) {
               if (pilot.connection.hasChannel(StopControlPayload.TYPE)) {
                  PacketDistributor.sendToPlayer(pilot, new StopControlPayload(reason, this.getX(), this.getY(), this.getZ()), new CustomPacketPayload[0]);
               }

               if (reason == StopControlPayload.Reason.DESTROYED || reason == StopControlPayload.Reason.CRASHED) {
                  SbwMonitor.unlinkMatching(pilot, this);
               }
            }

            DroneLongRange.release(this, pilot);
         });
         DroneLinks.remember(this);
         this.setController(null);
      }
   }

   public void tick() {
      this.xo = this.getX();
      this.yo = this.getY();
      this.zo = this.getZ();
      super.tick();
      if (this.level().isClientSide) {
         this.tickPropAnimation();
      }

      if (this.level().isClientSide && this.locallyControlled) {
         this.playedAttitude = null;
         this.forgetSnapshots();
         this.lerpSteps = 0;
         this.rotSteps = 0;
         this.wreckSteps = 0;
         this.observerCorrection = Vec3.ZERO;
      } else {
         if (this.level().isClientSide) {
            this.clearPilotPrediction();
         }

         if (this.isWrecked()) {
            this.tickFalling();
         } else if (this.level().isClientSide) {
            this.tickObserver();
         } else {
            int simBefore = this.simTick;
            this.serverTick();
            this.stepsLastTick = Math.max(1, this.simTick - simBefore);
         }
      }
   }

   private void tickPropAnimation() {
      this.propPhaseOld = this.propPhase;
      float targetRate = this.propTargetRate();
      if (targetRate > this.propRate) {
         this.propRate = Math.min(this.propRate + 4.6666665F, targetRate);
      } else {
         this.propRate = Math.max(this.propRate - 1.4F, targetRate);
      }

      this.propPhase = this.propPhase + this.propRate / 20.0F;
   }

   public float propTargetRate() {
      boolean airborne = !this.isRemoved() && !this.isGrounded();
      return !airborne ? 0.0F : (this.getCharge() > 0.0F ? 28.0F : 11.0F);
   }

   public float getPropPhase(float partialTick) {
      return Mth.lerp(partialTick, this.propPhaseOld, this.propPhase);
   }

   private void tickObserver() {
      this.playedAttitude = null;
      this.observerClock++;
      if (!this.snapshots.isEmpty()) {
         if (this.ticksSinceSnapshot++ < this.staleTicks()) {
            this.playSnapshots();
            this.lerpSteps = 0;
            this.observerCorrection = Vec3.ZERO;
            this.rotSteps = 0;
            return;
         }

         this.forgetSnapshots();
      }

      Vec3 velocity = ++this.trackerSilence > 6 ? Vec3.ZERO : this.getDeltaMovement();
      if (this.lerpSteps > 0) {
         this.lerpSteps = 0;
         Vec3 target = new Vec3(this.lerpX, this.lerpY, this.lerpZ).add(velocity.scale(2.0));
         this.observerCorrection = target.subtract(this.position());
         if (this.observerCorrection.lengthSqr() > 576.0) {
            this.setPos(target.x, target.y, target.z);
            this.observerCorrection = Vec3.ZERO;
         }
      }

      if (velocity.lengthSqr() > 1.0E-8 || this.observerCorrection.lengthSqr() > 1.0E-6) {
         Vec3 step = velocity.add(this.observerCorrection.scale(0.25));
         this.observerCorrection = this.observerCorrection.scale(0.75);
         this.setPos(this.getX() + step.x, this.getY() + step.y, this.getZ() + step.z);
      }

      if (this.rotSteps > 0) {
         float yRot = this.getYRot() + (float)Mth.wrapDegrees(this.lerpYRot - (double)this.getYRot()) / (float)this.rotSteps;
         float xRot = this.getXRot() + (float)(this.lerpXRot - (double)this.getXRot()) / (float)this.rotSteps;
         this.rotSteps--;
         this.setRot(yRot, xRot);
      }
   }

   private void maintainFlightChunks() {
      if (this.tickCount % 4 == 0) {
         this.loadFlightChunks();
      }
   }

   public void loadFlightChunks() {
      if (!SeekerChunks.load(this)) {
         if (this.level() instanceof ServerLevel serverLevel) {
            ChunkPos var22 = this.chunkPosition();
            ChunkLoadHelper.keepTicking(serverLevel, var22);
            Vec3 motion = this.getDeltaMovement();
            double speed = motion.horizontalDistance();
            if (this.needsLongRangeLink()) {
               double lead = (double)DroneLongRange.streamRadius() * 16.0 * 0.6;
               double leadX = speed > 0.001 ? motion.x / speed * lead : 0.0;
               double leadZ = speed > 0.001 ? motion.z / speed * lead : 0.0;
               ChunkPos centre = ChunkLoadHelper.chunkAt(this.getX() + leadX, this.getZ() + leadZ);
               int radius = DroneLongRange.loadedRadius();

               for (int dx = -radius; dx <= radius; dx++) {
                  for (int dz = -radius; dz <= radius; dz++) {
                     ChunkLoadHelper.keepLoaded(serverLevel, new ChunkPos(centre.x + dx, centre.z + dz));
                  }
               }

               if (speed > 0.001) {
                  double dirX = motion.x / speed;
                  double dirZ = motion.z / speed;
                  double preload = Math.max((double)(radius + 1) * 16.0 * 2.0, speed * 20.0 * 4.0);

                  for (double ahead = (double)(radius + 1) * 16.0; ahead <= preload; ahead += 16.0) {
                     ChunkLoadHelper.preloadAhead(serverLevel, ChunkLoadHelper.chunkAt(this.getX() + dirX * ahead, this.getZ() + dirZ * ahead));
                  }
               }
            } else if (!(speed < 0.001)) {
               double dirX = motion.x / speed;
               double dirZ = motion.z / speed;
               double ticking = Math.max(48.0, speed * 20.0 * 2.0);
               ChunkPos last = var22;

               for (double ahead = 16.0; ahead <= ticking; ahead += 16.0) {
                  ChunkPos next = ChunkLoadHelper.chunkAt(this.getX() + dirX * ahead, this.getZ() + dirZ * ahead);
                  if (!next.equals(last)) {
                     ChunkLoadHelper.keepTicking(serverLevel, next);
                     last = next;
                  }
               }

               double preload = Math.max(160.0, speed * 20.0 * 6.0);

               for (double aheadx = ticking + 64.0; aheadx <= preload; aheadx += 64.0) {
                  ChunkPos far = ChunkLoadHelper.chunkAt(this.getX() + dirX * aheadx, this.getZ() + dirZ * aheadx);
                  ChunkLoadHelper.preloadAhead(serverLevel, far);
               }
            }
         }
      }
   }

   private void serverTick() {
      this.simulatedThisTick = false;
      Optional<UUID> controller = this.getControllerId();
      ServerPlayer pilot = controller.<Player>map(id -> this.level().getPlayerByUUID(id))
         .filter(ServerPlayer.class::isInstance)
         .map(ServerPlayer.class::cast)
         .orElse(null);
      if (controller.isPresent()) {
         if (pilot == null || pilot.isRemoved() || !pilot.isAlive() || pilot.level() != this.level() || this.distanceToSqr(pilot) > this.controlRangeSqr()) {
            this.releaseControl(true);
            pilot = null;
         } else if (this.inputSilence > 100) {
            this.releaseControl(false);
            pilot = null;
         }
      }

      if (this.tickCount % 10 == 0) {
         DroneLinks.remember(this);
      }

      if (this.getCharge() <= 0.0F && this.isControlled()) {
         this.packRanOut();
      }

      boolean piloted = this.isControlled() && pilot != null;
      if (this.autolandsWhenFlat() && this.getCharge() <= 0.0F && !this.isGrounded()) {
         Vec3 velocity = this.getDeltaMovement();
         double descent = Math.max(velocity.y - 0.012, -0.1);
         this.setDeltaMovement(velocity.x * 0.93, descent, velocity.z * 0.93);
         this.move(MoverType.SELF, this.getDeltaMovement());
         this.simTick++;
         this.simulatedThisTick = true;
         this.broadcastState();
      } else {
         if (piloted) {
            this.inputSilence++;
            if (!this.flyQueuedInputs(pilot)) {
               return;
            }
         } else {
            if (this.isGrounded() && this.getDeltaMovement().lengthSqr() < 1.0E-6) {
               if (this.getDeltaMovement() != Vec3.ZERO) {
                  this.setDeltaMovement(Vec3.ZERO);
               }

               this.syncInputLoad();
               return;
            }

            if (!this.flyOneStep(PilotInput.NEUTRAL, null)) {
               return;
            }
         }

         this.syncInputLoad();
         if (piloted && this.isControlled()) {
            this.maintainFlightChunks();
            DroneLongRange.tick(this, pilot);
         }

         this.broadcastState();
      }
   }

   private boolean flyQueuedInputs(@Nullable ServerPlayer pilot) {
      boolean heard;
      for (heard = !this.inputQueue.isEmpty(); this.owedInputs > 0 && !this.inputQueue.isEmpty(); this.owedInputs--) {
         PilotInput owed = this.inputQueue.pollFirst();
         this.lastInput = owed;
         this.lastInputSeq = owed.seq();
      }

      if (!this.carryOutOrders(pilot)) {
         return false;
      } else {
         this.refillInputCredit();
         int flown = 0;

         while (!this.inputQueue.isEmpty() && flown < 40 && this.inputCredit >= 1.0) {
            PilotInput input = this.inputQueue.pollFirst();
            this.inputCredit--;
            this.lastInput = input;
            this.lastInputSeq = input.seq();
            flown++;
            if (!this.flyOneStep(input, pilot) || !this.carryOutOrders(pilot)) {
               return false;
            }

            if (!this.keepStepping()) {
               break;
            }
         }

         if (heard) {
            return true;
         } else {
            double silent = (double)(System.nanoTime() - this.lastInputNanos) / 5.0E7;
            if (this.lastInputSeq < 0) {
               if (silent <= 20.0) {
                  return true;
               } else if (!this.flyOneStep(PilotInput.NEUTRAL, pilot)) {
                  return false;
               } else {
                  this.keepStepping();
                  return true;
               }
            } else if (silent <= 4.0) {
               return true;
            } else if (this.inputCredit < 1.0) {
               return true;
            } else {
               PilotInput held = silent > 20.0 ? this.lastInput.released() : this.lastInput;
               PilotInput guess = held.withSeq(this.lastInputSeq + this.owedInputs + 1);
               this.inputCredit--;
               if (this.owedInputs < 100) {
                  this.owedInputs++;
               }

               if (this.flyOneStep(guess, pilot) && this.carryOutOrders(pilot)) {
                  this.keepStepping();
                  return true;
               } else {
                  return false;
               }
            }
         }
      }
   }

   private boolean keepStepping() {
      if (this.level() instanceof ServerLevel serverLevel && !this.isRemoved()) {
         ChunkPos chunk = this.chunkPosition();
         if (chunk.toLong() != this.steppedChunk) {
            this.steppedChunk = chunk.toLong();
            ChunkLoadHelper.keepTicking(serverLevel, chunk);
         }

         return serverLevel.isPositionEntityTicking(this.blockPosition());
      }

      return true;
   }

   private void refillInputCredit() {
      long now = System.nanoTime();
      if (this.creditClock != 0L) {
         this.inputCredit = Math.min(40.0, this.inputCredit + (double)(now - this.creditClock) / 5.0E7);
      }

      this.creditClock = now;
   }

   private boolean flyOneStep(PilotInput input, @Nullable ServerPlayer pilot) {
      this.flyPilotStep(input);
      this.simTick++;
      this.simulatedThisTick = true;
      if ((double)this.lastCollisionSpeed * 72.0 >= this.crashSpeedKmh()) {
         Entity credit = this.creditFor(pilot);
         Entity struck = this.lastRammed;
         this.releaseControl(StopControlPayload.Reason.CRASHED);
         if (struck != null && !struck.isRemoved()) {
            this.ram(struck, credit);
         }

         this.destroyOnImpact(credit);
         return false;
      } else {
         return true;
      }
   }

   private void broadcastState() {
      if (this.simulatedThisTick) {
         if (this.level() instanceof ServerLevel serverLevel) {
            Vec3 var9 = this.getDeltaMovement();
            Quaternionfc attitude = this.linkAttitude();
            DroneStatePayload state = new DroneStatePayload(
               this.getId(),
               this.simTick,
               this.getX(),
               this.getY(),
               this.getZ(),
               var9.x,
               var9.y,
               var9.z,
               this.getYRot(),
               this.getXRot(),
               attitude.x(),
               attitude.y(),
               attitude.z(),
               attitude.w()
            );
            TrackerAccess.Entry tracked = TrackerAccess.tracked(serverLevel, this.getId());
            if (tracked != null) {
               for (ServerPlayerConnection connection : tracked.sfw$seenBy()) {
                  ServerPlayer watcher = connection.getPlayer();
                  if (!this.isControlledBy(watcher) && watcher.connection.hasChannel(DroneStatePayload.TYPE)) {
                     PacketDistributor.sendToPlayer(watcher, state, new CustomPacketPayload[0]);
                  }
               }
            }
         }
      }
   }

   public boolean autolandsWhenFlat() {
      return true;
   }

   public boolean motorsDead() {
      return this.isRemoved() || this.isWrecked();
   }

   public boolean isGrounded() {
      AABB box = this.getBoundingBox();
      AABB probe = new AABB(box.minX + 0.1, box.minY - 0.06, box.minZ + 0.1, box.maxX - 0.1, box.minY + 0.01, box.maxZ - 0.1);
      return !this.level().noCollision(this, probe);
   }

   public void turnGimbal(double yawDelta, double pitchDelta) {
      float yaw = this.getYRot() + (float)yawDelta;
      float pitch = Mth.clamp(this.getXRot() + (float)pitchDelta, this.minPitch(), this.maxPitch());
      this.setYRot(yaw);
      this.setXRot(pitch);
      this.yRotO = yaw;
      this.xRotO = pitch;
   }

   public void applyControlInput(boolean forward, boolean backward, boolean left, boolean right, boolean up, boolean down) {
      float wrapped = Mth.wrapDegrees(this.getYRot());
      this.yRotO = this.yRotO + (wrapped - this.getYRot());
      this.setYRot(wrapped);
      this.inputSideways = decay(this.inputSideways, left, right);
      this.inputVertical = decay(this.inputVertical, up, down);
      this.inputForward = decay(this.inputForward, forward, backward);
      boolean grounded = this.isGrounded();
      float touchdownSpeed = grounded ? this.settleOnGround() : 0.0F;
      boolean throttled = up || !grounded && (forward || backward || left || right || down);
      if (throttled && this.getDeltaMovement().horizontalDistanceSqr() < 1.0) {
         this.setDeltaMovement(this.getDeltaMovement().multiply(1.04, 1.0, 1.04));
      }

      float friction = 0.91F;
      this.moveRelative(this.thrust(), new Vec3(2.0 * (double)this.inputSideways, 2.0 * (double)this.inputVertical, 2.0 * (double)this.inputForward));
      Vec3 approach = this.getDeltaMovement();
      Vec3 from = this.position();
      this.recordImpact(from, approach, touchdownSpeed);
      double yawRad = (double)(this.getYRot() * 0.017453292F);
      double sin = (double)Mth.sin((float)yawRad);
      double cos = (double)Mth.cos((float)yawRad);
      Vec3 velocity = this.getDeltaMovement();
      double localSide = velocity.x * cos + velocity.z * sin;
      double localForward = -velocity.x * sin + velocity.z * cos;
      localSide = axisFriction(localSide, this.inputSideways, friction, 1.05F, 0.95F);
      localForward = axisFriction(localForward, this.inputForward, friction, 1.05F, 0.95F);
      double localUp = axisFriction(velocity.y, this.inputVertical, 0.98F, 0.99F, 0.87F);
      double maxDescent = DroneTuning.get(DroneTuning.Value.MAVIC_MAX_DESCENT_SPEED) / 72.0;
      if (localUp < -maxDescent) {
         localUp = -maxDescent;
      }

      double cap = this.topSpeed();
      if (cap > 0.0) {
         double horizontal = Math.sqrt(localSide * localSide + localForward * localForward);
         if (horizontal > cap) {
            double scale = cap / horizontal;
            localSide *= scale;
            localForward *= scale;
         }

         if (localUp > cap) {
            localUp = cap;
         }
      }

      Vec3 newVelocity = new Vec3(localSide * cos - localForward * sin, localUp, localForward * cos + localSide * sin);
      if (newVelocity.lengthSqr() < 1.0E-7) {
         newVelocity = Vec3.ZERO;
      }

      this.setDeltaMovement(newVelocity);
   }

   protected float settleOnGround() {
      float touchdownSpeed = (float)this.getDeltaMovement().length();
      this.inputSideways = 0.0F;
      this.inputForward = 0.0F;
      if (this.inputVertical < 0.0F) {
         this.inputVertical = 0.0F;
      }

      Vec3 landing = this.getDeltaMovement();
      double skidX = landing.x * 0.82;
      double skidZ = landing.z * 0.82;
      if (skidX * skidX + skidZ * skidZ < 4.0E-4) {
         skidX = 0.0;
         skidZ = 0.0;
      }

      this.setDeltaMovement(skidX, Math.max(landing.y, 0.0), skidZ);
      return touchdownSpeed;
   }

   protected void recordImpact(Vec3 from, Vec3 approach, float touchdownSpeed) {
      this.move(MoverType.SELF, approach);
      if (!this.level().isClientSide) {
         this.recentApproach = Math.max(this.recentApproach * 0.85, approach.length());
      }

      DroneEntity.Ram ram = !this.replaying && approach.length() >= this.ramSpeed() ? this.entityInTheWay(from, approach) : null;
      float struck = this.impactSpeed(approach, ram);
      this.lastCollisionSpeed = Math.max(struck, touchdownSpeed);
      this.lastRammed = ram != null ? ram.entity() : null;
      if (ram != null) {
         Vec3 contact = from.add(approach.scale(ram.contact()));
         this.setPos(contact.x, contact.y, contact.z);
         this.setDeltaMovement(Vec3.ZERO);
      }
   }

   protected float impactSpeed(Vec3 approach, @Nullable DroneEntity.Ram ram) {
      if (ram != null) {
         return Math.nextUp((float)Math.max(approach.length(), this.crashSpeed()));
      } else {
         return !this.horizontalCollision && !this.verticalCollision ? 0.0F : (float)approach.length();
      }
   }

   protected static float decay(float axis, boolean positive, boolean negative) {
      if (positive) {
         return 1.5F;
      } else if (negative) {
         return -1.5F;
      } else {
         return axis >= 0.0F ? Mth.clamp(axis - 0.3F, 0.0F, 1.0F) : Mth.clamp(axis + 0.3F, -1.0F, 0.0F);
      }
   }

   protected static double axisFriction(double localVelocity, float axisInput, float baseFriction, float boost, float hold) {
      boolean boosting = axisInput != 0.0F && ((double)Math.signum(axisInput) != -Math.signum(localVelocity) || !(Math.abs(localVelocity) > 0.001));
      return localVelocity * (double)baseFriction * (double)(boosting ? boost : hold);
   }

   public void lerpTo(double x, double y, double z, float yRot, float xRot, int steps) {
      if (!this.locallyControlled) {
         this.lerpX = x;
         this.lerpY = y;
         this.lerpZ = z;
         this.lerpYRot = (double)yRot;
         this.lerpXRot = (double)xRot;
         this.lerpSteps = 1;
         this.trackerSilence = 0;
         this.rotSteps = Math.max(steps, 1);
      }
   }

   public void lerpMotion(double x, double y, double z) {
      if (!this.locallyControlled) {
         super.lerpMotion(x, y, z);
         this.trackerSilence = 0;
      }
   }

   public Quaternionfc linkAttitude() {
      return LEVEL;
   }

   @Nullable
   public Quaternionf renderRotation(float partialTick) {
      return null;
   }

   public double lerpTargetX() {
      return this.lerpSteps > 0 ? this.lerpX : this.getX();
   }

   public double lerpTargetY() {
      return this.lerpSteps > 0 ? this.lerpY : this.getY();
   }

   public double lerpTargetZ() {
      return this.lerpSteps > 0 ? this.lerpZ : this.getZ();
   }

   public float lerpTargetXRot() {
      return this.lerpSteps > 0 && !this.locallyControlled ? (float)this.lerpXRot : this.getXRot();
   }

   public float lerpTargetYRot() {
      return this.lerpSteps > 0 && !this.locallyControlled ? (float)this.lerpYRot : this.getYRot();
   }

   public InteractionResult interact(Player player, InteractionHand hand) {
      ItemStack held = player.getItemInHand(hand);
      if (player.isShiftKeyDown() && SbwMonitor.isLinkedTo(held, this)) {
         if (!this.level().isClientSide) {
            SbwMonitor.unlink(held, player);
            this.releaseControl(false);
            player.displayClientMessage(Component.translatable("message.sfw.drone.unlinked"), true);
         }

         return InteractionResult.sidedSuccess(this.level().isClientSide);
      } else if (player.isShiftKeyDown()) {
         if (!this.level().isClientSide) {
            this.packUpFor(player, !player.getAbilities().instabuild);
         }

         return InteractionResult.sidedSuccess(this.level().isClientSide);
      } else if (SbwMonitor.isMonitor(held)) {
         if (!this.level().isClientSide) {
            if (SbwMonitor.isLinked(held)) {
               player.displayClientMessage(
                  SbwMonitor.isLinkedTo(held, this)
                     ? Component.translatable("message.sfw.drone.linked")
                     : Component.translatable("message.sfw.drone.monitor_busy"),
                  true
               );
            } else {
               SbwMonitor.link(held, this);
               player.displayClientMessage(Component.translatable("message.sfw.drone.linked"), true);
            }
         }

         return InteractionResult.sidedSuccess(this.level().isClientSide);
      } else if (this.carriesStores() && !this.hasAttachment() && this.canCarry(held)) {
         if (!this.level().isClientSide) {
            this.setAttachment(held.copyWithCount(1));
            if (!player.getAbilities().instabuild) {
               held.shrink(1);
            }

            player.displayClientMessage(Component.translatable("message.sfw.drone.grenade_attached"), true);
         }

         return InteractionResult.sidedSuccess(this.level().isClientSide);
      } else {
         return InteractionResult.PASS;
      }
   }

   public void packUpFor(Player player, boolean give) {
      this.releaseControl(false);
      SbwMonitor.unlinkMatching(player, this);
      ItemStack store = this.getAttachment();
      this.setAttachment(ItemStack.EMPTY);
      if (give) {
         this.giveOrDrop(player, this.packedItem());
         if (!store.isEmpty()) {
            this.giveOrDrop(player, store);
         }
      }

      this.discard();
   }

   public void dropAsItem() {
      ItemStack store = this.getAttachment();
      this.setAttachment(ItemStack.EMPTY);
      this.spawnAtLocation(this.packedItem());
      if (!store.isEmpty()) {
         this.spawnAtLocation(store);
      }

      this.discard();
   }

   private void giveOrDrop(Player player, ItemStack stack) {
      if (!player.getInventory().add(stack)) {
         this.spawnAtLocation(stack);
      }
   }

   protected double maxHitpoints() {
      return (Double)SkyfrontConfig.MAVIC_HITPOINTS.get();
   }

   public float getHealth() {
      if (this.health < 0.0F) {
         this.health = (float)this.maxHitpoints();
      }

      return this.health;
   }

   public boolean hurt(DamageSource source, float amount) {
      if (!this.level().isClientSide && !this.isRemoved() && !this.destroyed && !(amount <= 0.0F)) {
         if (source.getEntity() == this || source.getDirectEntity() == this) {
            return false;
         } else if (this.setsOffCharge(source)) {
            this.destroyNow(this.creditFor(source.getEntity()));
            return true;
         } else if (this.isWrecked()) {
            return false;
         } else {
            this.health = this.getHealth() - amount;
            if (this.health > 0.0F) {
               return true;
            } else {
               this.releaseControl(StopControlPayload.Reason.DESTROYED);
               Entity attacker = this.creditFor(source.getEntity());
               if (this.isGrounded()) {
                  this.destroyNow(attacker);
                  return true;
               } else if (GrenadeAttachments.isExplosive(this.getAttachment())
                  && this.random.nextInt(100) < (Integer)SkyfrontConfig.DRONE_AIRBURST_CHANCE.get()) {
                  this.destroyNow(attacker);
                  return true;
               } else {
                  this.downedById = attacker != null ? attacker.getUUID() : null;
                  this.startFalling();
                  return true;
               }
            }
         }
      } else {
         return false;
      }
   }

   protected boolean setsOffCharge(DamageSource source) {
      return false;
   }

   private void startFalling() {
      this.entityData.set(DATA_WRECKED, true);
      this.swerve = this.random.nextBoolean() ? 1 : -1;
      this.setNoGravity(true);
      this.setDeltaMovement(this.getDeltaMovement().add(0.0, -0.05, 0.0));
   }

   private void followWreck() {
      if (this.lerpSteps > 0) {
         this.lerpSteps = 0;
         this.wreckSteps = 3;
      }

      if (this.wreckSteps > 0) {
         double share = 1.0 / (double)this.wreckSteps;
         this.setPos(
            this.getX() + (this.lerpX - this.getX()) * share,
            this.getY() + (this.lerpY - this.getY()) * share,
            this.getZ() + (this.lerpZ - this.getZ()) * share
         );
         this.setRot(
            this.getYRot() + (float)(Mth.wrapDegrees(this.lerpYRot - (double)this.getYRot()) * share),
            this.getXRot() + (float)((this.lerpXRot - (double)this.getXRot()) * share)
         );
         this.wreckSteps--;
      } else {
         Vec3 velocity = this.getDeltaMovement();
         this.setPos(this.getX() + velocity.x, this.getY() + velocity.y, this.getZ() + velocity.z);
      }
   }

   protected boolean fallsLikeAPlane() {
      return false;
   }

   protected Quaternionf wreckStartAttitude() {
      return new Quaternionf().rotationY((180.0F - this.getYRot()) * 0.017453292F);
   }

   protected float wreckStartRoll() {
      return 0.0F;
   }

   @Nullable
   public Quaternionf wreckRotation(float partialTick) {
      return !this.fallsLikeAPlane() && this.tumbleReady ? this.tumbleOld.slerp(this.tumble, Mth.clamp(partialTick, 0.0F, 1.0F), new Quaternionf()) : null;
   }

   private void tickFalling() {
      this.wreckTicks++;
      boolean plane = this.fallsLikeAPlane();
      if (plane) {
         this.spin += 0.12F;
         if (this.wreckTicks == 1) {
            this.roll = this.wreckStartRoll();
         }

         this.rollOld = this.roll;
         this.roll = this.roll - Math.min(this.spin * 1.5F, 9.0F);
      }

      if (this.level().isClientSide) {
         if (!plane) {
            this.tumbleStep();
         }

         this.followWreck();
      } else {
         Vec3 falling = plane ? this.planeFall() : this.quadFall();
         this.setDeltaMovement(falling);
         if (plane) {
            this.setYRot((float)(Mth.atan2(-falling.x, falling.z) * 57.2957763671875));
            this.setXRot((float)(Mth.atan2(-falling.y, falling.horizontalDistance()) * 57.2957763671875));
         }

         this.move(MoverType.SELF, falling);
         if (!this.horizontalCollision && !this.verticalCollision && !this.isGrounded() && !this.isInWall()) {
            if (this.getY() < (double)(this.level().getMinBuildHeight() - 16)) {
               this.destroyNow(this.downedBy());
            }
         } else {
            this.destroyNow(this.downedBy());
         }
      }
   }

   private Vec3 planeFall() {
      Vec3 motion = this.getDeltaMovement();
      double speed = motion.length();
      if (speed < 1.0E-4) {
         motion = new Vec3(0.0, -0.1, 0.0);
         speed = 0.1;
      }

      double blend = Math.min(0.0012 * (double)this.spin, 0.06);
      Vec3 direction = motion.scale(1.0 / speed);
      Vec3 down = new Vec3(0.0, -1.0, 0.0);
      Vec3 aim = direction.add(down.subtract(direction).scale(blend));
      aim = aim.lengthSqr() > 1.0E-6 ? aim.normalize() : down;
      double newSpeed = Math.min(speed + 0.02 * Math.max(0.0, -aim.y), 1.8);
      Vec3 falling = aim.scale(newSpeed).add(0.0, -Math.min(0.002 * (double)this.spin, 0.06), 0.0);
      if (this.swerve != 0) {
         double curve = (double)this.swerve * Math.min((double)this.spin * 0.004, 0.045);
         double cos = Math.cos(curve);
         double sin = Math.sin(curve);
         falling = new Vec3(falling.x * cos - falling.z * sin, falling.y, falling.x * sin + falling.z * cos);
      }

      return falling;
   }

   private Vec3 quadFall() {
      Vec3 motion = this.getDeltaMovement().add(0.0, -0.06, 0.0);
      return new Vec3(motion.x * 0.975, motion.y * 0.962, motion.z * 0.975);
   }

   private void tumbleStep() {
      if (!this.tumbleReady) {
         this.tumble.set(this.wreckStartAttitude());
         this.tumbleOld.set(this.tumble);
         RandomSource dice = RandomSource.create((long)this.getId() * 341873128712L + 132897987541L);
         this.tumbleAxis.set((float)dice.nextGaussian() * 0.6F, (float)dice.nextGaussian() * 0.3F, (float)dice.nextGaussian());
         if (this.tumbleAxis.lengthSquared() < 1.0E-4F) {
            this.tumbleAxis.set(1.0F, 0.0F, 0.0F);
         }

         this.tumbleAxis.normalize();
         this.tumbleRate = (14.0F + dice.nextFloat() * 14.0F) * 0.017453292F;
         this.tumbleReady = true;
      }

      this.tumbleOld.set(this.tumble);
      float windUp = Math.min(1.0F, (float)this.wreckTicks / 12.0F);
      float angle = this.tumbleRate * windUp * windUp;
      if (angle > 1.0E-5F) {
         new Quaternionf().fromAxisAngleRad(this.tumbleAxis, angle).mul(this.tumble, this.tumble);
      }
   }

   public void destroyOnImpact(@Nullable Entity pilot) {
      this.destroyNow(pilot);
   }

   public void ram(Entity struck, @Nullable Entity pilot) {
      if (!this.level().isClientSide) {
         float damage = this.ramDamage();
         if (!(damage <= 0.0F)) {
            Entity credit = this.creditFor(pilot);
            boolean vehicle = SbwCompat.isLoaded() && SbwVehicles.isVehicle(struck);
            if (vehicle) {
               SbwVehicles.damageVehicleDirectHit(struck, this, credit, damage);
            }

            struck.hurt(this.ramDamage(credit, vehicle), damage);
         }
      }
   }

   protected void destroyNow(@Nullable Entity attacker) {
      if (!this.destroyed) {
         this.destroyed = true;
         this.releaseControl(StopControlPayload.Reason.DESTROYED);
         if (this.level() instanceof ServerLevel serverLevel) {
            this.goOff(serverLevel, attacker);
         }

         this.discard();
      }
   }

   protected void goOff(ServerLevel level, @Nullable Entity attacker) {
      this.goOffWithStore(level, attacker);
   }

   protected final void goOffWithStore(ServerLevel level, @Nullable Entity attacker) {
      ItemStack store = this.getAttachment();
      this.setAttachment(ItemStack.EMPTY);
      if (GrenadeAttachments.isExplosive(store)) {
         GrenadeAttachments.detonate(level, store, this.position(), this, attacker);
      } else if (!store.isEmpty()) {
         ServerPlayer owner = attacker instanceof ServerPlayer player ? player : null;
         GrenadeAttachments.release(level, owner, store, this.position(), this.getDeltaMovement());
         GrenadeAttachments.breakUp(level, this.position(), this, attacker);
      } else {
         GrenadeAttachments.breakUp(level, this.position(), this, attacker);
      }
   }

   public void remove(RemovalReason reason) {
      if (!this.level().isClientSide) {
         this.releaseControl(false);
         if (reason == RemovalReason.KILLED || reason == RemovalReason.DISCARDED) {
            SbwMonitor.unlinkEverywhere(this);
            DroneLinks.forget(this);
         }
      }

      super.remove(reason);
   }

   public ItemStack packedItem() {
      return new ItemStack((ItemLike)DroneItems.DRONE.get());
   }

   public ItemStack getPickResult() {
      return this.packedItem();
   }

   public boolean isPickable() {
      return !this.isRemoved();
   }

   public boolean shouldRenderAtSqrDistance(double distanceSqr) {
      double range = Math.max(this.controlRange(), 256.0);
      return distanceSqr < range * range;
   }

   public boolean isPushable() {
      return false;
   }

   public boolean canBeCollidedWith() {
      return false;
   }

   protected void readAdditionalSaveData(CompoundTag tag) {
      if (tag.contains("Charge")) {
         this.setCharge(tag.getFloat("Charge"));
      }

      if (tag.contains("Health")) {
         this.health = tag.getFloat("Health");
      }

      if (tag.contains("Armed")) {
         this.entityData.set(DATA_ARMED, tag.getBoolean("Armed"));
      }

      if (tag.hasUUID("LastPilot")) {
         this.lastPilotId = tag.getUUID("LastPilot");
      }

      if (tag.contains("Attachment", 10)) {
         this.setAttachment(ItemStack.parseOptional(this.level().registryAccess(), tag.getCompound("Attachment")));
      }
   }

   protected void addAdditionalSaveData(CompoundTag tag) {
      tag.putFloat("Charge", this.getCharge());
      tag.putFloat("Health", this.getHealth());
      tag.putBoolean("Armed", (Boolean)this.entityData.get(DATA_ARMED));
      if (this.lastPilotId != null) {
         tag.putUUID("LastPilot", this.lastPilotId);
      }

      if (this.hasAttachment()) {
         tag.put("Attachment", this.getAttachment().save(this.level().registryAccess()));
      }
   }

   public static enum Osd {
      CAMERA,
      BETAFLIGHT,
      INAV,
      BETAFLIGHT_GPS,
      NONE;

      private Osd() {
      }

      public boolean isFlightController() {
         return this == BETAFLIGHT || this == INAV || this == BETAFLIGHT_GPS;
      }
   }

   protected static record Ram(Entity entity, double contact) {
   }

   private static record Snapshot(int simTick, double x, double y, double z, double vx, double vy, double vz, float yRot, float xRot, Quaternionf attitude) {
   }
}
