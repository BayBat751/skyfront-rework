package dev.krutlexik.skyfront.drone.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({LevelRenderer.class})
public class LevelRendererViewAreaMixin {
   public LevelRendererViewAreaMixin() {
   }

   @Redirect(
      method = {"setupRender"},
      require = 0,
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/player/LocalPlayer;getX()D"
      )
   )
   private double skyfront$gridX(LocalPlayer player) {
      Vec3 camera = skyfront$detachedCamera(player);
      return camera != null ? camera.x : player.getX();
   }

   @Redirect(
      method = {"setupRender"},
      require = 0,
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/player/LocalPlayer;getY()D"
      )
   )
   private double skyfront$gridY(LocalPlayer player) {
      Vec3 camera = skyfront$detachedCamera(player);
      return camera != null ? camera.y : player.getY();
   }

   @Redirect(
      method = {"setupRender"},
      require = 0,
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/player/LocalPlayer;getZ()D"
      )
   )
   private double skyfront$gridZ(LocalPlayer player) {
      Vec3 camera = skyfront$detachedCamera(player);
      return camera != null ? camera.z : player.getZ();
   }

   private static Vec3 skyfront$detachedCamera(LocalPlayer player) {
      Minecraft minecraft = Minecraft.getInstance();
      return minecraft.getCameraEntity() != null && minecraft.getCameraEntity() != player ? minecraft.gameRenderer.getMainCamera().getPosition() : null;
   }
}
