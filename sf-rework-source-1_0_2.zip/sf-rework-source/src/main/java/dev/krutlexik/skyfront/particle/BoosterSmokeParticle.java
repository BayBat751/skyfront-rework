package dev.krutlexik.skyfront.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.world.phys.AABB;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class BoosterSmokeParticle extends TrailParticle {
   private float startSize = 0.9F;
   private float endSize = 3.4F;
   private int growTicks = 110;
   private int hotTicks;
   private final float shade;
   private final float spin;

   protected BoosterSmokeParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, SpriteSet sprites) {
      super(level, x, y, z);
      this.xd = vx;
      this.yd = vy;
      this.zd = vz;
      this.lifetime = 320 + this.random.nextInt(140);
      this.hasPhysics = true;
      this.gravity = 0.0F;
      this.shade = 0.84F + this.random.nextFloat() * 0.12F;
      this.rCol = this.shade;
      this.gCol = this.shade;
      this.bCol = this.shade * 0.97F;
      this.alpha = 0.92F;
      this.quadSize = this.startSize;
      this.spin = (this.random.nextFloat() - 0.5F) * 0.02F;
      this.roll = this.random.nextFloat() * 6.2831855F;
      this.oRoll = this.roll;
      this.pickSprite(sprites);
   }

   public BoosterSmokeParticle shape(float startSize, float endSize, int growTicks, int lifetime) {
      this.startSize = startSize;
      this.endSize = endSize;
      this.growTicks = Math.max(1, growTicks);
      this.lifetime = lifetime;
      this.quadSize = startSize;
      return this;
   }

   public BoosterSmokeParticle hot(int ticks) {
      this.hotTicks = ticks;
      if (ticks > 0) {
         this.rCol = 1.0F;
         this.gCol = 0.72F;
         this.bCol = 0.42F;
      }

      return this;
   }

   public void tick() {
      this.xo = this.x;
      this.yo = this.y;
      this.zo = this.z;
      if (this.age++ >= this.lifetime) {
         this.remove();
      } else {
         this.oRoll = this.roll;
         this.roll = this.roll + this.spin;
         this.move(this.xd, this.yd, this.zd);
         double drag = this.age < 20 ? 0.86 : 0.96;
         this.xd = this.xd * drag + (double)(this.random.nextFloat() - 0.5F) * 0.0016;
         this.zd = this.zd * drag + (double)(this.random.nextFloat() - 0.5F) * 0.0016;
         this.yd = this.yd * drag + 0.0011;
         float grown = Math.min((float)this.age / (float)this.growTicks, 1.0F);
         float eased = 1.0F - (1.0F - grown) * (1.0F - grown);
         this.quadSize = this.startSize + (this.endSize - this.startSize) * eased;
         if (this.age < this.hotTicks) {
            float cool = (float)this.age / (float)this.hotTicks;
            this.rCol = 1.0F + (this.shade - 1.0F) * cool;
            this.gCol = 0.72F + (this.shade - 0.72F) * cool;
            this.bCol = 0.42F + (this.shade * 0.97F - 0.42F) * cool;
         } else if (this.age == this.hotTicks) {
            this.rCol = this.shade;
            this.gCol = this.shade;
            this.bCol = this.shade * 0.97F;
         }

         float life = (float)this.age / (float)this.lifetime;
         float fade = life < 0.6F ? 1.0F : 1.0F - (life - 0.6F) / 0.4F;
         this.alpha = 0.92F * (1.0F - 0.4F * eased) * fade;
      }
   }

   public int getLightColor(float partialTick) {
      return this.age < this.hotTicks ? 15728880 : super.getLightColor(partialTick);
   }

   public AABB getRenderBoundingBox(float partialTicks) {
      return this.getBoundingBox().inflate((double)this.quadSize);
   }

   public ParticleRenderType getRenderType() {
      return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
   }

   @OnlyIn(Dist.CLIENT)
   public static class Provider implements ParticleProvider<SimpleParticleType> {
      private final SpriteSet sprites;

      public Provider(SpriteSet sprites) {
         this.sprites = sprites;
      }

      public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double vx, double vy, double vz) {
         return new BoosterSmokeParticle(level, x, y, z, vx, vy, vz, this.sprites);
      }
   }
}
