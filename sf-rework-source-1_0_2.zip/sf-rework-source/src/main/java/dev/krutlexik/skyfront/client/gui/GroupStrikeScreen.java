package dev.krutlexik.skyfront.client.gui;

import com.mojang.math.Axis;
import dev.krutlexik.skyfront.client.ClientTerminalLimits;
import dev.krutlexik.skyfront.network.NetworkHandler;
import dev.krutlexik.skyfront.network.RequestWorldMapPacket;
import dev.krutlexik.skyfront.network.TerminalActionPacket;
import dev.krutlexik.skyfront.network.TerminalDataPacket;
import dev.krutlexik.skyfront.seeker.SeekerGroup;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public class GroupStrikeScreen extends Screen {
   private static final int MAP_RADIUS = 2000;
   private static final int LIST_ROWS = 6;
   private static final ResourceLocation DRONE_ICON = ResourceLocation.fromNamespaceAndPath("sfw", "textures/gui/shahed_icon.png");
   private final ShahedTerminalScreen parent;
   private final BlockPos terminalPos;
   private final double originX;
   private final double originZ;
   private final TerrainMapView mapView = new TerrainMapView(ResourceLocation.fromNamespaceAndPath("sfw", "dynamic/group_strike_map"));
   private final Set<UUID> selected = new HashSet<>();
   private boolean hasCenter;
   private int centerX;
   private int centerZ;
   private String radiusText = "60";
   private String altitudeText;
   private boolean farDive = true;
   private int listScroll;
   private float zoom = 1.0F;
   private float offsetX;
   private float offsetZ;
   private boolean dragging;
   private boolean pressedInMap;
   private boolean pannedWhilePressed;
   private double pressX;
   private double pressY;
   private EditBox radiusInput;
   private EditBox altInput;
   private EditBox xInput;
   private EditBox zInput;
   private String xText = "";
   private String zText = "";
   private TerminalButton strikeButton;
   private int refreshTimer;

   public GroupStrikeScreen(ShahedTerminalScreen var1) {
      super(Component.translatable("gui.sfw.group.title"));
      this.parent = var1;
      this.terminalPos = var1.getTerminalPos();
      this.originX = (double)this.terminalPos.getX();
      this.originZ = (double)this.terminalPos.getZ();
      int var2 = 300;

      for (TerminalDataPacket.Row var4 : var1.rows) {
         if (var4.status() == 0) {
            var2 = var4.altitude();
            break;
         }
      }

      this.altitudeText = String.valueOf(var2);
   }

   public BlockPos getTerminalPos() {
      return this.terminalPos;
   }

   public void updateData(List<TerminalDataPacket.Row> var1, TerminalDataPacket.MapSlot var2) {
      this.parent.updateData(var1, var2);
      HashSet var3 = new HashSet();

      for (TerminalDataPacket.Row var5 : this.ready()) {
         var3.add(var5.uuid());
      }

      this.selected.retainAll(var3);
      this.clampScroll();
      this.updateStrike();
   }

   private List<TerminalDataPacket.Row> ready() {
      ArrayList var1 = new ArrayList();

      for (TerminalDataPacket.Row var3 : this.parent.rows) {
         if (var3.status() == 0) {
            var1.add(var3);
         }
      }

      return var1;
   }

   private void clampScroll() {
      this.listScroll = Mth.clamp(this.listScroll, 0, Math.max(0, this.ready().size() - 6));
   }

   private void captureInputs() {
      if (this.radiusInput != null) {
         this.radiusText = this.radiusInput.getValue();
      }

      if (this.altInput != null) {
         this.altitudeText = this.altInput.getValue();
      }

      if (this.xInput != null) {
         this.xText = this.xInput.getValue();
      }

      if (this.zInput != null) {
         this.zText = this.zInput.getValue();
      }
   }

   private void syncCoordBoxes() {
      this.xText = String.valueOf(this.centerX);
      this.zText = String.valueOf(this.centerZ);
      if (this.xInput != null) {
         this.xInput.setValue(this.xText);
      }

      if (this.zInput != null) {
         this.zInput.setValue(this.zText);
      }
   }

   private void applyManual() {
      try {
         int var1 = Integer.parseInt(this.xInput.getValue().trim());
         int var2 = Integer.parseInt(this.zInput.getValue().trim());
         double var3 = (double)var1 - this.originX;
         double var5 = (double)var2 - this.originZ;
         if (var3 * var3 + var5 * var5 <= 4000000.0 && !ClientTerminalLimits.isForbidden(var1, var2)) {
            this.hasCenter = true;
            this.centerX = var1;
            this.centerZ = var2;
            this.updateStrike();
         }
      } catch (NumberFormatException var7) {
      }
   }

   private int radiusValue() {
      try {
         return Mth.clamp(Integer.parseInt(this.radiusInput.getValue().trim()), 1, 1000);
      } catch (NumberFormatException var2) {
         return 60;
      }
   }

   private int altitudeValue() {
      try {
         return Mth.clamp(Integer.parseInt(this.altInput.getValue().trim()), 70, ClientTerminalLimits.maxAltitude());
      } catch (NumberFormatException var2) {
         return 300;
      }
   }

   private boolean canStrike() {
      return this.hasCenter && !this.selected.isEmpty();
   }

   private int mapSize() {
      return Math.min(this.width - 150 - 40, this.height - 50);
   }

   private int layoutLeft() {
      return (this.width - (this.mapSize() + 12 + 150)) / 2;
   }

   private int mapCenterX() {
      return this.layoutLeft() + this.mapSize() / 2;
   }

   private int mapCenterY() {
      return this.height / 2;
   }

   private int panelLeft() {
      return this.layoutLeft() + this.mapSize() + 12;
   }

   private int panelTop() {
      return this.mapCenterY() - this.mapSize() / 2;
   }

   private float scale() {
      return (float)(this.mapSize() / 2) / (2000.0F / this.zoom);
   }

   protected void init() {
      this.captureInputs();
      int var1 = this.panelLeft();
      int var2 = this.panelTop();
      int var3 = var2 + 98;
      int var4 = var2 + 116;
      int var5 = var2 + 132;
      int var6 = var2 + 148;
      int var7 = var2 + 168;
      int var8 = var2 + 184;
      int var9 = var2 + 203;
      this.addRenderableWidget(new TerminalButton(var1, var3, 73, 16, Component.translatable("gui.sfw.group.all"), var1x -> {
         for (TerminalDataPacket.Row var3x : this.ready()) {
            this.selected.add(var3x.uuid());
         }

         this.updateStrike();
      }));
      this.addRenderableWidget(new TerminalButton(var1 + 75 + 2, var3, 73, 16, Component.translatable("gui.sfw.group.none"), var1x -> {
         this.selected.clear();
         this.updateStrike();
      }));
      this.radiusInput = new EditBox(this.font, var1 + 54, var4 + 2, 92, 12, Component.empty());
      this.radiusInput.setBordered(false);
      this.radiusInput.setMaxLength(4);
      this.radiusInput.setTextColor(-20420);
      this.radiusInput.setValue(this.radiusText);
      this.radiusInput.setFilter(var0 -> var0.isEmpty() || var0.matches("\\d{1,4}"));
      this.addRenderableWidget(this.radiusInput);
      this.altInput = new EditBox(this.font, var1 + 54, var5 + 2, 92, 12, Component.empty());
      this.altInput.setBordered(false);
      this.altInput.setMaxLength(4);
      this.altInput.setTextColor(-20420);
      this.altInput.setValue(this.altitudeText);
      this.altInput.setFilter(var0 -> var0.isEmpty() || var0.matches("\\d{1,4}"));
      this.addRenderableWidget(this.altInput);
      this.addRenderableWidget(new TerminalButton(var1, var6, 150, 16, this.diveLabel(), var1x -> {
         this.farDive = !this.farDive;
         var1x.setMessage(this.diveLabel());
      }).style(TerminalButton.Style.LIT));
      if (this.hasCenter && this.xText.isEmpty()) {
         this.xText = String.valueOf(this.centerX);
         this.zText = String.valueOf(this.centerZ);
      }

      this.xInput = new EditBox(this.font, var1 + 12, var7 + 2, 56, 12, Component.empty());
      this.xInput.setBordered(false);
      this.xInput.setMaxLength(8);
      this.xInput.setTextColor(-20420);
      this.xInput.setValue(this.xText);
      this.xInput.setFilter(var0 -> var0.matches("-?\\d{0,8}"));
      this.addRenderableWidget(this.xInput);
      this.zInput = new EditBox(this.font, var1 + 90, var7 + 2, 56, 12, Component.empty());
      this.zInput.setBordered(false);
      this.zInput.setMaxLength(8);
      this.zInput.setTextColor(-20420);
      this.zInput.setValue(this.zText);
      this.zInput.setFilter(var0 -> var0.matches("-?\\d{0,8}"));
      this.addRenderableWidget(this.zInput);
      this.addRenderableWidget(new TerminalButton(var1, var8, 150, 16, Component.translatable("gui.sfw.group.apply"), var1x -> this.applyManual()));
      this.strikeButton = (TerminalButton)this.addRenderableWidget(
         new TerminalButton(var1, var9, 150, 18, Component.translatable("gui.sfw.group.strike"), var1x -> this.strike()).style(TerminalButton.Style.LAUNCH)
      );
      this.addRenderableWidget(new TerminalButton(var1, var9 + 20, 150, 16, Component.translatable("gui.sfw.control.back"), var1x -> this.onClose()));
      this.updateStrike();
      NetworkHandler.sendToServer(new RequestWorldMapPacket((int)this.originX, (int)this.originZ, 2000));
   }

   private void updateStrike() {
      if (this.strikeButton != null) {
         this.strikeButton.active = this.canStrike();
      }
   }

   private Component diveLabel() {
      return Component.translatable(
         "gui.sfw.control.dive", new Object[]{Component.translatable(this.farDive ? "gui.sfw.control.dive.far" : "gui.sfw.control.dive.near")}
      );
   }

   private void strike() {
      if (this.canStrike()) {
         ArrayList var1 = new ArrayList();

         for (TerminalDataPacket.Row var3 : this.ready()) {
            if (this.selected.contains(var3.uuid())) {
               var1.add(var3.uuid());
            }
         }

         if (!var1.isEmpty()) {
            int[] var5 = new int[3 + var1.size() * 4];
            var5[0] = this.centerX;
            var5[1] = this.centerZ;
            var5[2] = this.radiusValue();

            for (int var6 = 0; var6 < var1.size(); var6++) {
               UUID var4 = (UUID)var1.get(var6);
               var5[3 + var6 * 4] = (int)(var4.getMostSignificantBits() >>> 32);
               var5[4 + var6 * 4] = (int)var4.getMostSignificantBits();
               var5[5 + var6 * 4] = (int)(var4.getLeastSignificantBits() >>> 32);
               var5[6 + var6 * 4] = (int)var4.getLeastSignificantBits();
            }

            NetworkHandler.sendToServer(new TerminalActionPacket(this.terminalPos, 7, new UUID(0L, 0L), var5, this.altitudeValue(), this.farDive));
            this.minecraft.setScreen(this.parent);
         }
      }
   }

   private int worldToScreenX(double var1) {
      return this.mapCenterX() + Math.round((float)((var1 - this.originX + (double)this.offsetX) * (double)this.scale()));
   }

   private int worldToScreenY(double var1) {
      return this.mapCenterY() + Math.round((float)((var1 - this.originZ + (double)this.offsetZ) * (double)this.scale()));
   }

   private boolean inMap(double var1, double var3) {
      int var5 = this.mapSize() / 2;
      return Math.abs(var1 - (double)this.mapCenterX()) <= (double)var5 && Math.abs(var3 - (double)this.mapCenterY()) <= (double)var5;
   }

   public boolean mouseClicked(double var1, double var3, int var5) {
      if (super.mouseClicked(var1, var3, var5)) {
         return true;
      } else {
         int var6 = this.panelLeft();
         int var7 = this.panelTop() + 20;
         if (var5 == 0 && var1 >= (double)var6 && var1 <= (double)(var6 + 150) && var3 >= (double)var7 && var3 < (double)(var7 + 72)) {
            List var8 = this.ready();
            int var9 = this.listScroll + (int)((var3 - (double)var7) / 12.0);
            if (var9 >= 0 && var9 < var8.size()) {
               UUID var10 = ((TerminalDataPacket.Row)var8.get(var9)).uuid();
               if (!this.selected.remove(var10)) {
                  this.selected.add(var10);
               }

               this.updateStrike();
            }

            return true;
         } else {
            if (this.inMap(var1, var3)) {
               if (var5 == 1) {
                  this.dragging = true;
                  return true;
               }

               if (var5 == 0) {
                  this.pressedInMap = true;
                  this.pannedWhilePressed = false;
                  this.pressX = var1;
                  this.pressY = var3;
                  return true;
               }
            }

            return false;
         }
      }
   }

   private void handleMapClick(double var1, double var3) {
      float var5 = this.scale();
      int var6 = (int)Math.round(this.originX + (var1 - (double)this.mapCenterX()) / (double)var5 - (double)this.offsetX);
      int var7 = (int)Math.round(this.originZ + (var3 - (double)this.mapCenterY()) / (double)var5 - (double)this.offsetZ);
      double var8 = (double)var6 - this.originX;
      double var10 = (double)var7 - this.originZ;
      if (var8 * var8 + var10 * var10 <= 4000000.0 && !ClientTerminalLimits.isForbidden(var6, var7)) {
         this.hasCenter = true;
         this.centerX = var6;
         this.centerZ = var7;
         this.syncCoordBoxes();
         this.updateStrike();
      }
   }

   public boolean mouseReleased(double var1, double var3, int var5) {
      if (var5 == 1) {
         this.dragging = false;
      }

      if (var5 == 0 && this.pressedInMap) {
         this.pressedInMap = false;
         if (!this.pannedWhilePressed) {
            this.handleMapClick(var1, var3);
         }

         return true;
      } else {
         return super.mouseReleased(var1, var3, var5);
      }
   }

   private void clampPan() {
      float var1 = Math.max(0.0F, 2000.0F - 2000.0F / this.zoom);
      this.offsetX = Mth.clamp(this.offsetX, -var1, var1);
      this.offsetZ = Mth.clamp(this.offsetZ, -var1, var1);
   }

   public boolean mouseDragged(double var1, double var3, int var5, double var6, double var8) {
      if (var5 == 0 && this.pressedInMap) {
         if (!this.pannedWhilePressed && Math.abs(var1 - this.pressX) + Math.abs(var3 - this.pressY) > 3.0) {
            this.pannedWhilePressed = true;
         }

         if (this.pannedWhilePressed) {
            this.panBy(var6, var8);
         }

         return true;
      } else if (this.dragging && var5 == 1) {
         this.panBy(var6, var8);
         return true;
      } else {
         return super.mouseDragged(var1, var3, var5, var6, var8);
      }
   }

   private void panBy(double var1, double var3) {
      float var5 = this.scale();
      this.offsetX += (float)(var1 / (double)var5);
      this.offsetZ += (float)(var3 / (double)var5);
      this.clampPan();
   }

   public boolean mouseScrolled(double var1, double var3, double var5, double var7) {
      if (this.inMap(var1, var3)) {
         this.zoom = var7 > 0.0 ? Math.min(this.zoom * 1.2F, 10.0F) : Math.max(this.zoom / 1.2F, 1.0F);
         this.clampPan();
         return true;
      } else if (var1 >= (double)this.panelLeft() && this.ready().size() > 6) {
         this.listScroll = Mth.clamp(this.listScroll - (int)Math.signum(var7), 0, this.ready().size() - 6);
         return true;
      } else {
         return super.mouseScrolled(var1, var3, var5, var7);
      }
   }

   public void tick() {
      super.tick();
      if (++this.refreshTimer >= 10) {
         this.refreshTimer = 0;
         NetworkHandler.sendToServer(TerminalActionPacket.refresh(this.terminalPos));
      }
   }

   public void render(GuiGraphics var1, int var2, int var3, float var4) {
      this.renderBlurredBackground(var4);
      int var5 = this.mapSize();
      int var6 = var5 / 2;
      int var7 = this.mapCenterX();
      int var8 = this.mapCenterY();
      ConsoleStyle.panel(var1, var7 - var6 - 8, var8 - var6 - 19, var7 + var6 + 7, var8 + var6 + 7);
      ConsoleStyle.bezel(var1, var7 - var6, var8 - var6, var7 + var6, var8 + var6);
      var1.fill(var7 - var6, var8 - var6, var7 + var6, var8 + var6, -16777216);
      this.mapView.render(var1, var7, var8, var6, this.originX, this.originZ, this.scale(), this.offsetX, this.offsetZ, 0.5F);
      var1.enableScissor(var7 - var6, var8 - var6, var7 + var6, var8 + var6);
      this.renderPaperMap(var1);
      var1.pose().pushPose();
      var1.pose().translate(0.0F, 0.0F, 2.0F);
      this.renderRangeRing(var1, var7, var8);
      this.renderDrones(var1);
      this.renderStrike(var1);
      var1.pose().popPose();
      var1.disableScissor();
      this.renderPanel(var1);
      ConsoleStyle.plate(var1, this.font, var7, var8 - var6 - 16, this.title);
      ConsoleStyle.hintStrip(var1, var7 - var6 - 8, var8 + var6 + 9, var7 + var6 + 7, var8 + var6 + 20);
      var1.drawString(this.font, Component.translatable("gui.sfw.group.controls"), var7 - var6 - 4, var8 + var6 + 11, -12541880);
      super.render(var1, var2, var3, var4);
   }

   private void renderPaperMap(GuiGraphics var1) {
      TerminalDataPacket.MapSlot var2 = this.parent.getMap();
      if (!var2.isEmpty() && var2.here() && TerminalMapPicture.isLoaded(var2)) {
         float var3 = 128.0F * (float)(1 << var2.scale());
         float var4 = this.scale();
         float var5 = (float)this.mapCenterX() + (float)(((double)((float)var2.centerX() - var3 / 2.0F) - this.originX + (double)this.offsetX) * (double)var4);
         float var6 = (float)this.mapCenterY() + (float)(((double)((float)var2.centerZ() - var3 / 2.0F) - this.originZ + (double)this.offsetZ) * (double)var4);
         TerminalMapPicture.render(var1, var2, var5, var6, var3 * var4, 0.8F);
      }
   }

   private void renderRangeRing(GuiGraphics var1, int var2, int var3) {
      float var4 = this.scale();
      this.circle(var1, var2 + Math.round(this.offsetX * var4), var3 + Math.round(this.offsetZ * var4), Math.round(2000.0F * var4), -13804995);
   }

   private void circle(GuiGraphics var1, int var2, int var3, int var4, int var5) {
      byte var6 = 96;

      for (int var7 = 0; var7 < var6; var7++) {
         double var8 = 6.283185307179586 * (double)var7 / (double)var6;
         double var10 = 6.283185307179586 * (double)(var7 + 1) / (double)var6;
         drawLine(
            var1,
            var2 + (int)(Math.cos(var8) * (double)var4),
            var3 + (int)(Math.sin(var8) * (double)var4),
            var2 + (int)(Math.cos(var10) * (double)var4),
            var3 + (int)(Math.sin(var10) * (double)var4),
            var5
         );
      }
   }

   private void renderDrones(GuiGraphics var1) {
      for (TerminalDataPacket.Row var3 : this.parent.rows) {
         if (var3.status() != 3) {
            int var4 = this.worldToScreenX((double)var3.ex());
            int var5 = this.worldToScreenY((double)var3.ez());
            boolean var6 = this.selected.contains(var3.uuid());
            var1.pose().pushPose();
            var1.pose().translate((float)var4, (float)var5, 0.0F);
            var1.pose().mulPose(Axis.ZP.rotationDegrees(180.0F - var3.yaw()));
            var1.pose().translate(-12.0F, -12.0F, 0.0F);
            if (var6) {
               var1.setColor(1.0F, 1.0F, 1.0F, 1.0F);
            } else {
               var1.setColor(0.45F, 0.5F, 0.45F, 0.8F);
            }

            var1.blit(DRONE_ICON, 0, 0, 24, 24, 0.0F, 0.0F, 32, 32, 32, 32);
            var1.setColor(1.0F, 1.0F, 1.0F, 1.0F);
            var1.pose().popPose();
            var1.drawString(this.font, "#" + var3.number(), var4 + 12 + 2, var5 - 4, var6 ? -1513240 : -6645094, false);
         }
      }
   }

   private void renderStrike(GuiGraphics var1) {
      if (this.hasCenter) {
         int var2 = this.worldToScreenX((double)this.centerX);
         int var3 = this.worldToScreenY((double)this.centerZ);
         int var4 = this.radiusInput == null ? 60 : this.radiusValue();
         this.circle(var1, var2, var3, Math.max(2, Math.round((float)var4 * this.scale())), -48060);
         drawLine(var1, var2 - 7, var3, var2 + 7, var3, -48060);
         drawLine(var1, var2, var3 - 7, var2, var3 + 7, -48060);
         int var5 = this.selected.size();

         for (int var6 = 0; var6 < var5; var6++) {
            int[] var7 = SeekerGroup.point(var6, var5, this.centerX, this.centerZ, var4, 0);
            int var8 = this.worldToScreenX((double)var7[0]);
            int var9 = this.worldToScreenY((double)var7[1]);
            var1.fill(var8 - 2, var9 - 2, var8 + 3, var9 + 3, -16777216);
            var1.fill(var8 - 1, var9 - 1, var8 + 2, var9 + 2, -20420);
         }
      }
   }

   private void renderPanel(GuiGraphics var1) {
      int var2 = this.panelLeft();
      int var3 = this.panelTop();
      int var4 = var3 + this.mapSize() + 2;
      ConsoleStyle.panel(var1, var2 - 4, var3 - 2, var2 + 150 + 4, var4);
      int var5 = var3 + 20;
      int var6 = var2 + 3;
      int var7 = var2 + 150 - 3;
      int var8 = var6 + 3;
      List var9 = this.ready();
      ConsoleStyle.lcd(var1, var6, var3 + 4, var7, var5 + 72 + 1);
      var1.drawString(
         this.font, Component.translatable("gui.sfw.group.selected", new Object[]{this.selected.size(), var9.size()}), var8, var3 + 7, -20420, false
      );
      if (var9.isEmpty()) {
         var1.drawString(this.font, Component.translatable("gui.sfw.group.empty"), var8, var5 + 2, -6657496, false);
      }

      for (int var10 = 0; var10 < 6; var10++) {
         int var11 = this.listScroll + var10;
         if (var11 >= var9.size()) {
            break;
         }

         TerminalDataPacket.Row var12 = (TerminalDataPacket.Row)var9.get(var11);
         boolean var13 = this.selected.contains(var12.uuid());
         int var14 = var5 + var10 * 12;
         if (var13) {
            var1.fill(var6, var14 - 1, var7, var14 + 10, 1090498620);
         }

         var1.drawString(this.font, (var13 ? "[x] " : "[ ] ") + "#" + var12.number(), var8, var14, var13 ? -20420 : -6657496, false);
      }

      int var15 = var3 + 116;
      int var16 = var3 + 132;
      int var17 = var3 + 168;
      var1.drawString(this.font, Component.translatable("gui.sfw.group.radius"), var2, var15 + 3, -3226218);
      ConsoleStyle.lcd(var1, var2 + 52, var15, var2 + 150 - 3, var15 + 14);
      var1.drawString(this.font, Component.translatable("gui.sfw.control.alt"), var2, var16 + 3, -3226218);
      ConsoleStyle.lcd(var1, var2 + 52, var16, var2 + 150 - 3, var16 + 14);
      var1.drawString(this.font, "X", var2 + 2, var17 + 3, -3226218);
      ConsoleStyle.lcd(var1, var2 + 10, var17, var2 + 72, var17 + 14);
      var1.drawString(this.font, "Z", var2 + 78, var17 + 3, -3226218);
      ConsoleStyle.lcd(var1, var2 + 86, var17, var2 + 150 - 3, var17 + 14);
   }

   private static void drawLine(GuiGraphics var0, int var1, int var2, int var3, int var4, int var5) {
      int var6 = Math.abs(var3 - var1);
      int var7 = Math.abs(var4 - var2);
      int var8 = var1 < var3 ? 1 : -1;
      int var9 = var2 < var4 ? 1 : -1;
      int var10 = var6 - var7;
      int var11 = 0;

      while (var11++ < 8192) {
         var0.fill(var1, var2, var1 + 1, var2 + 1, var5);
         if (var1 == var3 && var2 == var4) {
            break;
         }

         int var12 = 2 * var10;
         if (var12 > -var7) {
            var10 -= var7;
            var1 += var8;
         }

         if (var12 < var6) {
            var10 += var6;
            var2 += var9;
         }
      }
   }

   public void onClose() {
      this.minecraft.setScreen(this.parent);
   }

   public void removed() {
      super.removed();
      this.mapView.close();
   }

   public void renderBackground(GuiGraphics var1, int var2, int var3, float var4) {
   }

   public boolean isPauseScreen() {
      return false;
   }
}
