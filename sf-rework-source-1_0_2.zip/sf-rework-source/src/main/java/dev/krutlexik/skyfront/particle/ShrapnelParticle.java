package dev.krutlexik.skyfront.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.SimpleParticleType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ShrapnelParticle extends TextureSheetParticle {
   private final boolean burning;
   private final float rotationSpeed;

   protected ShrapnelParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, SpriteSet sprites) {
      super(level, x, y, z);
      this.xd = vx;
      this.yd = vy;
      this.zd = vz;
      this.burning = this.random.nextFloat() < 0.55F;
      this.lifetime = 60 + this.random.nextInt(60);
      this.hasPhysics = true;
      this.gravity = 0.6F + this.random.nextFloat() * 0.35F;
      this.quadSize = 0.133F + this.random.nextFloat() * 0.133F;
      this.rotationSpeed = (this.random.nextFloat() - 0.5F) * 0.5F;
      this.roll = this.random.nextFloat() * 6.2831855F;
      this.oRoll = this.roll;
      if (this.burning) {
         this.rCol = 1.0F;
         this.gCol = 0.55F + this.random.nextFloat() * 0.25F;
         this.bCol = 0.12F;
      } else {
         float shade = 0.08F + this.random.nextFloat() * 0.12F;
         this.rCol = shade;
         this.gCol = shade;
         this.bCol = shade;
      }

      this.alpha = 1.0F;
      this.pickSprite(sprites);
   }

   public void tick() {
      this.xo = this.x;
      this.yo = this.y;
      this.zo = this.z;
      if (this.age++ >= this.lifetime) {
         this.remove();
      } else {
         this.oRoll = this.roll;
         this.roll = this.roll + this.rotationSpeed * (this.onGround ? 0.2F : 1.0F);
         this.yd = this.yd - 0.04 * (double)this.gravity;
         this.move(this.xd, this.yd, this.zd);
         this.xd *= 0.98;
         this.yd *= 0.99;
         this.zd *= 0.98;
         if (this.onGround) {
            this.xd *= 0.6;
            this.zd *= 0.6;
            this.age++;
         }

         float progress = (float)this.age / (float)this.lifetime;
         if (this.burning) {
            this.gCol = Math.max(0.12F, this.gCol - 0.008F);
            if (!this.onGround && this.random.nextInt(6) == 0) {
               this.level.addParticle(ParticleTypes.SMOKE, this.x, this.y, this.z, 0.0, 0.01, 0.0);
            }
         }

         if (progress > 0.8F) {
            this.alpha = Math.max(0.0F, 1.0F - (progress - 0.8F) * 5.0F);
         }
      }
   }

   public int getLightColor(float partialTick) {
      return this.burning ? 15728880 : super.getLightColor(partialTick);
   }

   public ParticleRenderType getRenderType() {
      return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
   }

   @OnlyIn(Dist.CLIENT)
   public static class Provider implements ParticleProvider<SimpleParticleType> {
      private final SpriteSet sprites;

      public Provider(SpriteSet sprites) {
         this.sprites = sprites;
      }

      public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double vx, double vy, double vz) {
         return new ShrapnelParticle(level, x, y, z, vx, vy, vz, this.sprites);
      }
   }
}
