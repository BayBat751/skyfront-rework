package dev.krutlexik.skyfront.drone.client.render;

import com.mojang.blaze3d.platform.TextureUtil;
import com.mojang.blaze3d.shaders.Uniform;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat.Mode;
import dev.krutlexik.skyfront.drone.entity.DroneEntity;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.util.Mth;
import org.lwjgl.opengl.GL11;

public final class AnalogFeedPass {
   private static int texture = -1;
   private static int width;
   private static int height;
   private static final Random RANDOM = new Random();
   private static long nextStep;
   private static double fade;
   private static float level;
   private static long burstUntil;
   private static float burstStrength;
   private static long stripesUntil;
   private static float stripesStrength;
   private static long syncUntil;
   private static float syncShift;
   private static long rollUntil;
   private static float roll;
   private static float rollSpeed;

   private AnalogFeedPass() {
   }

   public static void renderPicture(GuiGraphics graphics, DroneEntity drone) {
      Minecraft minecraft = Minecraft.getInstance();
      if (minecraft.player != null) {
         advance(0.0);
         draw(graphics, 0.0F, false);
      }
   }

   public static void renderOverlay(GuiGraphics graphics) {
      draw(graphics, 1.0F, false);
   }

   public static void renderStatic(GuiGraphics graphics) {
      draw(graphics, 0.0F, true);
   }

   private static void advance(double reach) {
      long now = System.currentTimeMillis();
      if (now - nextStep > 1000L) {
         nextStep = now;
      }

      while (now >= nextStep) {
         nextStep += 50L;
         step(reach, nextStep);
      }
   }

   private static void step(double reach, long now) {
      fade = (fade + (RANDOM.nextDouble() - 0.5) * 0.35) * 0.92;
      double base = 0.55 * Math.pow(reach, 2.2);
      double fading = 0.25 * Math.pow(reach, 1.2) * Math.max(0.0, fade);
      level = (float)Mth.clamp(base + fading, 0.0, 1.0);
      if (!(reach <= 0.0)) {
         if (now >= burstUntil && RANDOM.nextDouble() < 0.0015 + 0.18 * Math.pow(reach, 2.5)) {
            burstUntil = now + 80L + (long)RANDOM.nextInt(420);
            burstStrength = (float)((0.3 + 0.7 * RANDOM.nextDouble()) * (0.35 + 0.65 * reach));
         }

         float burst = now < burstUntil ? burstStrength : 0.0F;
         float total = level + burst;
         if (now >= stripesUntil && RANDOM.nextDouble() < 0.012 + 0.22 * Math.pow((double)level, 1.3)) {
            stripesUntil = now + 40L + (long)RANDOM.nextInt(180);
            stripesStrength = (float)(0.35 + 0.65 * RANDOM.nextDouble());
         }

         if (now >= syncUntil && total > 0.55F && RANDOM.nextDouble() < 0.12) {
            syncUntil = now + 100L + (long)RANDOM.nextInt(500);
            syncShift = 0.15F + 0.7F * RANDOM.nextFloat();
         } else if (now < syncUntil) {
            syncShift = (syncShift + (RANDOM.nextFloat() - 0.5F) * 0.02F + 1.0F) % 1.0F;
         }

         if (now >= rollUntil && total > 0.7F && RANDOM.nextDouble() < 0.04) {
            rollUntil = now + 150L + (long)RANDOM.nextInt(450);
            roll = RANDOM.nextFloat();
            rollSpeed = 0.02F + 0.08F * RANDOM.nextFloat();
         } else if (now < rollUntil) {
            roll = (roll + rollSpeed) % 1.0F;
         }
      }
   }

   private static void draw(GuiGraphics graphics, float stage, boolean staticOnly) {
      ShaderInstance shader = ThermalShaders.analog();
      Minecraft minecraft = Minecraft.getInstance();
      if (shader != null) {
         int w = minecraft.getMainRenderTarget().width;
         int h = minecraft.getMainRenderTarget().height;
         if (w > 0 && h > 0) {
            long now = System.currentTimeMillis();
            graphics.flush();
            if (texture == -1 || w != width || h != height) {
               if (texture != -1) {
                  TextureUtil.releaseTextureId(texture);
               }

               texture = TextureUtil.generateTextureId();
               RenderSystem.bindTexture(texture);
               TextureUtil.prepareImage(texture, 0, w, h);
               width = w;
               height = h;
            }

            RenderSystem.bindTexture(texture);
            GL11.glCopyTexSubImage2D(3553, 0, 0, 0, 0, 0, w, h);
            float x0 = 0.0F;
            float y0 = 0.0F;
            float x1 = 1.0F;
            float y1 = 1.0F;
            float aspect = (float)w / (float)h;
            float feed = 1.3333334F;
            if (aspect > feed) {
               float share = feed / aspect;
               x0 = (1.0F - share) / 2.0F;
               x1 = 1.0F - x0;
            } else {
               float share = aspect / feed;
               y0 = (1.0F - share) / 2.0F;
               y1 = 1.0F - y0;
            }

            setFloat(shader, "Time", (float)(now % 100000L) / 1000.0F);
            setFloat(shader, "Interference", level);
            setFloat(shader, "Burst", now < burstUntil ? burstStrength : 0.0F);
            setFloat(shader, "Stripes", Math.max(now < stripesUntil ? stripesStrength : 0.0F, 0.08F * level));
            setFloat(shader, "StaticOnly", staticOnly ? 1.0F : 0.0F);
            setFloat(shader, "Stage", stage);
            setFloat(shader, "SyncShift", now < syncUntil ? Math.max(syncShift, 0.001F) : 0.0F);
            setFloat(shader, "SyncRoll", now < rollUntil ? Math.max(roll, 0.001F) : 0.0F);
            Uniform rect = shader.getUniform("FeedRect");
            if (rect != null) {
               rect.set(x0, y0, x1, y1);
            }

            RenderSystem.setShader(() -> shader);
            RenderSystem.setShaderTexture(0, texture);
            RenderSystem.disableBlend();
            RenderSystem.disableDepthTest();
            RenderSystem.depthMask(false);
            BufferBuilder buffer = Tesselator.getInstance().begin(Mode.QUADS, DefaultVertexFormat.POSITION_TEX);
            buffer.addVertex(-1.0F, -1.0F, 0.0F).setUv(0.0F, 0.0F);
            buffer.addVertex(1.0F, -1.0F, 0.0F).setUv(1.0F, 0.0F);
            buffer.addVertex(1.0F, 1.0F, 0.0F).setUv(1.0F, 1.0F);
            buffer.addVertex(-1.0F, 1.0F, 0.0F).setUv(0.0F, 1.0F);
            BufferUploader.drawWithShader(buffer.buildOrThrow());
            RenderSystem.depthMask(true);
            RenderSystem.enableDepthTest();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
         }
      }
   }

   private static void setFloat(ShaderInstance shader, String name, float value) {
      Uniform uniform = shader.getUniform(name);
      if (uniform != null) {
         uniform.set(value);
      }
   }

   public static void unload() {
      if (texture != -1) {
         TextureUtil.releaseTextureId(texture);
         texture = -1;
      }
   }
}
