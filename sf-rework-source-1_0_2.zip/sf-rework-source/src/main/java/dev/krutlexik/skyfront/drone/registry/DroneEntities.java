package dev.krutlexik.skyfront.drone.registry;

import dev.krutlexik.skyfront.drone.entity.DroneEntity;
import dev.krutlexik.skyfront.drone.entity.DroneStandEntity;
import dev.krutlexik.skyfront.drone.entity.FpvDroneEntity;
import dev.krutlexik.skyfront.drone.entity.InterceptorDroneEntity;
import dev.krutlexik.skyfront.drone.entity.MolniyaDroneEntity;
import dev.krutlexik.skyfront.drone.entity.ThermalDroneEntity;
import dev.krutlexik.skyfront.drone.entity.ThermalInterceptorDroneEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType.Builder;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class DroneEntities {
   public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(Registries.ENTITY_TYPE, "sfw");
   public static final DeferredHolder<EntityType<?>, EntityType<DroneEntity>> DRONE = ENTITIES.register(
      "drone", () -> Builder.of(DroneEntity::new, MobCategory.MISC).sized(1.0F, 0.35F).clientTrackingRange(10).updateInterval(1).build("drone")
   );
   public static final DeferredHolder<EntityType<?>, EntityType<ThermalDroneEntity>> THERMAL_DRONE = ENTITIES.register(
      "thermal_drone",
      () -> Builder.of(ThermalDroneEntity::new, MobCategory.MISC).sized(1.0F, 0.35F).clientTrackingRange(16).updateInterval(1).build("thermal_drone")
   );
   public static final DeferredHolder<EntityType<?>, EntityType<InterceptorDroneEntity>> INTERCEPTOR_DRONE = ENTITIES.register(
      "interceptor_drone",
      () -> Builder.of(InterceptorDroneEntity::new, MobCategory.MISC).sized(1.1F, 0.8F).clientTrackingRange(16).updateInterval(1).build("interceptor_drone")
   );
   public static final DeferredHolder<EntityType<?>, EntityType<ThermalInterceptorDroneEntity>> THERMAL_INTERCEPTOR_DRONE = ENTITIES.register(
      "thermal_interceptor_drone",
      () -> Builder.of(ThermalInterceptorDroneEntity::new, MobCategory.MISC)
            .sized(1.1F, 0.8F)
            .clientTrackingRange(16)
            .updateInterval(1)
            .build("thermal_interceptor_drone")
   );
   public static final DeferredHolder<EntityType<?>, EntityType<FpvDroneEntity>> FPV_DRONE = ENTITIES.register(
      "fpv_drone", () -> Builder.of(FpvDroneEntity::new, MobCategory.MISC).sized(0.85F, 0.5F).clientTrackingRange(16).updateInterval(1).build("fpv_drone")
   );
   public static final DeferredHolder<EntityType<?>, EntityType<DroneStandEntity>> DRONE_STAND = ENTITIES.register(
      "drone_stand",
      () -> Builder.of(DroneStandEntity::new, MobCategory.MISC).sized(0.64F, 0.225F).clientTrackingRange(16).updateInterval(20).build("drone_stand")
   );
   public static final DeferredHolder<EntityType<?>, EntityType<MolniyaDroneEntity>> MOLNIYA_DRONE = ENTITIES.register(
      "molniya_drone",
      () -> Builder.of(MolniyaDroneEntity::new, MobCategory.MISC).sized(4.2F, 1.0F).clientTrackingRange(16).updateInterval(1).build("molniya_drone")
   );

   private DroneEntities() {
   }
}
