package dev.krutlexik.skyfront.seeker;

import dev.krutlexik.skyfront.block.entity.ShahedTerminalBlockEntity;
import dev.krutlexik.skyfront.drone.MonitorControlEvents;
import dev.krutlexik.skyfront.entity.DebrisEntity;
import dev.krutlexik.skyfront.entity.ModEntities;
import dev.krutlexik.skyfront.entity.ShahedEntity;
import dev.krutlexik.skyfront.item.ModItems;
import dev.krutlexik.skyfront.network.NetworkHandler;
import dev.krutlexik.skyfront.network.TerminalActionPacket;
import dev.krutlexik.skyfront.network.TerminalDataPacket;
import dev.krutlexik.skyfront.sound.ModSounds;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public final class SeekerHooks {
   public static final int ACTION_CONNECT = 6;
   public static final int STATUS_SEEKER_FLIGHT = 4;

   private SeekerHooks() {
   }

   public static Item seekerItem() {
      return (Item)SeekerRegistry.SEEKER_ITEM.get();
   }

   public static boolean isSeeker(ShahedEntity var0) {
      return var0.getType() == SeekerRegistry.SEEKER.get();
   }

   public static boolean is238(ShahedEntity var0) {
      return var0.getType() == SeekerRegistry.SHAHED_238.get();
   }

   public static boolean isControllable(ShahedEntity var0) {
      return isSeeker(var0) || is238(var0);
   }

   public static Item item238() {
      return (Item)SeekerRegistry.SHAHED_238_ITEM.get();
   }

   public static double cruise(ShahedEntity var0) {
      return is238(var0) ? 3.5027027027027033 : 1.5;
   }

   public static double boost(ShahedEntity var0) {
      return is238(var0) ? 1.9702702702702704 : 2.1;
   }

   public static double turnScale(ShahedEntity var0) {
      return is238(var0) ? 1.45 : 1.0;
   }

   public static float easeScale(ShahedEntity var0) {
      return (float)(cruise(var0) / 1.5);
   }

   public static double passDist(ShahedEntity var0) {
      return is238(var0) ? 70.0 : 40.0;
   }

   public static double reachDist(ShahedEntity var0) {
      return is238(var0) ? 40.0 : 24.0;
   }

   public static double climbAccel(ShahedEntity var0) {
      return is238(var0) ? 0.06 : 0.008;
   }

   public static double vyMin(ShahedEntity var0) {
      return is238(var0) ? 0.1 : 0.03;
   }

   public static double vyGain(ShahedEntity var0) {
      return is238(var0) ? 0.06 : 0.04;
   }

   public static double vyMax(ShahedEntity var0) {
      return is238(var0) ? 1.2 : 0.3;
   }

   public static double vyBlend(ShahedEntity var0) {
      return is238(var0) ? 0.15 : 0.045;
   }

   public static float launchTurn(ShahedEntity var0) {
      return is238(var0) ? 3.6F : 2.2F;
   }

   public static double railAccel(ShahedEntity var0) {
      return is238(var0) ? 0.35 : 0.16;
   }

   public static double railMax(ShahedEntity var0) {
      return is238(var0) ? 2.5 : 0.9;
   }

   public static int syncInterval(ShahedEntity var0) {
      return is238(var0) && var0.isFinalLeg() && var0.getSyncedDiveProgress() > 0.01F ? 2 : 40;
   }

   public static float blastF(ShahedEntity var0) {
      return is238(var0) ? 1.25F : 1.0F;
   }

   public static double blastD(ShahedEntity var0) {
      return is238(var0) ? 1.25 : 1.0;
   }

   public static DebrisEntity.Airframe frame(ShahedEntity var0) {
      return is238(var0) ? DebrisEntity.Airframe.JET_SHAHED : DebrisEntity.Airframe.SHAHED;
   }

   public static String geoPath(Object var0) {
      return uses238Look(var0) ? "geo/jet_shahed.geo.json" : "geo/shahed.geo.json";
   }

   public static String texPath(Object var0) {
      return uses238Look(var0) ? "textures/entity/jet_shahed.png" : "textures/entity/shahed.png";
   }

   private static boolean uses238Look(Object var0) {
      return var0 instanceof ShahedEntity var1 ? is238(var1) : var0 == SeekerRegistry.SHAHED_238_ITEM.get();
   }

   public static SoundEvent engineSound(ShahedEntity var0) {
      return is238(var0) ? (SoundEvent)SeekerRegistry.JET_ENGINE.get() : (SoundEvent)ModSounds.SHAHED_ENGINE.get();
   }

   public static ShahedEntity newShahed(ItemStack var0, ServerLevel var1) {
      EntityType var2;
      if (var0.is(seekerItem())) {
         var2 = (EntityType)SeekerRegistry.SEEKER.get();
      } else if (var0.is(item238())) {
         var2 = (EntityType)SeekerRegistry.SHAHED_238.get();
      } else {
         var2 = (EntityType)ModEntities.SHAHED.get();
      }

      return new ShahedEntity(var2, var1);
   }

   public static ItemLike itemFor(ShahedEntity var0) {
      if (isSeeker(var0)) {
         return (ItemLike)SeekerRegistry.SEEKER_ITEM.get();
      } else {
         return is238(var0) ? (ItemLike)SeekerRegistry.SHAHED_238_ITEM.get() : (ItemLike)ModItems.SHAHED_136.get();
      }
   }

   public static int flightStatus(ShahedEntity var0) {
      return isControllable(var0) && var0.getLaunchState() == 0 ? 4 : 1;
   }

   public static boolean onTerminalAction(TerminalActionPacket var0, IPayloadContext var1) {
      if (var0.action == 7) {
         return SeekerGroup.handle(var0, var1);
      } else if (var0.action != 6) {
         return false;
      } else {
         if (var1.player() instanceof ServerPlayer var2
            && var2.level() instanceof ServerLevel var3
            && !(var2.position().distanceToSqr(var0.terminalPos.getCenter()) > 64.0)
            && var3.getBlockEntity(var0.terminalPos) instanceof ShahedTerminalBlockEntity var7) {
            connect(var3, var2, var7, var0.uuid);
            NetworkHandler.sendToPlayer(var2, TerminalDataPacket.build(var3, var0.terminalPos, var7, false));
         }

         return true;
      }
   }

   private static void say(ServerPlayer var0, String var1) {
      var0.displayClientMessage(Component.translatable(var1).withStyle(ChatFormatting.RED), true);
   }

   public static void connect(ServerLevel var0, ServerPlayer var1, ShahedTerminalBlockEntity var2, UUID var3) {
      if (var2.findByUuid(var3) != null) {
         if (!(var0.getEntity(var3) instanceof ShahedEntity var4) || !var4.isAlive() || !isControllable(var4)) {
            say(var1, "msg.sfw.seeker.no_link");
            return;
         }

         if (var4.getLaunchState() == 0 && !var4.getIsFalling()) {
            SeekerDroneEntity var12 = (SeekerDroneEntity)(is238(var4)
                  ? (EntityType)SeekerRegistry.SHAHED_238_DRONE.get()
                  : (EntityType)SeekerRegistry.SEEKER_DRONE.get())
               .create(var0);
            if (var12 != null) {
               Vec3 var6 = var4.position();
               Vec3 var7 = var4.getDeltaMovement();
               double var8 = Math.sqrt(var7.x * var7.x + var7.z * var7.z);
               float var10 = var8 > 1.0E-4 ? (float)(Math.atan2(-var7.x, var7.z) * 57.29577951308232) : -var4.getYRot();
               float var11 = var8 > 1.0E-4 ? (float)(-Math.atan2(var7.y, var8) * 57.29577951308232) : 0.0F;
               var4.discardAsItem();
               var12.moveTo(var6.x, var6.y, var6.z, var10, var11);
               var12.setUUID(var3);
               var12.setDeltaMovement(var7);
               var12.setArmed(true);
               var0.addFreshEntity(var12);
               MonitorControlEvents.connect(var1, var12);
            }
         } else {
            say(var1, "msg.sfw.seeker.not_flying");
         }
      }
   }
}
