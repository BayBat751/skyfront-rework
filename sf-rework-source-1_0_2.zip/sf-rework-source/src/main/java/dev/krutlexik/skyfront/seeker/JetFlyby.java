package dev.krutlexik.skyfront.seeker;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance.Attenuation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent.Post;

public class JetFlyby extends AbstractTickableSoundInstance {
   private static final List<JetFlyby> PENDING = new ArrayList<>();
   private final Supplier<Vec3> position;
   private final JetFlyby.Variant variant;
   private final float fullVolume;
   private int age;
   private boolean fading;
   private boolean started;

   public JetFlyby(JetFlyby.Variant var1, Supplier<Vec3> var2, float var3, boolean var4) {
      super(var1.sound(), SoundSource.HOSTILE, SoundInstance.createUnseededRandom());
      this.variant = var1;
      this.position = var2;
      this.fullVolume = Math.min(1.0F, var4 ? var3 * 1.6F : var3);
      this.looping = false;
      this.delay = 0;
      this.volume = this.fullVolume;
      this.pitch = 1.0F;
      this.attenuation = Attenuation.NONE;
      Vec3 var5 = (Vec3)var2.get();
      this.x = var5.x;
      this.y = var5.y;
      this.z = var5.z;
   }

   public static void startSoon(JetFlyby var0) {
      PENDING.add(var0);
   }

   static void startPending() {
      if (!PENDING.isEmpty()) {
         ArrayList var0 = new ArrayList<>(PENDING);
         PENDING.clear();

         for (JetFlyby var2 : var0) {
            if (!var2.fading) {
               var2.started = true;
               Minecraft.getInstance().getSoundManager().play(var2);
            }
         }
      }
   }

   public int age() {
      return this.age;
   }

   public int lead() {
      return this.variant.lead;
   }

   public boolean finished() {
      if (this.isStopped()) {
         return true;
      } else {
         return !this.started ? this.fading : this.age >= this.variant.length || !Minecraft.getInstance().getSoundManager().isActive(this);
      }
   }

   public boolean playing() {
      return !this.finished() && !this.fading && this.age < this.variant.length;
   }

   public void fadeOut() {
      this.fading = true;
   }

   public void tick() {
      this.age++;
      Vec3 var1 = this.position.get();
      this.x = var1.x;
      this.y = var1.y;
      this.z = var1.z;
      if (this.fading) {
         this.volume = Math.max(0.0F, this.volume - 0.08F * this.fullVolume);
         if (this.volume <= 0.0F) {
            this.stop();
         }
      } else if (this.age > this.variant.length + 20) {
         this.stop();
      }
   }

   @EventBusSubscriber(
      modid = "sfw",
      value = {Dist.CLIENT}
   )
   public static final class Starter {
      private Starter() {
      }

      @SubscribeEvent
      public static void onClientTick(Post var0) {
         JetFlyby.startPending();
      }
   }

   public static enum Variant {
      FROM_AFAR(104, 270),
      NEARER(60, 226),
      CLOSE(32, 198),
      ALMOST_HERE(14, 180);

      public final int lead;
      public final int length;

      private Variant(int nullxx, int nullxxx) {
         this.lead = nullxx;
         this.length = nullxxx;
      }

      SoundEvent sound() {
         switch (this) {
            case FROM_AFAR:
               return (SoundEvent)SeekerRegistry.JET_FLYBY.get();
            case NEARER:
               return (SoundEvent)SeekerRegistry.JET_FLYBY_60.get();
            case CLOSE:
               return (SoundEvent)SeekerRegistry.JET_FLYBY_32.get();
            default:
               return (SoundEvent)SeekerRegistry.JET_FLYBY_14.get();
         }
      }

      public static JetFlyby.Variant startingAt(double var0) {
         for (JetFlyby.Variant var5 : values()) {
            if (var0 <= (double)var5.lead && var0 > (double)(var5.lead - 3)) {
               return var5;
            }
         }

         return null;
      }
   }
}
