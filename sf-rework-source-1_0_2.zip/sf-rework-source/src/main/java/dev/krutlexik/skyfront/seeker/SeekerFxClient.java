package dev.krutlexik.skyfront.seeker;

import dev.krutlexik.skyfront.particle.JetExhaustParticle;
import dev.krutlexik.skyfront.particle.ModParticles;
import java.util.Map;
import java.util.Random;
import java.util.WeakHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.ParticleStatus;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

public final class SeekerFxClient {
   private static final Random RANDOM = new Random();
   private static final Map<Entity, double[]> STATE = new WeakHashMap<>();

   private SeekerFxClient() {
   }

   public static void droneTick(Entity var0) {
      try {
         haze(var0);
      } catch (Throwable var2) {
      }
   }

   private static void haze(Entity var0) {
      Minecraft var1 = Minecraft.getInstance();
      double[] var2 = STATE.get(var0);
      if (var2 == null) {
         var2 = new double[5];
         STATE.put(var0, var2);
      }

      Vec3 var3 = var0.getDeltaMovement();
      double var4 = var3.length();
      if (var1.level != null && var1.getCameraEntity() != var0 && !(var4 < 0.8)) {
         Vec3 var6 = var0.position();
         double var7 = var1.gameRenderer.getMainCamera().getPosition().distanceTo(var6);
         ParticleStatus var9 = (ParticleStatus)var1.options.particles().get();
         if (!(var7 >= 400.0) && var9 != ParticleStatus.MINIMAL) {
            double var10 = var9 == ParticleStatus.ALL ? 1.0 : (var9 == ParticleStatus.DECREASED ? 0.5 : 0.25);
            double var12 = var3.x / var4;
            double var14 = var3.y / var4;
            double var16 = var3.z / var4;
            double var18 = -var14 * var12;
            double var20 = 1.0 - var14 * var14;
            double var22 = -var14 * var16;
            double var24 = Math.sqrt(var18 * var18 + var20 * var20 + var22 * var22);
            if (var24 < 1.0E-4) {
               var18 = 0.0;
               var20 = 1.0;
               var22 = 0.0;
            } else {
               var18 /= var24;
               var20 /= var24;
               var22 /= var24;
            }

            double var26 = var6.x - var12 * 2.05 + var18 * 0.19;
            double var28 = var6.y - var14 * 2.05 + var20 * 0.19;
            double var30 = var6.z - var16 * 2.05 + var22 * 0.19;
            if (var2[4] > 0.5) {
               double var32 = var26 - var2[0];
               double var34 = var28 - var2[1];
               double var36 = var30 - var2[2];
               double var38 = Math.sqrt(var32 * var32 + var34 * var34 + var36 * var36);
               if (var38 > 40.0) {
                  var2[3] = 0.0;
               } else if (var38 > 1.0E-6) {
                  double var40 = 1.2 / var10 * Math.max(1.0, var7 / 96.0);
                  float var42 = (float)(0.38 * Math.min(1.0, 0.5 + 0.5 * var10));

                  double var43;
                  for (var43 = Math.max(0.0, var40 - var2[3]); var43 <= var38; var43 += var40) {
                     double var45 = var43 / var38;
                     spawn(var1, var2[0] + var32 * var45, var2[1] + var34 * var45, var2[2] + var36 * var45, -var12, -var14, -var16, var42, (float)var45);
                  }

                  var2[3] = var38 - (var43 - var40);
               }
            }

            var2[0] = var26;
            var2[1] = var28;
            var2[2] = var30;
            var2[4] = 1.0;
         } else {
            var2[4] = 0.0;
         }
      } else {
         var2[4] = 0.0;
      }
   }

   private static void spawn(Minecraft var0, double var1, double var3, double var5, double var7, double var9, double var11, float var13, float var14) {
      if (var0.particleEngine
         .createParticle(
            (SimpleParticleType)ModParticles.JET_EXHAUST.get(),
            var1,
            var3,
            var5,
            var7 * 0.04 + RANDOM.nextGaussian() * 0.006,
            var9 * 0.04 + RANDOM.nextGaussian() * 0.006,
            var11 * 0.04 + RANDOM.nextGaussian() * 0.006
         ) instanceof JetExhaustParticle var16) {
         var16.peak(var13).appearAt(var14);
      }
   }
}
