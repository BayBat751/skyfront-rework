package dev.krutlexik.skyfront.network;

import dev.krutlexik.skyfront.config.SkyfrontConfig;
import dev.krutlexik.skyfront.entity.ShahedEntity;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public class RequestRadarUpdatePacket implements CustomPacketPayload {
   public static final Type<RequestRadarUpdatePacket> TYPE = new Type(ResourceLocation.fromNamespaceAndPath("sfw", "RequestRadarUpdatePacket".toLowerCase()));
   public static final StreamCodec<RegistryFriendlyByteBuf, RequestRadarUpdatePacket> STREAM_CODEC = StreamCodec.ofMember(
      RequestRadarUpdatePacket::toBytes, RequestRadarUpdatePacket::new
   );
   private final BlockPos radarPos;

   public Type<RequestRadarUpdatePacket> type() {
      return TYPE;
   }

   public RequestRadarUpdatePacket(BlockPos radarPos) {
      this.radarPos = radarPos;
   }

   public RequestRadarUpdatePacket(RegistryFriendlyByteBuf buf) {
      this.radarPos = buf.readBlockPos();
   }

   public void toBytes(RegistryFriendlyByteBuf buf) {
      buf.writeBlockPos(this.radarPos);
   }

   public void handle(IPayloadContext ctx) {
      ctx.enqueueWork(
         () -> {
            ServerPlayer player = (ServerPlayer)ctx.player();
            if (player != null) {
               ServerLevel level = player.serverLevel();
               Vec3 radarCenter = Vec3.atCenterOf(this.radarPos);
               int range = (Integer)SkyfrontConfig.RADAR_DETECT_RANGE.get();
               AABB searchBox = new AABB(
                  radarCenter.x - (double)range,
                  (double)level.getMinBuildHeight(),
                  radarCenter.z - (double)range,
                  radarCenter.x + (double)range,
                  (double)level.getMaxBuildHeight(),
                  radarCenter.z + (double)range
               );
               double rangeSq = (double)range * (double)range;
               List<Vec3> dronePositions = new ArrayList<>();

               for (Entity entity : level.getEntities(null, searchBox)) {
                  if (entity instanceof ShahedEntity) {
                     double dx = entity.getX() - radarCenter.x;
                     double dz = entity.getZ() - radarCenter.z;
                     if (dx * dx + dz * dz <= rangeSq) {
                        dronePositions.add(entity.position());
                     }
                  }
               }

               NetworkHandler.sendToPlayer(player, new RadarUpdatePacket(this.radarPos, range, dronePositions));
            }
         }
      );
   }
}
