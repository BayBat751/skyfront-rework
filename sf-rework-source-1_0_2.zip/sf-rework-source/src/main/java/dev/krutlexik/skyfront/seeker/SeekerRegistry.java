package dev.krutlexik.skyfront.seeker;

import dev.krutlexik.skyfront.entity.ShahedEntity;
import dev.krutlexik.skyfront.item.ShahedItem;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType.Builder;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Item.Properties;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredRegister.Items;

public final class SeekerRegistry {
   public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(BuiltInRegistries.ENTITY_TYPE, "sfw");
   public static final Items ITEMS = DeferredRegister.createItems("sfw");
   public static final DeferredHolder<EntityType<?>, EntityType<ShahedEntity>> SEEKER = ENTITIES.register(
      "shahed_seeker",
      () -> Builder.of(ShahedEntity::new, MobCategory.MISC)
            .sized(3.0F, 1.5F)
            .clientTrackingRange(600)
            .updateInterval(1)
            .setShouldReceiveVelocityUpdates(true)
            .build("shahed_seeker")
   );
   public static final DeferredHolder<EntityType<?>, EntityType<SeekerDroneEntity>> SEEKER_DRONE = ENTITIES.register(
      "shahed_seeker_drone",
      () -> Builder.of(SeekerDroneEntity::new, MobCategory.MISC).sized(3.0F, 1.0F).clientTrackingRange(16).updateInterval(1).build("shahed_seeker_drone")
   );
   public static final DeferredHolder<EntityType<?>, EntityType<ShahedEntity>> SHAHED_238 = ENTITIES.register(
      "shahed_238",
      () -> Builder.of(ShahedEntity::new, MobCategory.MISC)
            .sized(3.0F, 1.5F)
            .clientTrackingRange(600)
            .updateInterval(1)
            .setShouldReceiveVelocityUpdates(true)
            .build("shahed_238")
   );
   public static final DeferredHolder<EntityType<?>, EntityType<Shahed238DroneEntity>> SHAHED_238_DRONE = ENTITIES.register(
      "shahed_238_drone",
      () -> Builder.of(Shahed238DroneEntity::new, MobCategory.MISC).sized(3.0F, 1.0F).clientTrackingRange(16).updateInterval(1).build("shahed_238_drone")
   );
   public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(BuiltInRegistries.SOUND_EVENT, "sfw");
   public static final DeferredHolder<SoundEvent, SoundEvent> JET_ENGINE = SOUNDS.register(
      "jet_shahed_engine", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("sfw", "jet_shahed_engine"))
   );
   public static final DeferredHolder<SoundEvent, SoundEvent> JET_FLYBY = sound("jet_shahed_flyby");
   public static final DeferredHolder<SoundEvent, SoundEvent> JET_FLYBY_60 = sound("jet_shahed_flyby_60");
   public static final DeferredHolder<SoundEvent, SoundEvent> JET_FLYBY_32 = sound("jet_shahed_flyby_32");
   public static final DeferredHolder<SoundEvent, SoundEvent> JET_FLYBY_14 = sound("jet_shahed_flyby_14");
   public static final DeferredItem<Item> SHAHED_238_ITEM = ITEMS.register("shahed_238", () -> new ShahedItem(new Properties()));
   public static final DeferredItem<Item> SEEKER_ITEM = ITEMS.register("shahed_seeker", () -> new ShahedItem(new Properties()));

   private static DeferredHolder<SoundEvent, SoundEvent> sound(String var0) {
      return SOUNDS.register(var0, () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("sfw", var0)));
   }

   private SeekerRegistry() {
   }

   public static void register(IEventBus var0) {
      ENTITIES.register(var0);
      ITEMS.register(var0);
      SOUNDS.register(var0);
   }
}
