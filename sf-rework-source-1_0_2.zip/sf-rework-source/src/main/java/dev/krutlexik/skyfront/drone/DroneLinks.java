package dev.krutlexik.skyfront.drone;

import dev.krutlexik.skyfront.drone.entity.DroneEntity;
import dev.krutlexik.skyfront.util.ChunkLoadHelper;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.function.BiConsumer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public final class DroneLinks {
   private static final int CONNECT_TIMEOUT_TICKS = 200;
   private static final Map<UUID, DroneLinks.Sighting> LAST_SEEN = new HashMap<>();
   private static final Map<UUID, DroneEntity> FLOWN_BY = new HashMap<>();
   private static final Map<UUID, DroneLinks.Pending> PENDING = new HashMap<>();

   private DroneLinks() {
   }

   public static void remember(DroneEntity drone) {
      if (!drone.level().isClientSide) {
         LAST_SEEN.put(drone.getUUID(), new DroneLinks.Sighting(drone.level().dimension(), drone.chunkPosition(), drone.controlRange()));
      }
   }

   public static void forget(DroneEntity drone) {
      LAST_SEEN.remove(drone.getUUID());
   }

   public static void controllerChanged(DroneEntity drone, @Nullable UUID previous, @Nullable UUID next) {
      if (!drone.level().isClientSide) {
         if (previous != null && FLOWN_BY.get(previous) == drone) {
            FLOWN_BY.remove(previous);
         }

         if (next != null) {
            FLOWN_BY.put(next, drone);
            PENDING.remove(next);
         }
      }
   }

   @Nullable
   public static Vec3 pilotView(ServerPlayer player) {
      if (FLOWN_BY.isEmpty()) {
         return null;
      } else {
         DroneEntity drone = FLOWN_BY.get(player.getUUID());
         return drone != null && !drone.isRemoved() && drone.level() == player.level() && drone.isControlledBy(player) ? drone.position() : null;
      }
   }

   public static void forEachPilotView(BiConsumer<ServerPlayer, Vec3> action) {
      if (!FLOWN_BY.isEmpty()) {
         for (Entry<UUID, DroneEntity> entry : FLOWN_BY.entrySet()) {
            DroneEntity drone = entry.getValue();
            if (!drone.isRemoved()) {
               Level var6 = drone.level();
               if (var6 instanceof ServerLevel) {
                  ServerLevel level = (ServerLevel)var6;
                  Player var7 = level.getPlayerByUUID(entry.getKey());
                  if (var7 instanceof ServerPlayer) {
                     ServerPlayer pilot = (ServerPlayer)var7;
                     if (drone.isControlledBy(pilot)) {
                        action.accept(pilot, drone.position());
                     }
                  }
               }
            }
         }
      }
   }

   @Nullable
   public static DroneEntity flownBy(ServerPlayer pilot) {
      DroneEntity drone = FLOWN_BY.get(pilot.getUUID());
      if (drone == null || !drone.isRemoved() && drone.isControlledBy(pilot)) {
         return drone;
      } else {
         FLOWN_BY.remove(pilot.getUUID());
         return null;
      }
   }

   public static boolean reconnectWhenLoaded(ServerPlayer pilot, UUID droneId, BiConsumer<ServerPlayer, DroneEntity> connect) {
      DroneLinks.Sighting where = LAST_SEEN.get(droneId);
      if (where != null && where.dimension() == pilot.level().dimension()) {
         double dx = (double)where.chunk().getMiddleBlockX() + 0.5 - pilot.getX();
         double dz = (double)where.chunk().getMiddleBlockZ() + 0.5 - pilot.getZ();
         double reach = where.controlRange() + 16.0;
         if (dx * dx + dz * dz > reach * reach) {
            return false;
         } else {
            PENDING.put(pilot.getUUID(), new DroneLinks.Pending(droneId, where, connect));
            load(pilot.serverLevel(), where.chunk());
            return true;
         }
      } else {
         return false;
      }
   }

   public static void serverTick(MinecraftServer server) {
      if (!PENDING.isEmpty()) {
         Iterator<Entry<UUID, DroneLinks.Pending>> entries = PENDING.entrySet().iterator();

         while (entries.hasNext()) {
            Entry<UUID, DroneLinks.Pending> entry = entries.next();
            DroneLinks.Pending pending = entry.getValue();
            ServerPlayer pilot = server.getPlayerList().getPlayer(entry.getKey());
            ServerLevel level = server.getLevel(pending.where.dimension());
            if (pilot != null && !pilot.hasDisconnected() && level != null && pilot.level() == level) {
               Entity var7 = level.getEntity(pending.drone);
               if (var7 instanceof DroneEntity) {
                  DroneEntity drone = (DroneEntity)var7;
                  if (!drone.isRemoved()) {
                     entries.remove();
                     pending.connect.accept(pilot, drone);
                     continue;
                  }
               }

               if (--pending.ticksLeft <= 0) {
                  entries.remove();
                  pilot.displayClientMessage(Component.translatable("message.sfw.drone.drone_missing"), true);
               } else if (pending.ticksLeft % 20 == 0) {
                  load(level, pending.where.chunk());
               }
            } else {
               entries.remove();
            }
         }
      }
   }

   private static void load(ServerLevel level, ChunkPos chunk) {
      ChunkLoadHelper.keepTicking(level, chunk);
   }

   private static final class Pending {
      private final UUID drone;
      private final DroneLinks.Sighting where;
      private final BiConsumer<ServerPlayer, DroneEntity> connect;
      private int ticksLeft = 200;

      private Pending(UUID drone, DroneLinks.Sighting where, BiConsumer<ServerPlayer, DroneEntity> connect) {
         this.drone = drone;
         this.where = where;
         this.connect = connect;
      }
   }

   private static record Sighting(ResourceKey<Level> dimension, ChunkPos chunk, double controlRange) {
   }
}
