package dev.krutlexik.skyfront.drone.mixin;

import dev.krutlexik.skyfront.drone.client.DroneControl;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({MouseHandler.class})
public class MouseHandlerMixin {
   @Shadow
   private double accumulatedDX;
   @Shadow
   private double accumulatedDY;
   private static final int LEFT_BUTTON = 0;
   private static final int RIGHT_BUTTON = 1;
   private static final int PRESSED = 1;

   public MouseHandlerMixin() {
   }

   @Inject(
      method = {"onPress(JIII)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void skyfront$droneMouseButton(long windowPointer, int button, int action, int modifiers, CallbackInfo callbackInfo) {
      if (button == 0 && action != 1) {
         DroneControl.setReleaseButton(false);
      }

      if (action == 1 && DroneControl.holdsTheScreen()) {
         if (windowPointer == Minecraft.getInstance().getWindow().getWindow() && Minecraft.getInstance().screen == null) {
            if (DroneControl.isFpvStatic()) {
               if (button == 1) {
                  DroneControl.endHeldPicture();
               }

               callbackInfo.cancel();
            } else if (button == 0) {
               DroneControl.setReleaseButton(true);
               callbackInfo.cancel();
            }
         }
      }
   }

   @Inject(
      method = {"turnPlayer(D)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void skyfront$steerDrone(double movementTime, CallbackInfo callbackInfo) {
      if (DroneControl.holdsTheScreen()) {
         if (!DroneControl.isActive()) {
            callbackInfo.cancel();
         } else {
            Minecraft minecraft = Minecraft.getInstance();
            double sensitivity = (Double)minecraft.options.sensitivity().get() * 0.6 + 0.2;
            double scale = sensitivity * sensitivity * sensitivity * 8.0 * 0.15;
            double invertY = minecraft.options.invertYMouse().get() ? -1.0 : 1.0;
            DroneControl.steer(this.accumulatedDX * scale, this.accumulatedDY * scale * invertY, this.accumulatedDX, this.accumulatedDY * invertY, movementTime);
            callbackInfo.cancel();
         }
      }
   }
}
