package dev.krutlexik.skyfront.seeker;

import dev.krutlexik.skyfront.client.gui.ShahedTerminalScreen;
import dev.krutlexik.skyfront.client.gui.TerminalButton;
import dev.krutlexik.skyfront.network.NetworkHandler;
import dev.krutlexik.skyfront.network.TerminalActionPacket;
import dev.krutlexik.skyfront.network.TerminalDataPacket;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

public class SeekerTerminalScreen extends ShahedTerminalScreen {
   public SeekerTerminalScreen(BlockPos var1, List<TerminalDataPacket.Row> var2, TerminalDataPacket.MapSlot var3) {
      super(var1, var2, var3);
   }

   @Override
   protected void init() {
      super.init();
      int var1 = this.listTop();
      int var2 = this.panelLeft() + 340 - 5 - 4;
      int var3 = Math.min(6, this.rows.size() - this.scrollOffset);

      for (int var4 = 0; var4 < var3; var4++) {
         TerminalDataPacket.Row var5 = this.rows.get(this.scrollOffset + var4);
         if (var5.status() == 4) {
            int var6 = var1 + var4 * 24;
            this.addRenderableWidget(new TerminalButton(var2 - 122 - 62, var6, 58, 20, Component.translatable("gui.sfw.terminal.connect"), var2x -> {
               NetworkHandler.sendToServer(new TerminalActionPacket(this.getTerminalPos(), 6, var5.uuid(), new int[0], 0, true));
               this.minecraft.setScreen(null);
            }));
         }
      }

      this.addRenderableWidget(SeekerGroupClient.button(this));
   }
}
