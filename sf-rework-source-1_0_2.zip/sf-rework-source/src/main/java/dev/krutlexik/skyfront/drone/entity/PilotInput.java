package dev.krutlexik.skyfront.drone.entity;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.util.Mth;

public record PilotInput(int seq, byte keys, float gimbalYaw, float gimbalPitch, float roll, float pitch, float yaw, float throttle) {
   public static final PilotInput NEUTRAL = new PilotInput(-1, (byte)0, 0.0F / 0.0F, 0.0F / 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);

   public boolean holds(int key) {
      return (this.keys & key) != 0;
   }

   public boolean hasGimbal() {
      return !Float.isNaN(this.gimbalYaw) && !Float.isNaN(this.gimbalPitch);
   }

   public PilotInput released() {
      byte arm = (byte)(this.keys & 192);
      return new PilotInput(this.seq, arm, this.gimbalYaw, this.gimbalPitch, 0.0F, 0.0F, 0.0F, this.throttle);
   }

   public PilotInput withSeq(int newSeq) {
      return new PilotInput(newSeq, this.keys, this.gimbalYaw, this.gimbalPitch, this.roll, this.pitch, this.yaw, this.throttle);
   }

   public PilotInput sanitized() {
      boolean gimbal = Float.isFinite(this.gimbalYaw) && Float.isFinite(this.gimbalPitch);
      return new PilotInput(
         this.seq,
         this.keys,
         gimbal ? this.gimbalYaw : 0.0F / 0.0F,
         gimbal ? this.gimbalPitch : 0.0F / 0.0F,
         axis(this.roll, -1.0F),
         axis(this.pitch, -1.0F),
         axis(this.yaw, -1.0F),
         axis(this.throttle, 0.0F)
      );
   }

   private static float axis(float value, float min) {
      return Float.isFinite(value) ? Mth.clamp(value, min, 1.0F) : 0.0F;
   }

   public void write(FriendlyByteBuf buf) {
      buf.writeVarInt(this.seq);
      buf.writeByte(this.keys);
      buf.writeFloat(this.gimbalYaw);
      buf.writeFloat(this.gimbalPitch);
      buf.writeFloat(this.roll);
      buf.writeFloat(this.pitch);
      buf.writeFloat(this.yaw);
      buf.writeFloat(this.throttle);
   }

   public static PilotInput read(FriendlyByteBuf buf) {
      return new PilotInput(
         buf.readVarInt(), buf.readByte(), buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readFloat()
      );
   }
}
