package dev.krutlexik.skyfront.seeker;

import dev.krutlexik.skyfront.drone.client.DroneControl;
import dev.krutlexik.skyfront.drone.entity.DroneEntity;
import java.util.Locale;

public final class SeekerOsd {
   private static final String NONE = "X --   Y --   Z --";

   private SeekerOsd() {
   }

   public static String coordText(boolean var0) {
      if (var0) {
         return "X --   Y --   Z --";
      } else {
         DroneEntity var1 = DroneControl.drone();
         return var1 == null
            ? "X --   Y --   Z --"
            : String.format(Locale.ROOT, "X %d   Y %d   Z %d", (int)Math.floor(var1.getX()), (int)Math.floor(var1.getY()), (int)Math.floor(var1.getZ()));
      }
   }
}
