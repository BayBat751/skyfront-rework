package dev.krutlexik.skyfront.drone.client;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.pipeline.TextureTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.platform.NativeImage;
import dev.krutlexik.skyfront.drone.DroneMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FastColor.ABGR32;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.jetbrains.annotations.Nullable;

@OnlyIn(Dist.CLIENT)
public final class DroneFeedFreeze {
   private static final ResourceLocation FROZEN_FRAME = DroneMod.id("frozen_feed");
   private static final ResourceLocation GREY_FRAME = DroneMod.id("frozen_feed_grey");
   private static boolean captureRequested;
   private static boolean frameReady;
   private static boolean heldForFpv;
   private static int frameWidth;
   private static int frameHeight;
   @Nullable
   private static DroneTelemetry frozenTelemetry;
   @Nullable
   private static RenderTarget lastFrame;
   private static boolean lastFrameTaken;
   private static boolean fromFrameBefore;
   private static long frameCount;
   private static long copiedFrame = -1L;

   public static void arm(@Nullable DroneTelemetry lastReading) {
      frozenTelemetry = lastReading;
      captureRequested = true;
      frameReady = false;
      heldForFpv = false;
      fromFrameBefore = false;
   }

   public static void armHold() {
      frozenTelemetry = null;
      captureRequested = true;
      frameReady = false;
      heldForFpv = true;
      fromFrameBefore = false;
   }

   public static void newFrame() {
      frameCount++;
   }

   public static void useFrameBefore() {
      fromFrameBefore = true;
   }

   private static void keepFrame() {
      if (DroneControl.isActive() && !DroneControl.isPictureHeld() && !DroneSignalLoss.isActive() && copiedFrame != frameCount) {
         copiedFrame = frameCount;
         RenderTarget main = Minecraft.getInstance().getMainRenderTarget();
         if (lastFrame == null || lastFrame.width != main.width || lastFrame.height != main.height) {
            if (lastFrame != null) {
               lastFrame.destroyBuffers();
            }

            lastFrame = new TextureTarget(main.width, main.height, false, Minecraft.ON_OSX);
            lastFrameTaken = false;
         }

         GlStateManager._glBindFramebuffer(36008, main.frameBufferId);
         GlStateManager._glBindFramebuffer(36009, lastFrame.frameBufferId);
         GlStateManager._glBlitFrameBuffer(0, 0, main.width, main.height, 0, 0, lastFrame.width, lastFrame.height, 16384, 9728);
         main.bindWrite(false);
         lastFrameTaken = true;
      }
   }

   @Nullable
   public static DroneTelemetry frozenTelemetry() {
      return frozenTelemetry;
   }

   public static boolean isFrameReady() {
      return frameReady;
   }

   public static void release() {
      captureRequested = false;
      frozenTelemetry = null;
      heldForFpv = false;
      lastFrameTaken = false;
      fromFrameBefore = false;
      if (frameReady) {
         frameReady = false;
         Minecraft minecraft = Minecraft.getInstance();
         minecraft.getTextureManager().release(FROZEN_FRAME);
         minecraft.getTextureManager().release(GREY_FRAME);
      }
   }

   public static void captureIfRequested() {
      if (!captureRequested) {
         keepFrame();
      } else {
         captureRequested = false;
         if (heldForFpv || DroneSignalLoss.elapsed() <= 12) {
            Minecraft minecraft = Minecraft.getInstance();

            try {
               boolean before = fromFrameBefore && lastFrame != null && lastFrameTaken;
               fromFrameBefore = false;
               NativeImage colour = Screenshot.takeScreenshot(before ? lastFrame : minecraft.getMainRenderTarget());
               NativeImage grey = desaturate(colour);
               frameWidth = colour.getWidth();
               frameHeight = colour.getHeight();
               minecraft.getTextureManager().register(FROZEN_FRAME, new DynamicTexture(colour));
               minecraft.getTextureManager().register(GREY_FRAME, new DynamicTexture(grey));
               frameReady = true;
            } catch (Exception var4) {
               DroneMod.LOGGER.error("Could not capture the drone feed's last frame", var4);
            }
         }
      }
   }

   public static void render(GuiGraphics graphics) {
      if (DroneSignalLoss.isActive() && frameReady) {
         ResourceLocation frame = DroneSignalLoss.isBlanked() ? GREY_FRAME : FROZEN_FRAME;
         blitFrame(graphics, frame);
      }
   }

   public static void renderHold(GuiGraphics graphics) {
      if (heldForFpv && frameReady) {
         blitFrame(graphics, FROZEN_FRAME);
      }
   }

   private static void blitFrame(GuiGraphics graphics, ResourceLocation frame) {
      graphics.blit(frame, 0, 0, graphics.guiWidth(), graphics.guiHeight(), 0.0F, 0.0F, frameWidth, frameHeight, frameWidth, frameHeight);
   }

   private static NativeImage desaturate(NativeImage source) {
      NativeImage grey = new NativeImage(source.getWidth(), source.getHeight(), false);

      for (int y = 0; y < source.getHeight(); y++) {
         for (int x = 0; x < source.getWidth(); x++) {
            int abgr = source.getPixelRGBA(x, y);
            int luma = (int)(0.299 * (double)ABGR32.red(abgr) + 0.587 * (double)ABGR32.green(abgr) + 0.114 * (double)ABGR32.blue(abgr));
            grey.setPixelRGBA(x, y, ABGR32.color(ABGR32.alpha(abgr), luma, luma, luma));
         }
      }

      return grey;
   }

   private DroneFeedFreeze() {
   }
}
