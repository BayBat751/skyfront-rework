package dev.krutlexik.skyfront.network;

import dev.krutlexik.skyfront.client.ClientExplosionEffects;
import dev.krutlexik.skyfront.client.ClientViewpoint;
import dev.krutlexik.skyfront.client.ClientWorldMapData;
import dev.krutlexik.skyfront.client.sound.ShahedEngineSoundClient;
import dev.krutlexik.skyfront.entity.ShahedEntity;
import dev.krutlexik.skyfront.sound.ModSounds;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.Map.Entry;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ClientPacketHandler {
   private static final Map<Integer, ShahedEngineSoundClient> activeSounds = new HashMap<>();
   private static final Random random = new Random();

   public ClientPacketHandler() {
   }

   public static void handleShahedSpawn(
      int entityId, Vec3 currentPos, BlockPos targetPos, String diveMode, float healthFract, boolean falling, float diveProgress, boolean finalLeg
   ) {
      cleanupStoppedSounds();
      Minecraft mc = Minecraft.getInstance();
      if (mc.level != null && mc.level.getEntity(entityId) instanceof ShahedEntity shahed) {
         shahed.setServerPosition(currentPos);
      }

      ShahedEngineSoundClient existingSound = activeSounds.get(entityId);
      if (existingSound != null) {
         if (!existingSound.isStopped()) {
            existingSound.updateDronePosition(currentPos);
            existingSound.updateTarget(targetPos);
            existingSound.updateDamageState(healthFract, falling, diveProgress, finalLeg);
            return;
         }

         activeSounds.remove(entityId);
      }

      ShahedEngineSoundClient sound = new ShahedEngineSoundClient(entityId, currentPos, targetPos, diveMode);
      sound.updateDamageState(healthFract, falling, diveProgress, finalLeg);
      activeSounds.put(entityId, sound);
      mc.execute(sound::start);
   }

   public static void handleShahedRemove(int entityId) {
      ShahedEngineSoundClient sound = activeSounds.remove(entityId);
      if (sound != null && !sound.isStopped()) {
         sound.stopSound();
      }
   }

   public static void handleExplosion(Vec3 explosionPos, float particleMultiplier, boolean customSounds) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player != null) {
         ClientExplosionEffects.spawn(explosionPos, particleMultiplier);
         ShahedEngineSoundClient closestSound = null;
         double closestDistance = 1.7976931348623157E308;
         int closestEntityId = -1;

         for (Entry<Integer, ShahedEngineSoundClient> entry : activeSounds.entrySet()) {
            ShahedEngineSoundClient sound = entry.getValue();
            if (!sound.isStopped()) {
               Vec3 soundPos = new Vec3(sound.getX(), sound.getY(), sound.getZ());
               double dist = soundPos.distanceTo(explosionPos);
               if (dist < closestDistance && dist < 150.0) {
                  closestDistance = dist;
                  closestSound = sound;
                  closestEntityId = entry.getKey();
               }
            }
         }

         if (closestSound != null) {
            closestSound.markExploded(explosionPos);
            int entityId = closestEntityId;
            new Thread(() -> {
               try {
                  Thread.sleep(3000L);
               } catch (InterruptedException var2x) {
               }

               Minecraft.getInstance().execute(() -> activeSounds.remove(entityId));
            }).start();
         }

         Vec3 playerPos = ClientViewpoint.position();
         double distance = playerPos.distanceTo(explosionPos);
         float explosionVolume = calculateExplosionVolume(distance);
         if (!(explosionVolume < 0.1F)) {
            if (customSounds) {
               int delay = (int)(distance / 17.0);
               int randomSound = random.nextInt(5);
               new Thread(
                     () -> {
                        try {
                           Thread.sleep((long)delay * 50L);
                           mc.execute(
                              () -> {
                                 float randomPitch = 0.9F + random.nextFloat() * 0.2F;

                                 SoundEvent soundEvent = switch (randomSound) {
                                    case 0 -> (SoundEvent)ModSounds.EXPLOSION_1.get();
                                    case 1 -> (SoundEvent)ModSounds.EXPLOSION_2.get();
                                    case 2 -> (SoundEvent)ModSounds.EXPLOSION_3.get();
                                    case 3 -> (SoundEvent)ModSounds.EXPLOSION_4.get();
                                    default -> (SoundEvent)ModSounds.EXPLOSION_5.get();
                                 };
                                 mc.level
                                    .playLocalSound(
                                       explosionPos.x, explosionPos.y, explosionPos.z, soundEvent, SoundSource.HOSTILE, explosionVolume, randomPitch, false
                                    );
                              }
                           );
                        } catch (InterruptedException var6) {
                        }
                     }
                  )
                  .start();
            }
         }
      }
   }

   private static float calculateExplosionVolume(double distance) {
      if (distance >= 700.0) {
         return 0.0F;
      } else if (distance <= 350.0) {
         return 40.0F;
      } else if (distance <= 450.0) {
         return 24.0F;
      } else if (distance <= 550.0) {
         return 12.0F;
      } else {
         return distance <= 650.0 ? 4.0F : 1.0F;
      }
   }

   private static void cleanupStoppedSounds() {
      Iterator<Entry<Integer, ShahedEngineSoundClient>> iterator = activeSounds.entrySet().iterator();

      while (iterator.hasNext()) {
         Entry<Integer, ShahedEngineSoundClient> entry = iterator.next();
         if (entry.getValue().isStopped()) {
            iterator.remove();
         }
      }
   }

   public static void clearAll() {
      for (ShahedEngineSoundClient sound : activeSounds.values()) {
         if (!sound.isStopped()) {
            sound.stopSound();
         }
      }

      activeSounds.clear();
   }

   public static void handleWorldMapPacket(WorldMapPacket packet) {
      ClientWorldMapData.getInstance()
         .update(
            packet.getCenterChunkX(),
            packet.getCenterChunkZ(),
            packet.getRadiusChunks(),
            packet.decodeGrid(),
            packet.isScanComplete(),
            packet.getScanProgress(),
            packet.getTotalChunks()
         );
   }
}
