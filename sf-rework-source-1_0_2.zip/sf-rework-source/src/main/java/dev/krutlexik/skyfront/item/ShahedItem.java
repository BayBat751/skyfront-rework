package dev.krutlexik.skyfront.item;

import dev.krutlexik.skyfront.client.renderer.ShahedItemRenderer;
import dev.krutlexik.skyfront.config.SkyfrontConfig;
import dev.krutlexik.skyfront.entity.ShahedEntity;
import dev.krutlexik.skyfront.seeker.SeekerHooks;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.item.Item.TooltipContext;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.EventBusSubscriber.Bus;
import net.neoforged.neoforge.client.extensions.common.IClientItemExtensions;
import net.neoforged.neoforge.client.extensions.common.RegisterClientExtensionsEvent;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager.ControllerRegistrar;
import software.bernie.geckolib.util.GeckoLibUtil;

@EventBusSubscriber(
   modid = "sfw",
   bus = Bus.MOD
)
public class ShahedItem extends Item implements GeoItem {
   public static final String TAG_UUID = "ShahedUuid";
   public static final String TAG_HEALTH = "ShahedHealth";
   public static final String TAG_TERMINAL = "ShahedTerminal";
   public static final String TAG_TERMINAL_DIM = "ShahedTerminalDim";
   private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

   public ShahedItem(Properties properties) {
      super(properties.stacksTo(1));
   }

   @SubscribeEvent
   private static void registerClientExtensions(RegisterClientExtensionsEvent event) {
      event.registerItem(new IClientItemExtensions() {
         private BlockEntityWithoutLevelRenderer renderer;

         public BlockEntityWithoutLevelRenderer getCustomRenderer() {
            if (this.renderer == null) {
               this.renderer = new ShahedItemRenderer();
            }

            return this.renderer;
         }
      }, new Item[]{(Item)ModItems.SHAHED_136.get(), SeekerHooks.seekerItem(), SeekerHooks.item238()});
   }

   public void registerControllers(ControllerRegistrar controllers) {
   }

   public AnimatableInstanceCache getAnimatableInstanceCache() {
      return this.cache;
   }

   public InteractionResult useOn(UseOnContext context) {
      Player player = context.getPlayer();
      if (!context.getLevel().isClientSide && player != null) {
         player.displayClientMessage(Component.translatable("msg.sfw.place.launcher_only").withStyle(ChatFormatting.RED), true);
      }

      return InteractionResult.FAIL;
   }

   public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
      CompoundTag tag = getData(stack);
      float max = (float)Math.max(1.0, (Double)SkyfrontConfig.SHAHED_HEALTH.get());
      float hp = tag.contains("ShahedHealth") && tag.getFloat("ShahedHealth") >= 0.0F ? tag.getFloat("ShahedHealth") : max;
      ChatFormatting color = hp >= max ? ChatFormatting.GREEN : (hp > max * 0.25F ? ChatFormatting.YELLOW : ChatFormatting.RED);
      tooltip.add(Component.translatable("tooltip.sfw.shahed.health", new Object[]{String.format("%.0f", hp), String.format("%.0f", max)}).withStyle(color));
      if (tag.contains("ShahedTerminal")) {
         int[] p = tag.getIntArray("ShahedTerminal");
         if (p.length == 3) {
            tooltip.add(Component.translatable("tooltip.sfw.shahed.bound", new Object[]{p[0], p[1], p[2]}).withStyle(ChatFormatting.AQUA));
         }
      }

      super.appendHoverText(stack, context, tooltip, flag);
   }

   public static void applyStackData(ShahedEntity drone, Level level, ItemStack stack) {
      CompoundTag tag = getData(stack);
      UUID uuid = tag.hasUUID("ShahedUuid") ? tag.getUUID("ShahedUuid") : UUID.randomUUID();
      if (level instanceof ServerLevel serverLevel && serverLevel.getEntity(uuid) != null) {
         uuid = UUID.randomUUID();
      }

      drone.setUUID(uuid);
      drone.setDroneHealthDirect(tag.contains("ShahedHealth") ? tag.getFloat("ShahedHealth") : -1.0F);
      if (tag.contains("ShahedTerminal")) {
         int[] p = tag.getIntArray("ShahedTerminal");
         if (p.length == 3) {
            drone.setBoundTerminal(new BlockPos(p[0], p[1], p[2]));
         }
      }
   }

   public static CompoundTag getData(ItemStack stack) {
      return ((CustomData)stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY)).copyTag();
   }

   public static void writeData(ItemStack stack, UUID uuid, float health, @Nullable BlockPos terminal, @Nullable String terminalDim) {
      CompoundTag tag = getData(stack);
      tag.putUUID("ShahedUuid", uuid);
      if (health >= 0.0F) {
         tag.putFloat("ShahedHealth", health);
      } else {
         tag.remove("ShahedHealth");
      }

      if (terminal != null) {
         tag.putIntArray("ShahedTerminal", new int[]{terminal.getX(), terminal.getY(), terminal.getZ()});
         if (terminalDim != null) {
            tag.putString("ShahedTerminalDim", terminalDim);
         }
      } else {
         tag.remove("ShahedTerminal");
         tag.remove("ShahedTerminalDim");
      }

      stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
   }
}
