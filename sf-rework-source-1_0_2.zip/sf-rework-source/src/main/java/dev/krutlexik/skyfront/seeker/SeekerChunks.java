package dev.krutlexik.skyfront.seeker;

import dev.krutlexik.skyfront.drone.DroneLongRange;
import dev.krutlexik.skyfront.drone.entity.DroneEntity;
import dev.krutlexik.skyfront.util.ChunkLoadHelper;
import java.util.HashSet;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.phys.Vec3;

public final class SeekerChunks {
   private static final double FAST = 1.2;
   private static final int LEAD_CHUNKS = 5;
   private static final int MAX_SHIFT = 4;
   private static final int MAX_BUDGET = 18;
   private static final int SWITCH_TICKS = 10;
   private static final Map<DroneEntity, int[]> CENTRE = new WeakHashMap<>();

   private SeekerChunks() {
   }

   public static boolean load(DroneEntity var0) {
      if (var0.level() instanceof ServerLevel var1 && var0.needsLongRangeLink()) {
         Vec3 var25 = var0.getDeltaMovement();
         double var3 = var25.horizontalDistance();
         if (var3 < 1.2) {
            return false;
         }

         ChunkPos var5 = var0.chunkPosition();
         ChunkLoadHelper.keepTicking(var1, var5);
         double var6 = var25.x / var3;
         double var8 = var25.z / var3;
         int var10 = DroneLongRange.loadedRadius();
         int var11 = (int)Math.round(var6 * 5.0);
         int var12 = (int)Math.round(var8 * 5.0);

         for (int var13 = -var10; var13 <= var10; var13++) {
            for (int var14 = -var10; var14 <= var10; var14++) {
               ChunkLoadHelper.keepLoaded(var1, new ChunkPos(var5.x + var11 + var13, var5.z + var12 + var14));
            }
         }

         double var26 = Math.min(640.0, Math.max((double)(var10 + 8) * 16.0, var3 * 100.0));
         int var15 = var3 >= 3.0 ? 3 : 2;
         double var16 = -var8;
         double var18 = var6;
         HashSet var20 = new HashSet();

         for (double var21 = (double)(5 + var10 + 1) * 16.0; var21 <= var26; var21 += 16.0) {
            for (int var23 = -var15; var23 <= var15; var23++) {
               ChunkPos var24 = ChunkLoadHelper.chunkAt(
                  var0.getX() + var6 * var21 + var16 * (double)var23 * 16.0, var0.getZ() + var8 * var21 + var18 * (double)var23 * 16.0
               );
               if (var20.add(ChunkPos.asLong(var24.x, var24.z))) {
                  ChunkLoadHelper.preloadAhead(var1, var24);
               }
            }
         }

         return true;
      }

      return false;
   }

   public static int budget(DroneEntity var0) {
      double var1 = var0.getDeltaMovement().horizontalDistance();
      int var3 = (int)Math.ceil(var1 / 16.0 * (double)(2 * DroneLongRange.streamRadius() + 1) * 2.0);
      return Math.max(5, Math.min(18, var3 + 4));
   }

   public static ChunkPos streamCentre(DroneEntity var0) {
      ChunkPos var1 = var0.chunkPosition();
      Vec3 var2 = var0.getDeltaMovement();
      double var3 = var2.horizontalDistance();
      int[] var5 = CENTRE.get(var0);
      if (var5 == null) {
         var5 = new int[6];
         CENTRE.put(var0, var5);
      }

      int var6 = 0;
      int var7 = 0;
      if (var3 >= 1.0) {
         int var8 = (int)Math.min(4L, Math.round(var3 * 1.2));
         var6 = (int)Math.round(var2.x / var3 * (double)var8);
         var7 = (int)Math.round(var2.z / var3 * (double)var8);
      }

      if (var5[5] == 0) {
         var5[0] = var6;
         var5[1] = var7;
         var5[5] = 1;
      } else if (var6 == var5[0] && var7 == var5[1]) {
         var5[4] = 0;
      } else if (var6 == var5[2] && var7 == var5[3]) {
         var5[4]++;
         if (var5[4] >= 10) {
            var5[0] = var6;
            var5[1] = var7;
            var5[4] = 0;
         }
      } else {
         var5[2] = var6;
         var5[3] = var7;
         var5[4] = 1;
      }

      return new ChunkPos(var1.x + var5[0], var1.z + var5[1]);
   }
}
