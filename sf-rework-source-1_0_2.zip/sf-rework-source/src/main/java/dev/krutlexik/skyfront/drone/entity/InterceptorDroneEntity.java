package dev.krutlexik.skyfront.drone.entity;

import dev.krutlexik.skyfront.config.SkyfrontConfig;
import dev.krutlexik.skyfront.drone.DroneTuning;
import dev.krutlexik.skyfront.drone.FpvPack;
import dev.krutlexik.skyfront.drone.GrenadeAttachments;
import dev.krutlexik.skyfront.drone.RateModeFlight;
import dev.krutlexik.skyfront.drone.registry.DroneItems;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;
import org.joml.Vector3f;

public class InterceptorDroneEntity extends DroneEntity {
   private static final float RATE_STEP = 0.3F;
   private static final int RATE_HOLD_CAP = 5;
   private static final float RATE_DECAY = 0.7F;
   private static final float MAX_TILT = 30.0F;
   private static final float MAX_NOSE_TILT = 78.0F;
   private static final double AIR_DRAG = 0.965;
   private static final double VERTICAL_DRAG = 0.7;
   private static final double GROUND_DRAG = 0.8;
   private static final float MAX_POWER = 0.2F;
   private static final float MIN_POWER = 0.02F;
   private static final float POWER_UP_STEP = 0.01F;
   private static final float POWER_DOWN_STEP = 0.02F;
   private static final float POWER_TRIM_STEP = 0.005F;
   private static final float LIFT_PER_POWER = 0.6F;
   private static final double CLIMB_STEP = 0.05;
   private static final int CLIMB_HOLD_CAP = 40;
   private static final double GRAVITY = 0.06;
   private static final double STEADY_RATE = 3.499999701976788;
   private static final double THRUST_MARGIN = 1.06;
   private static final int RATE_MODE_SUBSTEPS = 8;
   private static final double CENTRE_RATE = 150.0;
   private static final double YAW_CENTRE_RATE = 120.0;
   private static final double SETPOINT_FILTER = 138.23007675795088;
   private static final double RATE_RESPONSE = 5.5;
   private static final double YAW_RATE_RESPONSE = 3.0;
   private static final double HARD_RATE_LIMIT = 1200.0;
   private static final double DISC_BRAKE = 0.09;
   private static final double RATE_MODE_MIN_DRAG = 0.8;
   private static final double RATE_MODE_MAX_DRAG = 0.995;
   private static final double PLANE_THRUST_WEIGHT = 3.0;
   private static final double PLANE_IDLE_THROTTLE = 0.12;
   private static final double PLANE_SPOOL = 0.13;
   private static final double PLANE_CRUISE_FRACTION = 0.55;
   private static final double PLANE_ROTATE_FRACTION = 0.92;
   private static final double PLANE_AUTHORITY_SPEED = 0.6;
   private static final double PLANE_MIN_AUTHORITY = 0.12;
   private static final double PLANE_ROLL_RATE = 160.0;
   private static final double PLANE_PITCH_RATE = 70.0;
   private static final double PLANE_YAW_RATE = 22.0;
   private static final double PLANE_RATE_RESPONSE = 7.0;
   private static final double PLANE_YAW_RESPONSE = 4.0;
   private static final double PLANE_ROLL_LEVEL = 1.6;
   private static final double PLANE_GLIDE_LIFT = 0.88;
   private static final double PLANE_GLIDE_RANGE = 250.0;
   private static final double PLANE_GLIDE_RANGE_HARD = 280.0;
   private static final double PLANE_DRAG_BASE = 0.006;
   private static final double PLANE_GLIDE_DRAG = 0.992;
   private static final double PLANE_KEEP_SIDE = 0.55;
   private static final double PLANE_KEEP_VERT = 0.8;
   private static final double PLANE_GROUND_FRICTION = 0.99;
   private final Quaternionf attitude = new Quaternionf();
   private boolean attitudeReady;
   private final Quaternionf clientAttitude = new Quaternionf();
   private final Quaternionf clientAttitudeOld = new Quaternionf();
   private final Quaternionf clientBlend = new Quaternionf();
   private double ratePitch;
   private double rateYaw;
   private double rateRoll;
   private double demandPitch;
   private double demandYaw;
   private double demandRoll;
   private static final EntityDataAccessor<Quaternionf> DATA_ATTITUDE = SynchedEntityData.defineId(
      InterceptorDroneEntity.class, EntityDataSerializers.QUATERNION
   );
   private static final float CAMERA_UP_LIMIT = -60.0F;
   private static final float CAMERA_DOWN_LIMIT = 90.0F;
   private int holdX;
   private int holdY;
   private int holdZ;
   private int lastVerticalDir;
   private float leanRateX;
   private float leanRateZ;
   private float power = 0.02F;
   private static final EntityDataAccessor<Boolean> DATA_RAIL_SEATED = SynchedEntityData.defineId(InterceptorDroneEntity.class, EntityDataSerializers.BOOLEAN);
   private static final EntityDataAccessor<Float> DATA_RAIL_PITCH = SynchedEntityData.defineId(InterceptorDroneEntity.class, EntityDataSerializers.FLOAT);
   private static final float RAIL_LAUNCH_THROTTLE = 0.5F;
   private static final double RAIL_LAUNCH_SPEED = 1.1;
   private double planeThrottle = 0.12;
   private float heldThrottle;
   private double glideRun;
   private static final float TILT_EASE = 0.35F;
   private float clientNose;
   private float clientNoseOld;
   private float clientBank;
   private float clientBankOld;
   private static final int WARHEAD_EFFECT = 2;
   private static final double FUSE_SPEED = 0.15;
   private static final double NOSE_FUSE_SPEED = 0.05;
   @Nullable
   private Vec3 impactFrom;
   @Nullable
   private Boolean rateModeOverride;
   private boolean clientAttitudeShown;
   private static final float PROP_MAX_RATE = 100.0F;

   public void seatOnRail(Vec3 pos, float yawDeg, float pitchDeg) {
      this.setPos(pos);
      this.setYRot(yawDeg);
      this.yRotO = yawDeg;
      this.entityData.set(DATA_RAIL_SEATED, true);
      this.entityData.set(DATA_RAIL_PITCH, pitchDeg);
      this.holdOnRail();
   }

   public boolean isRailSeated() {
      return (Boolean)this.entityData.get(DATA_RAIL_SEATED);
   }

   private void holdOnRail() {
      this.attitude.identity().rotateY((180.0F - this.getYRot()) * 0.017453292F).rotateX((Float)this.entityData.get(DATA_RAIL_PITCH) * 0.017453292F);
      this.attitudeReady = true;
      this.ratePitch = 0.0;
      this.rateYaw = 0.0;
      this.rateRoll = 0.0;
      this.demandPitch = 0.0;
      this.demandYaw = 0.0;
      this.demandRoll = 0.0;
      this.setDeltaMovement(Vec3.ZERO);
      this.publishAttitude();
   }

   @Override
   public boolean isGrounded() {
      return this.isRailSeated() || super.isGrounded();
   }

   public InterceptorDroneEntity(EntityType<? extends InterceptorDroneEntity> type, Level level) {
      super(type, level);
   }

   @Override
   protected void defineSynchedData(Builder builder) {
      super.defineSynchedData(builder);
      builder.define(DATA_ATTITUDE, new Quaternionf());
      builder.define(DATA_RAIL_SEATED, false);
      builder.define(DATA_RAIL_PITCH, 0.0F);
   }

   public boolean rateMode() {
      return this.rateModeOverride != null ? this.rateModeOverride : DroneTuning.flag(DroneTuning.Value.INTERCEPTOR_RATE_MODE);
   }

   @Override
   public boolean flownOnSticks() {
      return this.rateMode();
   }

   public boolean fliesAsAircraft() {
      return false;
   }

   public float defaultCameraTilt() {
      return 25.0F;
   }

   public boolean tiltableCamera() {
      return true;
   }

   public boolean noseFused() {
      return false;
   }

   public boolean analogVideo() {
      return false;
   }

   @Override
   public void setController(@Nullable UUID id) {
      if (id == null && this.isControlled()) {
         this.heldThrottle = this.stickThrottle();
      } else if (id != null) {
         this.heldThrottle = 0.0F;
      }

      super.setController(id);
   }

   public void forceRateMode(boolean rateMode) {
      this.rateModeOverride = rateMode;
      this.attitudeReady = false;
   }

   public double glideRun() {
      return this.glideRun;
   }

   public void forceGlideRun(double blocks) {
      this.glideRun = blocks;
   }

   @Override
   public void tick() {
      super.tick();
      if (!this.level().isClientSide) {
         if (this.rateMode() && !this.attitudeReady && !this.isControlled()) {
            if (this.isRailSeated()) {
               this.holdOnRail();
            } else {
               this.attitudeFromYaw();
               this.publishAttitude();
            }
         }
      } else if (!this.rateMode() || !this.locallyControlled) {
         if (!this.isWrecked()) {
            this.clientNoseOld = this.clientNose;
            this.clientBankOld = this.clientBank;
            if (this.rateMode()) {
               if (this.playedAttitude != null) {
                  this.attitude.set(this.playedAttitude);
                  this.attitudeReady = true;
                  this.shiftClientAttitude();
               } else {
                  this.readAttitude();
               }
            } else {
               this.clientNose = this.clientNose + (this.tiltFromTravel(true) - this.clientNose) * 0.35F;
               this.clientBank = this.clientBank + (this.tiltFromTravel(false) - this.clientBank) * 0.35F;
            }
         }
      }
   }

   @Override
   public double controlRange() {
      return (double)((Integer)SkyfrontConfig.INTERCEPTOR_CONTROL_RANGE.get()).intValue();
   }

   @Override
   public int fullFlightTicks() {
      return (int)DroneTuning.get(DroneTuning.Value.INTERCEPTOR_FLIGHT_SECONDS) * 20;
   }

   @Override
   public double crashSpeedKmh() {
      return DroneTuning.get(DroneTuning.Value.INTERCEPTOR_CRASH_SPEED);
   }

   @Override
   protected double topSpeed() {
      return this.topSpeedKmh() / 72.0;
   }

   public double topSpeedPerTick() {
      return Math.max(0.001, this.topSpeed());
   }

   public double trimSpeed() {
      return this.topSpeedPerTick() * 0.55;
   }

   public double topSpeedKmh() {
      return DroneTuning.get(DroneTuning.Value.INTERCEPTOR_TOP_SPEED);
   }

   protected double thrustToWeight() {
      return DroneTuning.get(DroneTuning.Value.INTERCEPTOR_THRUST_TO_WEIGHT);
   }

   public double hoverThrottle() {
      return 1.0 / this.thrustToWeight();
   }

   protected double agility() {
      return 1.0;
   }

   @Override
   protected float thrust() {
      double needed = this.topSpeed() * 0.03500000000000003 / 0.965 * 1.06;
      return (float)(needed / 3.499999701976788);
   }

   @Override
   protected double ramSpeed() {
      return 0.15;
   }

   @Override
   public double lookGearing() {
      return (Double)SkyfrontConfig.INTERCEPTOR_LOOK_SENSITIVITY.get();
   }

   @Override
   public double gimbalLag() {
      return 0.0;
   }

   @Override
   protected double maxHitpoints() {
      return (Double)SkyfrontConfig.INTERCEPTOR_HITPOINTS.get();
   }

   @Override
   protected boolean carriesStores() {
      return false;
   }

   @Override
   public DroneEntity.Osd osdStyle() {
      return DroneEntity.Osd.BETAFLIGHT;
   }

   @Override
   public boolean hasEngineSound() {
      return true;
   }

   @Override
   public boolean autolandsWhenFlat() {
      return false;
   }

   @Override
   public boolean motorsDead() {
      return super.motorsDead() || !this.isArmed() || this.packFade() <= 0.0F;
   }

   @Override
   public boolean requiresArming() {
      return true;
   }

   @Override
   public boolean hasCameraZoom() {
      return false;
   }

   @Override
   public float minPitch() {
      return -60.0F;
   }

   @Override
   public float maxPitch() {
      return 90.0F;
   }

   @Override
   protected float computeInputLoad() {
      if (this.rateMode()) {
         return Mth.clamp(this.stickThrottle(), 0.0F, 1.0F);
      } else {
         float collective = (this.power - 0.02F) / 0.18F;
         float sticks = (float)((double)(Math.abs(this.leanRateX) + Math.abs(this.leanRateZ)) / 6.999999403953576);
         return Mth.clamp(0.6F * collective + 0.4F * sticks, 0.0F, 1.0F);
      }
   }

   @Override
   public ItemStack packedItem() {
      return new ItemStack((ItemLike)DroneItems.INTERCEPTOR_DRONE.get());
   }

   @Override
   public void applyControlInput(boolean forward, boolean backward, boolean left, boolean right, boolean up, boolean down) {
      float wrapped = Mth.wrapDegrees(this.getYRot());
      this.yRotO = this.yRotO + (wrapped - this.getYRot());
      this.setYRot(wrapped);
      if (this.fliesAsAircraft() && this.isRailSeated()) {
         this.holdOnRail();
         if (this.motorsDead() || this.stickThrottle() < 0.5F) {
            return;
         }

         this.entityData.set(DATA_RAIL_SEATED, false);
         Vector3f nose = this.attitude.transform(0.0F, 0.0F, -1.0F, new Vector3f());
         this.setDeltaMovement(new Vec3((double)nose.x(), (double)nose.y(), (double)nose.z()).scale(this.trimSpeed() * 1.1));
         this.planeThrottle = (double)this.stickThrottle();
      }

      boolean grounded = this.isGrounded();
      float touchdownSpeed = grounded ? (float)this.getDeltaMovement().length() : 0.0F;
      if (!this.motorsDead()) {
         this.glideRun = 0.0;
         if (this.fliesAsAircraft()) {
            this.flyPlane(grounded, touchdownSpeed, true);
         } else if (this.rateMode()) {
            this.flyRateMode(grounded, touchdownSpeed);
         } else {
            if (!grounded) {
               if (right) {
                  this.holdX++;
                  this.leanRateX = this.leanRateX - 0.3F * (float)Math.min(this.holdX, 5);
               } else if (left) {
                  this.holdX++;
                  this.leanRateX = this.leanRateX + 0.3F * (float)Math.min(this.holdX, 5);
               } else {
                  this.holdX = 0;
               }

               if (forward) {
                  this.holdZ++;
                  this.leanRateZ = this.leanRateZ - 0.3F * (float)Math.min(this.holdZ, 5);
               } else if (backward) {
                  this.holdZ++;
                  this.leanRateZ = this.leanRateZ + 0.3F * (float)Math.min(this.holdZ, 5);
               } else {
                  this.holdZ = 0;
               }

               this.setDeltaMovement(this.getDeltaMovement().multiply(0.965, 0.7, 0.965));
            } else {
               this.setDeltaMovement(this.getDeltaMovement().multiply(0.8, 1.0, 0.8));
               this.holdX = 0;
               this.holdZ = 0;
            }

            int verticalDir = up ? 1 : (down ? -1 : 0);
            if (verticalDir != this.lastVerticalDir) {
               this.holdY = 0;
            }

            this.lastVerticalDir = verticalDir;
            float fade = this.packFade();
            Vec3 velocity = this.getDeltaMovement();
            if (up) {
               this.holdY++;
               this.power = Math.min(this.power + 0.01F * (float)Math.min(this.holdY, 5), 0.2F);
               this.setDeltaMovement(velocity.x, 0.05 * (double)climbAuthority(fade) * (double)Math.min(this.holdY, 40), velocity.z);
            } else if (down) {
               this.holdY++;
               this.power = Math.max(this.power - 0.02F * (float)Math.min(this.holdY, 5), grounded ? 0.0F : 0.06F);
               this.setDeltaMovement(velocity.x, -0.05 * (double)Math.min(this.holdY, 40), velocity.z);
            } else {
               this.power = this.getDeltaMovement().y < 0.0
                  ? Math.min(this.power + 0.005F, 0.2F)
                  : Math.max(this.power - (grounded ? 4.9999997E-4F : 0.005F), 0.02F);
            }

            this.leanRateX *= 0.7F;
            this.leanRateZ *= 0.7F;
            if (!grounded) {
               this.setDeltaMovement(this.getDeltaMovement().add(0.0, (double)(this.power * 0.6F * fade) - 0.06, 0.0));
            }

            float thrust = this.thrust() * fade;
            double yawRad = (double)(this.getYRot() * 0.017453292F);
            double sin = (double)Mth.sin((float)yawRad);
            double cos = (double)Mth.cos((float)yawRad);
            Vec3 forwardAxis = new Vec3(-sin, 0.0, cos);
            Vec3 sideAxis = new Vec3(cos, 0.0, sin);
            this.setDeltaMovement(
               this.getDeltaMovement().add(sideAxis.scale((double)(this.leanRateX * thrust))).add(forwardAxis.scale((double)(-this.leanRateZ * thrust)))
            );
            double cap = this.topSpeed();
            Vec3 capped = this.getDeltaMovement();
            if (cap > 0.0) {
               double horizontal = capped.horizontalDistance();
               if (horizontal > cap) {
                  capped = new Vec3(capped.x * cap / horizontal, capped.y, capped.z * cap / horizontal);
               }

               capped = new Vec3(capped.x, Mth.clamp(capped.y, -cap, cap), capped.z);
            }

            if (capped.lengthSqr() < 1.0E-7) {
               capped = Vec3.ZERO;
            }

            this.setDeltaMovement(capped);
            Vec3 approach = this.getDeltaMovement();
            Vec3 from = this.position();
            this.recordImpact(from, approach, touchdownSpeed);
         }
      } else {
         if (this.fliesAsAircraft() && !grounded) {
            this.flyPlane(grounded, touchdownSpeed, false);
         } else {
            this.glideRun = 0.0;
            this.tickDisarmed(grounded, touchdownSpeed);
         }
      }
   }

   private void tickDisarmed(boolean grounded, float touchdownSpeed) {
      this.power = 0.02F;
      this.leanRateX = 0.0F;
      this.leanRateZ = 0.0F;
      this.holdX = 0;
      this.holdY = 0;
      this.holdZ = 0;
      this.lastVerticalDir = 0;
      Vec3 velocity = this.getDeltaMovement();
      if (grounded) {
         this.setDeltaMovement(velocity.x * 0.8, Math.max(velocity.y, 0.0), velocity.z * 0.8);
         if (this.rateMode()) {
            this.attitudeFromYaw();
            this.publishAttitude();
         } else {
            this.attitudeReady = false;
         }
      } else {
         this.setDeltaMovement(velocity.x * 0.965, velocity.y - 0.06, velocity.z * 0.965);
      }

      Vec3 approach = this.getDeltaMovement();
      Vec3 from = this.position();
      this.recordImpact(from, approach, touchdownSpeed);
   }

   private void flyRateMode(boolean grounded, float touchdownSpeed) {
      if (!this.attitudeReady) {
         this.attitudeFromYaw();
      }

      float fade = this.packFade();
      boolean piloted = this.isPiloted();
      double dtTicks = 0.125;
      double dtSeconds = dtTicks / 20.0;
      double maxRate = DroneTuning.get(DroneTuning.Value.INTERCEPTOR_ROLL_PITCH_RATE);
      double maxYawRate = DroneTuning.get(DroneTuning.Value.INTERCEPTOR_YAW_RATE);
      double expo = DroneTuning.get(DroneTuning.Value.INTERCEPTOR_EXPO);
      double topSpeedKmh = this.topSpeedKmh();
      double maxThrust = this.thrustToWeight() * 0.06;
      double flatOut = maxThrust * RateModeFlight.thrustAtAirspeed(topSpeedKmh, topSpeedKmh);
      double drag = Mth.clamp(1.0 - flatOut / Math.max(this.topSpeed(), 0.001), 0.8, 0.995);
      double dragPerStep = Math.pow(drag, dtTicks);
      double ground = RateModeFlight.groundEffect(this.heightAboveGround());
      Vector3f up = new Vector3f();

      for (int step = 0; step < 8; step++) {
         double demandPitchRaw;
         double demandYawRaw;
         double demandRollRaw;
         double throttle;
         if (piloted) {
            demandPitchRaw = RateModeFlight.actualRate((double)this.stickPitch(), 150.0, maxRate, expo);
            demandRollRaw = -RateModeFlight.actualRate((double)this.stickRoll(), 150.0, maxRate, expo);
            demandYawRaw = -RateModeFlight.actualRate((double)this.stickYaw(), 120.0, maxYawRate, expo);
            throttle = (double)this.stickThrottle();
         } else {
            demandPitchRaw = 0.0;
            demandRollRaw = 0.0;
            demandYawRaw = 0.0;
            throttle = (double)this.heldThrottle;
         }

         this.demandPitch = RateModeFlight.approach(this.demandPitch, demandPitchRaw, 138.23007675795088, dtSeconds);
         this.demandYaw = RateModeFlight.approach(this.demandYaw, demandYawRaw, 138.23007675795088, dtSeconds);
         this.demandRoll = RateModeFlight.approach(this.demandRoll, demandRollRaw, 138.23007675795088, dtSeconds);
         this.ratePitch = closeRate(this.ratePitch, this.demandPitch * (double)fade, 5.5 * this.agility(), dtSeconds);
         this.rateYaw = closeRate(this.rateYaw, this.demandYaw * (double)fade, 3.0 * this.agility(), dtSeconds);
         this.rateRoll = closeRate(this.rateRoll, this.demandRoll * (double)fade, 5.5 * this.agility(), dtSeconds);
         this.turnAirframe(dtSeconds);
         this.attitude.transform(0.0F, 1.0F, 0.0F, up);
         Vec3 lift = new Vec3((double)up.x(), (double)up.y(), (double)up.z());
         Vec3 velocity = this.getDeltaMovement();
         double climbKmh = velocity.dot(lift) * 72.0;
         double thrust = maxThrust * throttle * (double)fade * ground * RateModeFlight.thrustAtAirspeed(climbKmh, topSpeedKmh);
         velocity = velocity.add(lift.scale(thrust * dtTicks)).subtract(0.0, 0.06 * dtTicks, 0.0);
         velocity = velocity.scale(dragPerStep);
         double idle = 1.0 - throttle;
         double brake = 0.09 * idle * idle;
         if (brake > 0.0) {
            double along = velocity.dot(lift);
            velocity = velocity.subtract(lift.scale(along * (1.0 - Math.pow(1.0 - brake, dtTicks))));
         }

         this.setDeltaMovement(velocity);
      }

      if (grounded) {
         Vec3 velocity = this.getDeltaMovement();
         this.setDeltaMovement(velocity.x * 0.8, Math.max(velocity.y, 0.0), velocity.z * 0.8);
         this.settleUpright();
      }

      double cap = this.topSpeed();
      Vec3 capped = this.getDeltaMovement();
      if (cap > 0.0) {
         double horizontal = capped.horizontalDistance();
         if (horizontal > cap) {
            capped = new Vec3(capped.x * cap / horizontal, capped.y, capped.z * cap / horizontal);
         }

         capped = new Vec3(capped.x, Mth.clamp(capped.y, -cap, cap), capped.z);
      }

      if (capped.lengthSqr() < 1.0E-7) {
         capped = Vec3.ZERO;
      }

      this.setDeltaMovement(capped);
      this.publishAttitude();
      Vec3 approach = this.getDeltaMovement();
      Vec3 from = this.position();
      this.recordImpact(from, approach, touchdownSpeed);
   }

   private void flyPlane(boolean grounded, float touchdownSpeed, boolean powered) {
      if (!this.attitudeReady) {
         this.attitudeFromYaw();
      }

      float fade = this.packFade();
      boolean piloted = this.isPiloted();
      double dtTicks = 0.125;
      double dtSeconds = dtTicks / 20.0;
      double topSpeed = Math.max(0.001, this.topSpeed());
      double cruise = topSpeed * 0.55;
      double liftCoef = 0.06 / (cruise * cruise);
      double maxThrust = 0.18;
      double ground = RateModeFlight.groundEffect(this.heightAboveGround());
      double throttleTarget = !powered ? 0.0 : Math.max(0.12, piloted ? (double)this.stickThrottle() : (double)this.heldThrottle);
      this.planeThrottle = this.planeThrottle + (throttleTarget - this.planeThrottle) * 0.13;

      for (int step = 0; step < 8; step++) {
         double speed = this.getDeltaMovement().length();
         double authority = Mth.clamp(speed / (cruise * 0.6), 0.12, 1.0);
         float[] angles = this.attitudeAngles();
         double pitchDemand;
         double rollDemand;
         double yawDemand;
         if (piloted) {
            pitchDemand = 70.0 * (double)this.stickPitch() * authority;
            rollDemand = -160.0 * (double)this.stickRoll() * authority;
            yawDemand = -22.0 * (double)this.stickYaw() * authority;
            if (powered && Math.abs(this.stickRoll()) < 0.05F) {
               rollDemand += (double)RateModeFlight.cameraRoll(angles[2]) * 1.6 * authority;
            }
         } else {
            pitchDemand = 0.0;
            rollDemand = 0.0;
            yawDemand = 0.0;
         }

         double bank = (double)(RateModeFlight.cameraRoll(angles[2]) * 0.017453292F);
         double turnSpeed = Math.max(speed, cruise * 0.5);
         double coordinated = 0.06 * Math.tan((double)Mth.clamp((float)bank, -1.4F, 1.4F)) / turnSpeed * 20.0 * 57.2957763671875;
         yawDemand -= coordinated;
         this.ratePitch = closeRate(this.ratePitch, pitchDemand * (double)fade, 7.0, dtSeconds);
         this.rateRoll = closeRate(this.rateRoll, rollDemand * (double)fade, 7.0, dtSeconds);
         this.rateYaw = closeRate(this.rateYaw, yawDemand, 4.0, dtSeconds);
         this.turnAirframe(dtSeconds);
      }

      Vector3f up = this.attitude.transform(0.0F, 1.0F, 0.0F, new Vector3f());
      Vector3f noseF = this.attitude.transform(0.0F, 0.0F, -1.0F, new Vector3f());
      Vector3f rightF = this.attitude.transform(1.0F, 0.0F, 0.0F, new Vector3f());
      Vec3 upV = new Vec3((double)up.x(), (double)up.y(), (double)up.z());
      Vec3 noseV = new Vec3((double)noseF.x(), (double)noseF.y(), (double)noseF.z());
      Vec3 rightV = new Vec3((double)rightF.x(), (double)rightF.y(), (double)rightF.z());
      Vec3 velocity = this.getDeltaMovement();
      double speed = velocity.length();
      double liftScale;
      if (powered) {
         liftScale = 1.0;
      } else {
         double spent = (this.glideRun - 250.0) / 30.0;
         liftScale = 0.88 * (1.0 - Mth.clamp(spent, 0.0, 1.0));
      }

      velocity = velocity.add(noseV.scale(maxThrust * this.planeThrottle * (double)fade));
      velocity = velocity.add(upV.scale(liftCoef * speed * speed * ground * liftScale));
      velocity = velocity.subtract(0.0, 0.06, 0.0);
      double vForward = velocity.dot(noseV);
      double vSide = velocity.dot(rightV);
      double vUp = velocity.dot(upV);
      double drag = powered ? Mth.clamp(0.994 - this.dragPerBlock() * Math.abs(vForward), 0.9, 0.999) : 0.992;
      vForward *= drag;
      vSide *= 0.55;
      vUp *= 0.8;
      velocity = noseV.scale(vForward).add(rightV.scale(vSide)).add(upV.scale(vUp));
      if (grounded) {
         double rotate = cruise * 0.92;
         double vy = velocity.horizontalDistance() >= rotate ? Math.max(velocity.y, 0.0) : 0.0;
         velocity = new Vec3(velocity.x * 0.99, vy, velocity.z * 0.99);
         this.settleUpright();
      }

      double horizontal = velocity.horizontalDistance();
      if (horizontal > topSpeed) {
         velocity = new Vec3(velocity.x * topSpeed / horizontal, velocity.y, velocity.z * topSpeed / horizontal);
      }

      velocity = new Vec3(velocity.x, Mth.clamp(velocity.y, -topSpeed, topSpeed), velocity.z);
      if (velocity.lengthSqr() < 1.0E-7) {
         velocity = Vec3.ZERO;
      }

      this.setDeltaMovement(velocity);
      if (!powered) {
         this.glideRun = this.glideRun + velocity.horizontalDistance();
      }

      this.publishAttitude();
      Vec3 approach = this.getDeltaMovement();
      Vec3 from = this.position();
      this.recordImpact(from, approach, 0.0F);
   }

   @Override
   protected void recordImpact(Vec3 from, Vec3 approach, float touchdownSpeed) {
      this.impactFrom = from;
      super.recordImpact(from, approach, touchdownSpeed);
   }

   @Override
   protected float impactSpeed(Vec3 approach, DroneEntity.Ram ram) {
      if (this.noseFused() && ram == null && (this.horizontalCollision || this.verticalCollision) && this.impactFrom != null) {
         Vec3 blocked = approach.subtract(this.position().subtract(this.impactFrom));
         Vector3f nose = this.attitude.transform(0.0F, 0.0F, -1.0F, new Vector3f());
         double intoNose = blocked.x * (double)nose.x() + blocked.y * (double)nose.y() + blocked.z * (double)nose.z();
         if (intoNose >= 0.05) {
            return Math.nextUp((float)Math.max(approach.length(), this.crashSpeed()));
         }
      }

      return this.fliesAsAircraft() && ram == null && !this.horizontalCollision && this.verticalCollision
         ? (float)Math.abs(approach.y)
         : super.impactSpeed(approach, ram);
   }

   private double dragPerBlock() {
      double top = Math.max(0.001, this.topSpeed());
      double net = 0.18 - 0.006 * top;
      return Math.max(1.0E-4, net / (top * top));
   }

   @Override
   public Quaternionfc linkAttitude() {
      return this.attitude;
   }

   @Override
   protected void readAdditionalSaveData(CompoundTag tag) {
      super.readAdditionalSaveData(tag);
      this.entityData.set(DATA_RAIL_SEATED, tag.getBoolean("RailSeated"));
      this.entityData.set(DATA_RAIL_PITCH, tag.getFloat("RailPitch"));
      this.heldThrottle = tag.getFloat("HeldThrottle");
   }

   @Override
   protected void addAdditionalSaveData(CompoundTag tag) {
      super.addAdditionalSaveData(tag);
      tag.putBoolean("RailSeated", this.isRailSeated());
      tag.putFloat("RailPitch", (Float)this.entityData.get(DATA_RAIL_PITCH));
      tag.putFloat("HeldThrottle", this.heldThrottle);
   }

   @Override
   public void captureFlightState(DroneFlightState out) {
      super.captureFlightState(out);
      out.airframe = true;
      out.attitudeReady = this.attitudeReady;
      out.attitude.set(this.attitude);
      out.ratePitch = this.ratePitch;
      out.rateYaw = this.rateYaw;
      out.rateRoll = this.rateRoll;
      out.demandPitch = this.demandPitch;
      out.demandYaw = this.demandYaw;
      out.demandRoll = this.demandRoll;
      out.holdX = this.holdX;
      out.holdY = this.holdY;
      out.holdZ = this.holdZ;
      out.lastVerticalDir = this.lastVerticalDir;
      out.leanRateX = this.leanRateX;
      out.leanRateZ = this.leanRateZ;
      out.power = this.power;
      out.planeThrottle = this.planeThrottle;
      out.glideRun = this.glideRun;
      out.railSeated = this.isRailSeated();
      out.railPitch = (Float)this.entityData.get(DATA_RAIL_PITCH);
   }

   @Override
   public void restoreFlightState(DroneFlightState state) {
      super.restoreFlightState(state);
      if (state.airframe) {
         this.attitudeReady = state.attitudeReady;
         this.attitude.set(state.attitude);
         this.ratePitch = state.ratePitch;
         this.rateYaw = state.rateYaw;
         this.rateRoll = state.rateRoll;
         this.demandPitch = state.demandPitch;
         this.demandYaw = state.demandYaw;
         this.demandRoll = state.demandRoll;
         this.holdX = state.holdX;
         this.holdY = state.holdY;
         this.holdZ = state.holdZ;
         this.lastVerticalDir = state.lastVerticalDir;
         this.leanRateX = state.leanRateX;
         this.leanRateZ = state.leanRateZ;
         this.power = state.power;
         this.planeThrottle = state.planeThrottle;
         this.glideRun = state.glideRun;
         this.entityData.set(DATA_RAIL_SEATED, state.railSeated);
         this.entityData.set(DATA_RAIL_PITCH, state.railPitch);
      }
   }

   public void presentPredictedAttitude(Quaternionfc correction, float shownYaw, float shownPitch) {
      this.clientNoseOld = this.clientNose;
      this.clientBankOld = this.clientBank;
      boolean first = !this.clientAttitudeShown;
      this.clientAttitudeOld.set(this.clientAttitude);
      this.clientAttitude.set(correction).mul(this.attitude).normalize();
      if (first) {
         this.clientAttitudeOld.set(this.clientAttitude);
         this.clientAttitudeShown = true;
      }

      float[] angles = anglesOf(this.clientAttitude);
      this.clientNose = angles[1];
      this.clientBank = angles[2];
      this.yRotO = shownYaw;
      this.xRotO = shownPitch;
      this.setYRot(shownYaw + Mth.wrapDegrees(angles[0] - shownYaw));
      this.setXRot(Mth.clamp(-angles[1], -90.0F, 90.0F));
   }

   @Override
   public void settleInterpolation() {
      super.settleInterpolation();
      this.clientAttitudeOld.set(this.clientAttitude);
      this.clientNoseOld = this.clientNose;
      this.clientBankOld = this.clientBank;
   }

   public Quaternionfc flightAttitude() {
      return this.attitude;
   }

   private void attitudeFromYaw() {
      this.attitude.identity().rotateY((180.0F - this.getYRot()) * 0.017453292F);
      this.ratePitch = 0.0;
      this.rateYaw = 0.0;
      this.rateRoll = 0.0;
      this.demandPitch = 0.0;
      this.demandYaw = 0.0;
      this.demandRoll = 0.0;
      this.attitudeReady = true;
   }

   private static double closeRate(double current, double demand, double response, double dtSeconds) {
      double next = RateModeFlight.approach(current, demand, response, dtSeconds);
      return Mth.clamp(next, -1200.0, 1200.0);
   }

   private void turnAirframe(double dtSeconds) {
      double pitch = this.ratePitch * dtSeconds;
      double yaw = this.rateYaw * dtSeconds;
      double roll = this.rateRoll * dtSeconds;
      double magnitude = Math.sqrt(pitch * pitch + yaw * yaw + roll * roll);
      if (!(magnitude < 1.0E-7)) {
         this.attitude.rotateAxis((float)(magnitude * 0.01745329238474369), (float)(pitch / magnitude), (float)(yaw / magnitude), (float)(roll / magnitude));
         this.attitude.normalize();
      }
   }

   private void settleUpright() {
      float[] angles = this.attitudeAngles();
      this.attitude.identity().rotateY((180.0F - angles[0]) * 0.017453292F).rotateX(angles[1] * 0.65F * 0.017453292F).rotateZ(angles[2] * 0.65F * 0.017453292F);
      this.ratePitch = 0.0;
      this.rateRoll = 0.0;
   }

   private double heightAboveGround() {
      Vec3 from = this.position();
      Vec3 to = from.subtract(0.0, 1.2, 0.0);
      BlockHitResult hit = this.level().clip(new ClipContext(from, to, Block.COLLIDER, Fluid.NONE, this));
      return hit.getType() == Type.MISS ? 1.2 : Math.max(0.0, from.y - hit.getLocation().y);
   }

   private float[] attitudeAngles() {
      return anglesOf(this.attitude);
   }

   @Override
   protected boolean fallsLikeAPlane() {
      return this.fliesAsAircraft();
   }

   @Override
   protected Quaternionf wreckStartAttitude() {
      return this.attitudeReady ? new Quaternionf(this.attitude) : super.wreckStartAttitude();
   }

   @Override
   protected float wreckStartRoll() {
      return this.attitudeReady ? this.attitudeAngles()[2] : 0.0F;
   }

   private static float[] anglesOf(Quaternionfc rotation) {
      Vector3f euler = rotation.getEulerAnglesYXZ(new Vector3f());
      return new float[]{Mth.wrapDegrees(180.0F - euler.y() * 57.295776F), euler.x() * 57.295776F, euler.z() * 57.295776F};
   }

   private void publishAttitude() {
      float[] angles = this.attitudeAngles();
      this.setYRot(angles[0]);
      this.setXRot(Mth.clamp(-angles[1], -90.0F, 90.0F));
      if (!this.level().isClientSide) {
         this.entityData.set(DATA_ATTITUDE, new Quaternionf(this.attitude), this.tickCount % 20 == 0);
      }
   }

   public void adoptAttitudeFrom(InterceptorDroneEntity previous) {
      this.attitude.set(previous.attitude);
      this.clientAttitude.set(previous.clientAttitude);
      this.clientAttitudeOld.set(previous.clientAttitudeOld);
      this.clientNose = previous.clientNose;
      this.clientNoseOld = previous.clientNoseOld;
      this.clientBank = previous.clientBank;
      this.clientBankOld = previous.clientBankOld;
      this.clientAttitudeShown = previous.clientAttitudeShown;
      this.attitudeReady = previous.attitudeReady;
   }

   private void readAttitude() {
      this.attitude.set((Quaternionfc)this.entityData.get(DATA_ATTITUDE));
      this.shiftClientAttitude();
   }

   private void shiftClientAttitude() {
      this.clientAttitudeOld.set(this.clientAttitudeShown ? this.clientAttitude : this.attitude);
      this.clientAttitude.set(this.attitude);
      this.clientAttitudeShown = true;
      float[] angles = this.attitudeAngles();
      this.clientNose = angles[1];
      this.clientBank = angles[2];
      float yaw = this.getYRot() + Mth.wrapDegrees(angles[0] - this.getYRot());
      this.yRotO = this.getYRot();
      this.xRotO = this.getXRot();
      this.setYRot(yaw);
      this.setXRot(Mth.clamp(-angles[1], -90.0F, 90.0F));
   }

   public float[] attitudeAngles(float partialTick) {
      if (this.level().isClientSide && this.rateMode()) {
         Vector3f euler = this.blendedAttitude(partialTick).getEulerAnglesYXZ(new Vector3f());
         return new float[]{Mth.wrapDegrees(180.0F - euler.y() * 57.295776F), euler.x() * 57.295776F, euler.z() * 57.295776F};
      } else {
         return this.attitudeAngles();
      }
   }

   @Nullable
   @Override
   public Quaternionf renderRotation(float partialTick) {
      return this.rateMode() && !this.isWrecked() ? new Quaternionf(this.level().isClientSide ? this.blendedAttitude(partialTick) : this.attitude) : null;
   }

   public float[] cameraAngles(float partialTick, float mountTilt) {
      return RateModeFlight.cameraAnglesOf(this.level().isClientSide ? this.blendedAttitude(partialTick) : this.attitude, mountTilt);
   }

   private Quaternionf blendedAttitude(float partialTick) {
      this.clientAttitudeOld.slerp(this.clientAttitude, Mth.clamp(partialTick, 0.0F, 1.0F), this.clientBlend);
      return this.clientBlend.normalize();
   }

   private static float climbAuthority(float fade) {
      double best = 0.12000000476837158;
      double full = best - 0.06;
      return full <= 0.0 ? 0.0F : (float)Mth.clamp((best * (double)fade - 0.06) / full, 0.0, 1.0);
   }

   public float packFade() {
      return FpvPack.powerFade(FpvPack.openCircuitCellVolts(this.getCharge()));
   }

   @Override
   public float propTargetRate() {
      if (this.motorsDead()) {
         return 0.0F;
      } else {
         double topSpeed = Math.max(1.0, this.topSpeedKmh());
         double speedKmh = this.getDeltaMovement().length() * 72.0;
         float drive = (float)Mth.clamp(Math.max(speedKmh / topSpeed, (double)this.inputLoad()), 0.0, 1.0);
         return Mth.lerp(drive, 28.0F, 100.0F);
      }
   }

   @Override
   public float bodyPitch(float partialTick) {
      if (!this.level().isClientSide) {
         return this.rateMode() ? this.attitudeAngles()[1] : -this.tiltFromTravel(true);
      } else {
         return this.rateMode() ? this.attitudeAngles(partialTick)[1] : -Mth.lerp(partialTick, this.clientNoseOld, this.clientNose);
      }
   }

   @Override
   public float bodyRoll(float partialTick) {
      if (!this.level().isClientSide) {
         return this.rateMode() ? this.attitudeAngles()[2] : this.tiltFromTravel(false);
      } else {
         return this.rateMode() ? this.attitudeAngles(partialTick)[2] : Mth.lerp(partialTick, this.clientBankOld, this.clientBank);
      }
   }

   private float tiltFromTravel(boolean alongNose) {
      Vec3 velocity = this.getDeltaMovement();
      float yawRad = this.getYRot() * 0.017453292F;
      double sin = (double)Mth.sin(yawRad);
      double cos = (double)Mth.cos(yawRad);
      double along = alongNose ? -velocity.x * sin + velocity.z * cos : velocity.x * cos + velocity.z * sin;
      float max = alongNose ? 78.0F : 30.0F;
      double cap = Math.max(this.topSpeed(), 0.001);
      return (float)Mth.clamp(along / cap * (double)max, (double)(-max), (double)max);
   }

   @Override
   public void selfDestruct(@Nullable Entity by) {
      this.destroyNow(by);
   }

   @Override
   protected void goOff(ServerLevel level, @Nullable Entity attacker) {
      GrenadeAttachments.detonateWarhead(
         level, this.position(), this, attacker, this.warheadBlast(), this.warheadVehicleDamage(), this.warheadVehicleRadius(), 2
      );
   }

   protected float warheadBlast() {
      return (float)((Double)SkyfrontConfig.INTERCEPTOR_BLAST.get()).doubleValue();
   }

   protected float warheadVehicleDamage() {
      return (float)((Double)SkyfrontConfig.INTERCEPTOR_VEHICLE_DAMAGE.get()).doubleValue();
   }

   protected float warheadVehicleRadius() {
      return (float)((Double)SkyfrontConfig.INTERCEPTOR_VEHICLE_RADIUS.get()).doubleValue();
   }
}
