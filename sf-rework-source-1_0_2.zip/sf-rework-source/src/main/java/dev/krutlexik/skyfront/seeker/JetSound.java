package dev.krutlexik.skyfront.seeker;

import dev.krutlexik.skyfront.client.ClientViewpoint;
import dev.krutlexik.skyfront.entity.ShahedEntity;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.world.phys.Vec3;

public final class JetSound {
   private static final Map<Integer, JetSound.State> STATES = new HashMap<>();

   private JetSound() {
   }

   public static float maxDistance(ShahedEntity var0) {
      return SeekerHooks.is238(var0) ? 380.0F : 150.0F;
   }

   public static float shape(float var0, ShahedEntity var1) {
      if (!SeekerHooks.is238(var1)) {
         return var0;
      } else {
         int var2 = var1.getId();
         if (var1.isRemoved()) {
            STATES.remove(var2);
            return var0;
         } else {
            JetSound.State var3 = STATES.get(var2);
            if (var3 == null) {
               var3 = new JetSound.State();
               STATES.put(var2, var3);
            }

            tickFlyby(var3, var1);
            return var0 * var3.duck;
         }
      }
   }

   private static void tickFlyby(JetSound.State var0, ShahedEntity var1) {
      Vec3 var2 = ClientViewpoint.position();
      Vec3 var3 = var1.getDeltaMovement();
      Vec3 var4 = var1.position().subtract(var2);
      double var5 = var3.lengthSqr();
      double var7 = var5 > 1.0E-6 && !var1.getIsFalling() ? -var4.dot(var3) / var5 : -1.0;
      double var9 = var7 > 0.0 ? var4.add(var3.scale(var7)).length() : var4.length();
      boolean var11 = var0.flyby == null || var0.flyby.finished();
      JetFlyby.Variant var12 = var11 && var7 > 0.0 && var9 < 150.0 ? JetFlyby.Variant.startingAt(var7) : null;
      if (var12 != null) {
         float var13 = (float)Math.max(0.55, Math.min(1.0, 60.0 / Math.max(var9, 1.0)));
         var0.flyby = new JetFlyby(var12, () -> var1.position(), var13, var9 < 80.0);
         JetFlyby.startSoon(var0.flyby);
      } else if (!var11 && var0.flyby.age() < var0.flyby.lead() && var9 > 375.0) {
         var0.flyby.fadeOut();
      }

      boolean var14 = var0.flyby != null && var0.flyby.playing();
      var0.duck = approach(var0.duck, var14 ? 0.1F : 1.0F, var14 ? 0.05F : 0.02F);
   }

   private static float approach(float var0, float var1, float var2) {
      return var0 < var1 ? Math.min(var1, var0 + var2) : Math.max(var1, var0 - var2);
   }

   private static final class State {
      JetFlyby flyby;
      float duck = 1.0F;

      private State() {
      }
   }
}
