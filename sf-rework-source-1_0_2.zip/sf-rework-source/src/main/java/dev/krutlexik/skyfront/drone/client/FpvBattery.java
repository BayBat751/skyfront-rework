package dev.krutlexik.skyfront.drone.client;

import dev.krutlexik.skyfront.config.SkyfrontConfig;
import dev.krutlexik.skyfront.drone.FpvPack;
import dev.krutlexik.skyfront.drone.entity.DroneEntity;
import dev.krutlexik.skyfront.drone.entity.InterceptorDroneEntity;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.util.Mth;
import org.jetbrains.annotations.Nullable;

public final class FpvBattery {
   private static final double CELL_RESISTANCE = 0.006;
   private static final double IDLE_CURRENT = 1.5;
   private static final double DISARMED_CURRENT = 0.4;
   private static final double HOVER_LOAD = 0.35;
   private static final double STICK_LOAD = 0.5;
   private static final double SPEED_LOAD = 0.25;
   private static final double LOAD_RESPONSE = 0.25;
   private static final double SAG_FALL = 0.45;
   private static final double SAG_RECOVER = 0.12;
   private static boolean armed;
   private static final Map<UUID, Long> ARMED_AT = new HashMap<>();
   private static final Map<UUID, Integer> STOPPED_AT = new HashMap<>();
   @Nullable
   private static DroneEntity reading;
   private static double load;
   private static double voltage;

   public static void arm(DroneEntity drone) {
      armed = true;
      reading = drone;
      load = 0.0;
      voltage = openCircuitVolts(drone.getCharge());
      ARMED_AT.putIfAbsent(drone.getUUID(), drone.level().getGameTime());
   }

   public static void armedNow(DroneEntity drone) {
      STOPPED_AT.remove(drone.getUUID());
      ARMED_AT.put(drone.getUUID(), drone.level().getGameTime());
      arm(drone);
   }

   public static void disarm(DroneEntity drone) {
      armed = false;
      reading = drone;
      load = 0.0;
      Long since = ARMED_AT.remove(drone.getUUID());
      if (since != null) {
         STOPPED_AT.put(drone.getUUID(), (int)((drone.level().getGameTime() - since) / 20L));
      }

      if (voltage <= 0.0) {
         voltage = openCircuitVolts(drone.getCharge()) - sagVolts();
      }
   }

   public static void reset() {
      armed = false;
      reading = null;
      load = 0.0;
      voltage = 0.0;
   }

   public static void rest(DroneEntity drone) {
      double target = openCircuitVolts(drone.getCharge()) - sagVolts();
      voltage = voltage + (target - voltage) * 0.12;
   }

   public static boolean isArmed() {
      return armed;
   }

   public static int armedSeconds() {
      DroneEntity drone = reading;
      if (drone == null) {
         return 0;
      } else {
         Long since = ARMED_AT.get(drone.getUUID());
         return since != null ? (int)Math.max(0L, (drone.level().getGameTime() - since) / 20L) : STOPPED_AT.getOrDefault(drone.getUUID(), 0);
      }
   }

   public static void tick(DroneEntity drone) {
      if (!armed) {
         arm(drone);
      }

      double speedKmh = drone.getDeltaMovement().length() * 72.0;
      double demand = drone.isGrounded() ? 0.0 : 0.35 + 0.5 * (double)drone.inputLoad() + 0.25 * Math.min(1.0, speedKmh / Math.max(1.0, topSpeedKmh(drone)));
      load = load + (Mth.clamp(demand, 0.0, 1.0) - load) * 0.25;
      double target = openCircuitVolts(drone.getCharge()) - sagVolts();
      double response = target < voltage ? 0.45 : 0.12;
      voltage = voltage + (target - voltage) * response;
   }

   public static int cells() {
      return (Integer)SkyfrontConfig.INTERCEPTOR_BATTERY_CELLS.get();
   }

   public static double packVolts() {
      return voltage;
   }

   public static double cellVolts() {
      return voltage / (double)Math.max(1, cells());
   }

   public static double amps() {
      return armed ? 1.5 + load * (Double)SkyfrontConfig.INTERCEPTOR_PEAK_CURRENT.get() : 0.4;
   }

   private static double topSpeedKmh(DroneEntity drone) {
      return drone instanceof InterceptorDroneEntity interceptor ? interceptor.topSpeedKmh() : (Double)SkyfrontConfig.INTERCEPTOR_TOP_SPEED.get();
   }

   public static int mahDrawn(DroneEntity drone) {
      return Math.round((1.0F - drone.getCharge()) * (float)((Integer)SkyfrontConfig.INTERCEPTOR_BATTERY_MAH.get()).intValue());
   }

   private static double openCircuitVolts(float charge) {
      return FpvPack.openCircuitCellVolts(charge) * (double)cells();
   }

   private static double sagVolts() {
      return amps() * 0.006 * (double)cells();
   }

   private FpvBattery() {
   }
}
