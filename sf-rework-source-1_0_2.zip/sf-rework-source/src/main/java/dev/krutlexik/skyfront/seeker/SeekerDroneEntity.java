package dev.krutlexik.skyfront.seeker;

import dev.krutlexik.skyfront.drone.GrenadeAttachments;
import dev.krutlexik.skyfront.drone.entity.MolniyaDroneEntity;
import dev.krutlexik.skyfront.entity.DebrisEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;

public class SeekerDroneEntity extends MolniyaDroneEntity {
   public SeekerDroneEntity(EntityType<? extends SeekerDroneEntity> var1, Level var2) {
      super(var1, var2);
   }

   @Override
   public double topSpeedKmh() {
      return 259.2;
   }

   @Override
   public double controlRange() {
      return Math.max(super.controlRange(), 4000.0);
   }

   @Override
   public int fullFlightTicks() {
      return 72000;
   }

   @Override
   public ItemStack packedItem() {
      return new ItemStack((ItemLike)SeekerRegistry.SEEKER_ITEM.get());
   }

   protected DebrisEntity.Airframe debrisFrame() {
      return DebrisEntity.Airframe.SHAHED;
   }

   @Override
   protected void goOff(ServerLevel var1, @Nullable Entity var2) {
      GrenadeAttachments.detonateWarhead(var1, this.position(), this, var2, this.warheadBlast(), this.warheadVehicleDamage(), this.warheadVehicleRadius(), 2);
      Quaternionf var3 = this.renderRotation(1.0F);
      if (var3 == null) {
         var3 = new Quaternionf().rotationY((180.0F - this.getYRot()) * 0.017453292F);
      }

      DebrisEntity.burst(var1, this.debrisFrame(), this.position(), new Quaternionf(var3).rotateY(3.1415927F), this.getDeltaMovement());
   }
}
