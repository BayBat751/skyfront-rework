package dev.krutlexik.skyfront.config;

import com.electronwill.nightconfig.core.UnmodifiableConfig;
import com.electronwill.nightconfig.core.file.CommentedFileConfig;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import net.neoforged.fml.loading.FMLPaths;
import net.neoforged.neoforge.common.ModConfigSpec;
import net.neoforged.neoforge.common.ModConfigSpec.BooleanValue;
import net.neoforged.neoforge.common.ModConfigSpec.Builder;
import net.neoforged.neoforge.common.ModConfigSpec.ConfigValue;
import net.neoforged.neoforge.common.ModConfigSpec.DoubleValue;
import net.neoforged.neoforge.common.ModConfigSpec.IntValue;
import net.neoforged.neoforge.common.ModConfigSpec.ValueSpec;

public class SkyfrontConfig {
   public static final String FILE_NAME = "skyfront-common.toml";
   private static final Builder BUILDER = new Builder();
   public static final ModConfigSpec SPEC = BUILDER.build();
   public static final BooleanValue BLACKLIST_ENABLED = BUILDER.comment("Forbid Shahed targets inside the forbidden zones.").define("blacklistEnabled", false);
   public static final ConfigValue<List<? extends String>> FORBIDDEN_ZONES = BUILDER.comment("Forbidden zones, each \"x1,z1,x2,z2\" (two opposite corners).")
      .defineListAllowEmpty("forbiddenZones", List.of(), () -> "0,0,100,100", SkyfrontConfig::isZone);
   public static final BooleanValue WHITELIST_ENABLED = BUILDER.comment("Allow Shahed targets only inside the allowed zones.")
      .define("whitelistEnabled", false);
   public static final ConfigValue<List<? extends String>> ALLOWED_ZONES = BUILDER.comment("Allowed zones, each \"x1,z1,x2,z2\" (two opposite corners).")
      .defineListAllowEmpty("allowedZones", List.of(), () -> "0,0,100,100", SkyfrontConfig::isZone);
   public static final BooleanValue EXPLOSION_PARTICLES_ENABLED = BUILDER.comment("Shahed explosion particles. Decided by the server for every player.")
      .define("particles", true);
   public static final IntValue EXPLOSION_PARTICLE_MULTIPLIER = BUILDER.comment("Amount of explosion particles, percent (100 = default).")
      .defineInRange("particleMultiplier", 100, 0, 500);
   public static final BooleanValue EXPLOSION_BREAKS_BLOCKS = BUILDER.comment("Whether Shahed, drone warheads and drone ordnance break blocks.")
      .define("breakBlocks", true);
   public static final BooleanValue CUSTOM_EXPLOSION_SOUNDS = BUILDER.comment(
         "Shahed explosion sounds, delayed by distance. Decided by the server for every player."
      )
      .define("customSounds", true);
   public static final DoubleValue SHAHED_HEALTH = BUILDER.comment("Shahed hit points. At zero it is shot down.").defineInRange("health", 40.0, 1.0, 10000.0);
   public static final IntValue MAX_FLIGHT_RANGE = BUILDER.comment(
         "Farthest a Shahed may fly from its launch point, blocks. Also the reach of the terminal map."
      )
      .defineInRange("maxFlightRange", 2000, 100, 30000);
   public static final IntValue MAX_ROUTE_WAYPOINTS = BUILDER.comment("Most waypoints in one route (at most 15).")
      .defineInRange("maxRouteWaypoints", 15, 1, 15);
   public static final IntValue MIN_WAYPOINT_DISTANCE = BUILDER.comment("Least distance between consecutive waypoints, blocks.")
      .defineInRange("minWaypointDistance", 50, 50, 1000);
   public static final IntValue MIN_LAUNCH_DISTANCE = BUILDER.comment("Least distance of any waypoint from the launch point, blocks.")
      .defineInRange("minLaunchDistance", 100, 0, 2000);
   public static final IntValue MAX_ALTITUDE = BUILDER.comment("Highest cruise altitude (Y) a Shahed may be ordered to (at least 70).")
      .defineInRange("maxAltitude", 320, 70, 1000);
   public static final IntValue RADAR_DETECT_RANGE = BUILDER.comment("Radius in which the radar shows drones, blocks.")
      .defineInRange("detectRange", 1000, 50, 30000);
   public static final IntValue SIREN_RANGE = BUILDER.comment("Distance the air-raid siren can be heard, blocks.").defineInRange("range", 100, 8, 2000);
   public static final IntValue DRONE_CHUNK_RADIUS = BUILDER.comment(
         new String[]{
            "Chunks loaded and streamed around a drone flown beyond its pilot's own view, radius.",
            "Applies per flying drone: this is the main chunk cost on a busy server."
         }
      )
      .defineInRange("longRangeChunkRadius", 4, 2, 12);
   public static final IntValue DRONE_AIRBURST_CHANCE = BUILDER.comment(
         "Chance, percent, that ordnance under a drone goes off in the air when the drone is shot down."
      )
      .defineInRange("airburstChance", 35, 0, 100);
   public static final DoubleValue DRONE_RAM_DAMAGE = BUILDER.comment("Damage a drone deals to what it rams, before any ordnance it carries goes off.")
      .defineInRange("ramDamage", 60.0, 0.0, 100000.0);
   public static final IntValue MAVIC_FLIGHT_SECONDS = BUILDER.comment("Battery life, seconds in the air.").defineInRange("flightSeconds", 300, 10, 36000);
   public static final IntValue MAVIC_CONTROL_RANGE = BUILDER.comment("Control range, blocks.").defineInRange("controlRange", 2000, 16, 4000);
   public static final DoubleValue MAVIC_CRASH_SPEED = BUILDER.comment("Impact speed that destroys it, km/h.").defineInRange("crashSpeed", 45.0, 1.0, 1000.0);
   public static final DoubleValue MAVIC_MAX_DESCENT_SPEED = BUILDER.comment("Fastest powered descent, km/h. Keep it below crashSpeed.")
      .defineInRange("maxDescentSpeed", 43.0, 1.0, 1000.0);
   public static final DoubleValue MAVIC_MAX_ZOOM = BUILDER.comment("Largest camera zoom.").defineInRange("maxZoom", 8.0, 1.0, 64.0);
   public static final DoubleValue MAVIC_HITPOINTS = BUILDER.comment("Hit points.").defineInRange("hitpoints", 6.0, 1.0, 10000.0);
   public static final DoubleValue MAVIC_LOOK_SENSITIVITY = BUILDER.comment("Gimbal speed against the player's mouse sensitivity.")
      .defineInRange("lookSensitivity", 0.3, 0.05, 2.0);
   public static final IntValue MAVIC_3T_FLIGHT_SECONDS = BUILDER.comment("Battery life, seconds in the air.").defineInRange("flightSeconds", 480, 10, 36000);
   public static final IntValue MAVIC_3T_CONTROL_RANGE = BUILDER.comment("Control range, blocks.").defineInRange("controlRange", 2000, 16, 4000);
   public static final DoubleValue MAVIC_3T_TOP_SPEED = BUILDER.comment("Top speed, km/h.").defineInRange("topSpeed", 95.0, 1.0, 1000.0);
   public static final IntValue INTERCEPTOR_FLIGHT_SECONDS = BUILDER.comment("Battery life, seconds in the air.")
      .defineInRange("flightSeconds", 180, 10, 36000);
   public static final IntValue INTERCEPTOR_CONTROL_RANGE = BUILDER.comment("Control range, blocks.").defineInRange("controlRange", 2000, 16, 4000);
   public static final DoubleValue INTERCEPTOR_CRASH_SPEED = BUILDER.comment("Impact speed against terrain that destroys it, km/h.")
      .defineInRange("crashSpeed", 70.0, 1.0, 1000.0);
   public static final DoubleValue INTERCEPTOR_LOOK_SENSITIVITY = BUILDER.comment(
         "How fast the airframe follows the mouse, against the player's mouse sensitivity."
      )
      .defineInRange("lookSensitivity", 0.9, 0.05, 2.0);
   public static final BooleanValue INTERCEPTOR_RATE_MODE = BUILDER.comment(
         new String[]{
            "Rate mode (acro): the sticks set a rate of turn and nothing levels the drone, as on a real FPV quad.",
            "Off: simplified flight where the drone levels itself and holds height."
         }
      )
      .define("rateMode", true);
   public static final DoubleValue INTERCEPTOR_ROLL_PITCH_RATE = BUILDER.comment("Rate mode: roll and pitch rate at full stick, degrees per second.")
      .defineInRange("rollPitchRate", 420.0, 60.0, 1400.0);
   public static final DoubleValue INTERCEPTOR_YAW_RATE = BUILDER.comment("Rate mode: yaw rate at full stick, degrees per second.")
      .defineInRange("yawRate", 300.0, 60.0, 1400.0);
   public static final DoubleValue INTERCEPTOR_EXPO = BUILDER.comment("Rate mode: expo, softens the middle of the stick travel.")
      .defineInRange("expo", 0.2, 0.0, 0.9);
   public static final DoubleValue INTERCEPTOR_MOUSE_GAIN = BUILDER.comment("Rate mode: how far the virtual stick moves for a given mouse movement.")
      .defineInRange("mouseGain", 1.0, 0.1, 4.0);
   public static final DoubleValue INTERCEPTOR_THRUST_TO_WEIGHT = BUILDER.comment("Rate mode: thrust-to-weight ratio at full throttle.")
      .defineInRange("thrustToWeight", 2.1, 1.1, 8.0);
   public static final IntValue INTERCEPTOR_BATTERY_CELLS = BUILDER.comment("Battery cells shown on the OSD.").defineInRange("batteryCells", 8, 1, 24);
   public static final IntValue INTERCEPTOR_BATTERY_MAH = BUILDER.comment("Battery capacity, mAh.").defineInRange("batteryMah", 3000, 100, 50000);
   public static final DoubleValue INTERCEPTOR_PEAK_CURRENT = BUILDER.comment("Current draw at full load, amps.")
      .defineInRange("peakCurrent", 60.0, 1.0, 500.0);
   public static final ConfigValue<String> INTERCEPTOR_CRAFT_NAME = BUILDER.comment("Craft name shown at the top of the OSD.").define("craftName", "P1SUN");
   public static final IntValue INTERCEPTOR_OSD_MAX_PITCH = BUILDER.comment("Pitch at which the OSD horizon reaches the edge of its travel, degrees.")
      .defineInRange("osdMaxPitch", 20, 5, 90);
   public static final IntValue INTERCEPTOR_OSD_MAX_ROLL = BUILDER.comment("Roll at which the OSD horizon reaches full tilt, degrees.")
      .defineInRange("osdMaxRoll", 40, 5, 90);
   public static final DoubleValue INTERCEPTOR_TOP_SPEED = BUILDER.comment("Top speed, km/h. Fixed in code at 591.09 (1.5x Shahed-238); this value is ignored.")
      .defineInRange("topSpeed", 591.09, 1.0, 1000.0);
   public static final DoubleValue INTERCEPTOR_HITPOINTS = BUILDER.comment("Hit points. Also used by the FPV drone.")
      .defineInRange("hitpoints", 4.0, 1.0, 10000.0);
   public static final DoubleValue INTERCEPTOR_BLAST = BUILDER.comment("Warhead explosion power (TNT is 4).").defineInRange("warheadBlast", 9.0, 0.0, 100.0);
   public static final DoubleValue INTERCEPTOR_VEHICLE_DAMAGE = BUILDER.comment("Warhead damage to Superb Warfare vehicles.")
      .defineInRange("warheadVehicleDamage", 300.0, 0.0, 100000.0);
   public static final DoubleValue INTERCEPTOR_VEHICLE_RADIUS = BUILDER.comment("Radius of that vehicle damage, blocks.")
      .defineInRange("warheadVehicleRadius", 10.0, 0.0, 100.0);
   public static final DoubleValue MOLNIYA_HITPOINTS = BUILDER.comment("Hit points.").defineInRange("hitpoints", 30.0, 1.0, 10000.0);
   public static final DoubleValue MOLNIYA_BLAST = BUILDER.comment("Warhead explosion power (TNT is 4): half again the P1-SUN's.")
      .defineInRange("warheadBlast", 13.5, 0.0, 100.0);
   public static final DoubleValue MOLNIYA_VEHICLE_DAMAGE = BUILDER.comment("Warhead damage to Superb Warfare vehicles.")
      .defineInRange("warheadVehicleDamage", 450.0, 0.0, 100000.0);
   public static final DoubleValue MOLNIYA_VEHICLE_RADIUS = BUILDER.comment("Radius of that vehicle damage, blocks.")
      .defineInRange("warheadVehicleRadius", 15.0, 0.0, 100.0);
   public static final BooleanValue MOLNIYA_WARHEAD_SHOT = BUILDER.comment(
         "A shot that strikes the warhead under the nose sets it off in the air, whatever hit points are left."
      )
      .define("warheadDetonatesWhenShot", true);
   public static final double KMH_PER_BLOCK_TICK = 72.0;
   public static final int WAYPOINT_HARD_CAP = 15;
   public static final int WAYPOINT_MIN_SPACING_FLOOR = 50;
   public static final int MIN_ALTITUDE = 70;

   public SkyfrontConfig() {
   }

   private static boolean isZone(Object value) {
      if (value instanceof String text && SkyfrontConfig.ForbiddenZone.parse(text) != null) {
         return true;
      }

      return false;
   }

   public static int getMaxWaypoints() {
      return Math.min((Integer)MAX_ROUTE_WAYPOINTS.get(), 15);
   }

   public static int getMinWaypointDistance() {
      return Math.max((Integer)MIN_WAYPOINT_DISTANCE.get(), 50);
   }

   public static int getMaxAltitude() {
      return Math.max((Integer)MAX_ALTITUDE.get(), 70);
   }

   public static boolean isInForbiddenZone(int x, int z) {
      return isBlocked(
         x,
         z,
         (Boolean)WHITELIST_ENABLED.get(),
         packZones((List<? extends String>)ALLOWED_ZONES.get()),
         (Boolean)BLACKLIST_ENABLED.get(),
         packZones((List<? extends String>)FORBIDDEN_ZONES.get())
      );
   }

   public static boolean isBlocked(int x, int z, boolean whitelistEnabled, int[] whitelist, boolean blacklistEnabled, int[] blacklist) {
      return whitelistEnabled && !isInsideAny(x, z, whitelist) ? true : blacklistEnabled && isInsideAny(x, z, blacklist);
   }

   private static boolean isInsideAny(int x, int z, int[] zones) {
      for (int i = 0; i + 3 < zones.length; i += 4) {
         int minX = Math.min(zones[i], zones[i + 2]);
         int maxX = Math.max(zones[i], zones[i + 2]);
         int minZ = Math.min(zones[i + 1], zones[i + 3]);
         int maxZ = Math.max(zones[i + 1], zones[i + 3]);
         if (x >= minX && x <= maxX && z >= minZ && z <= maxZ) {
            return true;
         }
      }

      return false;
   }

   public static int[] packZones(List<? extends String> zones) {
      List<Integer> out = new ArrayList<>();

      for (String text : zones) {
         SkyfrontConfig.ForbiddenZone zone = SkyfrontConfig.ForbiddenZone.parse(text);
         if (zone != null) {
            out.add(zone.x1);
            out.add(zone.z1);
            out.add(zone.x2);
            out.add(zone.z2);
         }
      }

      int[] packed = new int[out.size()];

      for (int i = 0; i < out.size(); i++) {
         packed[i] = out.get(i);
      }

      return packed;
   }

   private static <T> void store(ConfigValue<T> value, T newValue) {
      value.set(newValue);
      SPEC.save();
   }

   public static SkyfrontConfig.ReloadResult reloadFromFile() {
      Path path = FMLPaths.CONFIGDIR.get().resolve("skyfront-common.toml");
      if (!Files.exists(path)) {
         return new SkyfrontConfig.ReloadResult(0, List.of(), false);
      } else {
         int[] changed = new int[]{0};
         List<String> rejected = new ArrayList<>();
         CommentedFileConfig file = (CommentedFileConfig)CommentedFileConfig.builder(path).sync().build();

         try {
            file.load();
            reloadInto(SPEC.getValues(), file, changed, rejected);
         } catch (Throwable var7) {
            if (file != null) {
               try {
                  file.close();
               } catch (Throwable var6) {
                  var7.addSuppressed(var6);
               }
            }

            throw var7;
         }

         if (file != null) {
            file.close();
         }

         return new SkyfrontConfig.ReloadResult(changed[0], rejected, true);
      }
   }

   private static void reloadInto(UnmodifiableConfig values, CommentedFileConfig file, int[] changed, List<String> rejected) {
      for (Object node : values.valueMap().values()) {
         if (node instanceof UnmodifiableConfig section) {
            reloadInto(section, file, changed, rejected);
         } else if (node instanceof ConfigValue) {
            ConfigValue<?> setting = (ConfigValue<?>)node;
            Object raw = file.get(setting.getPath());
            if (raw != null) {
               Object current = setting.get();
               Object value = raw;
               if (raw instanceof Number) {
                  Number number = (Number)raw;
                  if (current instanceof Integer) {
                     value = number.intValue();
                  } else if (current instanceof Long) {
                     value = number.longValue();
                  } else if (current instanceof Double) {
                     value = number.doubleValue();
                  }
               }

               Object spec = SPEC.getSpec().get(setting.getPath());
               if (spec instanceof ValueSpec) {
                  ValueSpec valueSpec = (ValueSpec)spec;
                  if (!valueSpec.test(value)) {
                     rejected.add(String.join(".", setting.getPath()));
                     continue;
                  }
               }

               if (!value.equals(current)) {
                  setting.set(value);
                  changed[0]++;
               }
            }
         }
      }
   }

   public static boolean areExplosionParticlesEnabled() {
      return (Boolean)EXPLOSION_PARTICLES_ENABLED.get();
   }

   public static void setExplosionParticlesEnabled(boolean enabled) {
      store(EXPLOSION_PARTICLES_ENABLED, enabled);
   }

   public static int getParticleMultiplier() {
      return (Integer)EXPLOSION_PARTICLE_MULTIPLIER.get();
   }

   public static void setParticleMultiplier(int multiplier) {
      store(EXPLOSION_PARTICLE_MULTIPLIER, Math.max(0, Math.min(500, multiplier)));
   }

   public static boolean doExplosionsBreakBlocks() {
      return (Boolean)EXPLOSION_BREAKS_BLOCKS.get();
   }

   public static void setExplosionsBreakBlocks(boolean breaks) {
      store(EXPLOSION_BREAKS_BLOCKS, breaks);
   }

   public static boolean areCustomExplosionSoundsEnabled() {
      return (Boolean)CUSTOM_EXPLOSION_SOUNDS.get();
   }

   public static void setCustomExplosionSoundsEnabled(boolean enabled) {
      store(CUSTOM_EXPLOSION_SOUNDS, enabled);
   }

   public static boolean isBlacklistEnabled() {
      return (Boolean)BLACKLIST_ENABLED.get();
   }

   public static void setBlacklistEnabled(boolean enabled) {
      store(BLACKLIST_ENABLED, enabled);
   }

   public static boolean isWhitelistEnabled() {
      return (Boolean)WHITELIST_ENABLED.get();
   }

   public static void setWhitelistEnabled(boolean enabled) {
      store(WHITELIST_ENABLED, enabled);
   }

   static {
      BUILDER.push("targeting");
      BUILDER.pop();
      BUILDER.push("explosions");
      BUILDER.pop();
      BUILDER.push("shahed");
      BUILDER.pop();
      BUILDER.push("radar");
      BUILDER.pop();
      BUILDER.push("siren");
      BUILDER.pop();
      BUILDER.push("drones");
      BUILDER.pop();
      BUILDER.comment("Mavic 3 Pro. The Mavic 3T uses these too, except where its own section says otherwise.").push("mavic3Pro");
      BUILDER.pop();
      BUILDER.push("mavic3T");
      BUILDER.pop();
      BUILDER.comment("Flight shared by the P1-SUN, the FPV drone and the Molniya.").push("fpvFlight");
      BUILDER.pop();
      BUILDER.push("p1sun");
      BUILDER.pop();
      BUILDER.push("molniya");
      BUILDER.pop();
   }

   public static class ForbiddenZone {
      public final int x1;
      public final int z1;
      public final int x2;
      public final int z2;

      public ForbiddenZone(int x1, int z1, int x2, int z2) {
         this.x1 = Math.min(x1, x2);
         this.z1 = Math.min(z1, z2);
         this.x2 = Math.max(x1, x2);
         this.z2 = Math.max(z1, z2);
      }

      public boolean contains(int x, int z) {
         return x >= this.x1 && x <= this.x2 && z >= this.z1 && z <= this.z2;
      }

      public static SkyfrontConfig.ForbiddenZone parse(String text) {
         try {
            String[] parts = text.split(",");
            if (parts.length == 4) {
               return new SkyfrontConfig.ForbiddenZone(
                  Integer.parseInt(parts[0].trim()), Integer.parseInt(parts[1].trim()), Integer.parseInt(parts[2].trim()), Integer.parseInt(parts[3].trim())
               );
            }
         } catch (NumberFormatException var2) {
         }

         return null;
      }
   }

   public static record ReloadResult(int changed, List<String> rejected, boolean fileFound) {
   }
}
