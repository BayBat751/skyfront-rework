package dev.krutlexik.skyfront.seeker;

import dev.krutlexik.skyfront.block.entity.ShahedTerminalBlockEntity;
import dev.krutlexik.skyfront.config.SkyfrontConfig;
import dev.krutlexik.skyfront.entity.ShahedEntity;
import dev.krutlexik.skyfront.network.TerminalActionPacket;
import java.util.ArrayList;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public final class SeekerGroup {
   public static final int ACTION = 7;
   public static final int MAX_RADIUS = 1000;
   public static final int MAX_GROUP = 32;
   private static final double GOLDEN_ANGLE = 2.399963229728653;

   private SeekerGroup() {
   }

   public static int[] point(int var0, int var1, int var2, int var3, int var4, int var5) {
      if (var1 <= 1 && var5 == 0) {
         return new int[]{var2, var3};
      } else {
         double var6 = (double)var4 * Math.sqrt(((double)var0 + 0.5) / (double)Math.max(var1, 1));
         if (var5 > 0) {
            var6 *= Math.max(0.15, 1.0 - (double)var5 * 0.08);
         }

         double var8 = (double)var0 * 2.399963229728653 + (double)var5 * 0.9;
         return new int[]{(int)Math.round((double)var2 + Math.cos(var8) * var6), (int)Math.round((double)var3 + Math.sin(var8) * var6)};
      }
   }

   public static boolean handle(TerminalActionPacket var0, IPayloadContext var1) {
      if (var0.action != 7) {
         return false;
      } else {
         if (!(var1.player() instanceof ServerPlayer var2) || !(var2.level() instanceof ServerLevel var3)) {
            return true;
         }

         if (var2.position().distanceToSqr(var0.terminalPos.getCenter()) > 64.0) {
            return true;
         } else {
            if (!(var3.getBlockEntity(var0.terminalPos) instanceof ShahedTerminalBlockEntity var23)) {
               return true;
            }

            int[] var24 = var0.route;
            if (var24.length >= 7 && (var24.length - 3) % 4 == 0) {
               int var6 = var24[0];
               int var7 = var24[1];
               int var8 = Mth.clamp(var24[2], 1, 1000);
               ArrayList var9 = new ArrayList();

               for (byte var10 = 3; var10 + 3 < var24.length && var9.size() < 32; var10 += 4) {
                  long var11 = (long)var24[var10] << 32 | (long)var24[var10 + 1] & 4294967295L;
                  long var13 = (long)var24[var10 + 2] << 32 | (long)var24[var10 + 3] & 4294967295L;
                  UUID var15 = new UUID(var11, var13);
                  if (!var9.contains(var15) && var23.findByUuid(var15) != null) {
                     Entity var17 = var3.getEntity(var15);
                     if (var17 instanceof ShahedEntity) {
                        ShahedEntity var16 = (ShahedEntity)var17;
                        if (var16.isAlive() && var16.isParked()) {
                           var9.add(var15);
                        }
                     }
                  }
               }

               int var25 = var9.size();
               if (var25 == 0) {
                  var2.sendSystemMessage(Component.translatable("msg.sfw.group.none").withStyle(ChatFormatting.RED));
                  return true;
               } else {
                  int var26 = (Integer)SkyfrontConfig.MIN_LAUNCH_DISTANCE.get();

                  for (int var12 = 0; var12 < var25; var12++) {
                     UUID var27 = (UUID)var9.get(var12);
                     Entity var14 = var3.getEntity(var27);
                     int[] var28 = null;

                     for (int var29 = 0; var29 < 12 && var28 == null; var29++) {
                        int[] var30 = point(var12, var25, var6, var7, var8, var29);
                        if (!SkyfrontConfig.isInForbiddenZone(var30[0], var30[1])) {
                           if (var14 != null && var26 > 0) {
                              double var18 = (double)var30[0] - var14.getX();
                              double var20 = (double)var30[1] - var14.getZ();
                              if (var18 * var18 + var20 * var20 < (double)var26 * (double)var26) {
                                 continue;
                              }
                           }

                           var28 = var30;
                        }
                     }

                     if (var28 == null) {
                        var28 = point(var12, var25, var6, var7, var8, 0);
                     }

                     new TerminalActionPacket(var0.terminalPos, 2, var27, new int[]{var28[0], var28[1]}, var0.altitude, var0.farDive).handle(var1);
                  }

                  var2.sendSystemMessage(Component.translatable("msg.sfw.group.sent", new Object[]{var25, var6, var7, var8}).withStyle(ChatFormatting.GREEN));
                  return true;
               }
            } else {
               return true;
            }
         }
      }
   }
}
