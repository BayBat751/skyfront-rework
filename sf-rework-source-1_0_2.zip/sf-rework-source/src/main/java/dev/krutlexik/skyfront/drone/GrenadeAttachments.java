package dev.krutlexik.skyfront.drone;

import dev.krutlexik.skyfront.compat.sbw.SbwCompat;
import dev.krutlexik.skyfront.compat.sbw.SbwVehicles;
import dev.krutlexik.skyfront.config.SkyfrontConfig;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public final class GrenadeAttachments {
   public static final ResourceLocation RGO_GRENADE = ResourceLocation.fromNamespaceAndPath("superbwarfare", "rgo_grenade");
   public static final ResourceLocation M18_SMOKE_GRENADE = ResourceLocation.fromNamespaceAndPath("superbwarfare", "m18_smoke_grenade");
   public static final ResourceLocation RPG_ROCKET_TBG = ResourceLocation.fromNamespaceAndPath("superbwarfare", "rpg_rocket_tbg");
   public static final ResourceLocation RPG_ROCKET_STANDARD = ResourceLocation.fromNamespaceAndPath("superbwarfare", "rpg_rocket_standard");
   public static final ResourceLocation MORTAR_SHELL = ResourceLocation.fromNamespaceAndPath("superbwarfare", "mortar_shell");
   public static final ResourceLocation C4_BOMB = ResourceLocation.fromNamespaceAndPath("superbwarfare", "c4_bomb");
   private static final GrenadeAttachments.Mount BALL = new GrenadeAttachments.Mount(0.06F, 0.0F, 0.0F, 0.0F, 0.0F, 0.85F, null);
   private static final GrenadeAttachments.Mount CANISTER = new GrenadeAttachments.Mount(-0.02F, 0.0F, 0.0F, 90.0F, 0.0F, 0.85F, null);
   private static final GrenadeAttachments.Mount ROCKET = new GrenadeAttachments.Mount(-0.02F, 1.5F, 0.0F, 0.0F, 0.0F, 0.85F, RPG_ROCKET_TBG);
   private static final GrenadeAttachments.Mount ROCKET_STANDARD = new GrenadeAttachments.Mount(-0.02F, 1.27F, 0.0F, 0.0F, 0.0F, 0.85F, RPG_ROCKET_STANDARD);
   private static final GrenadeAttachments.Mount CHARGE = new GrenadeAttachments.Mount(
      0.1F, 0.0F, 90.0F, 0.0F, -180.0F, 0.9F, ResourceLocation.fromNamespaceAndPath("superbwarfare", "c4")
   );
   private static final double INHERITED_MOTION = 0.2;
   private static final double SEPARATION_SPEED = 0.15;
   private static final int SMOKE_FUSE_TICKS = 40;

   @Nullable
   private static GrenadeAttachments.Warhead warhead(ResourceLocation id) {
      if (C4_BOMB.equals(id)) {
         return new GrenadeAttachments.Warhead(9.0F, 300.0F, 10.0F, 2);
      } else if (RPG_ROCKET_TBG.equals(id)) {
         return new GrenadeAttachments.Warhead(9.0F, 150.0F, 11.0F, 2);
      } else if (RPG_ROCKET_STANDARD.equals(id)) {
         return new GrenadeAttachments.Warhead(4.0F, 80.0F, 5.0F, 1);
      } else if (RGO_GRENADE.equals(id)) {
         return new GrenadeAttachments.Warhead(5.0F, 130.0F, 10.0F, 0);
      } else {
         return MORTAR_SHELL.equals(id) ? new GrenadeAttachments.Warhead(6.0F, 100.0F, 8.0F, 1) : null;
      }
   }

   public static boolean isAttachable(ItemStack stack) {
      if (stack.isEmpty()) {
         return false;
      } else {
         ResourceLocation id = BuiltInRegistries.ITEM.getKey(stack.getItem());
         return RGO_GRENADE.equals(id) || M18_SMOKE_GRENADE.equals(id) || isRocket(stack) || C4_BOMB.equals(id);
      }
   }

   public static boolean isRocket(ItemStack stack) {
      if (stack.isEmpty()) {
         return false;
      } else {
         ResourceLocation id = BuiltInRegistries.ITEM.getKey(stack.getItem());
         return RPG_ROCKET_STANDARD.equals(id) || RPG_ROCKET_TBG.equals(id);
      }
   }

   public static boolean isMortarShell(ItemStack stack) {
      return !stack.isEmpty() && MORTAR_SHELL.equals(BuiltInRegistries.ITEM.getKey(stack.getItem()));
   }

   public static float hitDamage(ItemStack stack) {
      if (stack.isEmpty()) {
         return 0.0F;
      } else {
         ResourceLocation id = BuiltInRegistries.ITEM.getKey(stack.getItem());
         if (RPG_ROCKET_STANDARD.equals(id)) {
            return 340.0F;
         } else if (RPG_ROCKET_TBG.equals(id)) {
            return 250.0F;
         } else {
            return MORTAR_SHELL.equals(id) ? 60.0F : 0.0F;
         }
      }
   }

   public static boolean isDroppable(ItemStack stack) {
      if (stack.isEmpty()) {
         return false;
      } else {
         ResourceLocation id = BuiltInRegistries.ITEM.getKey(stack.getItem());
         return RGO_GRENADE.equals(id) || M18_SMOKE_GRENADE.equals(id);
      }
   }

   public static boolean isExplosive(ItemStack stack) {
      return !stack.isEmpty() && warhead(BuiltInRegistries.ITEM.getKey(stack.getItem())) != null;
   }

   public static GrenadeAttachments.Mount mountOf(ItemStack stack) {
      if (stack.isEmpty()) {
         return BALL;
      } else {
         ResourceLocation id = BuiltInRegistries.ITEM.getKey(stack.getItem());
         if (M18_SMOKE_GRENADE.equals(id)) {
            return CANISTER;
         } else if (RPG_ROCKET_TBG.equals(id)) {
            return ROCKET;
         } else if (RPG_ROCKET_STANDARD.equals(id)) {
            return ROCKET_STANDARD;
         } else {
            return C4_BOMB.equals(id) ? CHARGE : BALL;
         }
      }
   }

   public static void detonate(ServerLevel level, ItemStack attachment, Vec3 at, @Nullable Entity source, @Nullable Entity attacker) {
      GrenadeAttachments.Warhead warhead = warhead(BuiltInRegistries.ITEM.getKey(attachment.getItem()));
      if (warhead != null) {
         detonateWarhead(level, at, source, attacker, warhead.blast(), warhead.sbwDamage(), warhead.sbwRadius(), warhead.effect());
      }
   }

   public static void detonateWarhead(
      ServerLevel level, Vec3 at, @Nullable Entity source, @Nullable Entity attacker, float blast, float sbwDamage, float sbwRadius, int effect
   ) {
      level.explode(
         source,
         blastDamage(level, source, attacker),
         null,
         at.x,
         at.y,
         at.z,
         blast,
         false,
         SkyfrontConfig.doExplosionsBreakBlocks() ? ExplosionInteraction.TNT : ExplosionInteraction.NONE
      );
      if (SbwCompat.isLoaded()) {
         SbwVehicles.spawnExplosionEffect(level, at, effect);
         if (source != null) {
            SbwVehicles.damageVehiclesAround(level, source, attacker, at, sbwDamage, sbwRadius);
         }
      }
   }

   public static void breakUp(ServerLevel level, Vec3 at, @Nullable Entity source, @Nullable Entity attacker) {
      level.explode(source, blastDamage(level, source, attacker), null, at.x, at.y, at.z, 1.0F, false, ExplosionInteraction.NONE);
      level.sendParticles(ParticleTypes.LARGE_SMOKE, at.x, at.y, at.z, 12, 0.3, 0.2, 0.3, 0.02);
      level.sendParticles(ParticleTypes.SMALL_FLAME, at.x, at.y, at.z, 8, 0.25, 0.2, 0.25, 0.05);
   }

   private static DamageSource blastDamage(ServerLevel level, @Nullable Entity source, @Nullable Entity attacker) {
      return level.damageSources().explosion(source, attacker);
   }

   public static void breakUpHarmlessly(ServerLevel level, Vec3 at) {
      level.playSound(null, at.x, at.y, at.z, (SoundEvent)SoundEvents.GENERIC_EXPLODE.value(), SoundSource.NEUTRAL, 0.6F, 1.6F);
      level.sendParticles(ParticleTypes.EXPLOSION, at.x, at.y, at.z, 1, 0.0, 0.0, 0.0, 0.0);
      level.sendParticles(ParticleTypes.LARGE_SMOKE, at.x, at.y, at.z, 12, 0.3, 0.2, 0.3, 0.02);
      level.sendParticles(ParticleTypes.SMALL_FLAME, at.x, at.y, at.z, 8, 0.25, 0.2, 0.25, 0.05);
   }

   public static boolean isSmokeCanister(ItemStack stack) {
      return !stack.isEmpty() && M18_SMOKE_GRENADE.equals(BuiltInRegistries.ITEM.getKey(stack.getItem()));
   }

   public static boolean release(ServerLevel level, @Nullable ServerPlayer pilot, ItemStack attachment, Vec3 pos, Vec3 droneVelocity) {
      ResourceLocation id = BuiltInRegistries.ITEM.getKey(attachment.getItem());
      Entity store = EntityType.byString(id.toString()).map(type -> type.create(level)).orElse(null);
      if (store == null) {
         return false;
      } else {
         if (store instanceof Projectile projectile) {
            projectile.setOwner(pilot);
         }

         if (isSmokeCanister(attachment)) {
            CompoundTag dropData = new CompoundTag();
            dropData.putInt("Fuse", 40);
            store.load(dropData);
         }

         store.setPos(pos.x, pos.y, pos.z);
         Vec3 motion = new Vec3(droneVelocity.x * 0.2, Math.min(droneVelocity.y, 0.0) * 0.2 - 0.15, droneVelocity.z * 0.2);
         store.setDeltaMovement(motion);
         float yaw = (float)(Mth.atan2(motion.x, motion.z) * 57.2957763671875);
         float pitch = (float)(Mth.atan2(motion.y, motion.horizontalDistance()) * 57.2957763671875);
         store.setYRot(yaw);
         store.setXRot(pitch);
         store.yRotO = yaw;
         store.xRotO = pitch;
         return level.addFreshEntity(store);
      }
   }

   private GrenadeAttachments() {
   }

   public static record Mount(float y, float z, float yaw, float pitch, float roll, float scale, @Nullable ResourceLocation display) {
   }

   private static record Warhead(float blast, float sbwDamage, float sbwRadius, int effect) {
   }
}
