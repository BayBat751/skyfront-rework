package dev.krutlexik.skyfront.item;

import dev.krutlexik.skyfront.block.ModBlocks;
import dev.krutlexik.skyfront.compat.sbw.SbwMonitor;
import dev.krutlexik.skyfront.drone.registry.DroneItems;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModCreativeTabs {
   public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, "sfw");
   public static final DeferredHolder<CreativeModeTab, CreativeModeTab> SKYFRONT_TAB = CREATIVE_MODE_TABS.register(
      "skyfront_tab",
      () -> CreativeModeTab.builder()
            .icon(() -> new ItemStack((ItemLike)ModItems.SHAHED_136.get()))
            .title(Component.translatable("itemGroup.sfw"))
            .displayItems((parameters, output) -> {
               output.accept((ItemLike)ModItems.SHAHED_136.get());
               output.accept((ItemLike)ModItems.LAUNCHER.get());
               output.accept((ItemLike)ModBlocks.SHAHED_TERMINAL.get());
               output.accept((ItemLike)ModBlocks.SHAHED_RADAR.get());
               output.accept((ItemLike)ModBlocks.SIREN.get());
               output.accept((ItemLike)DroneItems.DRONE.get());
               output.accept((ItemLike)DroneItems.THERMAL_DRONE.get());
               output.accept((ItemLike)DroneItems.INTERCEPTOR_DRONE.get());
               output.accept((ItemLike)DroneItems.THERMAL_INTERCEPTOR_DRONE.get());
               output.accept((ItemLike)DroneItems.FPV_DRONE.get());
               output.accept((ItemLike)DroneItems.MOLNIYA_DRONE.get());
               ItemStack monitor = SbwMonitor.newMonitor();
               if (!monitor.isEmpty()) {
                  output.accept(monitor);
               }
            })
            .build()
   );

   public ModCreativeTabs() {
   }

   public static void register(IEventBus eventBus) {
      CREATIVE_MODE_TABS.register(eventBus);
   }
}
