package dev.krutlexik.skyfront.seeker;

import dev.krutlexik.skyfront.item.ModCreativeTabs;
import net.minecraft.world.level.ItemLike;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.EventBusSubscriber.Bus;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;

@EventBusSubscriber(
   modid = "sfw",
   bus = Bus.MOD
)
public final class SeekerEvents {
   private SeekerEvents() {
   }

   @SubscribeEvent
   public static void fillTab(BuildCreativeModeTabContentsEvent var0) {
      if (var0.getTab() == ModCreativeTabs.SKYFRONT_TAB.get()) {
         var0.accept((ItemLike)SeekerRegistry.SEEKER_ITEM.get());
         var0.accept((ItemLike)SeekerRegistry.SHAHED_238_ITEM.get());
      }
   }
}
