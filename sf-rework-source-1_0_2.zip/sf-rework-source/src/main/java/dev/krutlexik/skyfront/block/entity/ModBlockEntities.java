package dev.krutlexik.skyfront.block.entity;

import dev.krutlexik.skyfront.block.ModBlocks;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.BlockEntityType.Builder;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModBlockEntities {
   public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(BuiltInRegistries.BLOCK_ENTITY_TYPE, "sfw");
   public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ShahedTerminalBlockEntity>> SHAHED_TERMINAL = BLOCK_ENTITIES.register(
      "shahed_terminal", () -> Builder.of(ShahedTerminalBlockEntity::new, new Block[]{(Block)ModBlocks.SHAHED_TERMINAL.get()}).build(null)
   );

   public ModBlockEntities() {
   }

   public static void register(IEventBus eventBus) {
      BLOCK_ENTITIES.register(eventBus);
   }
}
