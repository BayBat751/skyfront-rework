package dev.krutlexik.skyfront.client;

import dev.krutlexik.skyfront.network.ClientPacketHandler;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.EventBusSubscriber.Bus;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent.LoggingOut;

@OnlyIn(Dist.CLIENT)
@EventBusSubscriber(
   modid = "sfw",
   bus = Bus.GAME,
   value = {Dist.CLIENT}
)
class ClientForgeEvents {
   ClientForgeEvents() {
   }

   @SubscribeEvent
   public static void onClientDisconnect(LoggingOut event) {
      ClientPacketHandler.clearAll();
   }
}
