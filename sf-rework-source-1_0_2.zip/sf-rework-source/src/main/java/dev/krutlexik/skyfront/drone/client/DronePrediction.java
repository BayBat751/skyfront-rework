package dev.krutlexik.skyfront.drone.client;

import dev.krutlexik.skyfront.drone.entity.DroneEntity;
import dev.krutlexik.skyfront.drone.entity.DroneFlightState;
import dev.krutlexik.skyfront.drone.entity.InterceptorDroneEntity;
import dev.krutlexik.skyfront.drone.entity.PilotInput;
import java.util.Arrays;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;

final class DronePrediction {
   private static final int HISTORY = 128;
   private static final int MASK = 127;
   private static final double OFFSET_KEEP = 0.7;
   private static final float TURN_BLEED = 0.3F;
   private static final double SNAP_DISTANCE = 8.0;
   private static final float SNAP_ANGLE = (float)Math.toRadians(90.0);
   private static final double OFFSET_FLOOR = 1.0E-4;
   private final int[] seqs = new int[128];
   private final PilotInput[] inputs = new PilotInput[128];
   private final DroneFlightState[] states = new DroneFlightState[128];
   private int newestSeq = -2147483648;
   @Nullable
   private Vec3 flown;
   private Vec3 offset = Vec3.ZERO;
   private final Quaternionf turn = new Quaternionf();
   private float flownYaw;
   private float flownPitch;
   private boolean flownAngles;
   @Nullable
   private DroneFlightState pendingState;
   private int pendingAck;
   private boolean forceResync;
   private int corrections;

   DronePrediction() {
      for (int i = 0; i < 128; i++) {
         this.states[i] = new DroneFlightState();
      }

      this.reset();
   }

   void reset() {
      Arrays.fill(this.seqs, -2147483648);
      Arrays.fill(this.inputs, null);
      this.newestSeq = -2147483648;
      this.flown = null;
      this.offset = Vec3.ZERO;
      this.turn.identity();
      this.flownAngles = false;
      this.pendingState = null;
      this.forceResync = false;
      this.corrections = 0;
   }

   int corrections() {
      return this.corrections;
   }

   void acceptServerState(int ackSeq, DroneFlightState state) {
      this.pendingAck = ackSeq;
      this.pendingState = state;
   }

   void forceResync() {
      this.forceResync = true;
   }

   void step(DroneEntity drone, PilotInput input) {
      Vec3 shownBefore = drone.position();
      float shownYaw = drone.getYRot();
      float shownPitch = drone.getXRot();
      float shownYawO = drone.yRotO;
      float shownPitchO = drone.xRotO;
      if (this.flown == null) {
         this.flown = shownBefore;
      }

      boolean sticks = drone instanceof InterceptorDroneEntity && drone.flownOnSticks();
      if (sticks && this.flownAngles) {
         drone.setYRot(this.flownYaw);
         drone.setXRot(this.flownPitch);
      }

      this.reconcile(drone);
      drone.setPos(this.flown.x, this.flown.y, this.flown.z);
      drone.flyPilotStep(input);
      drone.notePredictedImpact();
      this.record(drone, input);
      this.flown = drone.position();
      this.flownYaw = drone.getYRot();
      this.flownPitch = drone.getXRot();
      this.flownAngles = true;
      this.offset = this.offset.scale(0.7);
      if (this.offset.lengthSqr() < 1.0E-8) {
         this.offset = Vec3.ZERO;
      }

      this.turn.slerp(new Quaternionf(), 0.3F).normalize();
      Vec3 shown = this.flown.add(this.offset);
      drone.setPos(shown.x, shown.y, shown.z);
      drone.xo = shownBefore.x;
      drone.yo = shownBefore.y;
      drone.zo = shownBefore.z;
      if (sticks) {
         ((InterceptorDroneEntity)drone).presentPredictedAttitude(this.turn, shownYaw, shownPitch);
      } else {
         drone.setYRot(shownYaw);
         drone.setXRot(shownPitch);
         drone.yRotO = shownYawO;
         drone.xRotO = shownPitchO;
      }
   }

   private void record(DroneEntity drone, PilotInput input) {
      int slot = input.seq() & 127;
      this.seqs[slot] = input.seq();
      this.inputs[slot] = input;
      drone.captureFlightState(this.states[slot]);
      this.newestSeq = input.seq();
   }

   @Nullable
   private DroneFlightState predictedFor(int seq) {
      int slot = seq & 127;
      return this.seqs[slot] == seq ? this.states[slot] : null;
   }

   @Nullable
   private PilotInput inputFor(int seq) {
      int slot = seq & 127;
      return this.seqs[slot] == seq ? this.inputs[slot] : null;
   }

   private void reconcile(DroneEntity drone) {
      DroneFlightState server = this.pendingState;
      if (server != null) {
         this.pendingState = null;
         int ack = this.pendingAck;
         DroneFlightState predicted = this.predictedFor(ack);
         if (this.forceResync || predicted == null || !predicted.matches(server)) {
            this.forceResync = false;
            this.corrections++;
            Vec3 flownBefore = this.flown;
            Quaternionf attitudeBefore = drone instanceof InterceptorDroneEntity airframe ? new Quaternionf(airframe.flightAttitude()) : null;
            drone.restoreFlightState(server);
            if (predicted != null) {
               predicted.copyFrom(server);
            }

            drone.setReplaying(true);

            try {
               if (this.newestSeq != -2147483648) {
                  int from = Math.max(ack + 1, this.newestSeq - 128 + 1);

                  for (int seq = from; seq <= this.newestSeq; seq++) {
                     PilotInput input = this.inputFor(seq);
                     if (input != null) {
                        drone.flyPilotStep(input);
                        drone.captureFlightState(this.states[seq & 127]);
                     }
                  }
               }
            } finally {
               drone.setReplaying(false);
            }

            this.flown = drone.position();
            if (flownBefore != null) {
               this.offset = this.offset.add(flownBefore.subtract(this.flown));
               if (this.offset.lengthSqr() > 64.0) {
                  this.offset = Vec3.ZERO;
               }
            }

            if (attitudeBefore != null && drone instanceof InterceptorDroneEntity airframex) {
               Quaternionf after = new Quaternionf(airframex.flightAttitude()).conjugate();
               this.turn.mul(attitudeBefore).mul(after).normalize();
               float angle = 2.0F * (float)Math.acos((double)Math.min(1.0F, Math.abs(this.turn.w)));
               if (angle > SNAP_ANGLE) {
                  this.turn.identity();
               }
            }
         }
      }
   }
}
