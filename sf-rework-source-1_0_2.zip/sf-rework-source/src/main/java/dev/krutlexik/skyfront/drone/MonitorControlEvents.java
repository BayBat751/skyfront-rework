package dev.krutlexik.skyfront.drone;

import dev.krutlexik.skyfront.compat.sbw.SbwMonitor;
import dev.krutlexik.skyfront.drone.entity.DroneEntity;
import dev.krutlexik.skyfront.drone.network.DroneTuningPayload;
import dev.krutlexik.skyfront.drone.network.StartControlPayload;
import java.util.UUID;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent.RightClickItem;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(
   modid = "sfw"
)
public final class MonitorControlEvents {
   @SubscribeEvent
   public static void onUseMonitor(RightClickItem event) {
      ItemStack stack = event.getItemStack();
      if (SbwMonitor.isMonitor(stack) && SbwMonitor.isLinked(stack) && SbwMonitor.isFlaggedAta(stack)) {
         event.setCanceled(true);
         if (!event.getLevel().isClientSide) {
            Player player = event.getEntity();
            if (!(player instanceof ServerPlayer pilot) || !(event.getLevel() instanceof ServerLevel level)) {
               return;
            }

            if (player.isShiftKeyDown()) {
               SbwMonitor.unlink(stack, player);
               player.displayClientMessage(Component.translatable("message.sfw.drone.unlinked"), true);
            } else {
               UUID linked = SbwMonitor.linkedDrone(stack);
               Entity entity = linked != null ? level.getEntity(linked) : null;
               if (entity != null && !(entity instanceof DroneEntity)) {
                  SbwMonitor.clearSkyfrontFlag(stack);
               } else if (entity != null || linked == null || !DroneLinks.reconnectWhenLoaded(pilot, linked, MonitorControlEvents::connect)) {
                  if (!(entity instanceof DroneEntity drone) || drone.isRemoved()) {
                     player.displayClientMessage(Component.translatable("message.sfw.drone.drone_missing"), true);
                     return;
                  }

                  if (drone.isControlledBy(player)) {
                     drone.releaseControl(false);
                  } else {
                     connect(pilot, drone);
                  }
               }
            }
         }
      }
   }

   public static void connect(ServerPlayer pilot, DroneEntity drone) {
      if (drone.isRemoved() || drone.isWrecked() || drone.distanceToSqr(pilot) > drone.controlRangeSqr()) {
         pilot.displayClientMessage(Component.translatable("message.sfw.drone.drone_missing"), true);
      } else if (drone.isControlled()) {
         pilot.displayClientMessage(Component.translatable("message.sfw.drone.busy"), true);
      } else if (drone.getCharge() <= 0.02F) {
         pilot.displayClientMessage(Component.translatable("message.sfw.drone.battery_empty"), true);
      } else {
         drone.setController(pilot.getUUID());
         drone.loadFlightChunks();
         PacketDistributor.sendToPlayer(pilot, DroneTuningPayload.current(), new CustomPacketPayload[0]);
         PacketDistributor.sendToPlayer(
            pilot,
            new StartControlPayload(
               drone.getId(),
               drone.controlRange(),
               drone.getX(),
               drone.getY(),
               drone.getZ(),
               drone.getYRot(),
               drone.getXRot(),
               BuiltInRegistries.ENTITY_TYPE.getId(drone.getType()),
               drone.isArmed(),
               drone.getCharge()
            ),
            new CustomPacketPayload[0]
         );
      }
   }

   private MonitorControlEvents() {
   }
}
