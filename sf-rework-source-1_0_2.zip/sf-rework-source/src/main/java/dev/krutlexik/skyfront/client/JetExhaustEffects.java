package dev.krutlexik.skyfront.client;

import dev.krutlexik.skyfront.client.sound.BoosterSound;
import dev.krutlexik.skyfront.entity.ShahedEntity;
import dev.krutlexik.skyfront.particle.BoosterSmokeParticle;
import dev.krutlexik.skyfront.particle.JetExhaustParticle;
import dev.krutlexik.skyfront.particle.ModParticles;
import dev.krutlexik.skyfront.seeker.SeekerFx;
import dev.krutlexik.skyfront.seeker.SeekerHooks;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.ParticleStatus;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.jetbrains.annotations.Nullable;

@OnlyIn(Dist.CLIENT)
public final class JetExhaustEffects {
   private static final double ENGINE_BACK = 2.05;
   private static final double ENGINE_UP = 0.19;
   private static final double BOOSTER_BACK = 1.4;
   private static final double BOOSTER_UP = -0.32;
   private static final double BOOSTER_CANT = Math.toRadians(14.0);
   private static final double HAZE_SPACING = 1.2;
   private static final double SMOKE_SPACING = 0.7;
   private static final float HAZE_PEAK = 0.38F;
   private static final float DAMAGED_HEALTH = 0.25F;
   private static final double HAZE_RANGE = 400.0;
   private static final double BOOSTER_RANGE = 512.0;
   private static final double BURNING_RANGE = 512.0;
   private static final double MAX_STEP = 40.0;
   private static final double BLAST_REACH = 9.0;
   private static final RandomSource RANDOM = RandomSource.create();
   private static final Map<ShahedEntity, JetExhaustEffects.State> STATES = new WeakHashMap<>();

   private JetExhaustEffects() {
   }

   public static Vec3 nose(float yaw, float pitch) {
      double y = Math.toRadians((double)yaw);
      double p = Math.toRadians((double)pitch);
      return new Vec3(Math.sin(y) * Math.cos(p), Math.sin(p), Math.cos(y) * Math.cos(p));
   }

   public static Vec3 top(float yaw, float pitch) {
      double y = Math.toRadians((double)yaw);
      double p = Math.toRadians((double)pitch);
      return new Vec3(-Math.sin(y) * Math.sin(p), Math.cos(p), -Math.cos(y) * Math.sin(p));
   }

   public static Vec3 engineNozzle(Vec3 nose, Vec3 top) {
      return nose.scale(-2.05).add(top.scale(0.19));
   }

   public static Vec3 boosterNozzle(Vec3 nose, Vec3 top) {
      return nose.scale(-1.4).add(top.scale(-0.32));
   }

   public static Vec3 boosterBlast(Vec3 nose, Vec3 top) {
      return nose.scale(-Math.cos(BOOSTER_CANT)).add(top.scale(-Math.sin(BOOSTER_CANT)));
   }

   public static int boosterAge(ShahedEntity jet) {
      JetExhaustEffects.State state = STATES.get(jet);
      return state == null ? -1 : state.boosterAge;
   }

   public static void tick(ShahedEntity jet) {
      JetExhaustEffects.State state = STATES.computeIfAbsent(jet, key -> new JetExhaustEffects.State());
      Vec3 nose = nose(jet.getYRot(), jet.getXRot());
      Vec3 top = top(jet.getYRot(), jet.getXRot());
      Vec3 engine = jet.position().add(engineNozzle(nose, top));
      Vec3 booster = jet.position().add(boosterNozzle(nose, top));
      Vec3 burning = SeekerFx.enginePosition(jet);
      Vec3 engineBefore = state.engine;
      Vec3 boosterBefore = state.booster;
      Vec3 burningBefore = state.burning;
      state.engine = engine;
      state.booster = booster;
      state.burning = burning;
      int launch = jet.getLaunchState();
      if (launch != 1) {
         Minecraft mc = Minecraft.getInstance();
         double distance = mc.gameRenderer.getMainCamera().getPosition().distanceTo(jet.position());
         ParticleStatus setting = (ParticleStatus)mc.options.particles().get();
         double density = setting == ParticleStatus.ALL ? 1.0 : (setting == ParticleStatus.DECREASED ? 0.5 : 0.25);
         if (jet.getIsFalling()) {
            if (distance < 512.0) {
               burningTrail(mc, state, burningBefore, burning, density, distance, true);
            }
         } else {
            if (jet.getHealthFraction() <= 0.25F && distance < 512.0) {
               burningTrail(mc, state, burningBefore, burning, density, distance, false);
            }

            if (SeekerFx.boosterLit(jet)) {
               if (state.boosterAge < 0) {
                  state.boosterAge = 0;
                  boolean launching = launch == 5 || launch == 2;
                  if (launching && distance < 512.0) {
                     ignition(mc, booster, boosterBlast(nose, top), density);
                  }

                  state.roar = BoosterSound.lit(booster, launching);
               } else if (state.roar != null) {
                  state.roar.burning(booster);
               }

               state.boosterAge++;
               if (distance < 512.0) {
                  boosterBurn(mc, jet, state, boosterBefore, booster, boosterBlast(nose, top), density, distance);
               }
            } else {
               if (state.boosterAge >= 0 && !state.burntOut) {
                  state.burntOut = true;
                  if (state.roar != null) {
                     state.roar.burntOut();
                  }

                  if (distance < 512.0) {
                     for (int i = 0; i < Math.max(2, (int)(6.0 * density)); i++) {
                        smoke(
                           mc,
                           booster,
                           RANDOM.nextGaussian() * 0.03,
                           RANDOM.nextGaussian() * 0.03,
                           RANDOM.nextGaussian() * 0.03,
                           0.6F,
                           2.6F,
                           90,
                           260 + RANDOM.nextInt(80),
                           0
                        );
                     }
                  }
               }

               if (SeekerHooks.is238(jet) && setting != ParticleStatus.MINIMAL && distance < 400.0) {
                  haze(mc, state, engineBefore, engine, nose.scale(-1.0), density, distance);
               }
            }
         }
      }
   }

   private static void ignition(Minecraft mc, Vec3 nozzle, Vec3 blast, double density) {
      int puffs = Math.max(8, (int)(40.0 * density));

      for (int i = 0; i < puffs; i++) {
         double angle = RANDOM.nextDouble() * 3.141592653589793 * 2.0;
         double out = 0.15 + RANDOM.nextDouble() * 0.35;
         double back = RANDOM.nextDouble() * 0.3;
         Vec3 at = nozzle.add(blast.scale(0.5 + RANDOM.nextDouble() * 2.0));
         smoke(
            mc,
            at,
            blast.x * back + Math.cos(angle) * out,
            0.02 + RANDOM.nextDouble() * 0.06,
            blast.z * back + Math.sin(angle) * out,
            1.2F + RANDOM.nextFloat(),
            3.8F + RANDOM.nextFloat() * 2.2F,
            100,
            300 + RANDOM.nextInt(180),
            i % 3 == 0 ? 4 : 0
         );
      }

      for (int i = 0; i < (int)(12.0 * density); i++) {
         Vec3 fling = blast.scale(0.3 + RANDOM.nextDouble() * 0.4)
            .add(RANDOM.nextGaussian() * 0.2, 0.15 + RANDOM.nextDouble() * 0.2, RANDOM.nextGaussian() * 0.2);
         spawn(mc, (SimpleParticleType)ModParticles.EMBER.get(), nozzle, fling.x, fling.y, fling.z);
      }
   }

   private static void boosterBurn(
      Minecraft mc, ShahedEntity jet, JetExhaustEffects.State state, Vec3 before, Vec3 nozzle, Vec3 blast, double density, double distance
   ) {
      double spacing = 0.7 / density * Math.max(1.0, distance / 128.0);
      boolean flown = before != null && before.distanceToSqr(nozzle) < 1600.0;
      if (flown) {
         state.smoke = along(
            before,
            nozzle,
            spacing,
            state.smoke,
            (atx, share) -> {
               BoosterSmokeParticle puff = smoke(
                  mc,
                  atx,
                  blast.x * 0.06 + RANDOM.nextGaussian() * 0.015,
                  blast.y * 0.06 + RANDOM.nextGaussian() * 0.015,
                  blast.z * 0.06 + RANDOM.nextGaussian() * 0.015,
                  0.7F + RANDOM.nextFloat() * 0.4F,
                  2.6F + RANDOM.nextFloat() * 1.4F,
                  120,
                  320 + RANDOM.nextInt(140),
                  3
               );
               if (puff != null) {
                  puff.appearAt(share);
               }
            }
         );
      }

      for (int i = 0; i < Math.max(1, (int)(2.0 * density)); i++) {
         Vec3 at = nozzle.add(blast.scale(1.5 + RANDOM.nextDouble() * 2.5));
         BoosterSmokeParticle puff = smoke(
            mc, at, blast.x * 0.15, blast.y * 0.15, blast.z * 0.15, 0.8F, 2.8F + RANDOM.nextFloat(), 100, 260 + RANDOM.nextInt(120), 3
         );
         if (puff != null && flown) {
            puff.appearAt(passing(before, nozzle, at));
         }
      }

      BlockHitResult ground = jet.level().clip(new ClipContext(nozzle, nozzle.add(blast.scale(9.0)), Block.COLLIDER, Fluid.ANY, jet));
      if (ground.getType() == Type.BLOCK) {
         double strength = 1.0 - ground.getLocation().distanceTo(nozzle) / 9.0;
         int puffs = (int)Math.round(3.0 * strength * density + RANDOM.nextDouble() * 0.5);
         Vec3 at = ground.getLocation().add(0.0, 0.3, 0.0);

         for (int ix = 0; ix < puffs; ix++) {
            double angle = RANDOM.nextDouble() * 3.141592653589793 * 2.0;
            double out = (0.25 + RANDOM.nextDouble() * 0.3) * (0.5 + strength);
            smoke(
               mc,
               at,
               Math.cos(angle) * out,
               0.02 + RANDOM.nextDouble() * 0.03,
               Math.sin(angle) * out,
               1.2F + RANDOM.nextFloat() * 0.6F,
               4.0F + RANDOM.nextFloat() * 2.0F,
               110,
               260 + RANDOM.nextInt(160),
               2
            );
         }
      }

      if (RANDOM.nextDouble() < 0.6 * density && before != null) {
         Vec3 velocity = nozzle.subtract(before).scale(0.3);
         Vec3 fling = velocity.add(blast.scale(0.4 + RANDOM.nextDouble() * 0.4))
            .add(RANDOM.nextGaussian() * 0.08, RANDOM.nextGaussian() * 0.08, RANDOM.nextGaussian() * 0.08);
         spawn(mc, (SimpleParticleType)ModParticles.EMBER.get(), nozzle, fling.x, fling.y, fling.z);
      }
   }

   private static void haze(Minecraft mc, JetExhaustEffects.State state, Vec3 before, Vec3 nozzle, Vec3 back, double density, double distance) {
      if (before != null && !(before.distanceToSqr(nozzle) > 1600.0)) {
         double spacing = 1.2 / density * Math.max(1.0, distance / 96.0);
         float peak = (float)(0.3799999952316284 * Math.min(1.0, 0.5 + 0.5 * density));
         state.haze = along(
            before,
            nozzle,
            spacing,
            state.haze,
            (at, share) -> {
               if (spawn(
                  mc,
                  (SimpleParticleType)ModParticles.JET_EXHAUST.get(),
                  at,
                  back.x * 0.04 + RANDOM.nextGaussian() * 0.006,
                  back.y * 0.04 + RANDOM.nextGaussian() * 0.006,
                  back.z * 0.04 + RANDOM.nextGaussian() * 0.006
               ) instanceof JetExhaustParticle puff) {
                  puff.peak(peak).appearAt(share);
               }
            }
         );
      } else {
         state.haze = 0.0;
      }
   }

   private static void burningTrail(Minecraft mc, JetExhaustEffects.State state, Vec3 before, Vec3 engine, double density, double distance, boolean downed) {
      ClientLevel level = mc.level;
      if (level != null) {
         Vec3 from = before != null && before.distanceToSqr(engine) < 1600.0 ? before : engine;
         if (!downed) {
            burst(level, ParticleTypes.SMOKE, from, 2, 0.15, 0.1, 0.15, 0.01);
            if (RANDOM.nextInt(4) == 0) {
               burst(level, ParticleTypes.LARGE_SMOKE, from, 1, 0.1, 0.1, 0.1, 0.01);
            }
         } else {
            for (int i = 0; i < 3; i++) {
               Vec3 at = from.lerp(engine, (double)i / 3.0);
               burst(level, ParticleTypes.LARGE_SMOKE, at, 2, 0.2, 0.2, 0.2, 0.01);
               if (i == 0) {
                  burst(level, ParticleTypes.CAMPFIRE_COSY_SMOKE, at, 1, 0.1, 0.1, 0.1, 0.005);
               }

               if (RANDOM.nextInt(3) == 0) {
                  burst(level, ParticleTypes.FLAME, at.add(0.0, -0.1, 0.0), 1, 0.1, 0.05, 0.1, 0.02);
               }

               if (RANDOM.nextInt(6) == 0) {
                  burst(level, ParticleTypes.LAVA, at, 1, 0.05, 0.05, 0.05, 0.05);
               }
            }
         }
      }
   }

   private static void burst(ClientLevel level, ParticleOptions type, Vec3 at, int count, double spreadX, double spreadY, double spreadZ, double speed) {
      for (int i = 0; i < count; i++) {
         level.addParticle(
            type,
            true,
            at.x + RANDOM.nextGaussian() * spreadX,
            at.y + RANDOM.nextGaussian() * spreadY,
            at.z + RANDOM.nextGaussian() * spreadZ,
            RANDOM.nextGaussian() * speed,
            RANDOM.nextGaussian() * speed,
            RANDOM.nextGaussian() * speed
         );
      }
   }

   private static double along(Vec3 from, Vec3 to, double spacing, double carried, JetExhaustEffects.Puff at) {
      double length = from.distanceTo(to);
      if (length < 1.0E-6) {
         return carried;
      } else {
         double next;
         for (next = Math.max(0.0, spacing - carried); next <= length; next += spacing) {
            at.at(from.lerp(to, next / length), (float)(next / length));
         }

         return length - (next - spacing);
      }
   }

   private static float passing(Vec3 from, Vec3 to, Vec3 point) {
      Vec3 way = to.subtract(from);
      double length = way.lengthSqr();
      return length < 1.0E-6 ? 0.0F : (float)Mth.clamp(point.subtract(from).dot(way) / length, 0.0, 1.0);
   }

   @Nullable
   private static BoosterSmokeParticle smoke(
      Minecraft mc, Vec3 at, double vx, double vy, double vz, float startSize, float endSize, int growTicks, int lifetime, int hotTicks
   ) {
      if (spawn(mc, (SimpleParticleType)ModParticles.BOOSTER_SMOKE.get(), at, vx, vy, vz) instanceof BoosterSmokeParticle puff) {
         puff.shape(startSize, endSize, growTicks, lifetime).hot(hotTicks);
         return puff;
      } else {
         return null;
      }
   }

   private static Particle spawn(Minecraft mc, SimpleParticleType type, Vec3 at, double vx, double vy, double vz) {
      return mc.particleEngine.createParticle(type, at.x, at.y, at.z, vx, vy, vz);
   }

   @FunctionalInterface
   private interface Puff {
      void at(Vec3 var1, float var2);
   }

   private static final class State {
      Vec3 engine;
      Vec3 booster;
      int boosterAge = -1;
      boolean burntOut;
      BoosterSound roar;
      Vec3 burning;
      double haze;
      double smoke;

      private State() {
      }
   }
}
