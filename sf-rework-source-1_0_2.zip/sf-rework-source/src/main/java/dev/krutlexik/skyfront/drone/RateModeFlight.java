package dev.krutlexik.skyfront.drone;

import net.minecraft.util.Mth;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;
import org.joml.Vector3f;

public final class RateModeFlight {
   private static final double[][] THRUST_CURVE = new double[][]{
      {-0.1, 0.8, 0.0, 0.0}, {30.2, 1.0, -8.3333254E-4, -8.3333254E-4}, {59.9, 0.75, -0.01390821, -0.01390821}, {102.1, 0.0, 0.0, 0.0}
   };
   private static final double[][] GROUND_CURVE = new double[][]{
      {0.1, 1.0, 0.051369887, 0.0}, {10.1, 2.0, 2.8834687E-4, 2.8834687E-4}, {59.9, 1.25, -0.009389674, -0.009389674}, {116.6, 1.0, 0.0, 0.0}
   };
   private static final double CURVE_ZERO_KMH = 102.1;
   private static final double AIRSPEED_STRETCH = 1.25;
   public static final double GROUND_EFFECT_REACH = 1.2;

   public static double actualRate(double stick, double centre, double max, double expo) {
      stick = Mth.clamp(stick, -1.0, 1.0);
      double amount = Math.abs(stick);
      if (amount <= 0.0) {
         return 0.0;
      } else {
         centre = Math.max(0.0, centre);
         max = Math.max(centre, max);
         expo = Mth.clamp(expo, 0.0, 0.95);
         double quadratic = amount * amount * (2.0 - amount);
         double cubic = amount * amount * amount;
         double blend = quadratic * (1.0 - expo) + cubic * expo;
         double rate = centre * amount + (max - centre) * blend;
         return stick < 0.0 ? -rate : rate;
      }
   }

   public static double approach(double current, double target, double rate, double dt) {
      if (rate <= 0.0) {
         return target;
      } else {
         double blend = 1.0 - Math.exp(-rate * Math.max(0.0, dt));
         double value = current + (target - current) * Mth.clamp(blend, 0.0, 1.0);
         return Math.abs(value) < 5.0E-4 && Math.abs(target) < 5.0E-4 ? 0.0 : value;
      }
   }

   private static double sampleCurve(double[][] points, double x) {
      if (x <= points[0][0]) {
         return points[0][1];
      } else {
         for (int i = 0; i < points.length - 1; i++) {
            double[] left = points[i];
            double[] right = points[i + 1];
            if (x <= right[0]) {
               double span = right[0] - left[0];
               double t = span > 0.0 ? (x - left[0]) / span : 0.0;
               double t2 = t * t;
               double t3 = t2 * t;
               return (2.0 * t3 - 3.0 * t2 + 1.0) * left[1]
                  + (t3 - 2.0 * t2 + t) * span * left[3]
                  + (-2.0 * t3 + 3.0 * t2) * right[1]
                  + (t3 - t2) * span * right[2];
            }
         }

         return points[points.length - 1][1];
      }
   }

   public static double thrustAtAirspeed(double axisKmh, double topSpeedKmh) {
      double scale = 102.1 / (Math.max(topSpeedKmh, 1.0) * 1.25);
      return Math.max(0.0, sampleCurve(THRUST_CURVE, axisKmh * scale));
   }

   public static double thrustAtRest() {
      return thrustAtAirspeed(0.0, 1.0);
   }

   public static double groundEffect(double blocksAboveGround) {
      return sampleCurve(GROUND_CURVE, blocksAboveGround * 100.0);
   }

   public static float cameraRoll(float bodyRoll) {
      return -bodyRoll;
   }

   public static float[] cameraAnglesOf(Quaternionfc attitude, float mountTilt) {
      Quaternionf camera = new Quaternionf(attitude).rotateX(mountTilt * 0.017453292F);
      Vector3f euler = camera.normalize().getEulerAnglesYXZ(new Vector3f());
      return new float[]{Mth.wrapDegrees(180.0F - euler.y() * 57.295776F), -euler.x() * 57.295776F, cameraRoll(euler.z() * 57.295776F)};
   }

   private RateModeFlight() {
   }
}
