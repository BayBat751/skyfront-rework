package dev.krutlexik.skyfront.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class DebrisParticle extends TextureSheetParticle {
   private final float rotationSpeed;

   protected DebrisParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, SpriteSet sprites) {
      super(level, x, y, z);
      this.xd = vx * 1.5;
      this.yd = vy * 1.5;
      this.zd = vz * 1.5;
      this.lifetime = 150;
      this.hasPhysics = true;
      this.gravity = 0.05F;
      this.quadSize = 0.25F + this.random.nextFloat() * 0.15F;
      this.rotationSpeed = (this.random.nextFloat() - 0.5F) * 0.4F;
      float brightness = 0.12F + this.random.nextFloat() * 0.2F;
      this.rCol = brightness;
      this.gCol = brightness;
      this.bCol = brightness;
      this.alpha = 1.0F;
      this.pickSprite(sprites);
   }

   public void tick() {
      this.xo = this.x;
      this.yo = this.y;
      this.zo = this.z;
      if (this.age++ >= this.lifetime) {
         this.remove();
      } else {
         this.oRoll = this.roll;
         this.roll = this.roll + this.rotationSpeed;
         this.yd = this.yd - (double)this.gravity;
         this.move(this.xd, this.yd, this.zd);
         if (this.onGround) {
            this.xd *= 0.7;
            this.zd *= 0.7;
            this.yd = 0.0;
         }

         if ((double)this.age > (double)this.lifetime * 0.5) {
            this.alpha = Math.max(0.0F, this.alpha - 0.025F);
            if (this.alpha <= 0.0F) {
               this.remove();
            }
         }

         this.xd *= 0.98;
         this.yd *= 0.98;
         this.zd *= 0.98;
      }
   }

   public ParticleRenderType getRenderType() {
      return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
   }

   @OnlyIn(Dist.CLIENT)
   public static class Provider implements ParticleProvider<SimpleParticleType> {
      private final SpriteSet sprites;

      public Provider(SpriteSet sprites) {
         this.sprites = sprites;
      }

      public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double vx, double vy, double vz) {
         return new DebrisParticle(level, x, y, z, vx, vy, vz, this.sprites);
      }
   }
}
