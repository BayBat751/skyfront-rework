package dev.krutlexik.skyfront.seeker;

import dev.krutlexik.skyfront.entity.DebrisEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;

public class Shahed238DroneEntity extends SeekerDroneEntity {
   private static final double TOP_SPEED_KMH = 394.06;
   public static final float BLAST = 22.5F;
   public static final float VEHICLE_DAMAGE = 1687.5F;
   public static final float VEHICLE_RADIUS = 30.0F;

   public Shahed238DroneEntity(EntityType<? extends Shahed238DroneEntity> var1, Level var2) {
      super(var1, var2);
   }

   @Override
   public double topSpeedKmh() {
      return 394.06;
   }

   @Override
   public ItemStack packedItem() {
      return new ItemStack((ItemLike)SeekerRegistry.SHAHED_238_ITEM.get());
   }

   @Override
   protected DebrisEntity.Airframe debrisFrame() {
      return DebrisEntity.Airframe.JET_SHAHED;
   }

   @Override
   protected float warheadBlast() {
      return 22.5F;
   }

   @Override
   protected float warheadVehicleDamage() {
      return 1687.5F;
   }

   @Override
   protected float warheadVehicleRadius() {
      return 30.0F;
   }

   @Override
   public void tick() {
      super.tick();
      SeekerFx.droneTick(this);
   }
}
