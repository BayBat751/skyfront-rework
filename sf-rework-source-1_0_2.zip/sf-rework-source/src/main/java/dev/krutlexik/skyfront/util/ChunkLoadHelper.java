package dev.krutlexik.skyfront.util;

import java.lang.reflect.Method;
import java.util.Comparator;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.TicketType;
import net.minecraft.world.level.ChunkPos;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public final class ChunkLoadHelper {
   private static final Logger LOGGER = LogManager.getLogger("SFW-ChunkLoader");
   private static final int TICKET_LIFETIME_TICKS = 60;
   public static final TicketType<ChunkPos> SHAHED_TICKET = TicketType.create("skyfront_shahed", Comparator.comparingLong(ChunkPos::toLong), 60);
   private static ChunkLoadHelper.Mode mode = ChunkLoadHelper.Mode.UNKNOWN;
   private static Method getBukkitWorld;
   private static Method getChunkAtAsync;
   private static final int TICKING_RADIUS = 3;

   private ChunkLoadHelper() {
   }

   private static void detect(ServerLevel level) {
      if (mode == ChunkLoadHelper.Mode.UNKNOWN) {
         try {
            Class.forName("org.bukkit.Bukkit");
            Method getWorld = level.getClass().getMethod("getWorld");
            Object bukkitWorld = getWorld.invoke(level);
            Method async = bukkitWorld.getClass().getMethod("getChunkAtAsync", int.class, int.class, boolean.class);
            getBukkitWorld = getWorld;
            getChunkAtAsync = async;
            mode = ChunkLoadHelper.Mode.YOUER_ASYNC;
            LOGGER.info("[SFW] Hybrid Bukkit/Paper core detected - use ASYNC chunk loading");
         } catch (Throwable var4) {
            mode = ChunkLoadHelper.Mode.NEOFORGE_TICKETS;
            LOGGER.info("[SFW] NeoForge server — use vanilla chunk loading");
         }
      }
   }

   public static void keepTicking(ServerLevel level, ChunkPos pos) {
      detect(level);
      level.getChunkSource().addRegionTicket(SHAHED_TICKET, pos, 3, pos);
      requestAsync(level, pos);
   }

   public static void preloadAhead(ServerLevel level, ChunkPos pos) {
      detect(level);
      level.getChunkSource().addRegionTicket(SHAHED_TICKET, pos, 0, pos);
      requestAsync(level, pos);
   }

   private static void requestAsync(ServerLevel level, ChunkPos pos) {
      if (mode == ChunkLoadHelper.Mode.YOUER_ASYNC) {
         try {
            Object bukkitWorld = getBukkitWorld.invoke(level);
            getChunkAtAsync.invoke(bukkitWorld, pos.x, pos.z, true);
         } catch (Throwable var3) {
            mode = ChunkLoadHelper.Mode.NEOFORGE_TICKETS;
            LOGGER.warn("[SFW] Paper async chunk load failed, falling back to vanilla chunk tickets only", var3);
         }
      }
   }

   public static void keepLoaded(ServerLevel level, ChunkPos pos) {
      detect(level);
      level.getChunkSource().addRegionTicket(SHAHED_TICKET, pos, 0, pos);
      if (level.getChunkSource().getChunkNow(pos.x, pos.z) == null) {
         requestAsync(level, pos);
      }
   }

   public static ChunkPos chunkAt(double x, double z) {
      return new ChunkPos(BlockPos.containing(x, 0.0, z));
   }

   private static enum Mode {
      UNKNOWN,
      NEOFORGE_TICKETS,
      YOUER_ASYNC;

      private Mode() {
      }
   }
}
