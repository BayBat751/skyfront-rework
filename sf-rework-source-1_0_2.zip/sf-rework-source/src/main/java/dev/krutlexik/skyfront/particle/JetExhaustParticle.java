package dev.krutlexik.skyfront.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.world.phys.AABB;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class JetExhaustParticle extends TrailParticle {
   private static final float START_SIZE = 0.32F;
   private static final float START_SHARE = 0.6F;
   private final float endSize;
   private float peakAlpha = 0.38F;

   protected JetExhaustParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, SpriteSet sprites) {
      super(level, x, y, z);
      this.xd = vx;
      this.yd = vy;
      this.zd = vz;
      this.lifetime = 36 + this.random.nextInt(20);
      this.hasPhysics = false;
      this.gravity = 0.0F;
      this.endSize = 1.7F + this.random.nextFloat() * 0.8F;
      float shade = 0.54F + this.random.nextFloat() * 0.1F;
      this.rCol = shade;
      this.gCol = shade;
      this.bCol = shade * 0.96F;
      this.alpha = this.peakAlpha * 0.6F;
      this.quadSize = 0.32F;
      this.roll = this.random.nextFloat() * 6.2831855F;
      this.oRoll = this.roll;
      this.pickSprite(sprites);
   }

   public JetExhaustParticle peak(float alpha) {
      this.peakAlpha = alpha;
      this.alpha = alpha * 0.6F;
      return this;
   }

   public void tick() {
      this.xo = this.x;
      this.yo = this.y;
      this.zo = this.z;
      if (this.age++ >= this.lifetime) {
         this.remove();
      } else {
         this.move(this.xd, this.yd, this.zd);
         this.xd *= 0.9;
         this.zd *= 0.9;
         this.yd = this.yd * 0.9 + 8.0E-4;
         float life = (float)this.age / (float)this.lifetime;
         this.quadSize = 0.32F + (this.endSize - 0.32F) * (float)Math.sqrt((double)life);
         float rise = Math.min(0.6F + 0.39999998F * (float)this.age / 2.0F, 1.0F);
         this.alpha = this.peakAlpha * rise * (1.0F - life) * (float)Math.sqrt((double)(1.0F - life));
      }
   }

   public AABB getRenderBoundingBox(float partialTicks) {
      return this.getBoundingBox().inflate((double)this.quadSize);
   }

   public ParticleRenderType getRenderType() {
      return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
   }

   @OnlyIn(Dist.CLIENT)
   public static class Provider implements ParticleProvider<SimpleParticleType> {
      private final SpriteSet sprites;

      public Provider(SpriteSet sprites) {
         this.sprites = sprites;
      }

      public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double vx, double vy, double vz) {
         return new JetExhaustParticle(level, x, y, z, vx, vy, vz, this.sprites);
      }
   }
}
