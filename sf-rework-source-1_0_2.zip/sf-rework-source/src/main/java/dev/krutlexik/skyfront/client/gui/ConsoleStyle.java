package dev.krutlexik.skyfront.client.gui;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public final class ConsoleStyle {
   private static final ResourceLocation METAL = ResourceLocation.fromNamespaceAndPath("sfw", "textures/gui/console_metal.png");
   private static final int METAL_SIZE = 64;
   public static final int STEEL_0 = -13092296;
   public static final int STEEL_1 = -11644851;
   public static final int STEEL_2 = -10065820;
   public static final int STEEL_3 = -8355203;
   public static final int STEEL_4 = -6644586;
   public static final int STEEL_5 = -4933968;
   private static final int EDGE_LIT = -10721736;
   private static final int EDGE_LIT_2 = -11906512;
   private static final int EDGE_DARK = -15065840;
   private static final int EDGE_DARK_2 = -14407654;
   private static final int KHAKI = -4871560;
   private static final int KHAKI_LIT = -3226218;
   private static final int KHAKI_DARK = -8884664;
   public static final int PLATE_TEXT = -14672364;
   public static final int PHOSPHOR_BG = -16245748;
   public static final int PHOSPHOR_DIM = -15318500;
   public static final int PHOSPHOR = -12541880;
   public static final int PHOSPHOR_BRIGHT = -8853886;
   public static final int AMBER_BG = -15200250;
   public static final int AMBER_ROW = -14806008;
   public static final int AMBER = -20420;
   public static final int AMBER_DIM = -6657496;
   public static final int AMBER_RED = -42436;
   public static final int LAMP_GREEN = -12788666;
   public static final int LAMP_AMBER = -1005016;
   public static final int LAMP_RED_OFF = -10872812;

   private ConsoleStyle() {
   }

   public static void panel(GuiGraphics g, int x0, int y0, int x1, int y1) {
      g.fill(x0 + 3, y0 + 3, x1 + 3, y1 + 3, 1879048192);

      for (int y = y0; y < y1; y += 64) {
         for (int x = x0; x < x1; x += 64) {
            int w = Math.min(64, x1 - x);
            int h = Math.min(64, y1 - y);
            g.blit(METAL, x, y, 0.0F, 0.0F, w, h, 64, 64);
         }
      }

      g.fillGradient(x0, y0, x1, y1, 285212671, 0);
      g.fill(x0, y0, x1, y0 + 1, -10721736);
      g.fill(x0, y0 + 1, x1 - 1, y0 + 2, -11906512);
      g.fill(x0, y0, x0 + 1, y1, -10721736);
      g.fill(x0 + 1, y0 + 1, x0 + 2, y1 - 1, -11906512);
      g.fill(x0, y1 - 1, x1, y1, -15065840);
      g.fill(x0 + 1, y1 - 2, x1 - 1, y1 - 1, -14407654);
      g.fill(x1 - 1, y0, x1, y1, -15065840);
      g.fill(x1 - 2, y0 + 1, x1 - 1, y1 - 1, -14407654);
      if (x1 - x0 >= 24 && y1 - y0 >= 24) {
         bolt(g, x0 + 4, y0 + 4);
         bolt(g, x1 - 6, y0 + 4);
         bolt(g, x0 + 4, y1 - 6);
         bolt(g, x1 - 6, y1 - 6);
      }
   }

   private static void bolt(GuiGraphics g, int x, int y) {
      g.fill(x, y, x + 2, y + 2, -10065820);
      g.fill(x, y, x + 1, y + 1, -4933968);
      g.fill(x + 1, y + 1, x + 2, y + 2, -15065840);
   }

   public static void plate(GuiGraphics g, Font font, int centreX, int y, Component text) {
      int w = font.width(text) + 10;
      int x0 = centreX - w / 2;
      int x1 = x0 + w;
      g.fill(x0, y, x1, y + 12, -4871560);
      g.fill(x0, y, x1, y + 1, -3226218);
      g.fill(x0, y, x0 + 1, y + 12, -3226218);
      g.fill(x0, y + 11, x1, y + 12, -8884664);
      g.fill(x1 - 1, y, x1, y + 12, -8884664);
      g.fill(x0 + 2, y + 5, x0 + 3, y + 7, -11644851);
      g.fill(x1 - 3, y + 5, x1 - 2, y + 7, -11644851);
      g.drawString(font, text, x0 + 5, y + 2, -14672364, false);
   }

   public static void bezel(GuiGraphics g, int x0, int y0, int x1, int y1) {
      int[] lit = new int[]{-6644586, -8355203, -10065820};
      int[] dark = new int[]{-11644851, -11644851, -13092296};

      for (int k = 0; k < 3; k++) {
         int ox0 = x0 - 3 + k;
         int oy0 = y0 - 3 + k;
         int ox1 = x1 + 3 - k;
         int oy1 = y1 + 3 - k;
         g.fill(ox0, oy0, ox1, oy0 + 1, lit[k]);
         g.fill(ox0, oy0, ox0 + 1, oy1, lit[k]);
         g.fill(ox0, oy1 - 1, ox1, oy1, dark[k]);
         g.fill(ox1 - 1, oy0, ox1, oy1, dark[k]);
      }
   }

   public static void crt(GuiGraphics g, int x0, int y0, int x1, int y1) {
      bezel(g, x0, y0, x1, y1);
      g.fill(x0, y0, x1, y1, -16245748);
      int band = Math.max(4, (y1 - y0) / 6);
      g.fillGradient(x0, y0, x1, y0 + band, 1610612736, 0);
      g.fillGradient(x0, y1 - band, x1, y1, 0, 1610612736);

      for (int y = y0 + 1; y < y1; y += 2) {
         g.fill(x0, y, x1, y + 1, 704643072);
      }

      g.fill(x0, y0, x1, y0 + 1, -2147483648);
      g.fill(x0, y0, x0 + 1, y1, 1879048192);
   }

   public static void lcd(GuiGraphics g, int x0, int y0, int x1, int y1) {
      bezel(g, x0, y0, x1, y1);
      g.fill(x0, y0, x1, y1, -15200250);

      for (int y = y0; y < y1; y += 2) {
         g.fill(x0, y, x1, y + 1, -14806008);
      }

      g.fill(x0, y0, x1, y0 + 1, -2147483648);
   }

   public static void lamps(GuiGraphics g, int x, int y, int... colours) {
      for (int k = 0; k < colours.length; k++) {
         int lx = x + k * 7;
         g.fill(lx, y, lx + 4, y + 4, -15065840);
         g.fill(lx + 1, y + 1, lx + 3, y + 3, colours[k]);
         g.fill(lx + 1, y + 1, lx + 2, y + 2, brighten(colours[k]));
      }
   }

   public static void hintStrip(GuiGraphics g, int x0, int y0, int x1, int y1) {
      g.fill(x0, y0, x1, y1, -804384756);
   }

   public static int brighten(int argb) {
      int r = Math.min(255, (argb >> 16 & 0xFF) + 80);
      int gr = Math.min(255, (argb >> 8 & 0xFF) + 80);
      int b = Math.min(255, (argb & 0xFF) + 80);
      return argb & 0xFF000000 | r << 16 | gr << 8 | b;
   }
}
