package dev.krutlexik.skyfront.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import dev.krutlexik.skyfront.client.model.ShahedModel;
import dev.krutlexik.skyfront.entity.ShahedEntity;
import dev.krutlexik.skyfront.seeker.SeekerFx;
import dev.krutlexik.skyfront.seeker.SeekerHooks;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

@OnlyIn(Dist.CLIENT)
public class ShahedRenderer extends GeoEntityRenderer<ShahedEntity> {
   public ShahedRenderer(Context context) {
      super(context, new ShahedModel());
      this.shadowRadius = 1.5F;
   }

   public void preRender(
      PoseStack poseStack,
      ShahedEntity animatable,
      BakedGeoModel model,
      MultiBufferSource bufferSource,
      VertexConsumer buffer,
      boolean isReRender,
      float partialTick,
      int packedLight,
      int packedOverlay,
      int colour
   ) {
      super.preRender(poseStack, animatable, model, bufferSource, buffer, isReRender, partialTick, packedLight, packedOverlay, colour);
      Vec3 motion = animatable.getDeltaMovement();
      if (!animatable.isParked() && motion.lengthSqr() > 1.0E-4) {
         double motionX = motion.x;
         double motionY = motion.y;
         double motionZ = motion.z;
         double horizontalLength = Math.sqrt(motionX * motionX + motionZ * motionZ);
         double yawRad = Math.atan2(motionX, motionZ);
         float yawDeg = (float)Math.toDegrees(yawRad) + 180.0F;
         double pitchRad = Math.atan2(-motionY, horizontalLength);
         float pitchDeg = (float)Math.toDegrees(pitchRad);
         poseStack.mulPose(Axis.YP.rotationDegrees(yawDeg));
         poseStack.mulPose(Axis.XP.rotationDegrees(-pitchDeg));
      } else {
         poseStack.mulPose(Axis.YP.rotationDegrees(animatable.getYRot() + 180.0F));
         poseStack.mulPose(Axis.XP.rotationDegrees(-animatable.getXRot()));
      }

      if (animatable.getIsFalling()) {
         poseStack.mulPose(Axis.ZP.rotationDegrees(animatable.getRenderRoll(partialTick)));
      }
   }

   public void render(ShahedEntity entity, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource bufferSource, int packedLight) {
      super.render(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);
      if (SeekerHooks.is238(entity) || SeekerFx.boosterLit(entity)) {
         JetFlames.render(
            entity, partialTick, poseStack, bufferSource, this.entityRenderDispatcher.cameraOrientation(), this.entityRenderDispatcher.camera.getPosition()
         );
      }
   }
}
