package dev.krutlexik.skyfront.drone.client.render;

import com.mojang.blaze3d.platform.Window;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexSorting;
import com.mojang.math.Axis;
import dev.krutlexik.skyfront.drone.GrenadeAttachments;
import dev.krutlexik.skyfront.drone.client.DroneControl;
import dev.krutlexik.skyfront.drone.entity.DroneEntity;
import dev.krutlexik.skyfront.drone.entity.FpvDroneEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource.BufferSource;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.joml.Matrix4f;
import org.joml.Matrix4fStack;
import org.joml.Vector3f;

@OnlyIn(Dist.CLIENT)
public final class FpvCockpitView {
   private static final float PROP_X = 0.55F;
   private static final float PROP_Z = -0.35F;
   private static final float PROP_BAND = 3.5F;
   private static final float PROP_LIFT = 0.03F;
   private static final Vector3f ROUND_TIP = new Vector3f(0.0F, -0.31F, -0.72F);
   private static final float ROUND_DIP = 0.0F;
   private static final float COCKPIT_FOV = 70.0F;

   private FpvCockpitView() {
   }

   public static void render(float partialTick) {
      Minecraft minecraft = Minecraft.getInstance();
      DroneEntity drone = DroneControl.drone();
      if (drone instanceof FpvDroneEntity
         && minecraft.level != null
         && DroneControl.onSticks()
         && !DroneControl.isPictureHeld()
         && minecraft.options.getCameraType().isFirstPerson()) {
         Window window = minecraft.getWindow();
         if (window.getWidth() > 0 && window.getHeight() > 0) {
            BufferSource buffers = minecraft.renderBuffers().bufferSource();
            int light = LevelRenderer.getLightColor(minecraft.level, BlockPos.containing(drone.getEyePosition(partialTick)));
            Matrix4f oldProjection = new Matrix4f(RenderSystem.getProjectionMatrix());
            VertexSorting oldSorting = RenderSystem.getVertexSorting();
            RenderSystem.setProjectionMatrix(
               new Matrix4f().setPerspective((float)Math.toRadians(70.0), (float)window.getWidth() / (float)window.getHeight(), 0.05F, 64.0F),
               VertexSorting.DISTANCE_TO_ORIGIN
            );
            Matrix4fStack modelView = RenderSystem.getModelViewStack();
            modelView.pushMatrix();
            modelView.identity();
            RenderSystem.applyModelViewMatrix();
            RenderSystem.clear(256, Minecraft.ON_OSX);
            PoseStack poseStack = new PoseStack();
            GlbModel glb = DroneRenderer.model(DroneRenderer.FPV_QUAD_MODEL);
            if (glb != null) {
               float spin = drone.getPropPhase(partialTick);

               for (int i = 0; i < glb.animatedGroupCount(); i++) {
                  Vector3f shaft = glb.groupPivot(i);
                  Vector3f pivot = new Vector3f(shaft.x, glb.groupCentre(i).y, shaft.z);
                  if (!(pivot.z >= 0.0F)) {
                     poseStack.pushPose();
                     double band = Math.toRadians(3.5);
                     float propY = (float)((0.029999999329447746 - Math.sin(band) * -0.3499999940395355) / Math.cos(band));
                     poseStack.translate(Math.signum(pivot.x) * 0.55F, propY, -0.35F);
                     poseStack.mulPose(Axis.XP.rotationDegrees(3.5F));
                     poseStack.scale(1.2F, 1.2F, 1.2F);
                     poseStack.translate(-pivot.x, -pivot.y, -pivot.z);
                     glb.renderGroup(i, poseStack, buffers, light, OverlayTexture.NO_OVERLAY, spin);
                     poseStack.popPose();
                  }
               }
            }

            if (drone.hasAttachment()) {
               GrenadeAttachments.Mount mount = drone.mountFor(drone.getAttachment());
               BedrockStoreModel round = mount.display() != null ? BedrockStoreModel.forProjectile(mount.display()) : null;
               if (round != null) {
                  poseStack.pushPose();
                  poseStack.translate(ROUND_TIP.x, ROUND_TIP.y, ROUND_TIP.z);
                  poseStack.mulPose(Axis.XP.rotationDegrees(-0.0F));
                  poseStack.translate(0.0F, 0.0F, round.length() * mount.scale());
                  poseStack.scale(mount.scale(), mount.scale(), mount.scale());
                  round.render(poseStack, buffers, light);
                  poseStack.popPose();
               }
            }

            buffers.endBatch();
            RenderSystem.clear(256, Minecraft.ON_OSX);
            modelView.popMatrix();
            RenderSystem.applyModelViewMatrix();
            RenderSystem.setProjectionMatrix(oldProjection, oldSorting);
         }
      }
   }
}
