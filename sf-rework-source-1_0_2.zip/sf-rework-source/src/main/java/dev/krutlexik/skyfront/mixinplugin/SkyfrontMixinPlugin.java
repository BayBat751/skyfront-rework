package dev.krutlexik.skyfront.mixinplugin;

import java.util.List;
import java.util.Set;
import net.neoforged.fml.loading.LoadingModList;
import org.objectweb.asm.tree.ClassNode;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

public class SkyfrontMixinPlugin implements IMixinConfigPlugin {
   private static final String[] SODIUM_LIKE = new String[]{"sodium", "embeddium", "rubidium", "magnesium"};

   public SkyfrontMixinPlugin() {
   }

   public boolean shouldApplyMixin(String targetClassName, String mixinClassName) {
      return mixinClassName.endsWith(".LevelRendererViewAreaMixin") ? !anyLoaded(SODIUM_LIKE) : true;
   }

   private static boolean anyLoaded(String... modIds) {
      LoadingModList mods = LoadingModList.get();
      if (mods == null) {
         return false;
      } else {
         for (String id : modIds) {
            if (mods.getModFileById(id) != null) {
               return true;
            }
         }

         return false;
      }
   }

   public void onLoad(String mixinPackage) {
   }

   public String getRefMapperConfig() {
      return null;
   }

   public void acceptTargets(Set<String> myTargets, Set<String> otherTargets) {
   }

   public List<String> getMixins() {
      return null;
   }

   public void preApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {
   }

   public void postApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {
   }
}
