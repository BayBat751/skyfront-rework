# Skyfront (sfw) — исходный код + SBW lock-on patch

Мод: Skyfront 1.4.0 (modId `sfw`), NeoForge 1.21.1, Java 21. Лицензия GPL-3.0-or-later.

## Важно
* Java-код **получен декомпиляцией** jar (Vineflower 1.10.1): комментарии, оригинальные имена
  локальных переменных и форматирование утрачены. Код читается, но **не гарантированно компилируется
  без правок** — декомпилятор без библиотек Minecraft иногда ошибается в типах/дженериках.
* Ресурсы (`assets`, `data`, модели, звуки, mixin-конфиги) — оригинальные, без потерь.
* `build.gradle` — шаблон, не проверялся.

## Что добавлено (патч «ракеты SBW захватывают дронов»)
* `src/main/java/dev/krutlexik/skyfront/compat/sbw/SbwSeekPatch.java` — кто считается захватываемым дроном
* `src/main/java/dev/krutlexik/skyfront/compat/sbw/mixin/SeekToolBuilderMixin.java` — mixin в SBW `SeekTool$Builder`
* `src/main/resources/sfw_seek.mixins.json` — отдельный mixin-конфиг (`required: false`)
* `src/main/resources/data/superbwarfare/tags/entity_type/destroyable_projectile.json` —
  `sfw:shahed`, `sfw:shahed_seeker`, `sfw:shahed_238`
* `META-INF/neoforge.mods.toml` — подключён второй mixin-конфиг

## Сборка
1. Положите jar Superb Warfare в `libs/`.
2. Откройте проект в IntelliJ IDEA (Gradle) или выполните `gradle build`.
3. Готовый jar: `build/libs/sf-rework-1.4.0.jar`.
