Положите сюда superbwarfare-*.jar (для компиляции, compileOnly).
